﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularAssessmentField : BaseAngularField
    {
        private readonly string _distributionId;
        private readonly string _exposureId;
        private readonly string _riskLevelId;
        private readonly string _probOccurrenceId;
        private readonly string _costCvId;
        private readonly string _emvId;
        private readonly string _mcvId;
        private readonly string _weightedScoreId;
        private readonly string _icvId;
        private readonly string _impactCategoryField;
        private readonly string _scoringSheetId;

        public AngularAssessmentField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            switch (id)
            {
                case "field_51":
                    _distributionId = "field_51_52";
                    _exposureId = "field_51_53";
                    _riskLevelId = "field_51_60";
                    _probOccurrenceId = "field_51_62";
                    _costCvId = "field_51_106";
                    _emvId = "field_51_129";
                    _mcvId = "field_51_239";
                    _weightedScoreId = "field_51_688";
                    _icvId = "dynamicfield_51_695";
                    _impactCategoryField = "field_51_695_a_2_icv_";
                    _scoringSheetId = "field_51_699_scoring_sheet";
                    break;
                case "field_54":
                    _distributionId = "field_54_52";
                    _exposureId = "field_54_53";
                    _riskLevelId = "field_54_60";
                    _probOccurrenceId = "field_54_62";
                    _costCvId = "field_54_106";
                    _emvId = "field_54_129";
                    _mcvId = "field_54_239";
                    _weightedScoreId = "field_54_688";
                    _icvId = "dynamicfield_54_695";
                    _impactCategoryField = "field_54_695_a_4_icv_";
                    _scoringSheetId = "field_54_699_scoring_sheet";
                    break;
                case "field_643":
                    _distributionId = "field_643_52";
                    _exposureId = "field_643_53";
                    _riskLevelId = "field_643_60";
                    _probOccurrenceId = "field_643_62";
                    _costCvId = "field_643_106";
                    _emvId = "field_643_129";
                    _mcvId = "field_643_239";
                    _weightedScoreId = "field_643_688";
                    _icvId = "dynamicfield_643_695";
                    _impactCategoryField = "field_643_695_a_1_icv_";
                    break;
                case "field_81":
                    _distributionId = "field_81_52";
                    _exposureId = "field_81_53";
                    _riskLevelId = "field_81_60";
                    _probOccurrenceId = "field_81_62";
                    _costCvId = "field_81_106";
                    _emvId = "field_81_129";
                    _mcvId = "field_81_239";
                    _weightedScoreId = "field_81_688";
                    _icvId = "dynamicfield_81_695";
                    _impactCategoryField = "field_81_695_a_2_icv_";
                    break;
                case "field_83":
                    _distributionId = "field_83_51_52";
                    _exposureId = "field_83_51_53";
                    _riskLevelId = "field_83_51_60";
                    _probOccurrenceId = "field_83_51_62";
                    _costCvId = "field_83_51_106";
                    _emvId = "field_83_51_129";
                    _mcvId = "field_83_51_239";
                    _weightedScoreId = "field_83_51_688";
                    _icvId = "dynamicfield_83_51_695";
                    _impactCategoryField = "field_83_51_695_a_2_icv_";
                    break;
                default:
                    throw new System.Exception();
            }
        }

        private AngularSingleLineTextField _riskLevel;
        public AngularSingleLineTextField RiskLevel
        {
            get
            {
                return _riskLevel ?? (_riskLevel = new AngularSingleLineTextField(Driver, Waiter, _riskLevelId));
            }
        }

        private AngularDropdownListField _distribution;
        public AngularDropdownListField Distribution
        {
            get
            {
                return _distribution ?? (_distribution = new AngularDropdownListField(Driver, Waiter, _distributionId));
            }
        }

        private AngularDropdownListField _exposure;
        public AngularDropdownListField Exposure
        {
            get
            {
                return _exposure ?? (_exposure = new AngularDropdownListField(Driver, Waiter, _exposureId));
            }
        }

        private AngularWeightedScoreField _weightedScore;
        public AngularWeightedScoreField WeightedScore
        {
            get
            {
                return _weightedScore ?? (_weightedScore = new AngularWeightedScoreField(Driver, Waiter, _weightedScoreId));
            }
        }

        private AngularImpactCategoryValueField _impactCategoryValues;
        public AngularImpactCategoryValueField ImpactCategoryValues
        {
            get
            {
                return _impactCategoryValues ?? (_impactCategoryValues = new AngularImpactCategoryValueField(Driver, Waiter, _icvId, _impactCategoryField));
            }
        }

        private AngularImpactProbabilityOccurrenceField _probabilityOccurrence;
        public AngularImpactProbabilityOccurrenceField ProbabilityOccurrence
        {
            get
            {
                return _probabilityOccurrence ?? (_probabilityOccurrence = new AngularImpactProbabilityOccurrenceField(Driver, Waiter, _probOccurrenceId));
            }
        }

        private AngularSingleLineTextField _costCv;
        public AngularSingleLineTextField CostCv
        {
            get
            {
                return _costCv ?? (_costCv = new AngularSingleLineTextField(Driver, Waiter, _costCvId));
            }
        }

        private AngularSingleLineTextField _expectedMonetaryValue;
        public AngularSingleLineTextField ExpectedMonetaryValue
        {
            get
            {
                return _expectedMonetaryValue ?? (_expectedMonetaryValue = new AngularSingleLineTextField(Driver, Waiter, _emvId));
            }
        }

        private AngularSingleLineTextField _meanCostValue;
        public AngularSingleLineTextField MeanCostValue
        {
            get
            {
                return _meanCostValue ?? (_meanCostValue = new AngularSingleLineTextField(Driver, Waiter, _mcvId));
            }
        }

        private AngularButton _scoringSheetButton;
        public AngularButton ScoringSheetButton
        {
            get
            {
                return _scoringSheetButton ?? (_scoringSheetButton = new AngularButton(Driver, Waiter, "#" + _scoringSheetId));
            }
        }
    }
}
