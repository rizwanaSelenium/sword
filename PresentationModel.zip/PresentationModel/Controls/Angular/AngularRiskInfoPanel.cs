﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public abstract class AngularRiskInfoPanel
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _element;

        protected AngularRiskInfoPanel(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
            _element = _driver.FindElement(By.Id("extra-options-container"));
            
        }

        private IWebElement _header;
        public IWebElement Header
        {
            get
            {
                if (_header == null)
                {
                    _header = _element.FindElement(By.CssSelector("header > h3"));
                }
                return _header;
            }
        }

        public string Title
        {
            get
            {
                return Header.Text;
            }
        }

          public bool IsVisible()
           {
            try
            {
                return _element.Displayed;
            }
            catch (StaleElementReferenceException)
            {
                return false;
            }
        }

        public bool HelpPageOpened(string name)
        {
            return _driver.HasHelpWindowWithName(name);
        }


        public abstract bool HelpPageOpened();

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get
            {
                if (_saveButton == null) { _saveButton = new WebDriverButton(_driver, _waiter, "SaveRecord"); }
                return _saveButton;
            }
        }
        private IWebElement _editSaveButton;
        public IWebElement EditSaveButton

        {
            get
            {
                if (_editSaveButton == null) { _editSaveButton = _element.FindElement(By.CssSelector("div button[id ^='SaveRecord_']")); }
                return _editSaveButton;
            }
        }

        public void WaitUntilSaveIsComplete()
        {
            _waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(By.Id("SaveRecord")));
        }
    }
}
