﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularImpactCategoryValueField : BaseAngularField
    {
        private readonly string _impactCategoryField;

        public AngularImpactCategoryValueField(IWebDriver driver, WebDriverWait waiter, string id, string impactCategoryField) :
            base(driver, waiter, id, false, false)
        {
            _impactCategoryField = impactCategoryField;
        }

        public void SetImpactValue(string impactName, string impactValue, string minExpMax) //pick one min, exp or max
        {
            var timeoutErrors = 0;
            var interceptionErrors = 0;

            for (var i = 0; i < 4; i++)
            {
                try
                {
                    var inputId = "control_" + _impactCategoryField + impactName + "_" + minExpMax;
                    Element.FindElement(By.Id(inputId)).Clear();
                    Element.FindElement(By.Id(inputId)).SendKeys(impactValue);
                    var impactWaiter = new WebDriverWait(Driver, new TimeSpan(0, 0, 30));
                    impactWaiter.Until(d => Element.FindElement(By.Id(inputId)).GetAttribute("value").Equals(impactValue));
                    break;
                }
                catch (Exception ex)
                {
                    if (ex is ElementClickInterceptedException)
                    {
                        if (interceptionErrors == 1)
                        {
                            throw new ElementClickInterceptedException("** Error ** Failed twice in SetImpactValue. Element intercepted. " + ex);
                        }
                        interceptionErrors++;
                    }
                    if (ex is WebDriverTimeoutException)
                    {
                        if (timeoutErrors == 3)
                        {
                            throw new WebDriverTimeoutException("** Error ** Failed twice in SetImpactValue. Timeout waiting for value to be set. " + ex);
                        }
                        timeoutErrors++;
                    }
                    if (!(ex is WebDriverTimeoutException) && !(ex is ElementClickInterceptedException))
                    {
                        throw new Exception("Something else went wrong when trying to set impact value. " + ex);
                    }
                    WaitUntilUiSpinnerIsNotDisplayed();
                }
            }
        }

        public void VerifyImpactValue(string impactName, string expectedImpactValue, string minExpMax) //pick one min, exp or max
        {
            var inputId = "control_" + _impactCategoryField + impactName + "_" + minExpMax;
            var impactValue = Element.FindElement(By.Id(inputId)).GetAttribute("value").Trim();

            Assert.AreEqual(expectedImpactValue, impactValue, "Incorrect impact value. {0} should have been {1}", impactValue, expectedImpactValue);
        }

        public void AssertImpactValueFieldState(string impactName, string minExpMax, string state)
        {
            var impactField = _impactCategoryField + impactName + "_" + minExpMax;
            state = state.ToLower();
            switch (state)
            {
                case "hidden":
                    int count = Element.FindElements(By.CssSelector("#" + impactField)).Count;
                    Assert.AreEqual(0, count, "The expected state of the field " + minExpMax + " is " + state + " but it was viweable");
                    break;

                case "enabled":
                    Assert.IsTrue(Element.FindElement(By.CssSelector("#" + impactField)).FindElement(By.CssSelector("input.form-control")).Enabled, "The expected state of the field " + minExpMax + " is " + state + " but it was disabled");
                    break;

                case "disabled":
                    Assert.IsFalse(Element.FindElement(By.CssSelector("#" + impactField)).FindElement(By.CssSelector("input.form-control")).Enabled, "The expected state of the field " + minExpMax + " is " + state + " but it was enabled");
                    string atribValue = Element.FindElement(By.CssSelector("#" + impactField)).FindElement(By.CssSelector("input.form-control")).GetAttribute("disabled");
                    Assert.AreEqual("disabled", state, "The expected state of the field " + minExpMax + " is " + state + " but it was " + atribValue + "");
                    break;
            }
        }

        public void AssertImpactQuantitativeFieldEnable(string impactName, string state)
        {
            string impactField = _impactCategoryField + impactName;
            state = state.ToLower();
            Assert.IsTrue(Element.FindElement(By.CssSelector("#" + impactField)).FindElement(By.CssSelector("button")).Enabled, "The expected state of buttons in " + impactName + " is " + state + " but it was disabled");
        }

        public void SetQuantitativeImpact(string impactName, string impactValue)
        {
            string impactField = _impactCategoryField + impactName;
            var myImpact = Element.FindElement(By.Id(impactField)).FindElement(By.CssSelector("button[title*='"+impactValue+"']"));
            myImpact.Click();
            Waiter.Until(d => myImpact.GetAttribute("style").Contains("border: 3px solid black"));
        }
        
        public void VerifyQuantitativeImpact(string impactName, string expectedImpactValue, string scoringType)
        {
            string impactField = _impactCategoryField + impactName;
            var impactValue = "";

            switch (scoringType)
            {
                case "One Click":
                case "Hybrid":
                    var impactFieldElement = Element.FindElement(By.Id(impactField));
                    var impactFieldButton = impactFieldElement.FindElements(By.TagName("Button"));
                    impactValue = impactFieldButton.First(s => s.GetAttribute("style").Contains("border: 3px solid black")).Text;
                    break;
                case "Classic":
                    impactValue = new SelectElement(Element.FindElement(By.Id(impactField + "_qualitativeDDL"))).SelectedOption.Text;
                    break;
                default:
                    throw new ArgumentException("Scoring type is unrecognizable");
            }

            Assert.AreEqual(expectedImpactValue, impactValue.Trim(), "Incorrect impact level selected. '{0}' was selected but expected '{1}'", impactValue, expectedImpactValue);
        }
    }
}
