﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularTab : WebDriverArmControl
    {

        public AngularTab(IWebDriver driver, WebDriverWait waiter, string id) : base(driver, waiter, "button#" + id)
        {
            try
            {
                waiter.Until(d => driver.FindElement(By.CssSelector(CssSelectorString)).Displayed);
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException("Timed out while waiting for the tab " + id + " to be displayed.");
            }
        }

        public override void Click()
        {
            try
            {
                Waiter.Until(x => Driver.FindElement(By.CssSelector(CssSelectorString)).Enabled);
                base.Click();
            }
            catch (TimeoutException tex)
            {
                throw new WebDriverTimeoutException("Expected tab with selector: " + CssSelectorString + " to become enabled but it never did, waiter timed out. (AngularTab - Click) " + tex);
            }
        }
    }
}
