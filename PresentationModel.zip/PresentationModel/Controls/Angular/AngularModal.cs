﻿using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private WebDriverTextField _modalHeaderText;
        private WebDriverTextField _modalText;
        private WebDriverTextField _modalBodyText;
        private WebDriverTextAreaControl _modalInputData;
        private WebDriverButton _actionButton;
        private WebDriverButton _altActionButton;
        private WebDriverButton _closeButton;
        private WebDriverButton _modalYesButton;
        private WebDriverButton _modalNoButton;
        private WebDriverButton _modalOkButton;
        private WebDriverButton _modalCancelButton;
        public IWebElement Element { get; }

        public WebDriverTextField ModalHeaderText
        {
            get {
                return _modalHeaderText ?? (_modalHeaderText = new WebDriverTextField(_driver, _waiter, "#modalHeaderText", true));
            }
        }
        public WebDriverTextField ModalText
        {
            get {
                return _modalText ?? (_modalText = new WebDriverTextField(_driver, _waiter, "#modalText", true));
            }
        }
        public WebDriverTextField ModalBodyText
        {
            get {
                return _modalBodyText ?? (_modalBodyText = new WebDriverTextField(_driver, _waiter, "#modalBodyText", true));
            }
        }
        public WebDriverTextAreaControl ModalInputData
        {
            get {
                return _modalInputData ?? (_modalInputData = new WebDriverTextAreaControl(_driver, _waiter, "modalInputData", true));
            }
        }
        public WebDriverButton ActionButton
        {
            get {
                return _actionButton ?? (_actionButton = new WebDriverButton(_driver, _waiter, "modalActionButton"));
            }
        }
        public WebDriverButton AltActionButton
        {
            get {
                return _altActionButton ?? (_altActionButton = new WebDriverButton(_driver, _waiter, "modalAltActionButton"));
            }
        }
        public WebDriverButton CloseButton
        {
            get {
                return _closeButton ?? (_closeButton = new WebDriverButton(_driver, _waiter, "modalCloseButton", true));
            }
        }
        public WebDriverButton YesButton
        {
            get {
                return _modalYesButton ?? (_modalYesButton = new WebDriverButton(_driver, _waiter, "modalYesButton"));
            }
        }
        public WebDriverButton NoButton
        {
            get {
                return _modalNoButton ?? (_modalNoButton = new WebDriverButton(_driver, _waiter, "modalNoButton"));
            }
        }
        public WebDriverButton CommentsOkButton
        {
            get
            {
                return _modalOkButton ?? (_modalOkButton = new WebDriverButton(_driver, _waiter, "changeCommentsOkBtn", false));
            }
        }

        public WebDriverButton CommentsCancelButton
        {
            get
            {
                return _modalCancelButton ?? (_modalCancelButton = new WebDriverButton(_driver, _waiter, "changeCommentsCancelBtn", false));

            }
        }        

        public AngularModal(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;         

            for (var i = 0; i < 20; i++)
            {
                if (_driver.FindElements(By.Id("modalMessageBox")).Count == 1)
                {
                    Element = _driver.FindElement(By.Id("modalMessageBox"));
                    break;
                }
                if (_driver.FindElements(By.CssSelector("div.modal-content")).Count == 1)
                {
                    Element = _driver.FindElement(By.CssSelector("div.modal-content"));
                    break;
                }
                Thread.Sleep(500);
                if (i == 19)
                {
                    Assert.Fail("Failed to locate modal message box.");
                }
            }
        }

        public void Action()
        {
            ActionButton.Click();
        }

        public void AltAction()
        {
            AltActionButton.Click();
        }

        public void Close()
        {
            CloseButton.Click();
        }

        public void Yes()
        {
            YesButton.WaitForElementToExist();
            YesButton.Click();
        }

        public void No()
        {
            NoButton.Click();
        }

        public bool IsMessageModalPopUpDisplayed()
        {
            try
            {
                bool displayed = _driver.FindElement(By.CssSelector("#modalMessageBox")).Displayed;
                return displayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }
    }
}
