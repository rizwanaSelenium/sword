﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularSurveyQuestionCreator : BaseAngularField
    {
        private IWebElement _addNewButton;
        private IWebElement _input;

        public AngularSurveyQuestionCreator(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject = true, bool hasLabel = true) :
            base(driver, waiter, id, hasObject, hasLabel)
        {

        }

        private IWebElement AddNewButton
        {
            get
            {
                _addNewButton = Element.FindElement(By.CssSelector("input"));
                return _addNewButton;
            }
        }

        public void AddQuestion(string value)
        {
            AddNewButton.Click();
            var inputs = Element.FindElements(By.CssSelector("textarea"));
            _input = inputs[inputs.Count - 1];
            _input.SendKeys(value);
        }

        public void AssertQuestionEquals(string value)
        {
            AssertQuestionEquals(value, 0);
        }

        public void AssertQuestionEquals(string value, int pos)
        {
            var inputs = Element.FindElements(By.CssSelector("textarea"));
            _input = inputs[pos];
            Assert.AreEqual(_input.Text, value);
        }
    }
}
