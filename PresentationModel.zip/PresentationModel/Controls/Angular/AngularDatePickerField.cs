﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularDatePickerField : AngularDatePicker
    {
        public AngularDatePickerField(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter)
        {
            var element = driver.FindElement(By.Id(id + "_object"));

            SetSelectorString("arm-date-picker#" + id + "_component");
            
            LabelElement = element.FindElement(By.TagName("label"));
        }
    }
}

