﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularIcon : WebDriverArmControl
    {
        public AngularIcon(IWebDriver driver, WebDriverWait waiter, string selector) : base(driver, waiter, selector)
        {
            CssSelectorString = selector;
        }

        public AngularIcon(IWebDriver driver, WebDriverWait waiter, string tagName, string id) : base(driver, waiter, tagName + " #" + id)
        {
            ElementId = id;
            TagNameString = Driver.FindElement(By.TagName(tagName));
        }

        public void AssertDisplayed()
        {
            Assert.True(Element.Displayed);
        }

        public void AssertTabIsDisabled()
        {
            Assert.IsTrue(Element.GetAttribute("disabled").Equals("true"));
        }

        public string GetTooltipText()
        {
            return Element.GetAttribute("title").Trim();
        }
    }
}

