﻿using System;
using System.Linq;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public abstract class BaseAngularControl
    {
        protected WebDriverWait Waiter;
        protected IWebDriver Driver;
        protected IWebElement Element;
        protected readonly string Id;
        protected readonly string ObjectId;

        protected BaseAngularControl(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject= true)
        {
            Driver = driver;
            Waiter = waiter;
            Id = id;
            if (hasObject)
            {
                ObjectId = Id + "_object";
                Waiter.Until(d => Driver.FindElements(By.Id(ObjectId)).Count > 0);
                Element = Driver.FindElement(By.Id(ObjectId));
            }

            if (!hasObject && Id != "")
            {
                Element = Driver.FindElement(By.Id(Id));
            }
        }

        public bool IsVisible()
        {
            return Element != null && Element.Displayed;
        }

        public void WaitUntilVisible()
        {
            if (Element == null)
            {
                Element = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id(ObjectId)));
            }
        }

        public void WaitUntilUiSpinnerIsNotDisplayed()
        {
            var errorCount = 0;
            int spinnerWait;
            const int spinnerMaxWait = 400;
            for (spinnerWait = 0 ; spinnerWait < spinnerMaxWait ; spinnerWait++)
            {
                try
                {
                    Thread.Sleep(1000);
                    var waiters = Driver.FindElements(By.CssSelector(".block-ui-spinner,.block-ui-message,.block-ui-wrapper,.blocked"));
                    if (waiters.Count == 0) break;
                    if (waiters.Count(e => e.Displayed) != 0) continue;
                    break;
                }
                catch (Exception ex)
                {
                    errorCount = errorCount + 1;
                    if (errorCount >= 30)
                    {
                        throw new Exception("Errored " + errorCount + " times checking if block spinner was displayed test aborted. " + ex);
                    }
                }
            }
            if (errorCount != 0)
            {
                Console.WriteLine("** WebDriverArmPage.cs ** ** Error dectecing if the Block spinner was displayed or not. Times errored: " + errorCount);
            }
            if (spinnerWait == spinnerMaxWait)
            {
                throw new Exception("Block spinner was still displayed checking from WebDriverArmPage.cs");
            }
        }
    }
}
