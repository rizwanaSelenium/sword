﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularAssessmentScoringSheetModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private AngularButton _applyButton;
        private AngularButton _closeButton;

       public AngularAssessmentScoringSheetModal(IWebDriver driver, WebDriverWait waiter)
       {
            _driver = driver;
            _waiter = waiter;
            _element = _driver.FindElement(By.CssSelector("div.modal-dialog"));
       }

        public AngularButton ApplyButton => _applyButton ?? (_applyButton = new AngularButton(_driver, _waiter, "button[ng-click='vm.ok();']"));

        public AngularButton CloseButton => _closeButton ?? (_closeButton = new AngularButton(_driver, _waiter, "button[ng-click='vm.close();']"));

       public void SelectProbability(string categoryValue)
       {
            var probability = _element.FindElement(By.CssSelector("div[ng-hide='vm.impactOnly']"));
            probability.FindElement(By.CssSelector($"label[title='{categoryValue.Trim()}']")).Click();
       }

       public void SelectCategory(string categoryName, string categoryValue)
       {
           var allCategories = _element.FindElements(By.CssSelector("div[ng-model='category']")).ToList();
           var selectedCategory = allCategories.First(c => c.FindElements(By.XPath($".//label[text()='{categoryName.Trim()}']")).Count > 0);
           selectedCategory.FindElement(By.CssSelector($"label[title='{categoryValue.Trim()}']")).Click();
       }

       public void VerifyProbability(string categoryValue)
       {
           var probability = _element.FindElement(By.CssSelector("div[ng-hide='vm.impactOnly']"));
           Assert.AreEqual(categoryValue.Trim(), probability.FindElement(By.CssSelector("div[style*='border: 3px solid black'] > label:first-child")).Text.Trim());
        }

        public void VerifyCategory(string categoryName, string categoryValue)
       {
           var allCategories = _element.FindElements(By.CssSelector("div[ng-model='category']")).ToList();
           var selectedCategory = allCategories.First(c => c.FindElements(By.XPath($".//label[text()='{categoryName.Trim()}']")).Count > 0);
           Assert.AreEqual(categoryValue.Trim(), selectedCategory.FindElement(By.CssSelector("div[style*='border: 3px solid black'] > label:first-child")).Text.Trim());
       }

       public void VerifyCategoryDeleteIcon(string categoryName)
       {
           var allCategories = _element.FindElements(By.CssSelector("div[ng-model='category']")).ToList();
           var selectedCategory = allCategories.First(c => c.FindElements(By.XPath($".//label[text()='{categoryName.Trim()}']")).Count > 0);
           Assert.IsTrue(selectedCategory.FindElement(By.CssSelector(".fa-trash")).Displayed);
       }

        public void WaitUntilScoringSheetModalClosed()
        {
            for (var i = 0; i < 2; i++)
            {
                try
                {
                    _waiter.Until(d => _driver.FindElements(By.CssSelector("div.modal-dialog")).Count(e => e.Displayed) == 0);
                    break;
                }
                catch (Exception ex)
                {
                    if (ex is WebDriverTimeoutException)
                    {
                        throw new WebDriverTimeoutException("Timed out waiting for the scoring sheet modal to close. " + ex);
                    }
                    if (ex is StaleElementReferenceException && i == 1)
                    {
                        throw new StaleElementReferenceException("Stale element trying to check if scoring sheet modal has closed. " + ex);
                    }
                    if (!(ex is StaleElementReferenceException))
                    {
                        throw new Exception("Another error has occured. " + ex);
                    }
                }
            }
        }
    }
}
