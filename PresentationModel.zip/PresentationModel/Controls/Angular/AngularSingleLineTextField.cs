﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularSingleLineTextField : BaseAngularField
    {
        private readonly IWebElement _input;

        public AngularSingleLineTextField(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject = true, bool hasLabel = true) :
            base(driver, waiter, id, hasObject, hasLabel)
        {
            _input = Element.FindElement(By.CssSelector("input"));
        }

        public void SetValue(string value)
        {
            _input.Clear();
            _input.SendKeys(value);
        }

        public void AssertEquals(string text)
        {
            Assert.AreEqual(text, _input.GetAttribute("value"));
        }

        public void AssertNotEquals(string value)
        {
            Assert.AreNotEqual(value, _input.GetAttribute("value"));
        }

        public void AssertTextEquals(string text)
        {
            
           Assert.AreEqual(text, _input.Text.Trim());
        }
        public void AssertColorEquals(string color)
        {
            string background = "";
            switch (color.ToLower())
            {
                case "yellow":
                    background = "rgb(255, 255, 0)";
                    break;
                case "red":
                    background = "rgb(255, 0, 0)";
                    break;
            }

            Assert.IsTrue(_input.GetAttribute("style").ToLower().Contains("background-color: " + background));
        }

        public void AppendValue(string text)
        {
            _input.SendKeys(Keys.End);
            _input.SendKeys(text);
        }

        public void AssertLabelEquals(string text)
        {
           Assert.AreEqual(text, Label.Text);
        }

        public string GetValue()
        {
            var getelementText = _input.GetAttribute("value");
            return getelementText;

        }
    }
}
