﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public abstract class BaseAngularField : BaseAngularControl
    {
        protected IWebElement Label;

        protected BaseAngularField(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject=true, bool hasLabel=true) : base(driver, waiter, id, hasObject)
        {
            if (hasLabel)
            {
                Label = Element.FindElement(By.CssSelector("label"));
            }
            
        }
    }
}
