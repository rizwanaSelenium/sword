﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularWeightedScoreField : BaseAngularField
    {


        public AngularWeightedScoreField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            throw new NotImplementedException();
        }
    }
}
