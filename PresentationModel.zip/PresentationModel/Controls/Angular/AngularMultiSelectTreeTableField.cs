﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiSelectTreeTableField : BaseAngularField
    {
        public AngularMultiSelectTreeTableField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {

        }

        public void DisplayTree()
        {
            var nodes = Driver.FindElements(By.CssSelector($"#{ObjectId} arm-table-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0);
            if (node == null)
            {
                Element.FindElement(By.CssSelector(".fa-plus-square")).Click();
                Thread.Sleep(1000);
            }
        }

        public void HideTree()
        {
            var nodes = Driver.FindElements(By.CssSelector($"#{ObjectId} arm-table-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0);
            if (node != null)
            {
                Element.FindElement(By.CssSelector(".fa-plus-square")).Click();
                Thread.Sleep(1000);
            }
        }

        public void SelectItem(string nodePath)
        {
            DisplayTree();
            var tree = new AngularTree(Driver, Waiter, "arm-table-tree-picker", ObjectId, "tree-list");
            var node = tree.Node(nodePath);
            node.Click();
        }

        public void DisabledItem(string nodePath)
        {
            DisplayTree();
            var tree = new AngularTree(Driver, Waiter, "arm-table-tree-picker", ObjectId, "tree-list");
            var node = tree.Node(nodePath);
            node.IsDisabled();
        }

        public void NotVisibleItem(string nodePath)
        {
            DisplayTree();
            var tree = new AngularTree(Driver, Waiter, "arm-table-tree-picker", ObjectId, "tree-list");
            tree.AssertNodeDoesNotExist(nodePath);
        }

        public void DisplayedItem(string nodePath)
        {
            HideTree();
            var nodes = Driver.FindElements(By.CssSelector($"#{Id} arm-table-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.XPath($"div//ul//li//span[text()='{nodePath}']")).Count > 0);
            Assert.IsNotNull(node);
        }

        public bool IsItemSelected(string nodePath)
        {
            HideTree();
            var nodes = Driver.FindElements(By.CssSelector($"#{ObjectId} arm-table-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.XPath($"div//ul//li//span[text()='{nodePath.Replace("/", " > ")}']")).Count > 0);
            return node != null;
        }
    }
}
