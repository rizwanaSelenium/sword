﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularEscalationField : BaseAngularField
    {
        public AngularEscalationField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            
        }

        public void SetValue(string value)
        {
            DisplayTree();
            var escaltionOption = Driver
                .FindElements(By.CssSelector("arm-field-risk-escalation  tree-node-wrapper tree-node-content span")).Select(x => x)
                .First(x => x.Text == value);
            escaltionOption.Click();
        }

        public bool VerifySelectedOptionBackgroundColor(string nodeName, string color)
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            var selectedItem = Driver
                .FindElements(By.CssSelector("arm-field-risk-escalation arm-tree-picker ul li")).Select(x => x)
                .First(x => x.Text == nodeName);
            string actualBackgroudColor = selectedItem.GetCssValue("background-color");
            string expectedBackgroundColor = ColorCode(color);
            return expectedBackgroundColor == actualBackgroudColor;

        }

        private string ColorCode(string color)
        {
            string colorCode = null;
            switch (color)
            {
                case "Yellow":
                    colorCode = "rgba(255, 255, 102, 1)";
                    break;
                case "Green":
                    colorCode = "rgba(153, 255, 153, 1)";
                    break;
                default:
                    Assert.Fail("No such color code exists");
                    break;
            }

            return colorCode;
        }
        public void AssertEquals(string text)
        {
            throw new NotImplementedException();
        }

        public void AppendValue(string text)
        {
            throw new NotImplementedException();
        }

        public void VerifyFieldState(string fieldState)
        {
            if (fieldState == "Enabled")
            {
                Assert.IsTrue(Element.FindElement(By.CssSelector(".arm-tree-picker.form-control")).Enabled);
            }
            else if (fieldState == "Disabled")
            {
                Assert.AreEqual("true", Element.FindElement(By.CssSelector(".arm-tree-picker.form-control")).GetAttribute("disabled"));
            }
            else
            {
                Assert.Fail("No such state available");
            }
           
        }

        private void DisplayTree()
        {
            var nodes = Driver.FindElements(By.CssSelector($"#{ObjectId} arm-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0);
            if (node == null)
            {
                try
                {
                    Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
                    Waiter.Until(d => d.FindElements(By.CssSelector($"#{ObjectId} arm-tree-picker")).FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0));
                }
                catch (WebDriverTimeoutException tex)
                {
                    throw new WebDriverTimeoutException("Timed out trying to display a tree. " + tex);
                }
            }
        }
    }
}
