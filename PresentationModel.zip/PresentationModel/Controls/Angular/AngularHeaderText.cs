﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularHeaderText : WebDriverArmControl
    {

        public AngularHeaderText(IWebDriver driver, WebDriverWait waiter, string selector) : base(driver, waiter, selector)
        {
            CssSelectorString = selector;
        }

        public string GetText()
        {
            WaitForElementToAppear();
            var getelementText = Element.Text;
            return getelementText;
        }

        public void AssertNotNull()
        {
            Assert.IsNotNull(GetText());
        }

     }
}
