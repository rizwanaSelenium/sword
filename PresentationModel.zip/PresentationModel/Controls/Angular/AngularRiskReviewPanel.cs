﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularRiskReviewPanel : AngularRiskInfoPanel
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _element;

        public AngularRiskReviewPanel(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {
            _driver = driver;
            _waiter = waiter;
            _element = _driver.FindElement(By.Id("extra-options-container"));
        }

        private IList<IWebElement> _reviews;
        public IList<IWebElement> Reviews
        {
            get
            {
                if (_reviews == null)
                {
                    _reviews = _element.FindElements(By.CssSelector(".content > ul > li")).ToList();
                }

                return _reviews;
            }
        }


        private WebDriverButton _closeButton;

        public WebDriverButton CloseButton
        {
            get
            {
                if (_closeButton == null)
                {
                    _closeButton = new WebDriverButton(_driver, _waiter, "CloseReview");
                }

                return _closeButton;
            }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get
            {
                if (_newButton == null)
                {
                    _newButton = new WebDriverButton(_driver, _waiter, "NewReview");
                }

                return _newButton;
            }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get
            {
                if (_helpButton == null)
                {
                    _helpButton = new WebDriverButton(_driver, _waiter, "HelpReview");
                }

                return _helpButton;
            }
        }


        private WebDriverTextAreaControl _newReviewComment;
        public WebDriverTextAreaControl NewReviewComment
        {
            get
            {
                if (_newReviewComment == null)
                {
                    _newReviewComment = new WebDriverTextAreaControl(_driver, _waiter, "#reviewNote", true);
                }

                return _newReviewComment;
            }
        }

        private IWebElement _updateReviewComment;
        public IWebElement UpdateReviewComment
        {
            get
            {
                if (_updateReviewComment == null)
                {
                    _updateReviewComment = _element.FindElement(By.CssSelector("div textarea[id ^='reviewNote_']"));
                }

                return _updateReviewComment;
            }
        }

        public bool ButtonIsVisible(string button)
        {
            string buttonId = "";
            switch (button)
            {
                case "Close":
                    buttonId = "CloseReview";
                    break;
                case "Help":
                    buttonId = "HelpReview";
                    break;
                case "New":
                    buttonId = "NewReview";
                    break;
                default:
                    Assert.Fail("button not recognised");
                    break;
            }

            return _element.FindElements(By.Id(buttonId)).Count > 0;
        }


        public override bool HelpPageOpened()
        {
            return HelpPageOpened("Risk_Review.htm");
        }

        public IEnumerable<AngularRiskReview> GetReviews()
        {
            foreach (var element in _element.FindElements(By.ClassName("risk-review")))
            {
                yield return new AngularRiskReview(_driver, _waiter, element);
            }
        }

        public AngularRiskReview GetFirstReview()
        {
            var elements = _element.FindElements(By.ClassName("risk-review"));
            if (elements.Count == 0)
            {
                return null;
            }

            return new AngularRiskReview(_driver, _waiter, elements[0]);
        }

        public AngularRiskReview GetReviewByComment(string comment)
        {
            foreach (var element in _element.FindElements(By.ClassName("risk-review")))
            {
                var review = new AngularRiskReview(_driver, _waiter, element);
                if (review.Comment == comment)
                {
                    return review;
                }
            }

            Assert.Fail($"Review with comment '{comment}' not found");
            return null;

        }

        public void SelectReviewId(string reviewName)
        {
            var reviewTable = _element.FindElements(By.CssSelector(".content > ul > li"));
            foreach (var row in reviewTable)
            {
                var review = row.FindElement(By.CssSelector("p[class='secondary ellipsisWrapping review-note ng-star-inserted']")).Text;
                if (review == reviewName)
                {
                    try
                    {
                        row.Click();
                        _waiter.Until(d => row.FindElements(By.CssSelector("p[class='secondary ellipsisWrapping review-note ng-star-inserted']")).Count == 0);
                        break;
                    }
                    catch (WebDriverTimeoutException ex)
                    {
                        throw new WebDriverTimeoutException("Timed out waiting for the review to be selected. " + ex);
                    }
                }
                if (reviewTable.IndexOf(row) == reviewTable.Count - 1)
                {
                    throw new WebDriverException("Faield to locate review to select. Check review exists and has not been deleted.");
                }
            }
        }

        public void VerifyUpdatedReviewComment(string comment)
        {
            foreach (var review in GetReviews())
            {
                if (review.Comment == comment)
                {
                    Assert.IsTrue(_element.FindElement(By.CssSelector("div button[id ^= 'EditReview']")).Displayed);
                    return;
                }
            }

            Assert.Fail($"Review with comment '{comment}' not found");
        }

        public int GetLatestReviewId()
        {
            int id = -1;
            foreach (var element in _element.FindElements(By.ClassName("risk-review")))
            {
                var review = new AngularRiskReview(_driver, _waiter, element);
                if (review.ReviewId > id)
                {
                    id = review.ReviewId;
                }
            }

            return id;
        }

        public void EnterTextIntoNewCommentField(string comment)
        {
            NewReviewComment.Click();
            NewReviewComment.SetValue(comment);
            _waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(By.Id("reviewNote"), comment));
        }

        public void UpdateRiskReviewComments(string updateComment)
        {
            UpdateReviewComment.Clear();
            UpdateReviewComment.SendKeys(updateComment);
            _waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(By.CssSelector("div textarea[id ^='reviewNote_']"), updateComment));
        }
    }
}



