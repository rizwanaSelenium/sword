﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiLineTextField : BaseAngularField
    {
        private IWebElement _input;
        private IWebElement Input()
        {
            _input = Element.FindElement(By.CssSelector("textarea"));
            return _input;
        }

        public AngularMultiLineTextField(IWebDriver driver, WebDriverWait waiter, string id,bool hasObject=true, bool hasLabel=true) :
            base(driver, waiter, id, hasObject,hasLabel)
        { 

        }

        public void SetValue(string value)
        {
            Input().Clear();
            Input().SendKeys(value);
        }

        public void AssertEquals(string text)
        {

            Assert.AreEqual(text, Input().GetAttribute("value").Trim());

        }

        public void AssertTextEquals(string text)
        {
           Assert.AreEqual(text, Input().Text.Trim());
        }
        public void AppendValue(string text)
        {
            Input().SendKeys(Keys.End);
            Input().SendKeys(text);
        }

        public void AssertLabelEquals(string text)
        {
            Assert.AreEqual(text, Label.Text.Trim());
        }
    }
}
