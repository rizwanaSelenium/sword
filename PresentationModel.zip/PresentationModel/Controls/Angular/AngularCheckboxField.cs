﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularCheckboxField : BaseAngularField
    {
        private readonly IWebElement _input;

        public AngularCheckboxField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _input = Element.FindElement(By.CssSelector("input"));
        }

        public void SetChecked()
        {
            if (!_input.Selected)
            {
                _input.Click();
            }
        }

        public void SetUnchecked()
        {
            if (_input.Selected)
            {
                _input.Click();
            }
        }

        public void AssertSelected()
        {
            Assert.True(_input.Selected);
        }

        public void AssertUnselected()
        {
            Assert.False(_input.Selected);
        }


    }
}
