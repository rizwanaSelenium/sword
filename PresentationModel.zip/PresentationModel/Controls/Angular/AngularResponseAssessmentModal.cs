﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularResponseAssessmentModal : AngularModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public AngularResponseAssessmentModal(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private AngularAssessmentField _targetAssessment;
        public AngularAssessmentField TargetAssessment
        {
            get
            {
                return _targetAssessment ?? (_targetAssessment = new AngularAssessmentField(_driver, _waiter, "field_81"));
            }
        }

        private AngularAssessmentField _currentAssessment;
        public AngularAssessmentField CurrentAssessment
        {
            get
            {
                return _currentAssessment ?? (_currentAssessment = new AngularAssessmentField(_driver, _waiter, "field_83"));
            }
        }

        private WebDriverButton _modalApplyButton;
        public WebDriverButton ApplyButton
        {
            get
            {
                return _modalApplyButton ?? (_modalApplyButton = new WebDriverButton(_driver, _waiter, "responseAssessmentModalApplyBtn"));
            }
        }

        private WebDriverButton _modalCopyButton;
        public WebDriverButton CopyButton
        {
            get
            {
                return _modalCopyButton ?? (_modalCopyButton = new WebDriverButton(_driver, _waiter, "responseAssessmentModalCopyBtn"));
            }
        }

        public bool AssessmentModalClosed()
        {
            return _driver.FindElements(By.Id("responseAssessmentModalApplyBtn")).Count == 0;
        }
    }
}
