﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularRiskReview
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _element;

        public AngularRiskReview(IWebDriver driver, WebDriverWait waiter, IWebElement element)
        {
            _driver = driver;
            _waiter = waiter;
            _element = element;
        }

        public string Id
        {
            get
            {
                return _element.GetAttribute("id");
            }
        }

        public string Comment
        {
            get
            {
                return _element.FindElement(By.ClassName("review-note")).Text;
            }
        }

        public int ReviewId
        {
            get { return int.Parse(_element.FindElement(By.ClassName("review-note")).GetAttribute("id").Split('_')[1]); }
        }

        public string Date
        {
            get
            {
                return _element.FindElement(By.ClassName("review-header")).Text.Split(new string[] { "  " }, StringSplitOptions.RemoveEmptyEntries)[1];
            }
        }

        public void Click()
        {
            _element.Click();
        }

        public WebDriverButton EditButton
        {
            get {
                return new WebDriverButton(_driver, _waiter,$"EditReview{ReviewId}");
            }
        }

        public bool EditButtonIsVisible
        {
            get
            {
                return _element.FindElements(By.Id($"EditReview{ReviewId}")).Count > 0;
            }
        }
    }
}
