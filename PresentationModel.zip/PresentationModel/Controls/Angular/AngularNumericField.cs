﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularNumericField : BaseAngularField
    {
        private readonly IWebElement _input;
        private readonly IWebElement _numericInput;

        public AngularNumericField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _input = Element.FindElement(By.CssSelector("input"));
            _numericInput = Element.FindElement(By.CssSelector("arm-numeric-input"));
        }

        public void AssertEquals(string text)
        {
            Assert.AreEqual(text, _numericInput.GetAttribute("ng-reflect-model"));
        }
        public void SetValue(string value)
        {
            _input.Clear();
            _input.SendKeys(value);
        }
    }
}
