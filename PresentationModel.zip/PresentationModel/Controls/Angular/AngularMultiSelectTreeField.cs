﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiSelectTreeField : BaseAngularControl
    {
        public AngularMultiSelectTreeField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            
        }

        public void SelectValue(string text)
        {
            DisplayTree();

           Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector($"#{ObjectId} div.tree-list")));

            var node = Element.FindElement(By.XPath($"arm-tree-picker//span[text()='{text}']"));
            node.Click();
            EnsureMenuClosed();
        }

        public void EnsureMenuClosed()
        {
            if (Driver.FindElements(By.CssSelector($"#{ObjectId} div.tree-list")).Count > 0)
            {
                try
                {
                    Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
                    Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(By.CssSelector($"#{ObjectId} div.tree-list")));
                }
                catch (WebDriverTimeoutException tex)
                {
                    throw new WebDriverTimeoutException("Timeout out trying to close a menu. " + tex);
                }
            }
        }

        public void SelectValues(string text)
        {
            DisplayTree();
            var selectValues = text.Split(',');
            foreach (var item in selectValues)
            {
                var name = item.Trim();
                if (!ValueIsSelected(name))
                {
                    Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector($"#{ObjectId} arm-tree-picker")));
                    var node = Element.FindElement(By.XPath($"arm-tree-picker//span[text()='{name}']"));
                    node.Click();
                }
            }
            Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
        }

        public void DeselectValue(string text)
        {
            DisplayTree();
            var deselectValue = text.Split(',');
            foreach (var item in deselectValue)
            {
                var name = item.Trim();
                if (ValueIsSelected(name))
                {
                    Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector($"#{ObjectId} arm-tree-picker")));
                    var node = Element.FindElement(By.XPath($"arm-tree-picker//span[text()='{name}']"));
                    node.Click();
                }
            }
            Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
        }

        public void DeselectAll()
        {
            DisplayTree();
            var nodes = new List<IWebElement>(Element.FindElements(By.CssSelector("div.tree-node tree-node-wrapper .node-content-wrapper-active .node-content")));
            foreach (var node in nodes)
            {
                DeselectValue(node.Text);
            }
        }

        private void DisplayTree()
        {
            var nodes = Driver.FindElements(By.CssSelector($"#{ObjectId} arm-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0);
            if (node == null)
            {
                try
                {
                    Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
                    Waiter.Until(d => d.FindElements(By.CssSelector($"#{ObjectId} arm-tree-picker")).FirstOrDefault(n => n.FindElements(By.CssSelector($".tree-list")).Count > 0));
                }
                catch (WebDriverTimeoutException tex)
                {
                    throw new WebDriverTimeoutException("Timed out trying to display a tree. " + tex);
                }
            }
        }

        public bool ValueIsSelected(string name)
        {
           var nodes = new List<IWebElement>(Element.FindElements(By.CssSelector("div.tree-node")));
           var node = nodes.First(n => n.FindElements(By.XPath($"tree-node-wrapper//span[text()='{name}']")).Count > 0);
           return node.FindElements(By.CssSelector("span.item-selected")).Count > 0;
        }

        public void AssertIsSelected(string text)
        {
            Assert.AreEqual(text, Element.FindElement(By.CssSelector(".picker-list")).Text);
           //verify is able to done only for one value. not able to verify for multiple values
            
        }

        public void AssertValueIsSelected(string names)
        {
            DisplayTree();
            var assertValue = names.Split(',');
            foreach (var item in assertValue)
            {
                var name = item.Trim();
                Assert.IsTrue(ValueIsSelected(name));
            }
            Element.FindElement(By.CssSelector("div.arm-tree-picker")).Click();
        }
    }
}
