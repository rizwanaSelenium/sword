﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularImpactProbabilityOccurrenceField : BaseAngularField
    {
        public AngularImpactProbabilityOccurrenceField(IWebDriver driver, WebDriverWait waiter, string id) : base(driver, waiter, id)
        {

        }

        public void SetProbabilityValue(string probabilityValue, IWebDriver driver)
        {
            for (var i = 0; i < 3; i++)
            {
                try
                {
                    Waiter.Until(e => Element.FindElement(By.TagName("input")).Displayed);
                    driver.ExecuteScript("arguments[0].scrollIntoView(true);", Element);
                }
                catch (NoSuchElementException ex)
                {
                    if (i >= 2)
                    {
                        throw new NoSuchElementException("Failed setting probability value - AngularImpactProbabilityOccurrenceField.cs. " + ex);
                    }
                }
                Element.FindElement(By.TagName("input")).Clear();
                Element.FindElement(By.TagName("input")).SendKeys(probabilityValue);
                Element.FindElement(By.TagName("input")).SendKeys(Keys.Tab);
                try
                {
                    Waiter.Until(e => Element.FindElement(By.TagName("input")).GetAttribute("value").Trim() == probabilityValue);
                    break;
                }
                catch (WebDriverTimeoutException et)
                {
                    if (i >= 2)
                    {
                        throw new WebDriverTimeoutException("Timed out wating for the probabiltiy value to be set correctly, was showing as: " + Element.FindElement(By.TagName("input")).GetAttribute("value") + " Should have been: " + probabilityValue + et);
                    }
                }
            }
        }

        public void SetProbabilityBand(string probabilityValue)
        {
            var selected = new SelectElement(Element.FindElement(By.TagName("select")));
            selected.SelectByText(probabilityValue);
        }

        public void VerifyProbabilityValue(string expectedProbabilityValue)
        {
            var probabilityValue = Element.FindElement(By.TagName("input")).GetAttribute("value").Trim();
            Assert.AreEqual(expectedProbabilityValue,probabilityValue, "Incorrect probability value. {0} should have been {1}", probabilityValue, expectedProbabilityValue);
        }

        public void VerifyProbabilityBandName(string expectedProbabilityBand, string scoringType)
        {
            string selectedProbabilityBand;

            switch (scoringType)
            {
                case "One Click":
                case "Hybrid":
                    var probabilityRow = Element.FindElements(By.TagName("button")).Where(e => e.GetAttribute("style").Contains("border: 3px solid black")).ToList();
                    if (probabilityRow.Count != 1) { Assert.Fail(); }
                    selectedProbabilityBand = probabilityRow[0].Text;
                    break;
                case "Classic":
                    selectedProbabilityBand = new SelectElement(Element.FindElement(By.TagName("select"))).SelectedOption.Text;
                    break;
                default:
                    throw new ArgumentException("Scoring type is unrecognizable");
            }
            Assert.AreEqual(expectedProbabilityBand, selectedProbabilityBand.Trim(), "Incorrect probability band selected. {0} was selected but expected {1}", selectedProbabilityBand, expectedProbabilityBand);
        }
    } 
}
