﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
   public class AngularGridControl : BaseAngularField
    {
        public AngularGridControl(IWebDriver driver, WebDriverWait waiter, string id) : base(driver, waiter, id, false, false)
        {

        }

        public bool GridHeaderContains(string expText)
        {
            var elements = Element.FindElements(By.CssSelector("span.ag-header-cell-text"));
            var index = elements.ToList().FindIndex(e => e.Text == expText);

            return index > -1;
        }

        public bool AssertResponseGridId(string expText, int rowNum)
        {
            return CheckColumnText("customResponseRef", expText, rowNum);
        }

        public bool AssertResponseGridType(string expText, int rowNum)
        {
            return CheckColumnText("responseType", expText, rowNum);
        }

        public bool AssertResponseGridTitle(string expText, int rowNum)
        {
            return CheckColumnText("responseTitle", expText, rowNum);
        }

        public bool AssertResponseGridOwner(string expText, int rowNum)
        {
            return CheckColumnText("ownerID.name", expText, rowNum);

        }

        public bool AssertResponseGridDue(string expText, int rowNum)
        {
            return CheckColumnText("dueDate", expText, rowNum);
        }

        public bool AssertResponseGridScore(string expText, int rowNum)
        {
            return CheckColumnText("targetRiskScoreValue", expText, rowNum);
        }

        public bool AssertResponseGridStatus(string expText, int rowNum)
        {
            return CheckColumnText("responseStatus", expText, rowNum);
        }

        public bool AssertResponseGridEffectiveness(string expText, int rowNum)
        {
            return CheckColumnText("effectiveness", expText, rowNum);
        }

        public bool CheckColumnText(string columnId, string expectedText, int rowNum)
        {
            var elements = Element.FindElements(By.CssSelector($"div[col-id='{columnId}']"));
            if (elements.Count > 0)
            {
                return elements[rowNum].Text == expectedText;
            }
            Assert.Fail($"Response grid column {columnId} not found");
            return false;
        }

        public IWebElement FindRowByTitle(string title)
        {
            var elements = Element.FindElements(By.CssSelector("div[role='gridcell']"));
            foreach (var element in elements)
            {
                if (element.Text.Equals(title))
                    return element;
            }
            throw new ArgumentException("Row grid "+title+" not found");
        }

        public void DeleteRowByTitle()
        {
            var element = Element.FindElement(By.CssSelector("div[class*='ag-row-selected'] span[title='Delete']"));
            element.Click();
        }
    }
}
