﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularExpandableSingleLineTextField : BaseAngularField
    {
        private readonly IWebElement _input;

        public AngularExpandableSingleLineTextField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _input = Element.FindElement(By.CssSelector("textarea"));
        }

        public void SetValue(string value)
        {
            _input.Clear();
            _input.SendKeys(value);
        }

        public void AssertEquals(string text)
        {
            Assert.AreEqual(text, _input.Text.Trim());
        }

        public void AssertValueEquals(string text)
        { 
            Assert.AreEqual(text, _input.GetAttribute("value").Trim());
        }

        public void AppendValue(string text)
        {
            _input.SendKeys(Keys.End);
            _input.SendKeys(text);
        }
    }
}
