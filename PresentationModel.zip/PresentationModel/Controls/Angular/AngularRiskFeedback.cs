﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularRiskFeedback
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _element;

        public AngularRiskFeedback(IWebDriver driver, WebDriverWait waiter, IWebElement element)
        {
            _driver = driver;
            _waiter = waiter;
            _element = element;
        }

        public string Id
        {
            get
            {
                return _element.GetAttribute("id");
            }
        }

        public string Comment
        {
            get
            {
                return _element.FindElement(By.ClassName("ellipsisWrapping")).Text;
            }
        }
        
        public int FeedbackId
        {
            get { return int.Parse(_element.FindElement(By.TagName("p")).Text.Split(new string[] { "  " }, StringSplitOptions.RemoveEmptyEntries)[0]); }
        }
        
        public string Date
        {
            get
            {
                return _element.FindElement(By.TagName("p")).Text.Split(new string[] { "  " }, StringSplitOptions.RemoveEmptyEntries)[1];
            }
        }
        
        public void Click()
        {
            _element.Click();
        }
    }
}
