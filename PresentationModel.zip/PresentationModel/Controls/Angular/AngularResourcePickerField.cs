﻿using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularResourcePickerField : BaseAngularField
    {
        readonly IWebElement _input;
        public AngularResourcePickerField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _input = Element.FindElement(By.TagName("input"));
        }

        public void SelectResource(string name)
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            _input.Click();
            _input.Clear();
            _input.SendKeys(name);
            WaitUntilUiSpinnerIsNotDisplayed();
            Dropdown.FindElement(By.XPath($"button//span[text()='{name}']")).Click();
        }

        private IWebElement Dropdown
        {
            get
            {
                IWebElement dropdown = null;
                for (int i = 0; i < 5; i++)
                {
                    Waiter.Until(d => Element.FindElement(By.CssSelector(".dropdown-menu")).Displayed);
                    dropdown = Driver.FindElement(By.CssSelector(".dropdown-menu"));

                    if (dropdown != null)
                    {
                        break;
                    }
                    Thread.Sleep(500);
                }
                Assert.IsNotNull(dropdown);
                return dropdown;

            }
        }

        public void Clear()
        {
            _input.Clear();
        }


        public void AssertEquals(string name)
        {
            var resource = _input.GetAttribute("value");
            Assert.AreEqual(resource, name);
        }

        public void AssertLabelEquals(string text)
        {
            Assert.AreEqual(Label.Text, text);
        }

        public void ShouldContainResourceIcon()
        {
            var parentResourcePicker = _input.FindElement(By.XPath(".."));
            Assert.IsTrue(parentResourcePicker.FindElements(By.CssSelector("button[armResourceLookupToggler]")).Count > 0, "Resource Icon Not Found In {0} field", _input.GetAttribute("title"));
        }
    }
}
