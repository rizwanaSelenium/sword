﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularValidationErrorModal
    {
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        public AngularValidationErrorModal(IWebDriver driver, WebDriverWait waiter)
        {
            _waiter = waiter;
            _element = driver.FindElement(By.Id("validationPanel"));
        }

        private IWebElement _validationErrorList;
        public IWebElement ValidationErrorList
        {
            get
            {
                return _validationErrorList ?? (_validationErrorList =
                       _waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".content"))));
            }
        }

        public void AssertErrorMessagePresentFor(string errorMessage)
        {
            var elements = _element.FindElements(By.CssSelector("li.ng-star-inserted"));
            foreach (var message in elements)
            {
                string errorMessageList = message.FindElement(By.CssSelector("li > p")).Text;

                switch (errorMessage)
                {
                    case "IdNotUnique":
                        Assert.AreEqual("ID is not unique", errorMessageList);
                        break;
                    case "PlanStartLaterThanCompletion":
                        Assert.AreEqual("Plan Start cannot be later than Plan Completion", errorMessageList);
                        break;
                    case "ResponseStartLaterThanDue":
                        Assert.AreEqual("Start cannot be later than Due", errorMessageList);
                        break;
                }
            }
        }

        public void AssertErrorFieldNamePresent(string fieldName)
        {
            var elements = _element.FindElements(By.CssSelector("li.ng-star-inserted"));
            foreach (var message in elements)
            {
                string errorMessageList = message.FindElement(By.CssSelector("a > em")).Text;

                switch (fieldName)
                {
                    case "ID":
                        Assert.AreEqual("ID", errorMessageList);
                        break;
                    case "PlanStart":
                        Assert.AreEqual("Plan Start", errorMessageList);
                        break;
                    case "ResponseStart":
                        Assert.AreEqual("Start", errorMessageList);
                        break;
                }
            }
        }
    }
}
