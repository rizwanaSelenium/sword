﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularTextPopupButtonField : BaseAngularField
    {
        public AngularTextPopupButtonField(IWebDriver driver, WebDriverWait waiter, string id):
            base(driver, waiter, id)
        {
            throw new NotImplementedException();
        }

        public void SetValue(string value)
        {
            throw new NotImplementedException();
        }

        public void AssertEquals(string text)
        {
            throw new NotImplementedException();
        }

        public void AppendValue(string text)
        {
            throw new NotImplementedException();
        }
    }
}
