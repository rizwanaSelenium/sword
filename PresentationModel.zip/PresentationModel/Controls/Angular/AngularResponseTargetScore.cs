﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularResponseTargetScore : BaseAngularField
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _input;
        private readonly WebDriverButton _pidPicker;

        public AngularResponseTargetScore(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _driver = driver;
            _waiter = waiter;

            _input = Element.FindElement(By.CssSelector("input"));
            _pidPicker = new WebDriverButton(_driver, _waiter, "field_81_pid_picker_button");
        }

        public void AssertEquals(string text)
        {
            Assert.AreEqual(text, _input.GetAttribute("value"));
        }

        public void AssertColorEquals(string color)
        {
            var background = "";
            switch (color.ToLower())
            {
                case "yellow":
                    background = "rgb(255, 255, 0)";
                    break;
                case "red":
                    background = "rgb(255, 0, 0)";
                    break;
            }

            Assert.IsTrue(_input.GetAttribute("style").ToLower().Contains("background-color: " + background));
        }

        public void SetValue(string value)
        {
            _input.Clear();
            _input.SendKeys(value);
        }

        public void SetValueViaPid(string value)
        {
            _pidPicker?.Click();
            try
            {
                Waiter.Until(x =>
                    _driver.FindElement(By.XPath("//div[@id='responseAssessmentPidModalScreen']")).Displayed);
                var pidModal = Element.FindElement(By.XPath("//div[@id='responseAssessmentPidModalScreen']"));
                if (pidModal != null)
                {
                    try
                    {
                        _waiter.Until(x => _driver.FindElement(By.XPath($"//p[contains(text(), '{value}')]")).Enabled);
                        var pidValue = Element.FindElement(By.XPath($"//p[contains(text(), '{value}')]")); 
                        pidValue.Click();
                    }
                    catch (TimeoutException tex)
                    {
                        throw new WebDriverTimeoutException("Expected element " + value + " to become enabled but it never did, waiter timed out. " + tex);
                    }
                }
            }
            catch (Exception e)
            {
                throw new WebDriverException("Response target score pid modal not found. " + e.Message);
            }
        }
    }
}
