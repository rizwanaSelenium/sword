﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularRiskNavigationPanel : BaseAngularControl
    {
        public AngularRiskNavigationPanel(IWebDriver driver, WebDriverWait waiter):base(driver, waiter, "", false)
        {
            Element = Driver.FindElement(By.ClassName("dialogDetailsSectionNavPanel"));
        }

        private WebDriverButton _riskExpandButton;
        public WebDriverButton RiskExpandButton
        {
            get
            {
                if (_riskExpandButton == null)
                {
                    _riskExpandButton = new WebDriverButton(Driver, Waiter, "Risk_expand_button");
                }
                return _riskExpandButton;
            }
        }

        private WebDriverButton _scoringExpandButton;
        public WebDriverButton ScoringExpandButton
        {
            get
            {
                if (_scoringExpandButton == null)
                {
                    _scoringExpandButton = new WebDriverButton(Driver, Waiter, "Scoring_expand_button");
                }
                return _scoringExpandButton;
            }
        }

        private WebDriverButton _planExpandButton;
        public WebDriverButton PlanExpandButton
        {
            get
            {
                if (_planExpandButton == null)
                {
                    _planExpandButton = new WebDriverButton(Driver, Waiter, "Plan_expand_button");
                }
                return _planExpandButton;
            }
        }

        private WebDriverButton _responseExpandButton;
        public WebDriverButton ResponseExpandButton
        {
            get
            {
                if (_responseExpandButton == null)
                {
                    _responseExpandButton = new WebDriverButton(Driver, Waiter, "Response_expand_button");
                }
                return _responseExpandButton;
            }
        }

        private WebDriverButton _evaluationExpandButton;
        public WebDriverButton EvaluationExpandButton
        {
            get
            {
                if (_evaluationExpandButton == null)
                {
                    _evaluationExpandButton = new WebDriverButton(Driver, Waiter, "Evaluation_expand_button");
                }
                return _evaluationExpandButton;
            }
        }

        public IWebElement GetNavSection(string sectionName)
        {
            try
            {
                Waiter.Until(d => Element.FindElements(By.Id($"{sectionName}_nav_section")).Count != 0);
            }
            catch (WebDriverTimeoutException ex)
            {
                throw new WebDriverTimeoutException("Timed out while waitng for the navigation panel to contain some elemenets. " + ex);
            }

            return Element.FindElement(By.Id($"{sectionName}_nav_section"));
        }

        public void ExpandSection(string sectionName)
        {           
            IWebElement navSection = GetNavSection(sectionName);
            if (navSection != null)
            {
                var expandElement = navSection.FindElement(By.Id($"{sectionName}_expand_button"));
                if (expandElement.GetProperty("title") == "Expand")
                {
                    expandElement.Click();
                }
            }
        }

        public void CollapseSection(string sectionName)
        {
            IWebElement navSection = GetNavSection(sectionName);
            if (navSection != null)
            {
                var expandElement = navSection.FindElement(By.Id($"{sectionName}_expand_button"));
                if (expandElement.GetProperty("title") == "Collapse")
                {
                    expandElement.Click();
                }
            }
        }

        public IWebElement GetNavMenuOption(string sectionName, string menuOption)
        {
            var section = GetNavSection(sectionName);
            return section.FindElement(By.Id(menuOption));
        }

        public bool OptionIsVisibleInSection(string sectionName, string navMenuOption)
        {

            var option = GetNavMenuOption(sectionName, navMenuOption);
            return option != null;
        }

        public bool OptionIsEnabledInSection(string sectionName, string navMenuOption)
        {

            var option = GetNavMenuOption(sectionName, navMenuOption);
            return (option.Enabled);
        }

        public string GetNavOptionTooltip(string sectionName, string navMenuOption)
        {
            var option = GetNavMenuOption(sectionName, navMenuOption);
            return option.GetProperty("title");
        }

        public void SelectNavMenuOption(string sectionName, string menuOption)
        {
            var myMenuOption = GetNavMenuOption(sectionName, menuOption);
            myMenuOption.Click();
            WaitUntilUiSpinnerIsNotDisplayed();
        }
    }
}
