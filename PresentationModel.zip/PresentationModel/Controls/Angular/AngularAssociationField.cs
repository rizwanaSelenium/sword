﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularAssociationField : BaseAngularField
    {


        public AngularAssociationField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            throw new NotImplementedException();
        }
    }
}
