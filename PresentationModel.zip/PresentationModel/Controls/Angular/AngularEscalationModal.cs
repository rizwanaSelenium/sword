﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Desktop;

namespace PresentationModel.Controls.Angular
{
    public class AngularEscalationModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private WebDriverRadioButton _escalateRadioButton;
        private WebDriverRadioButton _proposeRadioButton;
        private WebDriverRadioButton _deescalateButton;
        private WebDriverTextAreaControl _escalationCommentArea;
        private WebDriverButton _saveButton;
        private WebDriverButton _cancelButton;
        private WebDriverButton _helpButton;

        public WebDriverRadioButton EscalateRadioButton
        {
            get
            {
                return _escalateRadioButton ?? (_escalateRadioButton =
                           new WebDriverRadioButton(_driver, _waiter, "ngb-modal-window input#escalate", true, false));
            }
        }

        public WebDriverRadioButton ProposeRadioButton
        {
            get
            {
                return _proposeRadioButton ?? (_proposeRadioButton =
                           new WebDriverRadioButton(_driver, _waiter, "ngb-modal-window input#propose", true, false));
            }
        }

        public WebDriverRadioButton DeescalateRadioButton
        {
            get
            {
                return _deescalateButton ?? (_deescalateButton =
                           new WebDriverRadioButton(_driver, _waiter, "ngb-modal-window input#deescalate", true,
                               false));
            }
        }

        public WebDriverTextAreaControl EscalateCommentTextArea
        {
            get
            {
                return _escalationCommentArea ?? (_escalationCommentArea =
                           new WebDriverTextAreaControl(_driver, _waiter, "textarea#escalationComments", true));
            }
        }

        public WebDriverButton SaveButton
        {
            get
            {
                return _saveButton ?? (_saveButton = new WebDriverButton(_driver, _waiter,
                           "[role] .buttonsrow .btn.btn-arm:nth-of-type(1)", true));
            }
        }

        public WebDriverButton CancelButton
        {
            get
            {
                return _cancelButton ?? (_cancelButton = new WebDriverButton(_driver, _waiter,
                           "[role] .buttonsrow .btn-arm:nth-of-type(2)", true));
            }
        }

        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(_driver, _waiter, "[armhelp]", true)); }
        } 

        public AngularEscalationModal(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
            _waiter.Until(e => _driver.FindElements(By.CssSelector(".modal-dialog")).Count(d => d.Displayed) > 0);
            _element = _driver.FindElement(By.CssSelector(".modal-dialog"));
        }

        public RiskComponent SaveEscalation()
        {
            SaveButton.Click();
            return new RiskComponent(_driver, _waiter);
        }

        public void WriteComment(string comment)
        {
            EscalateCommentTextArea.SetValue(comment);
            
        }

        public List<string> GetRadioButtonsOnPage()
        {
            List<string> radioButtons =
                _element.FindElements(By.CssSelector("div.radio label[for]")).Select(radioBtn => radioBtn.Text).ToList();
            return radioButtons;          
        }

        public bool ExpectedRadioButtonsArePresent(List<string> radioButtons)
        {
            try
            {
                _waiter.Until(d => GetRadioButtonsOnPage().Contains(radioButtons[0]));
            }
            catch (WebDriverTimeoutException tex)
            {
                throw new WebDriverTimeoutException("Timed out waiting for first Radio button to match. " + tex);
            }

            var availableRadioButtons = GetRadioButtonsOnPage();
            var doesContains = false;
            if (radioButtons.Count == availableRadioButtons.Count)
            {
                foreach (var radioButton in radioButtons)
                {
                    doesContains = availableRadioButtons.Contains(radioButton);
                    if (!doesContains) Assert.Fail("Radio button " + radioButton + " was not found on the page.");
                }
            }

            return doesContains;
        }      

        public void SelectRadioButton(string radioButton)
        {
            switch (radioButton)
            {
                case "Escalate":
                    EscalateRadioButton.Select();
                    break;
                case "Propose":
                    ProposeRadioButton.Select();
                    break;
                case "De-escalate":
                    DeescalateRadioButton.Select();
                    break;
                default:
                    Assert.Fail("Selected unknown radio button");
                    break;
            }
        }

        public bool IsValidationMessageDisplayed(string validationMessage)
        {
            bool valdidation = _driver.FindElements(By.CssSelector("p.ng-star-inserted"))
                .Select(x => x)
                .First(x => x.Text == validationMessage)
                .Displayed;
            return valdidation;
        }

        public RiskComponent Cancel()
        {
            CancelButton.Click();
            return new RiskComponent(_driver, _waiter);
        }
    }
}
