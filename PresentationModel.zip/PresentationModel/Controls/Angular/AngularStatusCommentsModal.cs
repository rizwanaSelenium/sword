﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace PresentationModel.Controls.Angular
{
    public class AngularStatusCommentsModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private WebDriverTextAreaControl _statusComments;
        private WebDriverButton _okButton;
        private WebDriverButton _cancelButton;

       public AngularStatusCommentsModal(IWebDriver driver, WebDriverWait waiter)
       {
            _driver = driver;
            _waiter = waiter;
            _element = _driver.FindElement(By.CssSelector("div.modal-content"));

        }

       public WebDriverTextAreaControl StatusComments => _statusComments ?? (_statusComments =
                                                             new WebDriverTextAreaControl(_driver, _waiter, "textarea[name='statusComment']", true));

        public WebDriverButton CommentsOkButton => _okButton ?? (_okButton =
                new WebDriverButton(_driver, _waiter, "changeCommentsOkBtn", false));

        public WebDriverButton CommentsCancelButton => _cancelButton ?? (_cancelButton =
                new WebDriverButton(_driver, _waiter, "changeCommentsCancelBtn", false));

        public void AssertRiskStatusCommentsErrorMessage()
        {

            var errorMessage = _element.FindElement(By.Id("changeCommentsValidationMsg"));
            Assert.AreEqual("Please enter a status change comment", errorMessage.Text);
        }

    }
}
