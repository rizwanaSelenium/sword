﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularDropdownListField : BaseAngularField
    {
        readonly SelectElement _select;
        public AngularDropdownListField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            try
            {
                waiter.Until(d => driver.FindElement(By.CssSelector("select#" + id)).Displayed);
                _select = new SelectElement(Element.FindElement(By.CssSelector("select#" + id)));
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException("Timed out while waiting for the dropdown with id " + id + " to be displayed.");
            }
        }

        public void SelectByText(string text)
        {
            _select.SelectByText(text);
        }

        public void SelectByValue(string value)
        {
            _select.SelectByValue(value);
        }

        public void AssertTextEquals(string text)
        {
            Assert.AreEqual( text, _select.SelectedOption.Text.Trim(), string.Format("Expected text on element should be '{0}' but is '{1}'.",  text, _select.SelectedOption.Text));
        }

        public void AssertValueEquals(string value)
        {
            Assert.AreEqual(value,_select.SelectedOption.GetAttribute("value").Trim());
        }

        public void AssertLabelEquals(string text)
        {
            Assert.AreEqual(text,Label.Text);
        }
    }
}
