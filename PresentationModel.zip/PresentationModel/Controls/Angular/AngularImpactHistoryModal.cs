﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularImpactHistoryModal : AngularModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private WebDriverButton _selectButton;

        public AngularImpactHistoryModal(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {
            _driver = driver;
            _waiter = waiter;
            _element = Element;
        }
        public WebDriverButton SelectButton
        {
            get
            {
                return _selectButton ?? (_selectButton = new WebDriverButton(_driver, _waiter, "impactHistorySelect", false));
            }
        }

        public void ClickCommentRow(string comment)
        {
            var column = _element.FindElement(By.XPath($"//div[contains(text(),'{comment}')]"));
            column.Click();
        }

        public void WaitForModalToDisappear()
        {
            _waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(By.Id("impactHistorySelect")));
        }
    }
}
