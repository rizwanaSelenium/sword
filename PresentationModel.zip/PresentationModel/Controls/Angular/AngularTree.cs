﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularTree : WebDriverArmPage
    {
        private readonly IWebElement _tree;
        public AngularTree(IWebDriver driver, WebDriverWait waiter, string tagName) : base(driver, waiter, "")
        {
            Waiter = waiter;
            Waiter.Until(d => d.FindElements(By.TagName(tagName)).Count >= 1);
            _tree = driver.FindElement(By.TagName(tagName));
        }

        public AngularTree(IWebDriver driver, WebDriverWait waiter, string tagName, string id, string className) : base(driver, waiter, "")
        {
            _tree = driver.FindElement(By.Id(id)).FindElement(By.TagName(tagName)).FindElement(By.ClassName(className));
        }

        public AngularTreeNode Node(string nodePath)
        {
            try
            {
                Waiter.Until(d => GetNode(nodePath) != null);
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException($"Leaf node '{nodePath}' does not exist");
            }
            return GetNode(nodePath);
        }

        public int TreeNodeCount(string nodePath)
        {
            return nodePath.Split('/').ToList().Count;
        }

        public void AssertNodeDoesNotExist(string nodePath)
        {
            Assert.IsNull(GetNode(nodePath), "Node exists when it was expected to be non-existent");
        }

        public void AssertNodeExist(string nodePath)
        {
            Assert.IsNotNull(Node(nodePath), "Node doesn't exist");
        }

        private AngularTreeNode GetNode(string nodePath)
        {
            // Build tree node title hierarchy, makes recursion easier later on
            var treeNodeTitle = BuildTreeNodeTitleHierarchy(nodePath.Split('/').ToList());
            return FindNode(treeNodeTitle, null);
        }

        private static TreeNodeTitle BuildTreeNodeTitleHierarchy(List<string> nodeTitles)
        {
            TreeNodeTitle treeNodeTitle = null;
            foreach (var title in nodeTitles)
            {
                var parentTreeNode = treeNodeTitle;
                treeNodeTitle = new TreeNodeTitle(treeNodeTitle, title);

                if (parentTreeNode != null)
                    parentTreeNode.Child = treeNodeTitle;
            }

            if (treeNodeTitle == null)
                throw new Exception("treeNode is null");
            return treeNodeTitle;
        }

        private class TreeNodeTitle
        {
            public TreeNodeTitle(TreeNodeTitle parent, string title)
            {
                Parent = parent;
                Title = title;
            }
            public TreeNodeTitle Parent { get; }
            public TreeNodeTitle Child { get; set; }
            public bool IsLeaf => Child == null;
            public string Title { get; }
        }

        private AngularTreeNode FindNode(TreeNodeTitle treeNode, AngularTreeNode node)
        {
            // This starts by looking for the leaf node, if the leaf node is null then it works
            // it's way up the leaf node's ancestors until it finds a node that does exist.  It then
            // checks to see if that node is expanded:
            // - if the node is expanded then returns null as it is then determined that the leaf node or an ancestor doesn't exist
            // - if it isn't expanded then it expands the node and looks for it's child:
            //      - if found then expand and continue down the tree
            //      - if not found then return null

            if (treeNode == null && node == null)
                return null;

            node = FindNode(treeNode.Title, node);

            if (node != null)
            {
                if (treeNode.IsLeaf)
                    return node;

                if (node.IsExpanded())
                    return null;

                node.Expand();

                return FindNode(treeNode.Child, node);
            }

            return FindNode(treeNode.Parent, null);
        }

        private AngularTreeNode FindNode(string nodeTitle, AngularTreeNode parentNode)
        {
            for (var i = 0; i < 2; i++)
            {
                try
                {
                    if (parentNode == null)
                    {
                        parentNode = new AngularTreeNode(Driver, Waiter, _tree.FindElement(By.TagName("tree-node")));
                    }

                    var parentChildNodes = parentNode.Children.ToArray();
                    AngularTreeNode childNode = null;

                    foreach (var checkNode in parentChildNodes)
                    {
                        if (checkNode.Title == nodeTitle)
                        {
                            childNode = checkNode;
                        }
                    }
                    return childNode;
                }
                catch (Exception ex)
                {
                    if (ex is StaleElementReferenceException && i > 0)
                    {
                        throw new StaleElementReferenceException("Stale element twice while searching for tree node investigate. " + ex);
                    }

                    if (!(ex is StaleElementReferenceException))
                    {
                        throw new Exception("Error while searching for tree node - " + nodeTitle + ". " + ex);
                    }     
                }
            }
            throw new Exception("Unexpected error in automation this point should not be reached.");
        }
    }
}
