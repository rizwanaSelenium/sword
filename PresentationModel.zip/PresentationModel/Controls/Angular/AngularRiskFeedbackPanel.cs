﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularRiskFeedbackPanel : AngularRiskInfoPanel
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private readonly IWebElement _element;

        public AngularRiskFeedbackPanel(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {
            _driver = driver;
            _waiter = waiter;
            _element = _driver.FindElement(By.Id("extra-options-container"));
        }

        private IList<IWebElement> _feedbacks;

        public IList<IWebElement> Feedbacks
        {
            get
            {
                if (_feedbacks == null)
                {
                    _feedbacks = _element.FindElements(By.CssSelector(".content > ul > li")).ToList();
                }

                return _feedbacks;
            }
        }

        private WebDriverButton _closeButton;

        public WebDriverButton CloseButton
        {
            get
            {
                if (_closeButton == null)
                {
                    _closeButton = new WebDriverButton(_driver, _waiter, "CloseFeedback");
                }

                return _closeButton;
            }
        }

        private WebDriverButton _newButton;

        public WebDriverButton NewButton
        {
            get
            {
                if (_newButton == null)
                {
                    _newButton = new WebDriverButton(_driver, _waiter, "NewFeedback");
                }

                return _newButton;
            }
        }

        private WebDriverButton _helpButton;

        public WebDriverButton HelpButton
        {
            get
            {
                if (_helpButton == null)
                {
                    _helpButton = new WebDriverButton(_driver, _waiter, "HelpFeedback");
                }

                return _helpButton;
            }
        }


        private WebDriverTextAreaControl _newFeedbackComment;

        public WebDriverTextAreaControl NewFeedbackComment
        {
            get
            {
                if (_newFeedbackComment == null)
                {
                    _newFeedbackComment = new WebDriverTextAreaControl(_driver, _waiter, "textarea[name='feedbackComment']", true);
                }

                return _newFeedbackComment;
            }
        }

        public bool ButtonIsVisible(string button)
        {
            string buttonId = "";
            switch (button)
            {
                case "Close":
                    buttonId = "CloseFeedback";
                    break;
                case "Help":
                    buttonId = "HelpFeedback";
                    break;
                case "New":
                    buttonId = "NewFeedback";
                    break;
                default:
                    Assert.Fail("button not recognised");
                    break;
            }

            return _element.FindElements(By.Id(buttonId)).Count > 0;
        }
        
        public override bool HelpPageOpened()
        {
            return HelpPageOpened("Risk_Feedback.htm");
        }
        
        public AngularRiskFeedback GetFirstFeedback()
        {
            var elements = _element.FindElements(By.CssSelector("li[tabindex='0']"));
            if (elements.Count == 0)
            {
                return null;
            }
            return new AngularRiskFeedback(_driver, _waiter, elements[0]);
        }

        public AngularRiskFeedback GetFeedbackByComment(string comment)
        {
            foreach (var element in _element.FindElements(By.CssSelector("li[tabindex='0']")))
            {
                var feedback = new AngularRiskFeedback(_driver, _waiter, element);
                if (feedback.Comment == comment)
                {
                    return feedback;
                }
            }
            Assert.Fail($"Feedback with comment '{comment}' not found");
            return null;
        }

        public int GetLatestFeedbackId()
        {
            int id = -1;
            foreach (var element in _element.FindElements(By.CssSelector("li[tabindex='0']")))
            {
                var feedback = new AngularRiskFeedback(_driver, _waiter, element);
                if (feedback.FeedbackId > id)
                {
                    id = feedback.FeedbackId;
                }
            }
            return id;
        }

        public void EnterTextIntoNewCommentField(string comment)
        {
            NewFeedbackComment.Click();
            SendKeys.SendWait(comment);
            _waiter.Until(
                SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementValue(By.Name("feedbackComment"), comment));
        }
    }
}



