﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularTreeNode : WebDriverArmPage
    {
        private readonly IWebElement _webElementNode;
        public AngularTreeNode(IWebDriver driver, WebDriverWait waiter, IWebElement webElementNode) : base(driver, waiter, "")
        {
            _webElementNode = webElementNode;
        }

        public void Click()
        {
            try
            {
                WaitUntilUiSpinnerIsNotDisplayed();
                _webElementNode.FindElement(By.TagName("tree-node-content")).Click();
                WaitUntilUiSpinnerIsNotDisplayed();
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException("Hit timeout trying to click on tree node in AngularTreeNode.cs");
            }
        }

        public bool IsExpanded()
        {
            var nodeExpander = _webElementNode.FindElement(By.TagName("tree-node-expander"));
            return nodeExpander.FindElements(By.ClassName("toggle-children-wrapper-collapsed")).Count == 0;
        }

        public void Expand()
        {
            try
            {
                WaitUntilUiSpinnerIsNotDisplayed();
                _webElementNode.FindElement(By.TagName("tree-node-expander")).Click();
                WaitUntilUiSpinnerIsNotDisplayed();
                if (!IsExpanded())
                {
                    Assert.Fail("Failed to expand tree node in AngularTreeNode.cs");
                }
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException("Hit timeout trying to expand tree node in AngularTreeNode.cs");
            }
        }

        public void IsDisabled()
        {
            var result = _webElementNode.FindElement(By.TagName("tree-node-content")).FindElements(By.ClassName("disabled")).Count > 0;
            Assert.IsTrue(result);
        }

        public new List<AngularTreeNode> Children
        {
            get
            {
                var myElements = _webElementNode.FindElements(By.XPath("//div[contains(@class, 'tree-node')]"));
                    return myElements.Select(child => new AngularTreeNode(Driver, Waiter, child)).ToList();
            }
        }

        public string Title
        {
            get
            {
                return _webElementNode.FindElement(By.TagName("tree-node-content")).Text;
            }
        }
    }
}
