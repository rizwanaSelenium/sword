﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace PresentationModel.Controls.Angular
{
    public class AngularBlackFlagCommentsModal: AngularModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private AngularMultiLineTextField _blackFlagComments;

       public AngularBlackFlagCommentsModal(IWebDriver driver, WebDriverWait waiter): base(driver, waiter)
       {
            _driver = driver;
            _waiter = waiter;
            _element = Element;
       }

        public AngularMultiLineTextField BlackFlagComments
        {
            get
            {
                return _blackFlagComments ?? (_blackFlagComments = new AngularMultiLineTextField(_driver, _waiter, "blackFlagChangeBody", false,false));
            }
        }

        public void AssertBlackFlagChangeCommentsErrorMessage()
        {            
            var errorMessage = _element.FindElement(By.Id("changeCommentsValidationMsg"));
            Assert.AreEqual("Please enter a black flag change comment", errorMessage.Text);
        }

    }
}
