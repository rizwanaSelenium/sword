﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiSelectDropdownField : BaseAngularField
    {
        private readonly IWebElement _multiSelect;
        public AngularMultiSelectDropdownField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _multiSelect = Element.FindElement(By.TagName("arm-multi-select"));
        }

        public void ClickItem(string name)
        {
           //First open the menu
            _multiSelect.Click();
            Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector($"#{ObjectId} arm-multi-select")));
            _multiSelect.FindElement(By.XPath($"//ul//li//div//label[contains(text(),'{name}')]")).Click();
            //close menu one selected
            _multiSelect.Click();
        }

        public void SelectMultipleItems(string names)
        {
            var selectItem = names.Split(',');
            foreach (var item in selectItem)
            {
                if (!ItemIsSelected(item))
                {
                    ClickItem(item);
                }
            }
        }

        public void SelectItem(string name)
        {
            if (!ItemIsSelected(name))
            {
                ClickItem(name);
            }
            
        }

        public void DeselectMultipleItems(string names)
        {
            var deselectItem = names.Split(',');
            foreach (var item in deselectItem)
            {
                if (ItemIsSelected(item))
                {
                    ClickItem(item);
                }
            }
        }

        public void DeselectItem(string name)
        {
            if (ItemIsSelected(name))
                {
                    ClickItem(name);
                }
            
        }

        public void DeselectAll()
        {
            var nodes = new List<IWebElement>(_multiSelect.FindElements(By.XPath($"div//ul[contains(@class,'picker-list')]//li//span")));
            foreach (var node in nodes)
            {
                DeselectItem(node.Text);
                _multiSelect.Click();
            }
        }

        public bool ItemIsSelected(string name)
        {
            var nodes = new List<IWebElement>(_multiSelect.FindElements(By.XPath($"div//ul[contains(@class,'picker-list')]//li")));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.XPath($"span[text()='{name}']")).Count > 0);
            return node != null;
        }

        public void AssertMultipleItemsSelected(string names)
        {
            _multiSelect.Click();
            Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector($"#{ObjectId} arm-multi-select")));
            var assertItem = names.Split(',');
            foreach (var item in assertItem)
            {
                Assert.IsTrue(ItemIsSelected(item.Trim()), "Item not selected "+item);

            }
            _multiSelect.Click();
        }

        public void AssertItemIsSelected(string name)
        {
            Assert.IsTrue(ItemIsSelected(name), "Item not selected " + name);
        }
    }
}
