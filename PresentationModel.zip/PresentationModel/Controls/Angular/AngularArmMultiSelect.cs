﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularArmMultiSelect : BaseAngularControl
    {
        private IWebElement _labelElement;
        public IWebElement LabelElement
        {
            get {
                return _labelElement ?? (_labelElement = Driver.FindElement(By.CssSelector("div label#" + Id + "-label")));
            }
        }

        private IWebElement DropdownList
        {
            get { return Driver.FindElement(By.CssSelector("ul.list")); }
        }

        private WebDriverButton _dropDownButton;

        public WebDriverButton DropDownButton
        {
            get
            {
                return _dropDownButton ?? (_dropDownButton = new WebDriverButton(Driver, Waiter, $"#{ObjectId} ul.picker-list", true));
            }
        }

        public AngularArmMultiSelect(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject) : base(driver, waiter, id, hasObject)
        {
        }

        public void Selectvalue(string value)
        {
            DropDownButton.Click();
            var optionListFound = false;
            for (int i = 0; i < 5; i++)
            {
                var optionsList = DropdownList.Displayed;
                if (optionsList)
                {
                    optionListFound = true;
                    break;
                }

                Thread.Sleep(500);
            }

            if (!optionListFound)
            {
                Assert.Fail("Angular Multi Select Dropdown not loaded");
            }

            var option = Driver.FindElements(By.CssSelector("ul.list li:not(.selected) label")).Where(x => x.Text == value);

            if (!option.Any())
            {
                Assert.Fail("Option to select from Angular Multi Select Dropdown was either not found or already selected");
            }
            option.First().Click();
            EnsureMenuClosed();
        }
        public void EnsureMenuClosed()
        {
            if (DropdownList.Displayed)
            {
                DropDownButton.Click();
            }
        }
        public string GetText()
        {
            return Element.Text;
        }
    }
}
