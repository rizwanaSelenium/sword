﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularButton : WebDriverArmControl
    {
        public AngularButton(IWebDriver driver, WebDriverWait waiter, string selector) : base(driver, waiter, selector)
        {
            CssSelectorString = selector;
        }

       public void AssertDisplayed()
        {
            Assert.True(Element.Displayed); 
        }
    }
}

