﻿using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiSelectTreeTableResourceField: AngularMultiSelectTreeTableField
    {
        public AngularMultiSelectTreeTableResourceField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {

        }

        public void SelectResource(string name)
        {
            HideTree();
            var resource = Driver.FindElement(By.CssSelector($"#{Id} arm-table-tree-picker span.fa-user-circle"));
            if (resource != null)
            {
                resource.Click();

                Waiter.Until(d => Element.FindElement(By.CssSelector(".extra-options-container")).Displayed);
                var input = Driver.FindElement(By.CssSelector(".extra-options-container input#resourceLookupSearchTerm"));

                if (input != null)
                {
                    input.SendKeys(name);
                    Waiter.Until(d => Element.FindElement(By.CssSelector(".extra-options-container span.fa-plus-circle")).Displayed);
                    var addButton = Driver.FindElement(By.CssSelector(".extra-options-container span.fa-plus-circle"));
                    addButton.Click();
                }
                Assert.IsNotNull(input);
            }
            Assert.IsNotNull(resource);
        }

        public void DisplayedResource(string name)
        {
            HideTree();
            var nodes = Driver.FindElements(By.CssSelector($"#{Id} arm-table-tree-picker"));
            var node = nodes.FirstOrDefault(n => n.FindElements(By.XPath($"div//ul//li//span[text()='{name}']")).Count > 0);
            Assert.IsNotNull(node);
        }
    }
}
