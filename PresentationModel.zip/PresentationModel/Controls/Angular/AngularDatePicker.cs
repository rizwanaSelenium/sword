﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using NUnit.Framework;

namespace PresentationModel.Controls.Angular
{
    public class AngularDatePicker : WebDriverArmControl
    {
        private SelectElement MonthSelector
        {
            get { return new SelectElement(Element.FindElement(By.CssSelector("ngb-datepicker select:first-child"))); }
        }

        private SelectElement YearSelector
        {
            get { return new SelectElement(Element.FindElement(By.CssSelector("ngb-datepicker select:last-child"))); }
        }

        private WebDriverTextField DayField
        {
            get { return new WebDriverTextField(Driver, Waiter,CssSelectorString + " .day",true); }
        }

        private WebDriverTextField MonthField
        {
            get { return new WebDriverTextField(Driver, Waiter, CssSelectorString + " .month", true); }
        }

        private WebDriverTextField YearField
        {
            get { return new WebDriverTextField(Driver, Waiter, CssSelectorString + " .year", true); }
        }

        private WebDriverButton _pickButton;

        public WebDriverButton PickButton
        {
            get
            {
                return _pickButton ??
                       (_pickButton = new WebDriverButton(Driver, Waiter, CssSelectorString + " i", true));
            }
        }

        public AngularDatePicker(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, null)
        {

        }

        public AngularDatePicker(IWebDriver driver, WebDriverWait waiter, string id)
            : this(driver, waiter)
        {
            SetSelectorString("arm-date-picker#" + id + string.Empty);
        }

        public void PickDate(string dateString)
        {
            if (string.IsNullOrEmpty(dateString))
            {
                Element.FindElement(By.ClassName("day")).SendKeys(Keys.Backspace);
            }
            else
            {
                var date = ParsedDate(dateString);

                var updatedDate = date.GetValueOrDefault(DateTime.Now);
                PickButton.Click();

                MonthSelector.SelectByValue(updatedDate.Month.ToString());
                YearSelector.SelectByValue(updatedDate.Year.ToString());

                Waiter.Until(d => d.FindElement(By.CssSelector("div.ngb-dp-day div")).Displayed);

                var days = Element.FindElements(By.CssSelector("div.ngb-dp-day div"));

                foreach (var day in days)
                {
                    if (!day.GetAttribute("class").Contains("outside") && day.Text == updatedDate.Day.ToString())
                    {
                        day.Click();
                        break;
                    }
                }

                Waiter.Until(d => !Element.FindElement(By.CssSelector("input")).GetAttribute("value").Length.Equals(0));
            }
        }

        public void EnterDate(string dateString)
        {
            if (string.IsNullOrEmpty(dateString))
            {
                Element.FindElement(By.ClassName("day")).SendKeys(Keys.Backspace);
            }
            else
            {
                var date = ParsedDate(dateString);

                var updatedDate = date.GetValueOrDefault(DateTime.Now);
                try
                {
                    var loopCounter = 1;
                    var monthName = updatedDate.ToString("MMM");
                    DayField.Click();
                    DayField.SetValue(updatedDate.ToString("dd"));

                    //Bug# APB-22533 Unable to enter month name in Date field
                    //Once this issue is resolved, below loop can be replaced by MonthField.SetValue

                    var monthFieldValue = "MMM";
                    while ((monthFieldValue != monthName) && (loopCounter < 5))
                    {
                        MonthField.SetValue(monthName.Substring(0, 1));
                        Waiter.Until(d => MonthField.GetValue() != monthFieldValue);
                        monthFieldValue = MonthField.GetValue();
                        loopCounter++;
                    }

                    //Throw exception if can't set the month field
                    if (monthFieldValue != monthName)
                    {
                        throw new Exception();
                    }
                    YearField.SetValue(updatedDate.ToString("yyyy"));
                }
                catch (WebDriverException ex)
                {
                    throw new WebDriverException("Date field can't be set properly. Expected date: " + updatedDate.ToString("dd-MMM-yyyy") +
                                                        ".Actual date: " + DayField.GetValue() + "-" + MonthField.GetValue() + "-" + YearField.GetValue() + " .. " + ex);
                }
                
            }
        }


        public void AssertValue(string date)
        {
            if (!String.IsNullOrEmpty(date))
            {
                var comparisonDate = DateTime.Parse(date).Date;
                var dateInElement = DateTime.Parse(Element.FindElement(By.CssSelector("input")).GetAttribute("value"))
                    .Date;
                Assert.AreEqual(comparisonDate, dateInElement,
                    string.Format("Expected date of element {0} to be {1} but it was {2}", CssSelectorString,
                        comparisonDate, dateInElement));
            }
            else
            {
                Assert.AreEqual(date, Element.FindElement(By.CssSelector("input")).GetAttribute("value"),
                    string.Format("Expected date of element {0} to be {1} but it was {2}", CssSelectorString, date,
                        Element.GetAttribute("value")));
            }
        }

        public DateTime? ParsedDate(string date)
        {
            if (string.IsNullOrEmpty(date)) return null;

            DateTime? parsedDate = null;
            switch (date)
            {
                case "Current Date":
                    parsedDate = DateTime.Now;
                    break;
                case "Tomorrow":
                    parsedDate = DateTime.Now.AddDays(1);
                    break;
                case "Next Week":
                    parsedDate = DateTime.Now.AddDays(7);
                    break;
                case "Next Month":
                    parsedDate = DateTime.Now.AddMonths(1);
                    break;
                case "Yesterday":
                    parsedDate = DateTime.Today.AddDays(-1);
                    break;
                default:
                    parsedDate = DateTime.Parse(date);
                    break;
            }
            return parsedDate;
        }

        public void AssertDateEquals(string date)
        {
            switch (date)
            {
                case "Current Date":
                    date = DateTime.Now.ToString("yyyy-MM-dd");
                    break;
                case "Tomorrow":
                    date = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd");
                    break;
                case "Next Week":
                    date = DateTime.Now.AddDays(7).ToString("yyyy-MM-dd");
                    break;
                case "Next Month":
                    date = DateTime.Now.AddMonths(1).ToString("yyyy-MM-dd");
                    break;
                default:
                    date = DateTime.Parse(date).ToString("yyyy-MM-dd");
                    break;
            }

            var dateElement = Element.FindElement(By.TagName("input"));
            Assert.AreEqual(date, dateElement.GetAttribute("value"));

        }
    }
}
