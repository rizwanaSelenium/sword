﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularMultiSelectResourcePickerField : BaseAngularField
    {
        private readonly IWebElement _input;

        public AngularMultiSelectResourcePickerField(IWebDriver driver, WebDriverWait waiter, string id) :
            base(driver, waiter, id)
        {
            _input = Element.FindElement(By.TagName("input"));

        }

        

        public void AssertEquals(string text)
        {
            _input.SendKeys(text);
            throw new NotImplementedException();
        }

        public void AppendValue(string text)
        {
            throw new NotImplementedException();
        }
    }
}
