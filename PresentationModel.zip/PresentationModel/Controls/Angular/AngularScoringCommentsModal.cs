﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace PresentationModel.Controls.Angular
{
    public class AngularScoringCommentsModal: AngularModal
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private readonly IWebElement _element;
        private AngularMultiLineTextField _scoringComments;
        private AngularButton _scoringChange;

        public AngularScoringCommentsModal(IWebDriver driver, WebDriverWait waiter): base(driver, waiter)
       {
            _driver = driver;
            _waiter = waiter;
           _element = Element;
       }

       public AngularMultiLineTextField ScoringComments
       {
           get
           {
               return _scoringComments ?? (_scoringComments = new AngularMultiLineTextField(_driver, _waiter, "scoringChangeCommentsBody", false, false));
           }
       }

       public AngularButton ScoringChange
       {
           get
           {
               return _scoringChange ?? (_scoringChange = new AngularButton(_driver, _waiter, "span[id*='changeCommentScoreTab']"));
           }
       }

        public void AssertScoringChangeCommentsErrorMessage()
        {

            var errorMessage = _element.FindElement(By.Id("changeCommentsValidationMsg"));
            Assert.AreEqual("Please enter a scoring change comment", errorMessage.Text);
        }

    }
}
