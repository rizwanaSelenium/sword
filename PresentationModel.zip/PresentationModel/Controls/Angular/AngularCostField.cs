﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.Angular
{
    public class AngularCostField : BaseAngularField
    {
        private readonly IWebElement _input;

        public AngularCostField(IWebDriver driver, WebDriverWait waiter, string id, bool hasObject = true, bool hasLabel = true, bool readOnly = false) :
            base(driver, waiter, id, hasObject, hasLabel)
        {
            if (!readOnly)
                _input = Element.FindElement(By.CssSelector("input"));
            else
            {
                _input = Element.FindElement(By.CssSelector("arm-numeric-input"));
            }
        }

        public void SetValue(string value)
        {
            _input.Clear();
            _input.SendKeys(value);
        }

        public void AssertEquals(string text)
        {
            Assert.AreEqual(_input.Text, text);
        }

        public void AppendValue(string text)
        {
            _input.SendKeys(Keys.End);
            _input.SendKeys(text);
        }

        public void AssertReadOnlyField(string text)
        {
            Waiter.Until(d => _input.GetAttribute("ng-reflect-model") != "0");
            Assert.AreEqual(text, _input.GetAttribute("ng-reflect-model"));
        }
    }
}
