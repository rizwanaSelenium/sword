﻿using System;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace PresentationModel
{
    public static class WebDriverExtensions
    {
        public static void WaitForAjaxToComplete(this IWebDriver driver)
        {
            bool ajaxComplete = false;

            for (var a = 1; a < 30; a++)
            {
                Thread.Sleep(1000);
                if ((bool) ExecuteScript(driver, "return jQuery.active == 0"))
                {
                    ajaxComplete = true;
                    break;
                }
                
            }

            if (!ajaxComplete)
            {
                Console.WriteLine("**************");
                Console.WriteLine("Was waiting for Ajax Jquery to return 0 but it did not complete whilst I was waiting");
                Console.WriteLine("**************");
            }
        }

        public static bool IsAjaxRequestInProgress(this IWebDriver driver)
        {
            return (bool) ExecuteScript(driver, "return (window['AjaxRequestInProgress'] != null) && window.AjaxRequestInProgress()");
        }

        public static bool IsInitialDataLoadComplete(this IWebDriver driver)
        {
            return (bool) ExecuteScript(driver, "return (window['InitialDataLoadComplete'] != null) && window.InitialDataLoadComplete()");
        }

        
        public static object ExecuteScript(this IWebDriver driver, string script, params object[] args)
        {
            try
            {
                return ((IJavaScriptExecutor) driver).ExecuteScript(script, args);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.WriteLine("SCRIPT THAT FAILED TO EXECUTE:");
                Console.WriteLine(script);
                throw;
            }
        }
        
        public static bool HasWindowWithName(this IWebDriver driver, string name)
        {
            foreach (var window in driver.WindowHandles)
            {
                driver.SwitchTo().Window(window);
                if (driver.Url.ToLower().Contains(name.ToLower()))
                    return true;
            }

            return false;
        }

        public static bool HasHelpWindowWithName(this IWebDriver driver, string name)
        {
            string winHandleBefore = driver.CurrentWindowHandle;
            bool helpWindowFound = false;
            foreach (var handle in driver.WindowHandles)
            {
                if (handle != winHandleBefore)
                {
                    driver.SwitchTo().Window(handle);
                    if (driver.Title.Contains("Online Help"))
                    {
                        helpWindowFound = true;
                        Assert.IsTrue(driver.Url.Contains(name));
                        driver.SwitchTo().Window(winHandleBefore);
                        break;
                    }

                }
            }
            driver.SwitchTo().Window(winHandleBefore);
            if (!helpWindowFound)
            {
                Assert.Fail("Help window not located");
            }
            return true;
        }

        public static bool HasAlertWindow(this IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (Exception ex)
            {
                if(ex is NoAlertPresentException || ex is NoSuchWindowException)
                    return false;

                throw;
            }
        }

        public static void RightClickOnElement(this IWebDriver driver, IWebElement element)
        {
            Actions action = new Actions(driver);
            action.MoveToElement(element);
            action.ContextClick(element).Build().Perform();
        }

        public static string GetEnumDescription(this Enum value)
        {
            var fi = value.GetType().GetField(value.ToString());
            var attributes = (System.ComponentModel.DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes.Length > 0 ? attributes[0].Description : value.ToString();
        }

        public static void ForEach<T>(this IEnumerable<T> collection, Action<T> action)
        {
            foreach (var thing in collection)
            {
                action(thing);
            }
        }
    }
}
