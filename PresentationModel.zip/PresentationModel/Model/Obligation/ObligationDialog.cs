﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;

namespace PresentationModel.Model.Obligation
{
    public class ObligationDialog : ComplianceComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private AngularMultiLineTextField _title;
        private AngularSingleLineTextField _id;
        private AngularMultiLineTextField _description;
        private AngularMultiLineTextField _practicalGuidance;
        private AngularMultiLineTextField _remediation;
        private AngularMultiLineTextField _consequence;
        private AngularMultiLineTextField _complianceSource;
        private AngularResourcePickerField _owner;
        private AngularResourcePickerField _approver;
        private AngularCheckboxField _archived;
        private AngularDatePickerField _created;
        private AngularDatePickerField _due;
        private AngularDatePickerField _sourceUpdated;
        private AngularDropdownListField _category;
        private AngularDropdownListField _complianceStatus;
        private AngularDropdownListField _approvalStatus;
        private AngularDatePickerField _approvalDate;
        private AngularDatePickerField _lastUpdated;
        private AngularMultiSelectTreeField _tree1;
        private AngularMultiSelectTreeField _tree2;
        private AngularMultiSelectDropdownField _multiSelect1;
        private AngularMultiSelectDropdownField _multiSelect2;
        private AngularMultiSelectDropdownField _multiSelect3;
        private AngularMultiSelectTreeTableField _applicableAreas;
        private AngularSingleLineTextField _assessmentTitle;
        private AngularDropdownListField _recurrence;
        private AngularDatePickerField _nextPublishDate;
        private AngularSingleLineTextField _assessmentSubject;
        private AngularMultiLineTextField _assessmentBody;
        private AngularSurveyQuestionCreator _assessmentQuestion;

        public ObligationDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Compliance")
        {
            _driver = driver;
            _waiter = waiter;
        }

        public AngularMultiSelectDropdownField MultiSelect1
        {
            get { return _multiSelect1 ?? (_multiSelect1 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_816")); }
        }

        public AngularMultiSelectDropdownField MultiSelect2
        {
            get { return _multiSelect2 ?? (_multiSelect2 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_817")); }
        }

        public AngularMultiSelectDropdownField MultiSelect3
        {
            get { return _multiSelect3 ?? (_multiSelect3 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_818")); }
        }
        
        public AngularMultiSelectTreeField Tree1
        {
            get { return _tree1 ?? (_tree1 = new AngularMultiSelectTreeField(_driver, _waiter, "field_819")); }
        }

        public AngularMultiSelectTreeField Tree2
        {
            get { return _tree2 ?? (_tree2 = new AngularMultiSelectTreeField(_driver, _waiter, "field_820")); }
        }

        public AngularSingleLineTextField Id
        {
            get { return _id ?? (_id = new AngularSingleLineTextField(_driver, _waiter, "field_800")); }
        }

        public AngularMultiLineTextField Title
        {
            get { return _title ?? (_title = new AngularMultiLineTextField(_driver, _waiter, "field_801")); }

        }

        public AngularMultiLineTextField Description
        {
            get { return _description ?? (_description = new AngularMultiLineTextField(_driver, _waiter, "field_806")); }
        }


        public AngularMultiLineTextField PracticalGuidance
        {
            get { return _practicalGuidance ?? (_practicalGuidance = new AngularMultiLineTextField(_driver, _waiter, "field_807")); }
        }

        public AngularMultiLineTextField Remediation
        {
            get { return _remediation ?? (_remediation = new AngularMultiLineTextField(_driver, _waiter, "field_808")); }
        }

        public AngularMultiLineTextField Consequence
        {
            get { return _consequence ?? (_consequence = new AngularMultiLineTextField(_driver, _waiter, "field_809")); }
        }

        public AngularMultiLineTextField ComplianceSource
        {
            get { return _complianceSource ?? (_complianceSource = new AngularMultiLineTextField(_driver, _waiter, "field_810")); }
        }

        public AngularDatePickerField ApprovalDate
        {
            get { return _approvalDate ?? (_approvalDate = new AngularDatePickerField(_driver, _waiter, "field_821")); }
        }

        public AngularDatePickerField LastUpdated
        {
            get { return _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(_driver, _waiter, "field_822")); }
        }

        public AngularResourcePickerField Owner
        {
            get { return _owner ?? (_owner = new AngularResourcePickerField(_driver, _waiter, "field_812")); }
        }

        public AngularResourcePickerField Approver
        {
            get { return _approver ?? (_approver = new AngularResourcePickerField(_driver, _waiter, "field_813")); }
        }

        public AngularCheckboxField Archived
        {
            get { return _archived ?? (_archived = new AngularCheckboxField(_driver, _waiter, "field_805")); }
        }

        public AngularDropdownListField Category
        {
            get { return _category ?? (_category = new AngularDropdownListField(_driver, _waiter, "field_811")); }
        }

        public AngularDropdownListField ComplianceStatus
        {
            get { return _complianceStatus ?? (_complianceStatus = new AngularDropdownListField(_driver, _waiter, "field_814")); }
        }

        public AngularDropdownListField ApprovalStatus
        {
            get { return _approvalStatus ?? (_approvalStatus = new AngularDropdownListField(_driver, _waiter, "field_815")); }
        }

       public AngularDatePickerField Created
        {
            get { return _created ?? (_created = new AngularDatePickerField(_driver, _waiter, "field_802")); }
        }

        public AngularDatePickerField Due
        {
            get { return _due ?? (_due = new AngularDatePickerField(_driver, _waiter, "field_804")); }
        }

        public AngularDatePickerField SourceUpdated
        {
            get { return _sourceUpdated ?? (_sourceUpdated = new AngularDatePickerField(_driver, _waiter, "field_803")); }
        }

        public AngularMultiSelectTreeTableField ApplicableAreas
        {
            get { return _applicableAreas ?? (_applicableAreas = new AngularMultiSelectTreeTableField(_driver, _waiter, "field_823_object")); }
        }

        public AngularSingleLineTextField AssessmentTitle
        {
            get { return _assessmentTitle ?? (_assessmentTitle = new AngularSingleLineTextField(_driver, _waiter, "field_857")); }
        }

        public AngularDropdownListField Recurrence
        {
            get { return _recurrence ?? (_recurrence = new AngularDropdownListField(_driver, _waiter, "field_854")); }
        }

        public AngularDatePickerField NextPublishDate
        {
            get { return _nextPublishDate ?? (_nextPublishDate = new AngularDatePickerField(_driver, _waiter, "field_855")); }
        }

        public AngularSingleLineTextField AssessmentSubject
        {
            get { return _assessmentSubject ?? (_assessmentSubject = new AngularSingleLineTextField(_driver, _waiter, "field_858")); }
        }

        public AngularMultiLineTextField AssessmentBody
        {
            get { return _assessmentBody ?? (_assessmentBody = new AngularMultiLineTextField(_driver, _waiter, "field_859")); }
        }

        public AngularSurveyQuestionCreator AssessmentQuestion
        {
            get { return _assessmentQuestion ?? (_assessmentQuestion = new AngularSurveyQuestionCreator(_driver, _waiter, "field_860")); }
        }

        public new void ClearParameters()
        {
            _title = null;
            _id = null;
            _description = null;
            _practicalGuidance = null;
            _remediation = null;
            _consequence = null;
            _complianceSource = null;
            _owner = null;
            _approver = null;
            _archived = null;
            _created = null;
            _due = null;
            _approvalDate = null;
            _lastUpdated = null;
            _sourceUpdated = null;
            _category = null;
            _complianceStatus = null;
            _approvalStatus = null;
            _multiSelect1 = null;
            _multiSelect2 = null;
            _multiSelect3 = null;
            _tree1 = null;
            _tree2 = null;
        }
    }
}
