﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class RiskComponent : WebDriverArmPage
    {
        public RiskComponent(IWebDriver driver, WebDriverWait waiter, string pageName = null) : base(driver, waiter, pageName ?? "")
        {
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        private IWebElement _riskNavButton;
        public IWebElement RiskNavButton
        {
            get
            {
                return _riskNavButton ?? (_riskNavButton = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("Risk_nav_button"))));
            }
        }

        private IWebElement _scoringNavButton;
        public IWebElement ScoringNavButton
        {
            get
            {
                return _scoringNavButton ?? (_scoringNavButton = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("Scoring_nav_button"))));
            }
        }

        private IWebElement _planNavButton;
        public IWebElement PlanNavButton
        {
            get
            {
                return _planNavButton ?? (_planNavButton = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("Plan_nav_button"))));
            }
        }

        private AngularButton _responseNavButton;
        public AngularButton ResponseNavButton
        {
            get { return _responseNavButton ?? (_responseNavButton = new AngularButton(Driver, Waiter, "#Response_nav_button")); }
        }

        private AngularButton _evaluationNavButton;
        public AngularButton EvaluationNavButton
        {
            get { return _evaluationNavButton ?? (_evaluationNavButton = new AngularButton(Driver, Waiter, "#Evaluation_nav_button")); }
        }

        private AngularButton _testNavButton;
        public AngularButton TestNavButton
        {
            get { return _testNavButton ?? (_testNavButton = new AngularButton(Driver, Waiter, "#Test_nav_button")); }
        }

        private AngularButton _deficiencyNavButton;
        public AngularButton DeficiencyNavButton
        {
            get { return _deficiencyNavButton ?? (_deficiencyNavButton = new AngularButton(Driver, Waiter, "#Deficiency_nav_button")); }
        }

        private AngularButton _ratingNavButton;
        public AngularButton RatingNavButton
        {
            get { return _ratingNavButton ?? (_ratingNavButton = new AngularButton(Driver, Waiter, "#Rating_nav_button")); }
        }

        private AngularButton _remediationPlanNavButton;
        public AngularButton RemediationPlanNavButton
        {
            get { return _remediationPlanNavButton ?? (_remediationPlanNavButton = new AngularButton(Driver, Waiter, "span[id^='Remediation'][id*='Plan_nav_button']")); }
        }

        private IWebElement _riskNavIcon;
        public IWebElement RiskNavIcon
        {
            get
            {
                return _riskNavIcon ?? (_riskNavIcon = Waiter.Until( SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-bolt"))));
            }
        }

        private IWebElement _scoringNavIcon;
        public IWebElement ScoringNavIcon
        {
            get
            {
                return _scoringNavIcon ??(_scoringNavIcon = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-th"))));
            }
        }

        private IWebElement _planNavIcon;
        public IWebElement PlanNavIcon
        {
            get
            {
                return _planNavIcon ?? (_planNavIcon = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-lightbulb-exclamation"))));
            }
        }

        private IWebElement _responseNavIcon;
        public IWebElement ResponseNavIcon
        {
            get
            {
                return _responseNavIcon ?? (_responseNavIcon = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-walking"))));
            }
        }

        private IWebElement _expandArrow;
        public IWebElement ExpandArrow
        {
            get
            {
                return _expandArrow ?? (_expandArrow = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-long-arrow-right"))));
            }
        }

        private IWebElement _collapseArrow;
        public IWebElement CollapseArrow
        {
            get
            {
                return _collapseArrow ?? (_collapseArrow = Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.CssSelector(".fa-long-arrow-left"))));
            }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get
            {
                Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("Save")));
                return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "Save"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "Close")); }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "Ok")); }
        }

        private WebDriverButton _detailsButton;
        public WebDriverButton DetailsButton
        {
            get
            {
                return _detailsButton ?? (_detailsButton = new WebDriverButton(Driver, Waiter, "details-tab-button"));
            }
        }

        private WebDriverButton _documentsButton;
        public WebDriverButton DocumentsButton
        {
            get
            {
                return _documentsButton ??
                       (_documentsButton = new WebDriverButton(Driver, Waiter, "documents-tab-button"));
            }
        }

        private WebDriverButton _historyButton;
        public WebDriverButton HistoryButton
        {
            get
            {
                return _historyButton ?? (_historyButton = new WebDriverButton(Driver, Waiter, "history-tab-button"));
            }
        }

        private WebDriverButton _chartsButton;
        public WebDriverButton ChartsButton
        {
            get { return _chartsButton ?? (_chartsButton = new WebDriverButton(Driver, Waiter, "charts-tab-button")); }
        }

        private WebDriverButton _armVisualizerButton;
        public WebDriverButton ArmVisualizerButton
        {
            get
            {
                return _armVisualizerButton ??
                       (_armVisualizerButton = new WebDriverButton(Driver, Waiter, "visualiser-tab-button"));
            }
        }

        private IWebElement _riskChangeIndicator;
        public IWebElement RiskChangeIndicator
        {
            get
            {
                _riskChangeIndicator = Driver.FindElement(By.Id("RiskChangeIndicator"));
                return _riskChangeIndicator;
            }
        }

        private IWebElement _scoringChangeIndicator;
        public IWebElement ScoringChangeIndicator
        {
            get
            {
                _scoringChangeIndicator = Driver.FindElement(By.Id("ScoringChangeIndicator"));
                return _scoringChangeIndicator;
            }
        }

        private IWebElement _responseChangeIndicator;
        public IWebElement ResponseChangeIndicator
        {
            get
            {
                _responseChangeIndicator = Driver.FindElement(By.Id("ResponseChangeIndicator"));
                return _responseChangeIndicator;
            }
        }

        private IWebElement _planChangeIndicator;
        public IWebElement PlanChangeIndicator
        {
            get
            {
                _planChangeIndicator = Driver.FindElement(By.Id("PlanChangeIndicator"));
                return _planChangeIndicator;
            }
        }

        private IWebElement _evaluationChangeIndicator;
        public IWebElement EvaluationChangeIndicator
        {
            get
            {
                _evaluationChangeIndicator = Driver.FindElement(By.Id("EvaluationChangeIndicator"));
                return _evaluationChangeIndicator;
            }
        }

        private IWebElement _testChangeIndicator;
        public IWebElement TestChangeIndicator
        {
            get
            {
                _testChangeIndicator = Driver.FindElement(By.Id("TestChangeIndicator"));
                return _testChangeIndicator;
            }
        }

        private IWebElement _deficiencyChangeIndicator;
        public IWebElement DeficiencyChangeIndicator
        {
            get
            {
                _deficiencyChangeIndicator = Driver.FindElement(By.Id("DeficiencyChangeIndicator"));
                return _deficiencyChangeIndicator;
            }
        }

        private IWebElement _ratingChangeIndicator;
        public IWebElement RatingChangeIndicator
        {
            get
            {
                _ratingChangeIndicator = Driver.FindElement(By.Id("RatingChangeIndicator"));
                return _ratingChangeIndicator;
            }
        }

        private IWebElement _remediationPlanChangeIndicator;
        public IWebElement RemediationPlanChangeIndicator
        {
            get
            {
                _remediationPlanChangeIndicator = Driver.FindElement(By.CssSelector("span[id^='Remediation'][id*='PlanChangeIndicator']"));
                return _remediationPlanChangeIndicator;
            }
        }

        private AngularRiskNavigationPanel _navigationPanel;
        public AngularRiskNavigationPanel NavigationPanel
        {
            get
            {
                if (_navigationPanel == null)
                {
                    _navigationPanel = new AngularRiskNavigationPanel(Driver, Waiter);
                }

                return _navigationPanel;
            }
        }

        private IWebElement _panelHeaderlabel;
        public IWebElement PanelHeaderLabel
        {
            get
            {
                _panelHeaderlabel = Driver.FindElement(By.CssSelector(".dialogDetailsMainPanelHeaderLabel"));
                return _panelHeaderlabel;
            }
        }

        private RiskDetailComponent _riskDetail;
        public RiskDetailComponent RiskDetail
        {
            get
            {
                if (_riskDetail == null)
                {
                    _riskDetail = new RiskDetailComponent(Driver, Waiter);
                }

                return _riskDetail;
            }
        }

        private ImpactComponent _impact;
        public ImpactComponent Impact
        {
            get
            {
                if (_impact == null)
                {
                    _impact = new ImpactComponent(Driver, Waiter);
                }

                return _impact;
            }
        }


        private ResponseComponent _response;
        public ResponseComponent Response
        {
            get
            {
                if (_response == null)
                {
                    _response = new ResponseComponent(Driver, Waiter);
                }

                return _response;
            }
        }

        private PlanComponent _plan;
        public PlanComponent Plan
        {
            get
            {
                if (_plan == null)
                {
                    _plan = new PlanComponent(Driver, Waiter);
                }

                return _plan;
            }
        }

        private EvaluationComponent _evaluation;
        public EvaluationComponent Evaluation
        {
            get
            {
                if (_evaluation == null)
                {
                    _evaluation = new EvaluationComponent(Driver, Waiter);
                }

                return _evaluation;
            }
        }

        private TestComponent _test;
        public TestComponent Test
        {
            get
            {
                if (_test == null)
                {
                    _test = new TestComponent(Driver, Waiter);
                }

                return _test;
            }
        }

        private DeficiencyComponent _deficiency;
        public DeficiencyComponent Deficiency
        {
            get
            {
                if (_deficiency == null)
                {
                    _deficiency = new DeficiencyComponent(Driver, Waiter);
                }

                return _deficiency;
            }
        }

        private RatingComponent _rating;
        public RatingComponent Rating
        {
            get
            {
                if (_rating == null)
                {
                    _rating = new RatingComponent(Driver, Waiter);
                }

                return _rating;
            }
        }

        private RemediationPlanComponent _remediationPlan;
        public RemediationPlanComponent RemediationPlan
        {
            get
            {
                if (_remediationPlan == null)
                {
                    _remediationPlan = new RemediationPlanComponent(Driver, Waiter);
                }

                return _remediationPlan;
            }
        }

        public void ExpandNavigationPanel()
        {

            WaitUntilUiSpinnerIsNotDisplayed();
            for (var i = 0; i < 15; i++)
            {
                Thread.Sleep(1000);
                var count = Driver.FindElements(By.CssSelector(".fa-long-arrow-right")).Count;
                if (count == 1)
                {
                    ExpandArrow.Click();
                    Waiter.Until(d => CollapseArrow.Displayed);
                    break;
                }
                var collapseArrow = Driver.FindElements(By.CssSelector(".fa-long-arrow-left")).Count;
                if (collapseArrow == 1) break;

                if (i == 14)
                {
                    throw new Exception("Expand Navigation Arrow not displayed in Risk Component.");
                }
            }
        }

        public bool IsIndicatorVisible(string id)
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            var indicator = Driver.FindElements(By.Id(id)).Where(e => e.Displayed);
            return indicator.Any();
        }

        private AngularHeaderText _folderName;
        public AngularHeaderText FolderName
        {
            get
            {
                return _folderName ??
                       (_folderName =
                           new AngularHeaderText(Driver, Waiter, ".dialogDetailsOwningItem.ellipsisWrapping"));
            }
        }

        private AngularHeaderText _riskHeaderTitle;
        public AngularHeaderText RiskHeaderTitle
        {
            get
            {
                return _riskHeaderTitle ??
                       (_riskHeaderTitle =
                           new AngularHeaderText(Driver, Waiter, ".dialogDetailsHeaderRecordNavigationDiv"));
            }
        }

        private AngularHeaderText _riskHeaderId;
        public AngularHeaderText RiskHeaderId
        {
            get
            {
                return _riskHeaderId ??
                       (_riskHeaderId = new AngularHeaderText(Driver, Waiter, ".headerId"));
            }
        }

        private AngularHeaderText _riskHeaderTitleTooltip;
        public AngularHeaderText RiskHeaderTitleTooltip
        {
            get
            {
                return _riskHeaderTitleTooltip ??
                       (_riskHeaderTitleTooltip = new AngularHeaderText(Driver, Waiter, "label.ellipsisWrapping"));
            }
        }

        public AngularHeaderText RiskHeaderFolderToolTip;
        public AngularHeaderText RiskHeaderFolderTooltip
        {
            get
            {
                return RiskHeaderFolderToolTip ??
                       (RiskHeaderFolderToolTip = new AngularHeaderText(Driver, Waiter,
                           ".dialogDetailsOwningItem.ellipsisWrapping > span"));
            }
        }

        private AngularIcon _nextRecord;
        public AngularIcon NextRecordIcon
        {
            get
            {
                return _nextRecord ??
                       (_nextRecord = new AngularIcon(Driver, Waiter, ".fa-chevron-right"));
            }
        }

        private AngularIcon _previousRecord;
        public AngularIcon PreviousRecordIcon
        {
            get
            {
                return _previousRecord ??
                       (_previousRecord = new AngularIcon(Driver, Waiter, ".fa-chevron-left"));
            }
        }

        private AngularRiskReviewPanel _reviewPanel;
        public AngularRiskReviewPanel ReviewPanel
        {
            get
            {
                return _reviewPanel ??
                       (_reviewPanel = new AngularRiskReviewPanel(Driver, Waiter));
            }
        }

        private AngularRiskFeedbackPanel _feedbackPanel;
        public AngularRiskFeedbackPanel FeedbackPanel
        {
            get
            {
                return _feedbackPanel ??
                       (_feedbackPanel = new AngularRiskFeedbackPanel(Driver, Waiter));
            }
        }

        private WebDriverButton _closePanelButton;
        public WebDriverButton ClosePanelButton
        {
            get { return _closePanelButton ?? (_closePanelButton = new WebDriverButton(Driver, Waiter, "button[class='closePanel']", true)); }
        }

        public AngularAssessmentScoringSheetModal ScoringSheetDialog
        {
            get
            {
                return new AngularAssessmentScoringSheetModal(Driver, Waiter);
            }
        }

        public void AssertNoRiskIdNotPresentInHeader()
        {
            var count = Driver.FindElements(By.CssSelector(".headerId")).Count;
            Assert.True(count == 0);
        }

        public bool IsArmVisualizerVisible()
        {
            var armvisualizer = Driver.FindElements(By.Id("visualiser-tab-button"));
            return armvisualizer.Count > 0;
        }

        public bool RiskPanelHeaderLabel()
        {
            var riskPanelHeader = Driver.FindElements(By.CssSelector(".dialogDetailsMainPanelHeader"));
            return riskPanelHeader.Count > 0;
        }

        public AngularRiskInfoPanel GetPanel(string panelName)
        {
            switch (panelName)
            {
                case "Review":
                    return ReviewPanel;
                case "Feedback":
                    return FeedbackPanel;
                default:
                    Assert.Fail($"{panelName} panel not recognised");
                    break;
            }

            return null;
        }

        public bool AssertChangeIndicatorNotDisplayed(string tabname)
        {
            switch (tabname)
            {
                case "Response":
                    return Driver.FindElements(By.Id("ResponseChangeIndicator")).Count == 0;
                default:
                    return false;
            }    
        }

        public bool IsExtraOptionsPanelVisible()
        {
            try
            {
                Driver.FindElement(By.Id("extra-options-container"));
            }
            catch (NoSuchElementException)
            {
                return false;
            }
            return true;
        }

        public void Save()
        {
            SaveButton.Click();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public RiskComponent GetOpenRiskComponent()
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            return new RiskComponent(Driver, Waiter);
        }

        public void SelectScoringSection()
        {
            ExpandNavigationPanel();
            for (int i = 0; i < 3; i++)
            {
                ScoringNavButton.Click();
                Thread.Sleep(1000);
                if (Driver.FindElement(By.Id("Scoring_nav_section")).GetAttribute("class").Contains("sectionSelected"))
                {
                    break;
                }
                if (i == 2)
                {
                    throw new WebDriverException("Failed to move to Risk scoring section.");
                }
            }
        }
    }
}
