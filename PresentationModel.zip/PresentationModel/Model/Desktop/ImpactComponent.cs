﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class ImpactComponent : WebDriverArmPage
    {
        public ImpactComponent(IWebDriver driver, WebDriverWait waiter, string pageName = null) : base(driver, waiter, pageName ?? "")
        {
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        private AngularSingleLineTextField _item;
        public AngularSingleLineTextField Item
        {
            get { return _item ?? (_item = new AngularSingleLineTextField(Driver, Waiter, "field_45")); }
        }

        private AngularSingleLineTextField _roi;
        public AngularSingleLineTextField Roi
        {
            get { return _roi ?? (_roi = new AngularSingleLineTextField(Driver, Waiter, "field_46")); }
        }

        private AngularDropdownListField _scoringScheme;
        public AngularDropdownListField ScoringScheme
        {
            get
            {
                return _scoringScheme ?? (_scoringScheme = new AngularDropdownListField(Driver, Waiter, "field_47"));
            }
        }

        private AngularDropdownListField _impactGroup;
        public AngularDropdownListField ImpactGroup
        {
            get { return _impactGroup ?? (_impactGroup = new AngularDropdownListField(Driver, Waiter, "field_48")); }
        }

        private AngularDropdownListField _blackFlagType;
        public AngularDropdownListField BlackFlagType
        {
            get
            {
                return _blackFlagType ?? (_blackFlagType = new AngularDropdownListField(Driver, Waiter, "field_49"));
            }
        }

        private AngularMultiLineTextField _description;
        public AngularMultiLineTextField Description
        {
            get { return _description ?? (_description = new AngularMultiLineTextField(Driver, Waiter, "field_50")); }
        }

        private AngularAssessmentField _currentAssessment;
        public AngularAssessmentField CurrentAssessment
        {
            get
            {
                return _currentAssessment ??
                       (_currentAssessment = new AngularAssessmentField(Driver, Waiter, "field_51"));
            }
        }

        private AngularAssessmentField _targetAssessment;
        public AngularAssessmentField TargetAssessment
        {
            get
            {
                return _targetAssessment ??
                       (_targetAssessment = new AngularAssessmentField(Driver, Waiter, "field_54"));
            }
        }

        private AngularAssessmentField _inherentAssessment;
        public AngularAssessmentField InherentAssessment
        {
            get
            {
                return _inherentAssessment ??
                       (_inherentAssessment = new AngularAssessmentField(Driver, Waiter, "field_643"));
            }
        }

        private AngularDropdownListField _criteriaType;
        public AngularDropdownListField CriteriaType
        {
            get
            {
                return _criteriaType ?? (_criteriaType = new AngularDropdownListField(Driver, Waiter, "field_61"));
            }
        }

        private AngularDropdownListField _scoringType;
        public AngularDropdownListField ScoringType
        {
            get
            {
                return _scoringType ?? (_scoringType = new AngularDropdownListField(Driver, Waiter, "field_708"));
            }
        }

        private AngularDatePickerField _triggerDate;
        public AngularDatePickerField TriggerDate
        {
            get { return _triggerDate ?? (_triggerDate = new AngularDatePickerField(Driver, Waiter, "field_63")); }
        }

        private AngularDatePickerField _expiryDate;
        public AngularDatePickerField ExpiryDate
        {
            get { return _expiryDate ?? (_expiryDate = new AngularDatePickerField(Driver, Waiter, "field_64")); }
        }

        private AngularDatePickerField _targetResolutionDate;
        public AngularDatePickerField TargetResolutionDate
        {
            get
            {
                return _targetResolutionDate ??
                       (_targetResolutionDate = new AngularDatePickerField(Driver, Waiter, "field_65"));
            }
        }

        private AngularSingleLineTextField _id;
        public AngularSingleLineTextField Id
        {
            get { return _id ?? (_id = new AngularSingleLineTextField(Driver, Waiter, "field_104")); }
        }

        private AngularCostField _actualCost;
        public AngularCostField ActualCost
        {
            get { return _actualCost ?? (_actualCost = new AngularCostField(Driver, Waiter, "field_130")); }
        }

        private AngularDatePickerField _dateImpacted;
        public AngularDatePickerField DateImpacted
        {
            get { return _dateImpacted ?? (_dateImpacted = new AngularDatePickerField(Driver, Waiter, "field_131")); }
        }

        private AngularAssociationField _associations;
        public AngularAssociationField Associations
        {
            get
            {
                return _associations ?? (_associations = new AngularAssociationField(Driver, Waiter, "field_526"));
            }
        }

        private AngularSingleLineTextField _customText1;
        public AngularSingleLineTextField CustomText1
        {
            get
            {
                return _customText1 ?? (_customText1 = new AngularSingleLineTextField(Driver, Waiter, "field_646"));
            }
        }

        private AngularSingleLineTextField _customText2;
        public AngularSingleLineTextField CustomText2
        {
            get
            {
                return _customText2 ?? (_customText2 = new AngularSingleLineTextField(Driver, Waiter, "field_647"));
            }
        }

        private AngularDropdownListField _customList1;
        public AngularDropdownListField CustomList1
        {
            get { return _customList1 ?? (_customList1 = new AngularDropdownListField(Driver, Waiter, "field_648")); }
        }

        private AngularDropdownListField _customList2;
        public AngularDropdownListField CustomList2
        {
            get { return _customList2 ?? (_customList2 = new AngularDropdownListField(Driver, Waiter, "field_649")); }
        }

        private AngularDatePickerField _customDate1;
        public AngularDatePickerField CustomDate1
        {
            get { return _customDate1 ?? (_customDate1 = new AngularDatePickerField(Driver, Waiter, "field_650")); }
        }

        private AngularDatePickerField _lastUpdated;
        public AngularDatePickerField LastUpdated
        {
            get { return _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(Driver, Waiter, "field_677")); }
        }

        private AngularDropdownListField _weightType;
        public AngularDropdownListField WeightType
        {
            get { return _weightType ?? (_weightType = new AngularDropdownListField(Driver, Waiter, "field_687")); }
        }

        private AngularMultiSelectDropdownField _impactCategories;
        public AngularMultiSelectDropdownField ImpactCategories
        {
            get
            {
                return _impactCategories ??
                       (_impactCategories = new AngularMultiSelectDropdownField(Driver, Waiter, "field_693"));
            }
        }

        private AngularSingleLineTextField _riskTitle;
        public AngularSingleLineTextField RiskTitle
        {
            get { return _riskTitle ?? (_riskTitle = new AngularSingleLineTextField(Driver, Waiter, "field_694")); }
        }

        private AngularButton _scoringSheet;
        public AngularButton ScoringSheet
        {
            get { return _scoringSheet ?? (_scoringSheet = new AngularButton(Driver, Waiter, "field_694")); }
        }

        private AngularButton _noAssessmentButton;
        public AngularButton NoAssessmentButton
        {
            get
            {
                return _noAssessmentButton ?? (_noAssessmentButton = new AngularButton(Driver, Waiter, "#btnNoAssessment"));
            }
        }

        private AngularButton _riskLevelButton;
        public AngularButton RiskLevelButton
        {
            get
            {
                return _riskLevelButton ?? (_riskLevelButton = new AngularButton(Driver, Waiter, "#btnRiskLevel"));
            }
        }
        private AngularDropdownListField _probabilityFrequency;
        public AngularDropdownListField ProbabilityFrequency
        {
            get { return _probabilityFrequency ?? (_probabilityFrequency = new AngularDropdownListField(Driver, Waiter, "field_61")); }
        }    

        private AngularButton _impactHistoryButton;
        public AngularButton ImpactHistoryButton
        {
            get
            {
                return _impactHistoryButton ??
                       (_impactHistoryButton = new AngularButton(Driver, Waiter, "#btnImpactHistory"));
            }
        }

        public void ClicksOnNoAssessmentButtonInInherentAssessment()
        {
            try
            {
                Waiter.Until(d => d.FindElements(By.CssSelector("#btnNoAssessment")).Count > 0);
            }
            catch (WebDriverTimeoutException tex)
            {
                throw new WebDriverTimeoutException("Timed out trying to find Inherent Assessment button. " + tex);
            }
            Driver.ExecuteScript("arguments[0].scrollIntoView(true);", Driver.FindElement(By.CssSelector("#btnNoAssessment")));
            NoAssessmentButton.Click();
        }
    }
}
