﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class ResponseComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public ResponseComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _addResponseButton;
        public WebDriverButton AddResponseButton
        {
            get
            {
                return _addResponseButton ?? (_addResponseButton = new WebDriverButton(_driver,_waiter, "AddResponseBtn"));
            }

        }

        private AngularSingleLineTextField _responseId;
        public AngularSingleLineTextField ResponseId
        {
            get
            {
                return _responseId ?? (_responseId = new AngularSingleLineTextField(_driver, _waiter, "field_77"));
            }

        }

        private AngularMultiLineTextField _responsetitle;
        public AngularMultiLineTextField ResponseTitle
        {
            get
            {
                return _responsetitle ?? (_responsetitle = new AngularMultiLineTextField(_driver, _waiter, "field_78"));
            }

        }

        private AngularResourcePickerField _responseOwner;
        public AngularResourcePickerField Owner
        {
            get
            {
                return _responseOwner ?? (_responseOwner = new AngularResourcePickerField(_driver, _waiter, "field_12"));
            }
        }

        private AngularDatePickerField _dueDate;

        public AngularDatePickerField DueDate
        {
            get
            {
                return _dueDate ?? (_dueDate = new AngularDatePickerField(_driver, _waiter, "field_14"));

            }
        }

        private AngularDatePickerField _startDate;

        public AngularDatePickerField StartDate
        {
            get
            {
                return _startDate ?? (_startDate = new AngularDatePickerField(_driver, _waiter, "field_13"));

            }
        }

        private AngularDropdownListField _responseStatus;
        public AngularDropdownListField ResponseStatus
        {
            get
            {
                return _responseStatus ?? (_responseStatus = new AngularDropdownListField(_driver, _waiter, "field_79"));
            }
        }

        private AngularDropdownListField _responseTypeoptions;
        public AngularDropdownListField ResponseTypeOptions
        {
            get
            {
                return _responseTypeoptions ?? (_responseTypeoptions = new AngularDropdownListField(_driver, _waiter, "field_80"));
            }
        }

        private AngularResponseTargetScore _targetScore;
        public AngularResponseTargetScore TargetScore
        {
            get
            {
                return _targetScore ?? (_targetScore = new AngularResponseTargetScore(_driver, _waiter, "field_81"));
            }

        }

        private AngularSingleLineTextField _achievedScore;
        public AngularSingleLineTextField AchievedScore
        {
            get
            {
                return _achievedScore ?? (_achievedScore = new AngularSingleLineTextField(_driver, _waiter, "field_83"));
            }

        }

        private AngularDropdownListField _responsePriority;
        public AngularDropdownListField ResponsePriority
        {
            get
            {
                return _responsePriority ?? (_responsePriority = new AngularDropdownListField(_driver, _waiter, "field_10"));
            }
        }

        private AngularGridControl _responseGrid;
        public AngularGridControl ResponseGrid
        {
            get
            {
                return _responseGrid ?? (_responseGrid = new AngularGridControl(_driver, _waiter, "grid_5"));
            }
        }

        private AngularCostField _plannedCost;

        public AngularCostField PlannedCost
        {
            get { return _plannedCost ?? (_plannedCost = new AngularCostField(_driver, _waiter, "field_11", true, true)); }
        }

        private AngularCostField _plannedCostReadOnly;
        public AngularCostField PlannedCostReadOnly
        {
            get { return _plannedCostReadOnly ?? (_plannedCostReadOnly = new AngularCostField(_driver, _waiter, "field_11", true, true, true)); }
        }

        private AngularCostField _actualCost;

        public AngularCostField ActualCost
        {
            get { return _actualCost ?? (_actualCost = new AngularCostField(_driver, _waiter, "field_132", true, true, true)); }
        }

        private AngularCostField _expectedCost;

        public AngularCostField ExpectedCost
        {
            get { return _expectedCost ?? (_expectedCost = new AngularCostField(_driver, _waiter, "field_146", true, true, true)); }
        }

        private AngularDropdownListField _currency;
        public AngularDropdownListField Currency
        {
            get
            {
                return _currency ?? (_currency = new AngularDropdownListField(_driver, _waiter, "field_290"));
            }
        }

        private IWebElement _addResponseButtonDropDown;

        public IWebElement AddResponseButtonDropDown
        {
            get
            {
                _addResponseButtonDropDown = _driver.FindElement(By.CssSelector(".dropdown-menu.show"));
                return _addResponseButtonDropDown;
            }
        }

        private WebDriverButton _responseButtonActionType;
        public WebDriverButton ResponseButtonActionType
        {
            get
            {
                return _responseButtonActionType ?? (_responseButtonActionType = new WebDriverButton(_driver, _waiter, "ActionOption"));
            }
        }

        private WebDriverButton _responseButtonControlType;
        public WebDriverButton ResponseButtonControlType
        {
            get
            {
                return _responseButtonControlType ?? (_responseButtonControlType = new WebDriverButton(_driver, _waiter, "ControlOption"));
            }
        }

        private WebDriverButton _responseButtonFallbackType;
        public WebDriverButton ResponseButtonFallbackType
        {
            get
            {
                return _responseButtonFallbackType ?? (_responseButtonFallbackType = new WebDriverButton(_driver, _waiter, "FallbackOption"));
            }
        }


        private AngularDropdownListField _effectiveness;
        public AngularDropdownListField Effectiveness
        {
            get
            {
                return _effectiveness ?? (_effectiveness = new AngularDropdownListField(_driver, _waiter, "field_84"));
            }
        }


        private AngularDatePickerField _completionDate;
        public AngularDatePickerField Completion
        {
            get
            {
                return _completionDate ?? (_completionDate = new AngularDatePickerField(_driver, _waiter, "field_15"));

            }
        }


        private AngularSingleLineTextField _percentComplete;
        public AngularSingleLineTextField PercentComplete
        {
            get
            {
                return _percentComplete ?? (_percentComplete = new AngularSingleLineTextField(_driver, _waiter, "field_9"));
            }

        }


        private WebDriverResponseCostAssessmentDialogue _responseAssessmentDialogue;

        public WebDriverResponseCostAssessmentDialogue ResponseAssessmentDialogue
        {
            get
            {
                return _responseAssessmentDialogue ?? (_responseAssessmentDialogue = new WebDriverResponseCostAssessmentDialogue(_driver, _waiter));
            }
        }

        private AngularButton _responseCostAssessment;

        public AngularButton ResponseCostAssessment
        {
            get
            {
                return _responseCostAssessment ??
                       (_responseCostAssessment = new AngularButton(_driver, _waiter, "button[id='field_147_cost_threat_button']"));
            }
        }

        private AngularButton _viewTargetScoreAssessment;

        public AngularButton ViewTargetScoreAssessment
        {
            get
            {
                return _viewTargetScoreAssessment ??
                       (_viewTargetScoreAssessment = new AngularButton(_driver, _waiter, "button[id='field_81_target_score_button']"));
            }
        }

        public bool AssertAddResponseButtonDropdownNotDisplayed()
        {
            return _driver.FindElements(By.CssSelector(".dropdown-menu.show")).Count == 0;
        }
    }
}
