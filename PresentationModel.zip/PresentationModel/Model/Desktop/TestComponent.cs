﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class TestComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public TestComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }
        
        private WebDriverButton _addTestButton;
        public WebDriverButton AddTestButton
        {
            get
            {
                return _addTestButton ?? (_addTestButton = new WebDriverButton(_driver, _waiter, "AddTestBtn"));
            }

        }

        private AngularSingleLineTextField _testRef;
        public AngularSingleLineTextField Ref
        {
            get
            {
                return _testRef ?? (_testRef = new AngularSingleLineTextField(_driver, _waiter, "field_173"));
            }

        }

        private AngularMultiLineTextField _testTitle;
        public AngularMultiLineTextField Title
        {
            get
            {
                return _testTitle ?? (_testTitle = new AngularMultiLineTextField(_driver, _waiter, "field_174"));
            }

        }

        private AngularDropdownListField _testResult;
        public AngularDropdownListField Result
        {
            get
            {
                return _testResult ?? (_testResult = new AngularDropdownListField(_driver, _waiter, "field_175"));
            }
        }

        private AngularDropdownListField _testType;
        public AngularDropdownListField TestType
        {
            get
            {
                return _testType ?? (_testType = new AngularDropdownListField(_driver, _waiter, "field_156"));
            }
        }

        private AngularDropdownListField _testCondition;
        public AngularDropdownListField TestCondition
        {
            get
            {
                return _testCondition ?? (_testCondition = new AngularDropdownListField(_driver, _waiter, "field_157"));
            }
        }

        private AngularDropdownListField _testClassification;
        public AngularDropdownListField TestClassification
        {
            get
            {
                return _testClassification ?? (_testClassification = new AngularDropdownListField(_driver, _waiter, "field_158"));
            }
        }

        private AngularMultiLineTextField _testCustomField1;
        public AngularMultiLineTextField CustomField1
        {
            get
            {
                return _testCustomField1 ?? (_testCustomField1 = new AngularMultiLineTextField(_driver, _waiter, "field_159"));
            }

        }

        private AngularMultiLineTextField _testCustomField2;
        public AngularMultiLineTextField CustomField2
        {
            get
            {
                return _testCustomField2 ?? (_testCustomField2 = new AngularMultiLineTextField(_driver, _waiter, "field_160"));
            }

        }

        private AngularMultiLineTextField _testCustomField3;
        public AngularMultiLineTextField CustomField3
        {
            get
            {
                return _testCustomField3 ?? (_testCustomField3 = new AngularMultiLineTextField(_driver, _waiter, "field_161"));
            }

        }

        private AngularDatePickerField _testDate;

        public AngularDatePickerField Date
        {
            get
            {
                return _testDate ?? (_testDate = new AngularDatePickerField(_driver, _waiter, "field_176"));

            }
        }

        private AngularGridControl _gridTests;

        public AngularGridControl GridTests
        {
            get { return _gridTests ?? (_gridTests = new AngularGridControl(_driver, _waiter, "grid_16")); }
        }
    }
}

