﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class RemediationPlanComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public RemediationPlanComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _addRemediationPlanButton;
        public WebDriverButton AddRemediationPlanButton
        {
            get
            {
                return _addRemediationPlanButton ?? (_addRemediationPlanButton = new WebDriverButton(_driver, _waiter, "button[id^='AddRemediation'][id*='PlanBtn']", true));
            }

        }

        private AngularMultiLineTextField _remediationPlanDescription;
        public AngularMultiLineTextField Description
        {
            get
            {
                return _remediationPlanDescription ?? (_remediationPlanDescription = new AngularMultiLineTextField(_driver, _waiter, "field_485"));
            }

        }

        private AngularDropdownListField _remediationPlanStatus;
        public AngularDropdownListField Status
        {
            get
            {
                return _remediationPlanStatus ?? (_remediationPlanStatus = new AngularDropdownListField(_driver, _waiter, "field_486"));
            }
        }

        private AngularDropdownListField _remediationPlanCompletionVerifiedIn;
        public AngularDropdownListField CompletionVerifiedIn
        {
            get
            {
                return _remediationPlanCompletionVerifiedIn ?? (_remediationPlanCompletionVerifiedIn = new AngularDropdownListField(_driver, _waiter, "field_487"));
            }
        }

        private AngularMultiLineTextField _remediationPlanVerificationNote;
        public AngularMultiLineTextField VerificationNote
        {
            get
            {
                return _remediationPlanVerificationNote ?? (_remediationPlanVerificationNote = new AngularMultiLineTextField(_driver, _waiter, "field_488"));
            }

        }

        private AngularMultiLineTextField _remediationPlanCustomField1;
        public AngularMultiLineTextField CustomField1
        {
            get
            {
                return _remediationPlanCustomField1 ?? (_remediationPlanCustomField1 = new AngularMultiLineTextField(_driver, _waiter, "field_489"));
            }

        }

        private AngularDatePickerField _remediationPlanCompletionDate;

        public AngularDatePickerField CompletionDate
        {
            get
            {
                return _remediationPlanCompletionDate ?? (_remediationPlanCompletionDate = new AngularDatePickerField(_driver, _waiter, "field_504"));

            }
        }

        private AngularDatePickerField _remediationPlanLastUpdatedDate;

        public AngularDatePickerField LastUpdated
        {
            get
            {
                return _remediationPlanLastUpdatedDate ?? (_remediationPlanLastUpdatedDate = new AngularDatePickerField(_driver, _waiter, "field_673"));

            }
        }
    }
}
