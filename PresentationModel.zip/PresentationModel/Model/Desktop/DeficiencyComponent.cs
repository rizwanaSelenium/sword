﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class DeficiencyComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public DeficiencyComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _addDeficiencyButton;
        public WebDriverButton AddDeficiencyButton
        {
            get
            {
                return _addDeficiencyButton ?? (_addDeficiencyButton = new WebDriverButton(_driver, _waiter, "AddDeficiencyBtn"));
            }

        }

        private AngularSingleLineTextField _deficiencyId;
        public AngularSingleLineTextField Id
        {
            get
            {
                return _deficiencyId ?? (_deficiencyId = new AngularSingleLineTextField(_driver, _waiter, "field_464"));
            }

        }

        private AngularMultiLineTextField _deficiencyTitle;
        public AngularMultiLineTextField Title
        {
            get
            {
                return _deficiencyTitle ?? (_deficiencyTitle = new AngularMultiLineTextField(_driver, _waiter, "field_465"));
            }

        }

        private AngularDatePickerField _deficiencyDateRaised;

        public AngularDatePickerField DateRaised
        {
            get
            {
                return _deficiencyDateRaised ?? (_deficiencyDateRaised = new AngularDatePickerField(_driver, _waiter, "field_469"));

            }
        }

        private AngularDropdownListField _deficiencyStatus;
        public AngularDropdownListField Status
        {
            get
            {
                return _deficiencyStatus ?? (_deficiencyStatus = new AngularDropdownListField(_driver, _waiter, "field_466"));
            }
        }

        private AngularDropdownListField _deficiencyIdentifiedFrom;
        public AngularDropdownListField IdentifiedFrom
        {
            get
            {
                return _deficiencyIdentifiedFrom ?? (_deficiencyIdentifiedFrom = new AngularDropdownListField(_driver, _waiter, "field_463"));
            }
        }

        private AngularDropdownListField _deficiencyIdentifiedBy;
        public AngularDropdownListField IdentifiedBy
        {
            get
            {
                return _deficiencyIdentifiedBy ?? (_deficiencyIdentifiedBy = new AngularDropdownListField(_driver, _waiter, "field_467"));
            }
        }

        private AngularResourcePickerField _deficiencyRaisedBy;
        public AngularResourcePickerField RaisedBy
        {
            get
            {
                return _deficiencyRaisedBy ?? (_deficiencyRaisedBy = new AngularResourcePickerField(_driver, _waiter, "field_468"));
            }
        }
        
        private AngularDropdownListField _deficiencyType;
        public AngularDropdownListField DeficiencyType
        {
            get
            {
                return _deficiencyType ?? (_deficiencyType = new AngularDropdownListField(_driver, _waiter, "field_470"));
            }
        }

        private AngularDropdownListField _deficiencyControlComponent;
        public AngularDropdownListField ControlComponent
        {
            get
            {
                return _deficiencyControlComponent ?? (_deficiencyControlComponent = new AngularDropdownListField(_driver, _waiter, "field_471"));
            }
        }

        private AngularMultiLineTextField _deficiencyDescription;
        public AngularMultiLineTextField Description
        {
            get
            {
                return _deficiencyDescription ?? (_deficiencyDescription = new AngularMultiLineTextField(_driver, _waiter, "field_472"));
            }

        }

        private AngularMultiLineTextField _deficiencyCustomField1;
        public AngularMultiLineTextField CustomField1
        {
            get
            {
                return _deficiencyCustomField1 ?? (_deficiencyCustomField1 = new AngularMultiLineTextField(_driver, _waiter, "field_473"));
            }

        }

        private AngularMultiLineTextField _deficiencyCustomField2;
        public AngularMultiLineTextField CustomField2
        {
            get
            {
                return _deficiencyCustomField2 ?? (_deficiencyCustomField2 = new AngularMultiLineTextField(_driver, _waiter, "field_474"));
            }

        }
        
        private AngularMultiLineTextField _deficiencyResponseOwningItem;
        public AngularMultiLineTextField ResponseOwningItem
        {
            get
            {
                return _deficiencyResponseOwningItem ?? (_deficiencyResponseOwningItem = new AngularMultiLineTextField(_driver, _waiter, "field_516"));
            }

        }
    }
}

