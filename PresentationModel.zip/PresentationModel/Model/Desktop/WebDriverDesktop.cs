using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.NewAdmin;
using PresentationModel.Model.Activity;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.AlertConfiguration;
using PresentationModel.Model.Audit;
using PresentationModel.Model.BulkUpdate;
using PresentationModel.Model.BusinessArea;
using PresentationModel.Model.BusinessFolder;
using PresentationModel.Model.Charts;
using PresentationModel.Model.DocumentManagement;
using PresentationModel.Model.Export;
using PresentationModel.Model.Filter;
using PresentationModel.Model.Filtering;
using PresentationModel.Model.HistorySearch;
using PresentationModel.Model.Import;
using PresentationModel.Model.Incident_Desktop;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.NewAdmin.Configuration;
using PresentationModel.Model.NewSplashScreen;
using PresentationModel.Model.Portfolio;
using PresentationModel.Model.Process;
using PresentationModel.Model.Risk;
using PresentationModel.Model.RiskVisualiser;
using PresentationModel.Model.SurveyBuilder;

namespace PresentationModel.Model.Desktop
{
    public class WebDriverDesktop : WebDriverArmPage
    {
        private WebDriverDesktopSelector _gridSelector;
        public WebDriverDesktopSelector GridSelector
        {
            get { return _gridSelector ?? (_gridSelector = new WebDriverDesktopSelector(Driver, Waiter, "grid")); }
        }

        private WebDriverDesktopSelector _portfolioSelector;
        public WebDriverDesktopSelector PortfolioSelector
        {
            get { return _portfolioSelector ?? (_portfolioSelector = new WebDriverDesktopSelector(Driver, Waiter, "portfolio")); }
        }

        private WebDriverDesktopSelector _filterSelector;
        public WebDriverDesktopSelector FilterSelector
        {
            get { return _filterSelector ?? (_filterSelector = new WebDriverDesktopSelector(Driver, Waiter, "filter")); }
        }

        private WebDriverMenu _menu;
        public WebDriverMenu Menu => _menu ?? (_menu = new WebDriverMenu(Driver, Waiter, "AV_Menu_menu"));

        private WebDriverButton _filterButton;
        public WebDriverButton FilterButton
        {
            get { return _filterButton ?? (_filterButton = new WebDriverButton(Driver, Waiter, "div.ui-state-default.filter-launcher", true)); }
        }

        private WebDriverButton _pasteButton;
        public WebDriverButton PasteButton
        {
            get { return _pasteButton ?? (_pasteButton = new WebDriverButton(Driver, Waiter, "AV_Paste_btn")); }
        }

        private WebDriverButton _pidButton;
        public WebDriverButton PidButton
        {
            get { return _pidButton ?? (_pidButton = new WebDriverButton(Driver, Waiter, "AV_Pid_btn")); }
        }

        private DesktopGridTableControl _riskIssuesGrid;
        public DesktopGridTableControl RiskIssuesGrid
        {
            get { return _riskIssuesGrid ?? (_riskIssuesGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RiskList_RisksTable", "Risk")); }
        }

        private DesktopGridTableControl _planGrid;
        public DesktopGridTableControl PlanGrid
        {
            get { return _planGrid ?? (_planGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_PlanList_PlansTable", "plan")); }
        }

        private DesktopGridTableControl _deficiencyGrid;
        public DesktopGridTableControl DeficiencyGrid
        {
            get { return _deficiencyGrid ?? (_deficiencyGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_DeficiencyList_DeficienciesTable", "deficiency")); }
        }

        private DesktopGridTableControl _evaluationGrid;
        public DesktopGridTableControl EvaluationGrid
        {
            get { return _evaluationGrid ?? (_evaluationGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_EvaluationList_EvaluationsTable", "evaluation")); }
        }

        private DesktopGridTableControl _responseGrid;
        public DesktopGridTableControl ResponseGrid
        {
            get { return _responseGrid ?? (_responseGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_ResponseList_ResponsesTable", "Response")); }
        }

        private DesktopGridTableControl _incidentGrid;
        public DesktopGridTableControl IncidentGrid
        {
            get { return _incidentGrid ?? (_incidentGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_IncidentList_IncidentsTable", "Incident")); }
        }

        private DesktopGridTableControl _documentGrid;
        public DesktopGridTableControl DocumentGrid
        {
            get { return _documentGrid ?? (_documentGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_DocumentList_DocumentsTable", "Document Vault")); }
        }

        private DesktopGridTableControl _incidentResponseGrid;
        public DesktopGridTableControl IncidentResponseGrid
        {
            get { return _incidentResponseGrid ?? (_incidentResponseGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_IncidentResponseList_IncidentResponsesTable", "Incident Response")); }
        }

        private WebDriverTableControl _investigationGrid;
        public WebDriverTableControl InvestigationGrid
        {
            get { return _investigationGrid ?? (_investigationGrid = new WebDriverTableControl(Driver, Waiter, "AV_Grids_InvestigationList_InvestigationsTable")); }
        }

        private DesktopGridTableControl _relatedIncidentGrid;
        public DesktopGridTableControl RelatedIncidentGrid
        {
            get { return _relatedIncidentGrid ?? (_relatedIncidentGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RelatedIncidentList_RelatedIncidentsTable", "Incident")); }
        }

        private DesktopGridTableControl _auditGrid;
        public DesktopGridTableControl AuditGrid
        {
            get { return _auditGrid ?? (_auditGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_AuditList_AuditsTable", "Audit")); }
        }

        private WebDriverTableControl _scoringGrid;
        public WebDriverTableControl ScoringGrid
        {
            get { return _scoringGrid ?? (_scoringGrid = new WebDriverTableControl(Driver, Waiter, "AV_Grids_ImpactList_ImpactsTable")); }
        }

        private DesktopGridTableControl _alertGrid;
        public DesktopGridTableControl AlertGrid
        {
            get { return _alertGrid ?? (_alertGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_AlertList_AlertsTable", "Alert")); }
        }

        public DesktopTree ActivityTree
        {
            get { return new DesktopTree(Driver, Waiter, "ActivityTree"); }
        }

        public DesktopTree RequirementsTree
        {
            get { return new DesktopTree(Driver, Waiter, "RequirementsTree"); }
        }

        public DesktopTree AssetsTree
        {
            get { return new DesktopTree(Driver, Waiter, "AssetsTree"); }
        }

        public DesktopTree KpisTree
        {
            get { return new DesktopTree(Driver, Waiter, "KPIsTree"); }
        }

        public DesktopTree FinancialAccountsTree
        {
            get { return new DesktopTree(Driver, Waiter, "FinancialAccountsTree"); }
        }

        public DesktopTree CostBreakdownsTree
        {
            get { return new DesktopTree(Driver, Waiter, "CostBreakdownsTree"); }
        }

        public DesktopTree EscalationsTree
        {
            get { return new DesktopTree(Driver, Waiter, "EscalationsTree"); }
        }

        public WebDriverMenuItem FileMenu
        {
            get { return Menu.GetMenuItemById("MenuFile"); }
        }

        public WebDriverMenuItem EditMenu
        {
            get { return Menu.GetMenuItemById("MenuEdit"); }
        }

        public WebDriverMenuItem NewMenu
        {
            get { return Menu.GetMenuItemById("MenuNew"); }
        }

        public WebDriverMenuItem LinkMenu
        {
            get { return Menu.GetMenuItemById("MenuLink"); }
        }

        public WebDriverMenuItem SurveyMenu
        {
            get { return Menu.GetMenuItemById("MenuSurvey"); }
        }

        public WebDriverDesktop(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "arm.aspx")
        {
            Waiter.Until(d => FilterSelector);
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        protected void WaitUntilTitleIsSet()
        {
            WaitUntilPageIsReady();

            try
            {
                Waiter.Until(d => d.IsInitialDataLoadComplete());
                Waiter.Until(d => d.Title.StartsWith("Active Risk Manager"));
            }
            catch (Exception ex)
            {
                throw new Exception("Error happend while waiting for title to be set. " + ex + Driver.PageSource);
            }
        }

        private void WaitUntilDesktopFooterIsDisplayed()
        {
            bool desktopFooterDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);

                var desktopFooters = Driver.FindElements(By.CssSelector("input[id^='AV_Grids_'][id$='Table_pagerText']"));
                var displayedDesktopFooters = desktopFooters.Where(x => x.Displayed).ToList();

                if (displayedDesktopFooters.Any())
                {
                    desktopFooterDisplayed = true;
                    break;
                }
            }

            if (!desktopFooterDisplayed)
            {
                Console.WriteLine("Was waiting for the Desktop Footer Text To Be Displayed, but it was not displayed");
            }
        }

        private void WaitUntilDesktopFooterIsEnabled()
        {
            bool desktopFooterEnabled = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);

                var desktopFooters = Driver
                    .FindElements(By.CssSelector("input[id^='AV_Grids_'][id$='Table_pagerText']")).Where(x => x.Enabled)
                    .ToList();

                if (desktopFooters.Any())
                {
                    desktopFooterEnabled = true;
                    break;
                }
            }

            if (!desktopFooterEnabled)
            {
                Console.WriteLine("Was waiting for the Desktop Footer Text To Be Enabled, but it was not enabled");
            }
        }

        public new void FocusWindow()
        {
            base.FocusWindow();
            WaitUntilDesktopFooterIsDisplayed();
        }

        private void ReloadDesktop(string text)
        {
            try
            {
                FocusWindow();
                Driver.FindElement(By.CssSelector("div#UIPrompt"));
            }
            catch (NoSuchElementException)
            {
                return;
            }

            try
            {
                FocusWindow();
                Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
                var prompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
                prompt.FindElement(By.CssSelector("button[title='" + text + "']")).SendKeys(Keys.Enter);
                WaitUntilPageIsReady();
                Waiter.Until(d => !d.IsAjaxRequestInProgress());
                WaitUntilTitleIsSet();
            }
            catch (WebDriverException e)
            {
                throw new WebDriverException("WebDriver encountered an error while waiting for Page Reload dialouge to be displayed. " + e);
            }
        }

        public static WebDriverDesktop Reload(WebDriverDesktop desktop, string text)
        {
            desktop.ReloadDesktop(text);
            return new WebDriverDesktop(desktop.Driver, desktop.Waiter);
        }

        public WebDriverNewAdminDialog AdminDialog()
        {
            FocusWindow();
            var toolsMenu = Menu.GetMenuItemById("MenuTools");
            toolsMenu.Click();
            toolsMenu.ClickOption("Admin...");

            return new WebDriverNewAdminDialog(Driver, Waiter);
        }

        public WebDriverUserOptionsDialog OptionsDialog()
        {
            FocusWindow();
            var toolsMenu = Menu.GetMenuItemById("MenuTools");
            toolsMenu.Click();
            toolsMenu.ClickOption("Options...");

            return new WebDriverUserOptionsDialog(Driver, Waiter);
        }

        public ImportFromExcelDialogue ImportRisksExcel()
        {
            FocusWindow();
            FileMenu.Click();
            FileMenu.ClickOption("Import Risks (Excel)");

            return OpenChildDialog<ImportFromExcelDialogue>();
        }

        public ImportFromExcelDialogue ImportAuditsExcel()
        {
            FocusWindow();
            FileMenu.Click();
            FileMenu.ClickOption("Import Audits (Excel)");

            return OpenChildDialog<ImportFromExcelDialogue>();
        }

        public ExportFromExcelDialogue ExportRisksExcel()
        {
            FocusWindow();
            FileMenu.Click();
            FileMenu.ClickOption("Export Risks (Excel)");

            return OpenChildDialog<ExportFromExcelDialogue>();
        }

        public ExportFromExcelDialogue ExportAuditsExcel()
        {
            FocusWindow();
            FileMenu.Click();
            FileMenu.ClickOption("Export Audits (Excel)");

            return OpenChildDialog<ExportFromExcelDialogue>();
        }

        public RiskComponent NewRiskViaContextMenu()
        {
            FocusWindow();
            var contextmenu = Driver.FindElement(By.CssSelector(".grid-title"));
            var contextpopup =
                Driver.FindElement(By.CssSelector("#AV_Grids_RiskList_RisksTable_ContextMenu_NewRecordType1"));
            RiskIssuesGrid.RightClickElement(contextmenu);
            contextpopup.Click();
            FocusNewWindow();
         
            return new RiskComponent(Driver, Waiter);
        }

        public RiskComponent NewAmazingRiskViaContextMenu()
        {
            FocusWindow();
            var contextmenu = Driver.FindElement(By.CssSelector(".grid-title"));
            var contextpopup =
                Driver.FindElement(By.CssSelector("#AV_Grids_RiskList_RisksTable_ContextMenu_NewRecordType42"));
            RiskIssuesGrid.RightClickElement(contextmenu);
            contextpopup.Click();
            FocusWindow();
            return new RiskComponent(Driver, Waiter);
        }

        public RiskComponent GetOpenedRisk()
        {
            return new RiskComponent(Driver, Waiter);
        }
        
        public ImpactComponent GetOpenedImpact()
        {
            FocusWindow();
            return new ImpactComponent(Driver, Waiter);
        }

        public WebdriverIncidentHistoryDataDialog OpenedIncidentSearchHistory()
        {
            FocusWindow();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return OpenChildDialog<WebdriverIncidentHistoryDataDialog>();
        }

        public DataHistoryDialog OpenedDataHistorySearch()
        {
            FocusWindow();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return OpenChildDialog<DataHistoryDialog>();
        }

        public WebDriverAuditDetailDialog NewAudit()
        {
            FocusWindow();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            GridSelector.Select("Audit");
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            newMenu.ClickOption("New Audit");

            return OpenChildDialog<WebDriverAuditDetailDialog>();
        }

        public WebDriverAuditDetailDialog OpenedAudit()
        {
            FocusWindow();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return OpenChildDialog<WebDriverAuditDetailDialog>();
        }

        public HistorySearchDialog SearchBusinessFolder()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("View Data History");

            return OpenChildDialog<HistorySearchDialog>();
        }

        public WebDriverActivityDialog NewActivityFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Activity...");

            return new WebDriverActivityDialog(Driver, Waiter);
        }

        public WebDriverActivityDialog NewActivityFromContextMenu(DesktopTreeType itemType, string itemName)
        {
            FocusWindow();

            ActivityTree.RightClickOnItem(itemType, itemName);
            SelectContextMenuItem("NewActivity");

            return new WebDriverActivityDialog(Driver, Waiter);
        }

        public WebDriverActivityDialog OpenedActivityProperties()
        {
            return new WebDriverActivityDialog(Driver, Waiter);
        }

        public void DeleteActivityFromEditMenu(string activity)
        {
            ActivityTree.DeleteItemFromEditMenu(DesktopTreeType.Activity, activity);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilTreeItemDeleted(DesktopTreeType.Activity, activity);
        }

        public void DeleteActivityFromContextMenu(string activity)
        {
            ActivityTree.DeleteItemFromContextMenu(DesktopTreeType.Activity, activity);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilTreeItemDeleted(DesktopTreeType.Activity, activity);
        }

        public void DeleteCopiedActivityFromEditMenu(string activity)
        {
            ActivityTree.DeleteCopiedItemFromEditMenu(DesktopTreeType.Activity, activity);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilCopiedTreeItemDeleted(DesktopTreeType.Activity, activity);
        }

        public WebDriverAuditDetailDialog SavedAudit()
        {
            return OpenChildDialog<WebDriverAuditDetailDialog>();
        }

        public WebDriverBusinessFolderDialog NewBusinessFolderFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Business Folder...");

            return new WebDriverBusinessFolderDialog(Driver, Waiter);
        }

        public WebDriverBusinessAreaOpenDialogue OpenBusinessAreaDialogueFromFileMenu()
        {
            var fileMenu = Menu.GetMenuItemById("MenuFile");
            fileMenu.Click();
            fileMenu.ClickOption("Open...");
            return new WebDriverBusinessAreaOpenDialogue(Driver, Waiter);
        }

        public void DeleteBusinessAreaFromEditMenuThenLogBackInto(string businessAreaToDelete,
            string businessAreaReloginName, int businessAreaReloginId)
        {
            var editMenu = Menu.GetMenuItemById("MenuEdit");
            editMenu.Click();
            editMenu.ClickOptionFromMenu("Delete Business Area");

            AssertUiPromptContainsText(businessAreaToDelete);
            RespondToUiPrompt("Yes");

            Waiter.Until(u => u.Url.EndsWith("arm/"));

            var reLoginScreen = new NewSplashScreenLogin(Driver, Waiter);
            Driver.Manage().Window.Maximize();

            reLoginScreen.SplashWelcomeMessage.AssertEnabled();

            var numberOfOpenWindows = Driver.WindowHandles.Count;

            if (numberOfOpenWindows == 1)
            {
                // Expected behaviour, Log back into the Business Area
                Driver.Manage().Window.Maximize();

                reLoginScreen.SplashWelcomeMessage.AssertEnabled();

                reLoginScreen.SelectBusinessArea(businessAreaReloginName, businessAreaReloginId);
                reLoginScreen.StartButton.Click();

                Driver.Manage().Window.Maximize();

                FocusWindow();
                ActivityTree.BusinessAreaNode.AssertTextEquals(businessAreaReloginName);
            }
            else if (numberOfOpenWindows > 1)
            {
                // Unexpected behaviour, we have more than one window open, call Driver.Quit() to close all windows and error
                Driver.Quit();
                Assert.Fail(
                    "Was expecting to be at the ARM Login screen after deleting Business Area {0} with only one window but there were {1} windows open",
                    businessAreaToDelete, numberOfOpenWindows);
            }

        }

        public WebDriverBusinessAreaPropertiesDialog ViewBusinessAreaPropertiesfromViewMenu()
        {
            FocusWindow();
            var viewMenu = Menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.ClickOption("Properties");
            return new WebDriverBusinessAreaPropertiesDialog(Driver, Waiter);

        }

        public WebDriverBusinessAreaPropertiesDialog NewBusinessAreaFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Business Area...");

            return new WebDriverBusinessAreaPropertiesDialog(Driver, Waiter);
        }

        public WebDriverBusinessFolderDialog NewBusinessFolderFromContextMenu(DesktopTreeType itemType, string itemName)
        {
            FocusWindow();

            ActivityTree.RightClickOnItem(itemType, itemName);
            SelectContextMenuItem("NewBusinessFolder");

            return new WebDriverBusinessFolderDialog(Driver, Waiter);
        }

        public WebDriverBusinessFolderDialog ViewBusinessFolderPropertiesfromViewMenu()
        {
            FocusWindow();
            var viewMenu = Menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.ClickOption("Properties");
            return new WebDriverBusinessFolderDialog(Driver, Waiter);

        }

        public void LinkRiskToFolderFromContextMenu(string businessFolder)
        {
            var activityTree = new DesktopTree(Driver, Waiter, "ActivityTree");
            activityTree.LinkRiskToFolderFromContextMenu(businessFolder);
        }

        public void LinkRiskToFolder(string businessFolder)
        {
            var activityTree = new DesktopTree(Driver, Waiter, "ActivityTree");
            activityTree.LinkRiskToFolder(businessFolder);
        }

        public void LinkRiskToActivity(string businessActivity)
        {
            var activityTree = new DesktopTree(Driver, Waiter, "ActivityTree");
            activityTree.LinkRiskToActivity(businessActivity);
        }

        public void LinkRiskToProcess(string businessProcess)
        {
            var activityTree = new DesktopTree(Driver, Waiter, "ActivityTree");
            activityTree.LinkRiskToProcess(businessProcess);
        }

        public WebDriverBusinessFolderDialog OpenedBusinessFolderProperties()
        {
            return new WebDriverBusinessFolderDialog(Driver, Waiter);
        }

        public WebDriverMultiCopyRiskDialog OpenedMultiCopyRiskDalog()
        {
            return new WebDriverMultiCopyRiskDialog(Driver, Waiter);
        }

        public void DeleteBusinessFolderFromEditMenu(string businessFolder)
        {
            ActivityTree.DeleteItemFromEditMenu(DesktopTreeType.Folder, businessFolder);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilTreeItemDeleted(DesktopTreeType.Folder, businessFolder);
            WaitUntilUiSpinnerIsNotDisplayed();
            WaitUntilDesktopFooterIsDisplayed();
        }

        public void DeleteCopiedBusinessFolderFromEditMenu(string businessFolder)
        {
            ActivityTree.DeleteCopiedItemFromEditMenu(DesktopTreeType.Folder, businessFolder);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilCopiedTreeItemDeleted(DesktopTreeType.Folder, businessFolder);
            WaitUntilDesktopFooterIsDisplayed();
        }

        public void DeleteBusinessFolderFromContextMenu(string businessFolder)
        {
            ActivityTree.DeleteItemFromContextMenu(DesktopTreeType.Folder, businessFolder);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilUiSpinnerIsNotDisplayed();
            ActivityTree.WaitUntilTreeItemDeleted(DesktopTreeType.Folder, businessFolder);
            WaitUntilDesktopFooterIsDisplayed();
        }

        public void SelectDeleteBusinessFolderFromContextMenu(string businessFolder)
        {
            ActivityTree.DeleteItemFromContextMenu(DesktopTreeType.Folder, businessFolder);
        }

        public void SelectDeleteBusinessFolderFromEditMenu(string businessFolder)
        {
            ActivityTree.DeleteItemFromEditMenu(DesktopTreeType.Folder, businessFolder);
        }

        public void ExpandActivityBusinessFolder(string businessFolder)
        {
            ActivityTree.ExpandItem(DesktopTreeType.Folder, businessFolder);
            WaitUntilPageIsReady();
        }

        public WebDriverProcessDialog NewProcessFromNewMenu()
        {
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Process...");

            return new WebDriverProcessDialog(Driver, Waiter);
        }

        public WebDriverProcessDialog NewProcessFromContextMenu(DesktopTreeType itemType, string itemName)
        {
            FocusWindow();

            ActivityTree.RightClickOnItem(itemType, itemName);
            SelectContextMenuItem("NewProcess");

            return new WebDriverProcessDialog(Driver, Waiter);
        }

        public WebDriverProcessDialog OpenedProcessProperties()
        {
            return new WebDriverProcessDialog(Driver, Waiter);
        }

        public CurrencyDialogue NewCurrencyDialogue()
        {
            return new CurrencyDialogue(Driver, Waiter);
        }

        public void DeleteProcessFromEditMenu(string process)
        {
            ActivityTree.DeleteItemFromEditMenu(DesktopTreeType.Process, process);
            AcceptAlert();
        }

        public void DeleteProcessFromContextMenu(string process)
        {
            ActivityTree.DeleteItemFromContextMenu(DesktopTreeType.Process, process);
            AcceptAlert();
        }

        public void DeleteCopiedProcessFromEditMenu(string process)
        {
            ActivityTree.DeleteCopiedItemFromEditMenu(DesktopTreeType.Process, process);
            AcceptAlert();
        }

        public WdAlertConfigurationDialogue NewAlertFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Alert");

            return OpenChildDialog<WdAlertConfigurationDialogue>();
        }

        public WebDriverDesktopFilterDialog NewFilter()
        {
            FilterButton.Click();
            return OpenChildDialog<WebDriverDesktopFilterDialog>();
        }

        public WebDriverFilterDialog EditFilter()
        {
            FocusWindow();
            FilterSelector.Select("Edit...");

            return OpenChildDialog<WebDriverFilterDialog>();
        }

        public WebDriverFilterDialog LaunchFilterDialogue()
        {
            FocusWindow();
            FilterButton.Click();

            return OpenChildDialog<WebDriverFilterDialog>();
        }

        public void CopyRecords()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Copy Selected Records");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
        }

        public void CutRecords()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Cut Selected Records");
            WaitUntilPageIsReady();
        }

        public void PasteRisks()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste");
            RespondToUiPrompt("Yes");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
            _riskIssuesGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RiskList_RisksTable", "Risk");
        }

        public void CutNode()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Cut Node");
            WaitUntilPageIsReady();

        }

        public void PasteHere()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste Here");
            Thread.Sleep(20000);
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public void PasteAsChild()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste As Child");
            Thread.Sleep(20000);
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public void PasteLinkedRisks()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste Linked");
            RespondToUiPrompt("Yes");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
            _riskIssuesGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RiskList_RisksTable", "Risk");
        }

        public void LinkRecordToANode()
        {
            FocusWindow();
            LinkMenu.Click();
            LinkMenu.ClickOption("Link Selected Record(s) to a Node");

            Thread.Sleep(2000);
        }

        public void LinkRecordToCurrentNode()
        {
            FocusWindow();
            LinkMenu.Click();
            LinkMenu.ClickOption("Link Selected Record(s) to Current Node");
            RespondToUiPrompt("Yes");
            Thread.Sleep(2000);
        }

        public void MultiCopyRiskIssue()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Multi Copy Risk, Issue...");

            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
            _riskIssuesGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RiskList_RisksTable", "Risk");
        }

        public void DeleteAllRisksDisplayedInRisksIssuesGrid()
        {
            FocusWindow();
            GridSelector.Select("Risk, Issue...");
            var risksToDelete = RiskIssuesGrid.GetTotalRowCount();
            if (risksToDelete <= 0) return;
            RiskIssuesGrid.SelectAll();
            DeleteSelectedRecords();
            Waiter.Until(d => Driver.FindElement(By.CssSelector("div.grid-norecords")).Displayed);
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilTitleIsSet();
        }

        public void SelectDeleteSelectedRecordsFromEditMenu()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Delete Selected Records");
        }

        public void DeleteSelectedResponseFromContextMenu(string responseToDelete)
        {
            ResponseGrid.SetHeaderFilter("Name", responseToDelete);
            if (ResponseGrid.GetPageRowCount() == 0)
            {
                Assert.Fail(
                    "Was trying to find {0} to delete in the Response Grid, but it was not present in the Response Grid",
                    responseToDelete);
            }

            var responses = Driver.FindElements(By.CssSelector("tr.grid-row"));
            bool responseDeleted = false;
            foreach (var response in responses)
            {
                if (response.FindElement(By.CssSelector("td[id$='_Name']")).Text.Equals(responseToDelete))
                {
                    var responseElement = response.FindElement(By.CssSelector("td[id$='_Name']"));
                    Actions actions = new Actions(Driver);
                    actions.MoveToElement(responseElement);
                    actions.ContextClick(responseElement).Build().Perform();

                    var contextMenuItem = Driver.FindElement(By.CssSelector("li[id$='_ContextMenu_DeleteResponse']"));
                    Waiter.Until(d => contextMenuItem.Displayed);
                    contextMenuItem.Click();
                    RespondToUiPrompt("Yes");
                    responseDeleted = true;
                    break;
                }
            }

            if (!responseDeleted)
            {
                Assert.Fail("Was trying to delete the Response {0} via Context Menu, but it failed to be deleted",
                    responseToDelete);
            }
        }

        public void SelectDeleteResponseFromContextMenuClickNoOnDeletePrompt(string responseToSelectToDelete)
        {
            ResponseGrid.SetHeaderFilter("Name", responseToSelectToDelete);
            if (ResponseGrid.GetPageRowCount() == 0)
            {
                Assert.Fail(
                    "Was trying to find {0} to delete in the Response Grid, but it was not present in the Response Grid",
                    responseToSelectToDelete);
            }

            var responses = Driver.FindElements(By.CssSelector("tr.grid-row"));
            bool responseFound = false;
            foreach (var response in responses)
            {
                if (response.FindElement(By.CssSelector("td[id$='_Name']")).Text.Equals(responseToSelectToDelete))
                {
                    responseFound = true;
                    var responseElement = response.FindElement(By.CssSelector("td[id$='_Name']"));
                    Actions actions = new Actions(Driver);
                    actions.MoveToElement(responseElement);
                    actions.ContextClick(responseElement).Build().Perform();

                    var contextMenuItem = Driver.FindElement(By.CssSelector("li[id$='_ContextMenu_DeleteResponse']"));
                    Waiter.Until(d => contextMenuItem.Displayed);
                    contextMenuItem.Click();
                    RespondToUiPrompt("No");
                    break;
                }
            }

            if (!responseFound)
            {
                Assert.Fail("Was trying to select the Response {0} via Context Menu, but it failed to be found",
                    responseToSelectToDelete);
            }
        }

        public void DeleteSelectedRecords()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Delete Selected Records");
            AcceptAlert();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
            WaitUntilTitleIsSet();
            WaitUntilUiSpinnerIsNotDisplayed();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public WebDriverBulkUpdateRiskDialog BulkUpdateRisks()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Bulk Update Selected Records");
            return OpenChildDialog<WebDriverBulkUpdateRiskDialog>();
        }

        public WebDriverBulkUpdateResponseDialog BulkUpdateResponses()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOptionById("MenuBulkUpdateResponse");
            return OpenChildDialog<WebDriverBulkUpdateResponseDialog>();
        }

        public void PasteCopiedIncidents()
        {
            FocusWindow();
            PasteButton.Click();

            var incidentPasteHereDialog = OpenChildDialog<WebDriverIncidentPasteHereDialog>();

            incidentPasteHereDialog.IncludeInvestigation.Check();
            incidentPasteHereDialog.IncludeResponses.Check();
            incidentPasteHereDialog.IncludeRegulatoryAuthorities.Check();
            incidentPasteHereDialog.OkButton.Click();
            WaitUntilTitleIsSet();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());

            _incidentGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_IncidentList_IncidentsTable", "Incident");
        }

        public void PasteCutIncidents()
        {
            FocusWindow();
            PasteButton.Click();
            RespondToUiPrompt("Yes");
            WaitUntilTitleIsSet();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            _incidentGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_IncidentList_IncidentsTable", "Incident");
        }

        public void PasteCopiedAudits()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste");
            var auditPasteHereDialog = OpenChildDialog<WebDriverAuditPasteHereDialog>();

            auditPasteHereDialog.IncludeFindings.Check();
            auditPasteHereDialog.IncludeActions.Check();
            auditPasteHereDialog.OkButton.Click();
            WaitUntilTitleIsSet();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            _auditGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_AuditList_AuditsTable", "Audit");
        }

        public void PasteCutAudits()
        {
            FocusWindow();
            PasteButton.Click();
            RespondToUiPrompt("Yes");
            WaitUntilTitleIsSet();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            _auditGrid = new DesktopGridTableControl(Driver, Waiter, "AV_Grids_AuditList_AuditsTable", "Audit");
        }

        public WebDriverModulePropertiesDialogue NewModuleFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Module...");

            return new WebDriverModulePropertiesDialogue(Driver, Waiter);
        }

        public void DeleteRequirementModuleFromEditMenu(string requirementModule)
        {
            RequirementsTree.DeleteItemFromEditMenu(DesktopTreeType.Module, requirementModule);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WebDriverRequirementPropertiesDialogue NewRequirementFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Requirement...");

            return new WebDriverRequirementPropertiesDialogue(Driver, Waiter);
        }

        public WebDriverRequirementPropertiesDialogue OpenedRequirementProperties()
        {

            return new WebDriverRequirementPropertiesDialogue(Driver, Waiter);
        }

        public void DeleteRequirementFromEditMenu(string requirement)
        {
            RequirementsTree.DeleteItemFromEditMenu(DesktopTreeType.Requirement, requirement);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WebDriverAssetPropertiesDialogue NewAssetFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Asset...");

            return new WebDriverAssetPropertiesDialogue(Driver, Waiter);
        }

        public WebDriverAssetPropertiesDialogue OpenedAssetProperties()
        {
            return new WebDriverAssetPropertiesDialogue(Driver, Waiter);
        }

        public void DeleteAssetFromEditMenu(string asset)
        {
            AssetsTree.DeleteItemFromEditMenu(DesktopTreeType.Asset, asset);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WebDriverKpiPropertiesDialogue NewKpiFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New KPI...");

            return new WebDriverKpiPropertiesDialogue(Driver, Waiter);
        }

        public WebDriverKpiPropertiesDialogue OpenedKpiProperties()
        {
            return new WebDriverKpiPropertiesDialogue(Driver, Waiter);
        }

        public void DeleteKpiFromEditMenu(string kpi)
        {
            KpisTree.DeleteItemFromEditMenu(DesktopTreeType.Kpi, kpi);
            ConfirmDeleteAndWaitForDesktopToBeReady();
            WaitUntilDesktopFooterIsDisplayed();
        }

        public WdFinancialAccountsPropertiesDialogue NewFinancialAccountFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Financial Account...");

            return new WdFinancialAccountsPropertiesDialogue(Driver, Waiter);
        }

        public WdFinancialAccountsPropertiesDialogue OpenedFinancialAccountProperties()
        {
            return new WdFinancialAccountsPropertiesDialogue(Driver, Waiter);
        }

        public void DeleteFinancialAccountFromEditMenu(string financialAccount)
        {
            FinancialAccountsTree.DeleteItemFromEditMenu(DesktopTreeType.FinancialAccount, financialAccount);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WdCostBreakdownPropertiesDialogue NewCostBreakdownFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Cost Breakdown Node...");

            return new WdCostBreakdownPropertiesDialogue(Driver, Waiter);
        }

        public WdCostBreakdownPropertiesDialogue OpenedCostBreakdownProperties()
        {

            return new WdCostBreakdownPropertiesDialogue(Driver, Waiter);
        }

        public void DeleteCostBreakdownFromEditMenu(string costBreakdown)
        {
            CostBreakdownsTree.DeleteItemFromEditMenu(DesktopTreeType.CostBreakdown, costBreakdown);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WdEscalationPropertiesDialogue NewEscalationFromNewMenu()
        {
            FocusWindow();
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickOption("New Escalation...");

            return new WdEscalationPropertiesDialogue(Driver, Waiter);
        }

        public SurveyLandingPage OpenLandingPage()
        {
            FocusWindow();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            SurveyMenu.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            NewMenu.ClickOption("Survey Manager");
            return new SurveyLandingPage(Driver, Waiter);
        }

        public WdEscalationPropertiesDialogue OpenedEscalationProperties()
        {
            return new WdEscalationPropertiesDialogue(Driver, Waiter);
        }

        public WebDriverAttributesDialog OpenAttributesDialog()
        {
            return new WebDriverAttributesDialog(Driver, Waiter);
        }

        public AdminConfigurationTabPage OpenConfigurationPage()
        {
            return new AdminConfigurationTabPage(Driver, Waiter);
        }

        public AdminSecurityTabPage OpenSecurityPage()
        {
            return new AdminSecurityTabPage(Driver, Waiter);
        }

        public WebDriverWeightedScoringConfigurationPage OpenedWeightedScoringPage()
        {
            return new WebDriverWeightedScoringConfigurationPage(Driver, Waiter);
        }

        public SchoringSchemeDialog OpenedScoringSchemeDialog()
        {
            return new SchoringSchemeDialog(Driver, Waiter);
        }

        public void DeleteEscalationFromEditMenu(string escalation)
        {
            EscalationsTree.DeleteItemFromEditMenu(DesktopTreeType.Escalation, escalation);
            ConfirmDeleteAndWaitForDesktopToBeReady();
        }

        public WdQuantitativeImapctAnalysisLaunchDialogue ImpactAnalysis()
        {
            FocusWindow();
            var analysisMenu = Menu.GetMenuItemById("MenuAnalysis");
            analysisMenu.Click();
            analysisMenu.ClickOption("Impact Analysis...");

            return OpenChildDialog<WdQuantitativeImapctAnalysisLaunchDialogue>();
        }

        public WdImpactAnalysisTrendDialogue ImpactAnalysisTrend()
        {
            FocusWindow();
            var analysisMenu = Menu.GetMenuItemById("MenuAnalysis");
            analysisMenu.Click();
            analysisMenu.ClickOption("Impact Analysis Trend");

            return OpenChildDialog<WdImpactAnalysisTrendDialogue>();
        }

        public WdScheduleAnalysisLaunchDialogue OldScheduleAnalysis()
        {
            FocusWindow();
            var analysisMenu = Menu.GetMenuItemById("MenuAnalysis");
            analysisMenu.Click();
            analysisMenu.ClickOption("Old Schedule Analysis...");

            return OpenChildDialog<WdScheduleAnalysisLaunchDialogue>();
        }

        public T PropertiesDialog<T>() where T : WebDriverArmPage
        {

            IWebElement updateBusinessFolder = Driver.FindElement(By.CssSelector("div.tree"));
            Actions action = new Actions(Driver);
            action.MoveToElement(updateBusinessFolder);
            action.ContextClick(updateBusinessFolder).Build().Perform();
        
            IWebElement propertiesElement =
                Driver.FindElement(By.CssSelector("li[id$='TreeGrid_ContextMenu_Properties']"));
            Waiter.Until(d => propertiesElement.Displayed);
            propertiesElement.Click();

            return OpenChildDialog<T>();
        }

        public void CopyNodeFromEditMenu()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Copy Node");
        
            Driver.WaitForAjaxToComplete();
            WaitUntilPageIsReady();
        }

        public void PasteAsChildFromEditMenu()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Paste As Child");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
        }

        public void CutNodeFromEditMenu()
        {
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Cut Node");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
        }

        public void DeleteNode()
        {
            //Deleting a node gives VBScript error, servers are unable to handle VBScript dialogs. So this wont work for now.
            FocusWindow();
            EditMenu.Click();
            EditMenu.ClickOption("Delete Node");
            AcceptAlert();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
            FocusWindow();
        }

        public DocumentDialog OpenDocumentDialog()
        {
            var linkMenu = Menu.GetMenuItemById("MenuLink");
            linkMenu.Click();
            linkMenu.ClickOption("Documents...");

            return OpenChildDialog<DocumentDialog>();
        }

        public PidChart OpenPid()
        {
            PidButton.Click();

            return OpenChildDialog<PidChart>();
        }

        public PidChart ReLoadedPidChart()
        {
            FocusWindow();
            return OpenChildDialog<PidChart>();
        }

        public PidChart OpenPidFromMenu()
        {
            var analysisMenu = Menu.GetMenuItemById("MenuAnalysis");
            analysisMenu.Click();
            analysisMenu.ClickOption("PID...");

            return OpenChildDialog<PidChart>();
        }

        public PidChart OpenPidFromTreeItemContextMenu(DesktopTreeType treeItemType, string itemName, string menuOption)
        {
            FocusWindow();
            ActivityTree.RightClickOnFolderAndSelectMenuOption(treeItemType, itemName, menuOption);

            return OpenChildDialog<PidChart>();
        }

        public void SelectContextMenuItem(string menuItemToSelect)
        {
            IWebElement contextMenuItem =
                Driver.FindElement(By.CssSelector("li[id$='TreeGrid_ContextMenu_" + menuItemToSelect + "']"));
            Waiter.Until(d => contextMenuItem.Displayed);
            contextMenuItem.Click();
        }

        public void ConfirmDeleteAndWaitForDesktopToBeReady()
        {
            AcceptAlert();
            WaitUntilDesktopFooterIsEnabled();
        }

        public void ClickOnToolsMenu()
        {
            FocusWindow();
            var toolsMenu = Menu.GetMenuItemById("MenuTools");
            toolsMenu.Click();
        }

        public void ClickOnViewMenu()
        {
            FocusWindow();
            var viewMenu = Menu.GetMenuItemById("MenuView");
            viewMenu.Click();
        }

        private void AcceptPrompt(bool expectLogoutPrompt)
        {
            if (expectLogoutPrompt)
            {
                Waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.AlertIsPresent());
                Driver.SwitchTo().Alert().Accept();
            }
        }

        public void Logout(bool expectLogoutPrompt = false)
        {
            FocusWindow();

            var fileMenu = Menu.GetMenuItemById("MenuFile");
            fileMenu.Click();
            fileMenu.ClickOption("Logout");

            AcceptPrompt(expectLogoutPrompt);

            // Wait until URL contains Logout or Timeout
            Waiter.Until(u => u.Url.Contains("Logout") || u.Url.Contains("TimeOut"));

            // Waiter until the "You have successfully logged out of ARM." or "Your session has expired." text is visible
            bool logoutTextDisplayed = false;

            //giving the application time to log the user out, it can break out as soon as it has so its not a time wasting sleep
            for (var i = 0; i < 60; i++)
            {
                Thread.Sleep(1000);
                var logoutTexts = Driver.FindElements(By.CssSelector("div.container div.shutdown-message")).Where(x => x.Displayed).ToList();
                if (logoutTexts.Count > 0)
                {
                    foreach (var logoutText in logoutTexts)
                    {
                        if (logoutText.Text.Contains("You have successfully logged out of ARM.") || logoutText.Text.Contains("Your session has expired."))
                        {
                            logoutTextDisplayed = true;
                            i = 61;
                            break;
                        }
                    }
                }
            }

            if (!logoutTextDisplayed)
            {
                Assert.Fail(
                    "Was waiting for the : You have successfully logged out of ARM. or Your session has expired. text to be displayed whilst on the Logout Screen, but it was not displayed");
            }

            // If the expected behaviour has occured, then we should be at the Logout Window and this should be the only
            // window that is left open.
            //
            // So we should be able to call Driver.Close() to close this last window.
            //
            // Calling Driver.Close() on the last window "should" cause Selenium to close the last window, and "should" also close the
            // Driver session.  Unfortunately, this area of functionality has always been flaky and the IEDriverServer executable
            // is left hanging.  So we will instead do a Driver.Quit().  This means we cannot do any Driver or Waiter calls after
            // this and any further (assume new login) interactions will require a new Driver.  This is therefore the assumption
            // that we must take.
            //
            // If we find more than one driver window here, then we should still do a Driver.Quit() to close all windows
            // in the hope that further tests can continue correctly but write an error condition.

            var numberOfOpenWindows = Driver.WindowHandles.Count;

            if (numberOfOpenWindows > 1)
            {
                //we used to error here but there is no point to error as this is tear-down not for testing
                Console.WriteLine("We had more than one window open - something did not tear-down correctly");
            }
        }

        public DesktopGridTableControl OpenRelatedRiskIssueGrid()
        {
            return new DesktopGridTableControl(Driver, Waiter, "AV_Grids_RelatedRiskList_RelatedRisksTable", "Risk");
        }

        public RiskVisualiserDialog RiskVisualiserDialog()
        {
            var viewMenu = _menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.ClickOptionById("MenuViewRiskVisualiserView");
            return OpenChildDialog<RiskVisualiserDialog>();
        }

        public RiskVisualiserDialog NewRiskFromNewRvMenu()
        {
            var newMenu = Menu.GetMenuItemById("MenuNew");
            newMenu.Click();
            newMenu.ClickSubMenuOption("Risk...");
            return OpenChildDialog<RiskVisualiserDialog>();
        }

        public void AssertRiskVisualiserOption()
        {
            var viewMenu = _menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.AssertOptionNotEnabled(MenuOption.RiskVisualiserOption);
        }

        public IncidentHistorySearchDialog ViewRiskDataHistory()
        {
            var viewMenu = _menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.ClickOption("View Data History");
            return OpenChildDialog<IncidentHistorySearchDialog>();
        }

        public DataHistoryDialog ViewRiskDataHistoryDialog()
        {
            FocusWindow();
            var viewMenu = _menu.GetMenuItemById("MenuView");
            viewMenu.Click();
            viewMenu.ClickOption("View Data History");
            return OpenChildDialog<DataHistoryDialog>();
        }
    }
}

namespace PresentationModel.Model.Desktop
{
    public class WebDriverDesktopNoAccess : WebDriverArmPage
    {
        protected IWebElement Element;

        public WebDriverDesktopNoAccess(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "LicenceCheckFailed.aspx")
        {
            Element = Driver.FindElement(By.CssSelector("form#form1"));
        }

        public void AssertUserDoesNotHaveAccessToArmDesktop()
        {
            AssertUrlEndsWith(
                "LicenceCheckFailed.aspx?message=You%20do%20not%20have%20access%20to%20ARM%20Desktop.%20Please%20contact%20your%20ARM%20Administrator.");
            Assert.True(
                Element.GetAttribute("action")
                    .Contains("message=You+do+not+have+access+to+ARM+Desktop.+Please+contact+your+ARM+Administrator"));
        }
    }
}
