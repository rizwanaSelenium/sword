﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class RiskDetailComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public RiskDetailComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private AngularExpandableSingleLineTextField _name;
        public AngularExpandableSingleLineTextField Name
        {
            get
            {
                return _name ?? (_name = new AngularExpandableSingleLineTextField(_driver, _waiter, "field_2"));
            }
        }

        private AngularMultiLineTextField _description;
        public AngularMultiLineTextField Description
        {
            get
            {
                return _description ?? (_description = new AngularMultiLineTextField(_driver, _waiter, "field_3"));
            }
        }

        private AngularDropdownListField _riskStatus;
        public AngularDropdownListField RiskStatus
        {
            get
            {
                return _riskStatus ?? (_riskStatus = new AngularDropdownListField(_driver, _waiter, "field_4"));
            }
        }

        private AngularDropdownListField _riskSource;
        public AngularDropdownListField RiskSource
        {
            get
            {
                return _riskSource ?? (_riskSource = new AngularDropdownListField(_driver, _waiter, "field_5"));
            }
        }

        private AngularResourcePickerField _owner;
        public AngularResourcePickerField Owner
        {
            get
            {
                return _owner ?? (_owner = new AngularResourcePickerField(_driver, _waiter, "field_6"));
            }
        }

        private AngularDropdownListField _riskPhase;
        public AngularDropdownListField RiskPhase
        {
            get
            {
                return _riskPhase ?? (_riskPhase = new AngularDropdownListField(_driver, _waiter, "field_7"));
            }
        }

        private AngularMultiSelectTreeField _riskCategories;
        public AngularMultiSelectTreeField RiskCategories
        {
            get
            {
                return _riskCategories ?? (_riskCategories = new AngularMultiSelectTreeField(_driver, _waiter, "field_21"));
            }
        }

        private AngularSingleLineTextField _riskId;
        public AngularSingleLineTextField RiskId
        {
            get
            {
                return _riskId ?? (_riskId = new AngularSingleLineTextField(_driver, _waiter, "field_32"));
            }
        }

        private AngularCostField _cost;
        public AngularCostField Cost
        {
            get
            {
                return _cost ?? (_cost = new AngularCostField(_driver, _waiter, "field_33", true, true, true));
            }
        }

        private AngularMultiSelectResourcePickerField _interestedParties;
        public AngularMultiSelectResourcePickerField InterestedParties
        {
            get
            {
                return _interestedParties ?? (_interestedParties = new AngularMultiSelectResourcePickerField(_driver, _waiter, "field_34"));
            }
        }

        private AngularResourcePickerField _raisedBy;
        public AngularResourcePickerField RaisedBy
        {
            get
            {
                return _raisedBy ?? (_raisedBy = new AngularResourcePickerField(_driver, _waiter, "field_35"));
            }
        }

        private AngularResourcePickerField _reviewedBy;
        public AngularResourcePickerField ReviewedBy
        {
            get
            {
                return _reviewedBy ?? (_reviewedBy = new AngularResourcePickerField(_driver, _waiter, "field_36"));
            }
        }

        private AngularDatePickerField _initiationDate;
        public AngularDatePickerField InitiationDate
        {
            get
            {
                return _initiationDate ?? (_initiationDate = new AngularDatePickerField(_driver, _waiter, "field_37"));
            }
        }

        private AngularDatePickerField _approvalDate;
        public AngularDatePickerField ApprovalDate
        {
            get
            {
                return _approvalDate ?? (_approvalDate = new AngularDatePickerField(_driver, _waiter, "field_38"));
            }
        }

        private AngularDatePickerField _assessmentDate;
        public AngularDatePickerField AssessmentDate
        {
            get
            {
                return _assessmentDate ?? (_assessmentDate = new AngularDatePickerField(_driver, _waiter, "field_39"));
            }
        }

        private AngularDatePickerField _lastReview;
        public AngularDatePickerField LastReview
        {
            get
            {
                return _lastReview ?? (_lastReview = new AngularDatePickerField(_driver, _waiter, "field_40"));
            }
        }

        private AngularMultiLineTextField _cause;
        public AngularMultiLineTextField Cause
        {
            get
            {
                return _cause ?? (_cause = new AngularMultiLineTextField(_driver, _waiter, "field_41"));
            }
        }

        private AngularMultiLineTextField _effect;
        public AngularMultiLineTextField Effect
        {
            get
            {
                return _effect ?? (_effect = new AngularMultiLineTextField(_driver, _waiter, "field_42"));
            }
        }

        private AngularMultiLineTextField _background;
        public AngularMultiLineTextField Background
        {
            get
            {
                return _background ?? (_background = new AngularMultiLineTextField(_driver, _waiter, "field_43"));
            }
        }

        private AngularMultiLineTextField _comments;
        public AngularMultiLineTextField Comments
        {
            get
            {
                return _comments ?? (_comments = new AngularMultiLineTextField(_driver, _waiter, "field_102"));
            }
        }

        private AngularMultiLineTextField _lastReviewNote;
        public AngularMultiLineTextField LastReviewNote
        {
            get
            {
                return _lastReviewNote ?? (_lastReviewNote = new AngularMultiLineTextField(_driver, _waiter, "field_105"));
            }
        }

        private AngularEscalationField _escalation;
        public AngularEscalationField Escalation
        {
            get
            {
                return _escalation ?? (_escalation = new AngularEscalationField(_driver, _waiter, "field_126"));
            }
        }

        private AngularCostField _actualCost;
        public AngularCostField ActualCost
        {
            get
            {
                return _actualCost ?? (_actualCost = new AngularCostField(_driver, _waiter, "field_128"));
            }
        }

        private AngularTextPopupButtonField _reviewButton;
        public AngularTextPopupButtonField ReviewButton
        {
            get
            {
                return _reviewButton ?? (_reviewButton = new AngularTextPopupButtonField(_driver, _waiter, "field_135"));
            }
        }

        private AngularResourcePickerField _feedbackBy;
        public AngularResourcePickerField FeedbackBy
        {
            get
            {
                return _feedbackBy ?? (_feedbackBy = new AngularResourcePickerField(_driver, _waiter, "field_136"));
            }
        }

        private AngularDatePickerField _lastFeedbackDate;
        public AngularDatePickerField LastFeedbackDate
        {
            get
            {
                return _lastFeedbackDate ?? (_lastFeedbackDate = new AngularDatePickerField(_driver, _waiter, "field_137"));
            }
        }

        private AngularExpandableSingleLineTextField _lastFeedbackComment;
        public AngularExpandableSingleLineTextField LastFeedbackComment
        {
            get
            {
                return _lastFeedbackComment ?? (_lastFeedbackComment = new AngularExpandableSingleLineTextField(_driver, _waiter, "field_138"));
            }
        }

        private AngularTextPopupButtonField _feedbackButton;
        public AngularTextPopupButtonField FeedbackButton
        {
            get
            {
                return _feedbackButton ?? (_feedbackButton = new AngularTextPopupButtonField(_driver, _waiter, "field_139"));
            }
        }

        private AngularMultiSelectTreeField _attributes;
        public AngularMultiSelectTreeField Attributes
        {
            get
            {
                return _attributes ?? (_attributes = new AngularMultiSelectTreeField(_driver, _waiter, "field_177"));
            }
        }

        private AngularSingleLineTextField _externalApplication;
        public AngularSingleLineTextField ExternalApplication
        {
            get
            {
                return _externalApplication ?? (_externalApplication = new AngularSingleLineTextField(_driver, _waiter, "field_236"));
            }
        }

        private AngularSingleLineTextField _externalId;
        public AngularSingleLineTextField ExternalId
        {
            get
            {
                return _externalId ?? (_externalId = new AngularSingleLineTextField(_driver, _waiter, "field_237"));
            }
        }

        private AngularDatePickerField _lastImported;
        public AngularDatePickerField LastImported
        {
            get
            {
                return _lastImported ?? (_lastImported = new AngularDatePickerField(_driver, _waiter, "field_289"));
            }
        }

        private AngularMultiSelectTreeField _businessImpactArea;
        public AngularMultiSelectTreeField BusinessImpactArea
        {
            get
            {
                return _businessImpactArea ?? (_businessImpactArea = new AngularMultiSelectTreeField(_driver, _waiter, "field_291"));
            }
        }

        private AngularMultiSelectDropdownField _projectStages;
        public AngularMultiSelectDropdownField ProjectStages
        {
            get
            {
                return _projectStages ?? (_projectStages = new AngularMultiSelectDropdownField(_driver, _waiter, "field_292"));
            }
        }

        private AngularSingleLineTextField _owningItem;
        public AngularSingleLineTextField OwningItem
        {
            get
            {
                return _owningItem ?? (_owningItem = new AngularSingleLineTextField(_driver, _waiter, "field_458"));
            }
        }

        private AngularMultiLineTextField _notes;
        public AngularMultiLineTextField Notes
        {
            get
            {
                return _notes ?? (_notes = new AngularMultiLineTextField(_driver, _waiter, "field_525"));
            }
        }

        private AngularMultiLineTextField _customText1;
        public AngularMultiLineTextField CustomText1
        {
            get
            {
                return _customText1 ?? (_customText1 = new AngularMultiLineTextField(_driver, _waiter, "field_627"));
            }
        }

        private AngularMultiLineTextField _customText2;
        public AngularMultiLineTextField CustomText2
        {
            get
            {
                return _customText2 ?? (_customText2 = new AngularMultiLineTextField(_driver, _waiter, "field_628"));
            }
        }

        private AngularMultiLineTextField _customText3;
        public AngularMultiLineTextField CustomText3
        {
            get
            {
                return _customText3 ?? (_customText3 = new AngularMultiLineTextField(_driver, _waiter, "field_629"));
            }
        }

        private AngularMultiLineTextField _customText4;
        public AngularMultiLineTextField CustomText4
        {
            get
            {
                return _customText4 ?? (_customText4 = new AngularMultiLineTextField(_driver, _waiter, "field_630"));
            }
        }

        private AngularDatePickerField _customDate1;
        public AngularDatePickerField CustomDate1
        {
            get
            {
                return _customDate1 ?? (_customDate1 = new AngularDatePickerField(_driver, _waiter, "field_631"));
            }
        }

        private AngularDatePickerField _customDate2;
        public AngularDatePickerField CustomDate2
        {
            get
            {
                return _customDate2 ?? (_customDate2 = new AngularDatePickerField(_driver, _waiter, "field_632"));
            }
        }

        private AngularDatePickerField _customDate3;
        public AngularDatePickerField CustomDate3
        {
            get
            {
                return _customDate3 ?? (_customDate3 = new AngularDatePickerField(_driver, _waiter, "field_633"));
            }
        }

        private AngularDatePickerField _customDate4;
        public AngularDatePickerField CustomDate4
        {
            get
            {
                return _customDate4 ?? (_customDate4 = new AngularDatePickerField(_driver, _waiter, "field_634"));
            }
        }

        private AngularResourcePickerField _customResource1;
        public AngularResourcePickerField CustomResource1
        {
            get
            {
                return _customResource1 ?? (_customResource1 = new AngularResourcePickerField(_driver, _waiter, "field_635"));
            }
        }

        private AngularResourcePickerField _customResource2;
        public AngularResourcePickerField CustomResource2
        {
            get
            {
                return _customResource2 ?? (_customResource2 = new AngularResourcePickerField(_driver, _waiter, "field_636"));
            }
        }

        private AngularResourcePickerField _customResource3;
        public AngularResourcePickerField CustomResource3
        {
            get
            {
                return _customResource3 ?? (_customResource3 = new AngularResourcePickerField(_driver, _waiter, "field_637"));
            }
        }

        private AngularResourcePickerField _customResource4;
        public AngularResourcePickerField CustomResource4
        {
            get
            {
                return _customResource4 ?? (_customResource4 = new AngularResourcePickerField(_driver, _waiter, "field_638"));
            }
        }

        private AngularDropdownListField _customList1;
        public AngularDropdownListField CustomList1
        {
            get
            {
                return _customList1 ?? (_customList1 = new AngularDropdownListField(_driver, _waiter, "field_639"));
            }
        }

        private AngularDropdownListField _customList2;
        public AngularDropdownListField CustomList2
        {
            get
            {
                return _customList2 ?? (_customList2 = new AngularDropdownListField(_driver, _waiter, "field_640"));
            }
        }

        private AngularDropdownListField _customList3;
        public AngularDropdownListField CustomList3
        {
            get
            {
                return _customList3 ?? (_customList3 = new AngularDropdownListField(_driver, _waiter, "field_640"));
            }
        }

        private AngularMultiSelectDropdownField _customMultiList1;
        public AngularMultiSelectDropdownField CustomMultiList1
        {
            get
            {
                return _customMultiList1 ?? (_customMultiList1 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_642"));
            }
        }

        private AngularDatePickerField _lastUpdated;
        public AngularDatePickerField LastUpdated
        {
            get
            {
                return _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(_driver, _waiter, "field_678"));
            }
        }
    }
}
