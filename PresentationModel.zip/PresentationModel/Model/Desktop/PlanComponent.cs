﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class PlanComponent : RiskComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public PlanComponent(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private AngularSingleLineTextField _planId;

        public AngularSingleLineTextField PlanId
        {
            get
            {
                return _planId ?? (_planId = new AngularSingleLineTextField(_driver, _waiter, "field_67"));

            }
        }

        private AngularMultiLineTextField _planTitle;
        public AngularMultiLineTextField PlanTitle
        {
            get
            {
                return _planTitle ?? (_planTitle = new AngularMultiLineTextField(_driver, _waiter, "field_16"));

            }

        }
        private AngularResourcePickerField _ownerPlan;
        public AngularResourcePickerField Owner
        {
            get
            {
                return _ownerPlan ?? (_ownerPlan = new AngularResourcePickerField(_driver, _waiter, "field_69"));
            }
        }

        private AngularDatePickerField _startDate;

        public AngularDatePickerField StartDate
        {
            get
            {
                return _startDate ?? (_startDate = new AngularDatePickerField(_driver, _waiter, "field_72"));

            }
        }

        private AngularDatePickerField _completionDate;

        public AngularDatePickerField CompletionDate
        {
            get
            {
                return _completionDate ?? (_completionDate = new AngularDatePickerField(_driver, _waiter, "field_73"));

            }
        }
        private AngularDropdownListField _strategy;
        public AngularDropdownListField Strategy
        {
            get
            {
                return _strategy ?? (_strategy = new AngularDropdownListField(_driver, _waiter, "field_70"));
            }
        }
        private AngularMultiLineTextField _highLevelDescription;
        public AngularMultiLineTextField HighLevelDescription
        {
            get
            {
                return _highLevelDescription ?? (_highLevelDescription = new AngularMultiLineTextField(_driver, _waiter, "field_74"));
            }
        }

        private AngularMultiLineTextField _fallbackPlanDescription;
        public AngularMultiLineTextField FallbackPlanDescription
        {
            get
            {
                return _fallbackPlanDescription ?? (_fallbackPlanDescription = new AngularMultiLineTextField(_driver, _waiter, "field_75"));
            }
        }

        private AngularCostField _cost;

        public AngularCostField Cost
        {
            get { return _cost ?? (_cost = new AngularCostField(_driver, _waiter, "field_71", true, true, true)); }
        }

        private WebDriverButton _addplanButton;
        public WebDriverButton AddPlanButton
        {
            get { return _addplanButton ?? (_addplanButton = new WebDriverButton(_driver, _waiter, "AddPlanBtn")); }
        }

    }

}

