﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class EvaluationComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public EvaluationComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _addEvaluationButton;
        public WebDriverButton AddEvaluationButton
        {
            get
            {
                return _addEvaluationButton ?? (_addEvaluationButton = new WebDriverButton(_driver, _waiter, "AddEvaluationBtn"));
            }

        }

        private AngularSingleLineTextField _evaluationRef;
        public AngularSingleLineTextField Ref
        {
            get
            {
                return _evaluationRef ?? (_evaluationRef = new AngularSingleLineTextField(_driver, _waiter, "field_162"));
            }

        }

        private AngularMultiLineTextField _evaluationTitle;
        public AngularMultiLineTextField Title
        {
            get
            {
                return _evaluationTitle ?? (_evaluationTitle = new AngularMultiLineTextField(_driver, _waiter, "field_163"));
            }

        }

        private AngularDatePickerField _dueDate;

        public AngularDatePickerField DueDate
        {
            get
            {
                return _dueDate ?? (_dueDate = new AngularDatePickerField(_driver, _waiter, "field_165"));

            }
        }

        private AngularResourcePickerField _evaluationReviewer;
        public AngularResourcePickerField Reviewer
        {
            get
            {
                return _evaluationReviewer ?? (_evaluationReviewer = new AngularResourcePickerField(_driver, _waiter, "field_108"));
            }
        }

        private AngularDropdownListField _evaluationStatus;
        public AngularDropdownListField Status
        {
            get
            {
                return _evaluationStatus ?? (_evaluationStatus = new AngularDropdownListField(_driver, _waiter, "field_164"));
            }
        }

        private AngularResourcePickerField _evaluationPreparer;
        public AngularResourcePickerField Preparer
        {
            get
            {
                return _evaluationPreparer ?? (_evaluationPreparer = new AngularResourcePickerField(_driver, _waiter, "field_107"));
            }
        }

        private AngularDropdownListField _evaluationOperatingResult;
        public AngularDropdownListField OperatingResult
        {
            get
            {
                return _evaluationOperatingResult ?? (_evaluationOperatingResult = new AngularDropdownListField(_driver, _waiter, "field_150"));
            }
        }

        private AngularDropdownListField _evaluationDesignResult;
        public AngularDropdownListField DesignResult
        {
            get
            {
                return _evaluationDesignResult ?? (_evaluationDesignResult = new AngularDropdownListField(_driver, _waiter, "field_151"));
            }
        }

        private AngularDropdownListField _evaluationControlInfluence;
        public AngularDropdownListField ControlInfluence
        {
            get
            {
                return _evaluationControlInfluence ?? (_evaluationControlInfluence = new AngularDropdownListField(_driver, _waiter, "field_152"));
            }
        }

        private AngularMultiLineTextField _evaluationRemedialActionLink;
        public AngularMultiLineTextField RemedialActionLink
        {
            get
            {
                return _evaluationRemedialActionLink ?? (_evaluationRemedialActionLink = new AngularMultiLineTextField(_driver, _waiter, "field_153"));
            }

        }

        private AngularMultiLineTextField _evaluationCustomField1;
        public AngularMultiLineTextField CustomField1
        {
            get
            {
                return _evaluationCustomField1 ?? (_evaluationCustomField1 = new AngularMultiLineTextField(_driver, _waiter, "field_154"));
            }

        }

        private AngularMultiLineTextField _evaluationCustomField2;
        public AngularMultiLineTextField CustomField2
        {
            get
            {
                return _evaluationCustomField2 ?? (_evaluationCustomField2 = new AngularMultiLineTextField(_driver, _waiter, "field_155"));
            }

        }

        private AngularDatePickerField _preparedDate;

        public AngularDatePickerField PreparedDate
        {
            get
            {
                return _preparedDate ?? (_preparedDate = new AngularDatePickerField(_driver, _waiter, "field_166"));

            }
        }

        private AngularDatePickerField _reviewDate;

        public AngularDatePickerField ReviewDate
        {
            get
            {
                return _reviewDate ?? (_reviewDate = new AngularDatePickerField(_driver, _waiter, "field_167"));

            }
        }

        private AngularMultiLineTextField _evaluationDescription;
        public AngularMultiLineTextField Description
        {
            get
            {
                return _evaluationDescription ?? (_evaluationDescription = new AngularMultiLineTextField(_driver, _waiter, "field_168"));
            }

        }

        private AngularMultiLineTextField _evaluationReviewComments;
        public AngularMultiLineTextField ReviewComments
        {
            get
            {
                return _evaluationReviewComments ?? (_evaluationReviewComments = new AngularMultiLineTextField(_driver, _waiter, "field_169"));
            }

        }

        private AngularMultiLineTextField _evaluationConclusions;
        public AngularMultiLineTextField Conclusions
        {
            get
            {
                return _evaluationConclusions ?? (_evaluationConclusions = new AngularMultiLineTextField(_driver, _waiter, "field_170"));
            }

        }

        private AngularMultiLineTextField _evaluationRecommendations;
        public AngularMultiLineTextField Recommendations
        {
            get
            {
                return _evaluationRecommendations ?? (_evaluationRecommendations = new AngularMultiLineTextField(_driver, _waiter, "field_171"));
            }

        }

        private AngularMultiLineTextField _evaluationObjective;
        public AngularMultiLineTextField Objective
        {
            get
            {
                return _evaluationObjective ?? (_evaluationObjective = new AngularMultiLineTextField(_driver, _waiter, "field_172"));
            }

        }

        private AngularGridControl _gridEvaluation;
        public AngularGridControl GridEvaluation
        {
            get
            {
                return _gridEvaluation ?? (_gridEvaluation = new AngularGridControl(_driver, _waiter, "grid_6"));
            }
        }
    }
}
