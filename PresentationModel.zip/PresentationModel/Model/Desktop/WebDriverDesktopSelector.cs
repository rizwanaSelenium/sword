﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Desktop
{
    public class WebDriverDesktopSelector : WebDriverArmControl
    {
        private readonly string _selectorType;

        public WebDriverDesktopSelector(IWebDriver driver, WebDriverWait waiter, string selectorType) : base(driver, waiter, "div#" + selectorType + "-selector")
        {
            _selectorType = selectorType;

        }

        public void Select(string viewName)
        {
            var found = false;

            for (var i = 0; i < 30; i++)
            {
                if (Element.FindElement(By.CssSelector("div.dropDownTextBox div")).Text == viewName) return;

                var selector = "div#" + _selectorType + "-selector-holder div[title='" + viewName + "']";

                OpenFilterDropDown();

                if (Driver.FindElements(By.CssSelector(selector)).Any())
                {
                    var optionToSelect = Driver.FindElements(By.CssSelector(selector));
                    foreach (var filterOption in optionToSelect)
                    {
                        if (filterOption.Displayed)
                        {
                            filterOption.Click();
                            found = true;
                            i = 31;
                            break;
                        }
                    }
                }
                Thread.Sleep(1000);
            }

            if (!found)
            {
                var availableOptions = Driver.FindElements(By.CssSelector("div#" + _selectorType + "-selector-holder div.b-m-item"));

                var errorMessage = new StringBuilder();
                errorMessage.AppendLine(string.Format("Could not select item '{0}' from {1} selector.", viewName, _selectorType));

                if (availableOptions.Any())
                {
                    errorMessage.AppendLine("The available options were:");
                    errorMessage.AppendLine(string.Join(Environment.NewLine, availableOptions.Select(o => o.Text)));
                    Assert.Fail(errorMessage.ToString());
                }

                errorMessage.AppendLine("Couldn't find any options to select from.");
                Assert.Fail(errorMessage.ToString());
            }

            WaitUntilUiSpinnerIsNotDisplayed();
            WaitUntilDesktopFooterIsDisplayed();
        }

        public bool CheckOptionNotPresent(string optionNotExpected)
        {
            bool filterFound = false;
            if (Element.FindElement(By.CssSelector("div.dropDownTextBox div")).GetAttribute("title").Equals(optionNotExpected))
            {
                filterFound = true;
                Console.WriteLine("Option: " + optionNotExpected + " not expected, but was present in the list");
            }

            Element.Click();

            var filterOptions = Driver.FindElements(By.CssSelector("div#" + _selectorType + "-selector-holder div.b-m-item"));

            foreach (var filterOption in filterOptions)
            {
                if (filterOption.GetAttribute("title").Equals(optionNotExpected) && filterOption.Displayed)
                {
                    //added this line as after deleting a filter the old list can be left in the DOM
                        filterFound = true;
                        Console.WriteLine("Option: " + optionNotExpected + " not expected, but was present in the list");
                }
            }

            Element.Click();
            return filterFound;
        }

        public bool CheckOptionPresent(string optionExpected)
        {
            bool filterFound = Element.FindElement(By.CssSelector("div.dropDownTextBox div")).GetAttribute("title").Equals(optionExpected);

            Element.Click();

            var filterOptions = Driver.FindElements(By.CssSelector("div#" + _selectorType + "-selector-holder div.b-m-item"));

            foreach (var filterOption in filterOptions)
            {
                if (filterOption.GetAttribute("title").Equals(optionExpected))
                {
                    filterFound = true;
                }
            }
            
            Element.Click();
            return filterFound;
        }

        private void OpenFilterDropDown()
        {
            var filterOptions = Element.FindElements(By.CssSelector("div.b-m-item")).Where(e => e.Displayed);

            if (!filterOptions.Any())
            {
                Element.Click();
            }
        }

        public void CloseFilterDropDown()
        {
            var filterOptions = Driver.FindElements(By.CssSelector("div#" + _selectorType + "-selector-holder div.b-m-item"));

            foreach (var filterOption in filterOptions)
            {
                if (filterOption.GetAttribute("title").Equals("Edit...") && filterOption.Displayed)
                {
                    //added this line as after deleting a filter the old list can be left in the DOM
                        //This will close it again - can be left open if a test fails
                        Element.Click();
                }
            }
        }
    }
}
