﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Desktop
{
    public class RatingComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public RatingComponent(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _addRatingButton;
        public WebDriverButton AddRatingButton
        {
            get
            {
                return _addRatingButton ?? (_addRatingButton = new WebDriverButton(_driver, _waiter, "AddRatingBtn"));
            }

        }

        private AngularDropdownListField _ratingAffectedAccounts;
        public AngularDropdownListField AffectedAccounts
        {
            get
            {
                return _ratingAffectedAccounts ?? (_ratingAffectedAccounts = new AngularDropdownListField(_driver, _waiter, "field_475"));
            }
        }

        private AngularSingleLineTextField _ratingGrossExposure;
        public AngularSingleLineTextField GrossExposure
        {
            get
            {
                return _ratingGrossExposure ?? (_ratingGrossExposure = new AngularSingleLineTextField(_driver, _waiter, "field_476"));
            }

        }

        private AngularMultiLineTextField _ratingGeExplanation;
        public AngularMultiLineTextField GeExplanation
        {
            get
            {
                return _ratingGeExplanation ?? (_ratingGeExplanation = new AngularMultiLineTextField(_driver, _waiter, "field_477"));
            }

        }

        private AngularMultiLineTextField _ratingCompensatingControlReference;
        public AngularMultiLineTextField CompensatingControlReference
        {
            get
            {
                return _ratingCompensatingControlReference ?? (_ratingCompensatingControlReference = new AngularMultiLineTextField(_driver, _waiter, "field_478"));
            }

        }

        private AngularSingleLineTextField _ratingNetExposure;
        public AngularSingleLineTextField NetExposure
        {
            get
            {
                return _ratingNetExposure ?? (_ratingNetExposure = new AngularSingleLineTextField(_driver, _waiter, "field_479"));
            }

        }

        private AngularMultiLineTextField _ratingNeExplanation;
        public AngularMultiLineTextField NeExplanation
        {
            get
            {
                return _ratingNeExplanation ?? (_ratingNeExplanation = new AngularMultiLineTextField(_driver, _waiter, "field_480"));
            }

        }

        private AngularDropdownListField _ratingSignificanceOfMissstatement;
        public AngularDropdownListField SignificanceOfMissstatement
        {
            get
            {
                return _ratingSignificanceOfMissstatement ?? (_ratingSignificanceOfMissstatement = new AngularDropdownListField(_driver, _waiter, "field_481"));
            }
        }

        private AngularDropdownListField _ratingLikelihoodOfMissstatement;
        public AngularDropdownListField LikelihoodOfMissstatement
        {
            get
            {
                return _ratingLikelihoodOfMissstatement ?? (_ratingLikelihoodOfMissstatement = new AngularDropdownListField(_driver, _waiter, "field_482"));
            }
        }

        private AngularDropdownListField _ratingSeverityOfDeficiency;
        public AngularDropdownListField SeverityOfDeficiency
        {
            get
            {
                return _ratingSeverityOfDeficiency ?? (_ratingSeverityOfDeficiency = new AngularDropdownListField(_driver, _waiter, "field_483"));
            }
        }

        private AngularMultiLineTextField _ratingCustomField1;
        public AngularMultiLineTextField CustomField1
        {
            get
            {
                return _ratingCustomField1 ?? (_ratingCustomField1 = new AngularMultiLineTextField(_driver, _waiter, "field_484"));
            }

        }

        private AngularDropdownListField _ratingCurrency;
        public AngularDropdownListField Currency
        {
            get
            {
                return _ratingCurrency ?? (_ratingCurrency = new AngularDropdownListField(_driver, _waiter, "field_515"));
            }
        }
        
        private AngularDatePickerField _ratingLastUpdate;
        public AngularDatePickerField LastUpdate
        {
            get
            {
                return _ratingLastUpdate ?? (_ratingLastUpdate = new AngularDatePickerField(_driver, _waiter, "field_672"));

            }
        }
    }
}

