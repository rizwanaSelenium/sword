﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model
{
    public class WebDriverReportFilterResults : WebDriverArmPage
    {
        //Old window but still in ARM

        public WebDriverTableControl ResultsTable;

        public WebDriverReportFilterResults(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "ReportsRecordCount.aspx")
        {
            ResultsTable = new WebDriverTableControl(driver, waiter, "RootView_RecordCounts");
        }
    }
}
