﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.SurveyBuilder
{
    public class SurveyPublishPage : SurveyBasecontrol
    {

        private WebDriverTextField _newSurveyTitle;
        public WebDriverTextField NewSurveyTitle
        {
            get
            {
                return _newSurveyTitle ?? (_newSurveyTitle = new WebDriverTextField(Driver, Waiter, "input#validated-input-title", true));
            }
        }


        private AngularDatePicker _fromDate;

        public AngularDatePicker FromDate
        {
            get { return _fromDate ?? (_fromDate = new AngularDatePicker(Driver, Waiter, "from-date_component")); }
        }

        private AngularDatePicker _toDate;
        public AngularDatePicker ToDate
        {
            get { return _toDate ?? (_toDate = new AngularDatePicker(Driver, Waiter, "to-date_component")); }
        }

        private AngularDatePicker _dueDate;
        public AngularDatePicker DueDate
        {
            get { return _dueDate ?? (_dueDate = new AngularDatePicker(Driver, Waiter, "due-date_component")); }
        }


        private WebDriverLinkControl _surveyDetailTab;
        public WebDriverLinkControl SurveyDetailTab
        {
            get
            {
                return _surveyDetailTab ?? (_surveyDetailTab = new WebDriverLinkControl(Driver, Waiter, "Survey Detail"));
            }
        }

        private WebDriverButton _surveyPublishOkButton;
        public WebDriverButton SurveyPublishOkButton
        {
            get
            {
                return _surveyPublishOkButton ?? (_surveyPublishOkButton = new WebDriverButton(Driver, Waiter, "modalYesButton"));
            }
        }

        public SurveyPublishPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "publish")
        {

        }

        private WebDriverDropDown _sendTo;
        public WebDriverDropDown SendTo
        {
            get
            {
                return _sendTo ?? (_sendTo = new WebDriverDropDown(Driver, Waiter, "select#emailRecipientType", true));
            }
        }

        private AngularResourcePickerField _resource;
        public AngularResourcePickerField Resource
        {
            get
            {
                return _resource ?? (_resource = new AngularResourcePickerField(Driver, Waiter, "resourceRecipient"));
            }
        }

        private AngularArmMultiSelect _resourceGroup;
        public AngularArmMultiSelect ResourceGroup
        {
            get
            {
                return _resourceGroup ?? (_resourceGroup = new AngularArmMultiSelect(Driver, Waiter, "recipients", false));
            }
        }

        private WebDriverTextField _subject;
        public WebDriverTextField Subject
        {
            get { return _subject ?? (_subject = new WebDriverTextField(Driver, Waiter, "input#subject", true)); }
        }

        private WebDriverButton _surveyUrl;
        public WebDriverButton SurveyUrl
        {
            get { return _surveyUrl ?? (_surveyUrl = new WebDriverButton(Driver, Waiter, "surveyUrl-button")); }
        }

        private WebDriverTextAreaControl _surveyEmailBody;
        public WebDriverTextAreaControl SurveyEmailBody
        {
            get
            {
                return _surveyEmailBody ?? (_surveyEmailBody = new WebDriverTextAreaControl(Driver, Waiter, "textarea#emailBody",true));
            }
        }
        private WebDriverButton _sendButton;

        public WebDriverButton SendButton
        {
            get
            {
                return _sendButton ?? (_sendButton = new WebDriverButton(Driver, Waiter, "send-button"));
            }
        }

        public void AssertSurveyEmailBodyText(string expectedValue)
        {
            var newsurveyTitle =
                new WebDriverTextAreaControl(Driver, Waiter, "arm-expandable-input#emailBody textarea", true)
                    .GetAttribute("ng-reflect-model");
            Assert.AreEqual(expectedValue, newsurveyTitle);
        }

        public void AssertSurveySubjectText(string expectedValue)
        {
            var newsurveyTitle = Subject.GetAttribute("ng-reflect-model");
            Assert.AreEqual(expectedValue, newsurveyTitle);
        }

        public void AssertSurveyResourceGroups(string expectedValue)
        {
            var resurceGroupText = ResourceGroup.GetText();
            Assert.AreEqual(expectedValue, resurceGroupText);
        }
    }
}
