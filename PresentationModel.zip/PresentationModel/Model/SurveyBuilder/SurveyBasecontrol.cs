﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.SurveyBuilder
{
    public class SurveyBasecontrol : WebDriverArmPage
    {

        private WebDriverButton _cancel;

        public WebDriverButton Cancel
        {
            get
            {
                return _cancel ?? (_cancel = new WebDriverButton(Driver, Waiter, "cancel-button"));

            }
        }


        private WebDriverButton _close;

        public new WebDriverButton Close
        {
            get { return _close ?? (_close = new WebDriverButton(Driver, Waiter, "close-button")); }
        }


        private WebDriverButton _surveySaveButton;

        public WebDriverButton SurveySaveButton
        {
            get
            {
                return _surveySaveButton ?? (_surveySaveButton = new WebDriverButton(Driver, Waiter, "save-button"));
            }
        }

        public void SaveSurvey()
        {
            SurveySaveButton.Click();
            WaitUntilPageIsReady();
        }

        public int GetId()
        {

            string wholeurl = Driver.Url;
            var stringArray = wholeurl.Split('/');

            int id = Int32.Parse(stringArray[8]);
            Console.WriteLine(id);
            return id;
        }


        private WebDriverButton _surveyBuildOkButton;

        public WebDriverButton SurveyBuildOkButton
        {
            get
            {
                return _surveyBuildOkButton ?? (_surveyBuildOkButton = new WebDriverButton(Driver, Waiter, "modalYesButton"));
            }
        }

        public void OkSurvey()
        {
            SurveyBuildOkButton.Click();
            WaitUntilPageIsReady();
        }

        public SurveyBasecontrol(IWebDriver driver, WebDriverWait waiter, string pageName) : base(driver, waiter, pageName)
        {

        }


    }

}
