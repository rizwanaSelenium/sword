﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using TechTalk.SpecFlow;

namespace PresentationModel.Model.SurveyBuilder
{
    public class SurveyLandingPage : SurveyBasecontrol
    {

        private AngularTab _homeTab;
        public AngularTab HomeTab
        {
            get { return _homeTab ?? (_homeTab = new AngularTab(Driver, Waiter, "navmenu-home")); }
        }

        private AngularTab _publishTab;
        public AngularTab PublishTab
        {
            get { return _publishTab ?? (_publishTab = new AngularTab(Driver, Waiter, "navmenu-publish")); }
        }

        private AngularTab _buildTab;
        public AngularTab BuildTab
        {
            get { return _buildTab ?? (_buildTab = new AngularTab(Driver, Waiter, "navmenu-build")); }
        }

        private WebDriverButton _newSurveyButton;
        public WebDriverButton NewSurveyButton
        {
            get { return _newSurveyButton ?? (_newSurveyButton = new WebDriverButton(Driver, Waiter, "div[class='icon fas fa-fw fa-plus-square']", true)); }
        }

        private WebDriverButton _deleteSurveyButton;
        public WebDriverButton DeleteSurveyButton
        {
            get { return _deleteSurveyButton ?? (_deleteSurveyButton = new WebDriverButton(Driver, Waiter, "div[class='icon fas fa-fw fa-trash-alt']", true)); }
        }

        private WebDriverButton _firstSurveyPageButton;
        public WebDriverButton FirstSurveyPageButton
        {
            get { return _firstSurveyPageButton ?? (_firstSurveyPageButton = new WebDriverButton(Driver, Waiter, "button[ref='btFirst']", true)); }
        }

        private WebDriverButton _nextSurveyPageButton;
        public WebDriverButton NextSurveyPageButton
        {
            get { return _nextSurveyPageButton ?? (_nextSurveyPageButton = new WebDriverButton(Driver, Waiter, "button[ref='btNext']", true)); }
        }

        private WebDriverButton _previousSurveyPageButton;
        public WebDriverButton PreviousSurveyPageButton
        {
            get { return _previousSurveyPageButton ?? (_previousSurveyPageButton = new WebDriverButton(Driver, Waiter, "button[ref='btPrevious']", true)); }
        }

        private IWebElement _currentSurveyPage;
        public IWebElement CurrentSurveyPage
        {
            get { return _currentSurveyPage ??(_currentSurveyPage = Driver.FindElement(By.CssSelector("span[ref='lbCurrent']"))); }
        }

        private IWebElement _totalSurveyPages;
        public IWebElement TotalSurveyPages
        {
            get { return _totalSurveyPages ?? (_totalSurveyPages = Driver.FindElement(By.CssSelector("span[ref='lbTotal']"))); }
        }

        public WebDriverTextField ArmSurveyBuilderMessage { get; set; }

        public SurveyLandingPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "surveys")
        {
            ArmSurveyBuilderMessage = new WebDriverTextField(driver, waiter, "div#nav-header-title ", true);
            WaitUntilPageIsReady();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public SurveyPublishPage SurveyPublishPage
        {
            get
            {
                FocusWindow();
                PublishTab.Click();
                return new SurveyPublishPage(Driver, Waiter);
            }
        }

        public SurveyBuildPage SurveyBuildPage
        {
            get
            {
                FocusWindow();
                BuildTab.Click();
                return new SurveyBuildPage(Driver, Waiter);
            }
        }

        public SurveyBuildPage NewSurvey
        {
            get
            {
                FocusWindow();
                NewSurveyButton.Click();
                return new SurveyBuildPage(Driver, Waiter);
            }
        }

        public void VerifySurveyData(string expectedValue, string columnname, string recordId)
        {
            var mySurvey = LocateSurveyInGrid(recordId, "id");
            var columnId = mySurvey.FindElement(By.CssSelector("div[col-id =" + columnname + "]"));
            Assert.AreEqual(columnId.Text, Convert.ToString(expectedValue));
        }

        public void SelectSurveyOnGrid(string columNname, string surveyToFind)
        {
            var mySurvey = LocateSurveyInGrid(surveyToFind, columNname);
            SelectSurveyInGrid(mySurvey);
        }

        public int CheckOnlyOneSurveyWithTheTitleExists(string surveyName, string columnName, bool shouldExist = true)
        {
            var surveysFound = 0;
            var surveyOnPage = 0;
            if (CurrentSurveyPage.Text != "1")
            {
                FirstSurveyPageButton.Click();
            }

            for (var i = 0; i < Convert.ToInt32(TotalSurveyPages.Text); i++)
            {
                var tempCount = Driver.FindElements(By.CssSelector("div[col-id='" + columnName + "']")).Where(a => a.Text == surveyName).ToList().Count;
                if (tempCount == 1 && surveyOnPage == 0)
                {
                    surveysFound = surveysFound + tempCount;
                    surveyOnPage = Convert.ToInt32(CurrentSurveyPage.Text);
                }else if (tempCount > 1 || tempCount == 1 && surveyOnPage != 0)
                {
                    throw new Exception("More than 1 survey found with the name " + surveyName + " there should only be one to ensure the correct one is being used.");
                }
                else if (surveysFound == 0 && i == Convert.ToInt32(TotalSurveyPages.Text) - 1 && shouldExist)
                {
                    throw new Exception("No surveys found with a column: " + columnName + " with the value of: " + surveyName + ". Expected to find one that matches the criteria.");
                }
                if(i +1 < Convert.ToInt32(TotalSurveyPages.Text)){NextSurveyPageButton.Click();}
            }

            return surveyOnPage;
        }

        private IWebElement LocateSurveyInGrid(string surveyToFind, string columnName)
        {
            try
            {
                Waiter.Until(d => Driver.FindElements(By.CssSelector("div[class^='ag-body-container'] div[class^='ag-row']")).Count >= 1);
            }
            catch (WebDriverTimeoutException)
            {
                throw new WebDriverTimeoutException("No surveys found on survey desktop.");
            }

            var surveyOnPage = CheckOnlyOneSurveyWithTheTitleExists(surveyToFind, columnName);

            while (Convert.ToInt32(CurrentSurveyPage.Text) != surveyOnPage)
            {
                if (Convert.ToInt32(CurrentSurveyPage.Text) < surveyOnPage)
                {
                    NextSurveyPageButton.Click();
                }
                else if (Convert.ToInt32(CurrentSurveyPage.Text) > surveyOnPage)
                {
                    PreviousSurveyPageButton.Click();
                }
            }

            var mySurveyGrid = Driver.FindElements(By.CssSelector("div[class^='ag-body-container'] div[class^='ag-row']"));

            foreach (var survey in mySurveyGrid)
                {
                    if (survey.FindElement(By.CssSelector("div[col-id='" + columnName + "']")).Text == surveyToFind)
                    {
                        return survey;
                    }
                }
            throw new Exception("Failed to find your survey in the grid, survey name " + surveyToFind);
        }

        private void SelectSurveyInGrid(IWebElement surveyToSelect)
        {
            surveyToSelect.Click();
            Thread.Sleep(1000);

            for (var i = 0; !HomeTab.GetAttribute("class").Contains("active"); i++)
            {
                HomeTab.Click();
                Thread.Sleep(1000);
                if (i > 10)
                {
                    throw new WebDriverException("Failed to select the survey on the grid.");
                }
            }

            if (surveyToSelect.GetAttribute("class").Contains("ag-row-selected") &&
                DeleteSurveyButton.IsEnabled())
            {
                return;
            }

            throw new Exception("Failed to select survey in grid.");
        }

        private void DeleteSurveyInGrid()
        {
            for (var i = 0; i < 10; i++)
            {
                DeleteSurveyButton.Click();
                Thread.Sleep(1000);
                if (Driver.FindElements(By.Id("modalMessageBox")).Count == 1)
                {
                    return;
                }
            }
            throw new Exception("Failed to delete survey.");
        }

        public void DeleteSurvey(Table surveysToDelete)
        {
            foreach (var surveyToDelete in surveysToDelete.Rows)
            {
                var mySurvey = LocateSurveyInGrid(surveyToDelete["Survey title"].Trim(), "title");
                SelectSurveyInGrid(mySurvey);
                DeleteSurveyInGrid();

                var modalControl = new AngularModal(Driver, Waiter);
                modalControl.Yes();

                Thread.Sleep(500);
            }
        }
    }
}
