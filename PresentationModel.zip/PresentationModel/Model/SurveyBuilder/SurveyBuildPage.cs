﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.SurveyBuilder
{
    public class SurveyBuildPage : SurveyBasecontrol
    {
        private WebDriverTextField _surveyPageTitle;
        public WebDriverTextField SurveyPageTitle
        {
            get
            {
                return _surveyPageTitle ?? (_surveyPageTitle = new WebDriverTextField(Driver, Waiter, "input#title", true));
            }
        }

        private WebDriverTextField _newSurveyTitle;
        public WebDriverTextField NewSurveyTitle
        {
            get
            {
                return _newSurveyTitle ?? (_newSurveyTitle =
                           new WebDriverTextField(Driver, Waiter, "input#surveytitle", true));
            }
        }

        private WebDriverLinkControl _publishTab;
        public WebDriverLinkControl PublishTab
        {
            get { return _publishTab ?? (_publishTab = new WebDriverLinkControl(Driver, Waiter, "Publish")); }
        }

        public SurveyPublishPage OpenSurvey
        {
            get
            {
                FocusWindow();
                PublishTab.Click();
                return new SurveyPublishPage(Driver, Waiter);
            }
        }

        public SurveyBuildPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "build")
        {
            WaitUntilPageIsReady();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        private WebDriverTextField _surveyPagenumber;
        public WebDriverTextField SurveyPagenumber
        {
            get
            {
                return _surveyPagenumber ?? (_surveyPagenumber =
                           new WebDriverTextField(Driver, Waiter, "div.list-item div.list-item-header", true));
            }
        }

        private WebDriverTextAreaControl _surveyPageDescription;
        public WebDriverTextAreaControl SurveyPageDescription
        {
            get
            {
                return _surveyPageDescription ?? (_surveyPageDescription = new WebDriverTextAreaControl(Driver, Waiter, "textarea[id='description']", true));
            }
        }

        private WebDriverButton _addQuestionButton;
        public WebDriverButton AddQuestionButton
        {
            get
            {
                return _addQuestionButton ??
                       (_addQuestionButton = new WebDriverButton(Driver, Waiter, "#new-question-button", true));
            }
        }

        private WebDriverButton _addNewPageButton;
        public WebDriverButton AddNewPageButton
        {
            get
            {
                return _addNewPageButton ??
                       (_addNewPageButton = new WebDriverButton(Driver, Waiter, "#add-survey-page", true));
            }
        }

        public void AssertSurveyTitle(string expectedValue)
        {
            var newsurveyTitle = NewSurveyTitle.GetAttribute("value");
            Assert.AreEqual(expectedValue, newsurveyTitle);
        }

        public void VerifyPageTitleandDescription(string pageTitle, string pageDescription, string surveyPageNumber)
        {
            SelectAddedNewsurveypage(surveyPageNumber);
            var surveyPage = Driver.FindElements(By.CssSelector("div#page-list div[data-page-order='" + surveyPageNumber + "']"));

            var surveyPageSidebarDescription = surveyPage[0].FindElement(By.CssSelector("p[id^='page-description']")).Text;
            var surveyPagesidebarTitle = Driver.FindElements(By.CssSelector(".list-item-header span")).Count(x => x.Text == surveyPageNumber + "." + pageTitle);

            var surveyPageDescription = Driver.FindElement(By.CssSelector("div.survey-page textarea#description")).Text;
            var surveyPageNum = Driver.FindElement(By.CssSelector("div.survey-page div.page-number")).Text;

            if (surveyPagesidebarTitle == 0) { throw new Exception("No Survey pages found with the title "+ surveyPageNumber + "." + pageTitle + " in the side bar");}
            if (surveyPagesidebarTitle > 1) { throw new Exception("More than one Survey page found with the title " + surveyPageNumber + "." + pageTitle + " in the side bar, should only have one."); }
            Assert.AreEqual(pageDescription, surveyPageSidebarDescription, "Survey sidebar description is not correct.");
            Assert.AreEqual(surveyPageNumber + ". " , surveyPageNum, "Survey page number showing incorrectly.");
            Assert.AreEqual(pageDescription, surveyPageDescription, "Survey main page description is not correct.");
        }

        public void VerifyNoSurveyTitleValidationMessage(string message)
        {
            var noSurveyTitleValidationMessage = Driver.FindElement(By.CssSelector("div[id='validationPanel'] ul li p"));
            Assert.AreEqual(message, noSurveyTitleValidationMessage.Text);
        }

        public void AddNewSurveyPage()
        {
            var pagesBefore = Driver.FindElements(By.CssSelector("div#page-list div.list-item")).Count;
            for (int i = 0; i < 10; i++)
            {
                AddNewPageButton.Click();
                Thread.Sleep(1000);
                var pagesAfter = Driver.FindElements(By.CssSelector("div#page-list div.list-item")).Count;
                if( pagesAfter > pagesBefore) { break; }
                if (i == 9) { throw new Exception("Failed to add a new survey page.");}
            }
        }

        public void SelectAddedNewsurveypage(string surveyPageNumber)
        {
            var found = false;
            var surveyPages = Driver.FindElements(By.CssSelector("div#page-list"));
            var surveyPage = Driver.FindElements(By.CssSelector("div#page-list div[data-page-order='" + surveyPageNumber + "']"));

            if (surveyPage.Count != 1) { throw new Exception("Something went wrong finding the survey page, looking for page number " + surveyPageNumber + ". Found " + surveyPages.Count + " pages."); }

            for (int i = 0; i < 10; i++)
            {
                if (Driver.FindElement(By.CssSelector("div.page-number")).Text != surveyPageNumber + ". ")
                {
                    surveyPage[0].Click();
                    Thread.Sleep(1000);
                    if(Driver.FindElement(By.CssSelector("div.page-number")).Text == surveyPageNumber + ". ")
                    {
                        found = true;
                        break;}
                }
                else
                {
                    found = true;
                    break;
                }
            }

            if (!found) { throw new Exception("Faield to select survey page " + surveyPageNumber); }
        }

        public string GetNewQuestionId()
        {
            var questionsList = Driver.FindElements(By.CssSelector("arm-question-list-item"));
            string newQuestionId = questionsList.Last().GetAttribute("id");
            return newQuestionId;
        }

        public string GetQuestionText(string questionId)
        {
            var questionTextElement = Driver.FindElement(By.CssSelector("arm-question-list-item#" + questionId + " div[class='question-text']"));
            return questionTextElement.Text;
        }

        public void SelectQuestionType(string newQuestionId, string questionType)
        {
            var dropDown = new WebDriverDropDown(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " select", true);

            switch (questionType)
            {
                case "single select radio button":
                    dropDown.SetValue("Single Select");
                    break;
                case "linear scaling":
                    dropDown.SetValue("Linear Scale");
                    break;
                case "Text":
                    dropDown.SetValue("Text");
                    break;
                case "Grid":
                    dropDown.SetValue("Matrix / Rating Scale");
                    break;
                default:
                    throw new ArgumentException("No such question type, was looking for question type " + questionType + ".");
            }
        }

        public void SetQuestionText(string newQuestionId, string questionText)
        {
            var questionField = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " arm-expandable-input textarea", true);
            questionField.SetValue(questionText);
        }

        public void CheckTheRequiredBox(string newQuestionId)
        {
            var requiredTickBox = new WedDriverBootstrapTickBoxControl(Driver, Waiter, "arm-question-list-item#" + newQuestionId);
            requiredTickBox.Check();
        }

        public void AddNewRadioButton(string newQuestionId, string label)
        {
            var addRadioButton = new WebDriverButton(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[id^='option-new']", true);
            addRadioButton.Click();
            WaitUntilPageIsReady();
            var inputRowBox = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[class*='ng-invalid']", true);
            inputRowBox.SetValue(label);
        }

        public void VerifyNewRadioButtonLabels(string newQuestionId, string newQuestionLabel, int index)
        {
            var optionsList = Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " label[id^='label_radio-input']"));

            var label = optionsList[index].Text.Trim();
            Assert.AreEqual(newQuestionLabel, label);
        }

        public void DeleteRadioButtonOption(string newQuestionId, string optionToBeDeleted)
        {
            var optionsList = Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " arm-question-option-list div.input-group"));
            foreach (var option in optionsList)
            {
                var rowedit = option.FindElement(By.CssSelector("input[class^='form-control'"));
                if (rowedit.GetAttribute("class") == "form-control option-new") continue;
                if (rowedit.GetAttribute("value").Trim() == optionToBeDeleted)
                {
                    var binButton = option.FindElement(By.CssSelector("button[id ^='delete-option']"));
                    binButton.Click();
                }
            }

            var optionsList2 = Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " arm-question-option-list div.input-group"));
            foreach (var option in optionsList2)
            {
                var rowedit = option.FindElement(By.CssSelector("input[class^='form-control'"));
                if (rowedit.GetAttribute("class") == "form-control option-new") continue;
                if (rowedit.GetAttribute("value").Trim() == optionToBeDeleted)
                {
                    throw new Exception("Option " + optionToBeDeleted + " has not been deleted!");
                }
            }
        }

        public void CheckNoMoreOptionCanBedeleted(string newQuestionId)
        {
            var optionsList = Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " arm-question-option-list div.input-group"));
            var optionsListwithBin = Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " arm-question-option-list div.input-group button[id ^='delete-option']"));
            if (optionsList.Count > 3)
            {
                throw new SystemException("There are more options than expected left " + optionsList.Count + ".");
            }
            if (optionsListwithBin.Count != 0)
            {
                throw new SystemException("The number are still options with bin buttons left, number of options found " + optionsListwithBin.Count + ".");
            }
        }

        public void VerifyQuestionCommons(string questionIdVerif, string questionTextVerif)

        {
            var questionText =
                Driver.FindElement(By.CssSelector("arm-question-list-item#" + questionIdVerif + " div[class='question-text']"));
            Assert.AreEqual(questionTextVerif, questionText.Text);
        }

        public void SetScalingQuestion(string newQuestionId, string maxScaleValue, string minScaleLabel, string maxScaleLabel)
        {
            var maxScale = new WebDriverDropDown(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " select[id^='number-of-options']",
                true);
            if (maxScaleValue != "")
            {
                maxScale.SetValue(maxScaleValue);
            }

            var minLabel = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[id^='min']", true);
            if (minScaleLabel != "")
            {
                minLabel.SetValue(minScaleLabel);
            }

            var maxLabel = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[id^='max']", true);
            if (maxScaleLabel != "")
            {
                maxLabel.SetValue(maxScaleLabel);
            }
        }

        public void VerifyScalingQuestion(string questionIdVerif, string maxScaleValueVerif, string minScaleLabelVerif, string maxScaleLabelVerif)
        {
            var maxScale = Driver.FindElements(By.CssSelector("arm-question-list-item#" + questionIdVerif + " input[id ^= 'radio-input']"));
            Assert.AreEqual(maxScaleValueVerif, maxScale.Count.ToString());

            var labels = Driver.FindElements(By.CssSelector("arm-question-list-item#" + questionIdVerif + " div[class='linear-scale-range-label-container'] label"));
            Assert.AreEqual(minScaleLabelVerif, labels[0].Text);
            Assert.AreEqual(maxScaleLabelVerif, labels[1].Text);
        }

        public void SetTextQuestion(string newQuestionId, string lineType)
        {

            var dropDown = new WebDriverDropDown(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " select[id^='number-of-options']",
                true);

            switch (lineType)
            {
                case "Single":
                    dropDown.SetValue("Single Line");
                    break;
                case "Multiple":
                    dropDown.SetValue("Multiple Line");
                    break;
                default:
                    throw new ArgumentException("No such Text question line type");
            }

        }

        public void VerifyTextQuestion(string questionIdVerif, string lineTypeVerif)
        {
            switch (lineTypeVerif)
            {
                case "Single Line":
                    try
                    {
                        Driver.FindElement(By.CssSelector("arm-question-list-item#" + questionIdVerif + " input[id^='text-input']"));
                    }
                    catch (NoSuchElementException)
                    {
                        throw new NoSuchElementException("Single Line input expected for " + questionIdVerif);
                    }
                    break;
                case "Multiple Line":
                    try
                    {
                        Driver.FindElement(By.CssSelector("arm-question-list-item#" + questionIdVerif + " textarea[id^='textarea']"));
                    }
                    catch (NoSuchElementException)
                    {
                        throw new NoSuchElementException("Multiple Line input expected for " + questionIdVerif);
                    }
                    break;
                default:
                    throw new ArgumentException("No such Text question line type");
            }
        }

        public void AddNewRowTitle(string newQuestionId, string label)
        {
            var addRadioButton = new WebDriverButton(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[id^='option-new-row']", true);
            addRadioButton.Click();
            WaitUntilPageIsReady();
            var inputRowBox = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[class*='ng-invalid']", true);
            inputRowBox.SetValue(label);
        }

        public void AddNewAnswerOption(string newQuestionId, string label)
        {
            var addRadioButton = new WebDriverButton(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[id^='option-new-col']", true);
            addRadioButton.Click();
            WaitUntilPageIsReady();
            var inputRowBox = new WebDriverTextField(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " input[class*='ng-invalid']", true);
            inputRowBox.SetValue(label);
        }

        public void VerifyGridRowColumValues(string questionIdVerif, string rowTitle, string columnTitle, int rowNumber)
        {
            var rowTitle1 = Driver.FindElements(By.CssSelector("arm-question-list-item#" + questionIdVerif + " table[class^='table'] tr"));
            Assert.AreEqual(rowTitle, rowTitle1[rowNumber].Text.Trim());

            var columnTitle1 = Driver.FindElements(By.CssSelector("arm-question-list-item#" + questionIdVerif + " table[class^='table'] tr th"));
            Assert.AreEqual(columnTitle, columnTitle1[rowNumber].Text.Trim());
        }

        public void EditAQuestion(string newQuestionId)
        {
            var editQuestionButton = new WebDriverButton(Driver, Waiter, "arm-question-list-item#" + newQuestionId + " button[id^='edit-question']", true);
            editQuestionButton.Click();

            //click action on edit button is not always picked up so we should try a few times before we fail the test
            for (var i = 0; i < 5; i++)
            {
                Thread.Sleep(4000);

                if (Driver.FindElements(By.CssSelector("arm-question-list-item#" + newQuestionId + " select")).Any(x => x.Displayed) )
                {
                    Console.WriteLine("Found drop-down menu");
                    break;
                }

                Console.WriteLine("Failed to find drop-down menu");
                editQuestionButton.Click();
            }
        }
    }
}
