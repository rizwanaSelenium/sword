﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;

namespace PresentationModel.Model.ComplianceTask
{
    public class ComplianceTaskDialog : ComplianceComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private AngularSingleLineTextField _id;
        private AngularMultiLineTextField _title;
        private AngularDatePickerField _created;
        private AngularDatePickerField _due;
        private AngularDatePickerField _lastUpdated;
        private AngularMultiLineTextField _description;
        private AngularMultiLineTextField _notes;
        private AngularResourcePickerField _owner;
        private AngularDropdownListField _status;

        public ComplianceTaskDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Task")
        {
            _driver = driver;
            _waiter = waiter;
        }

        public AngularSingleLineTextField Id
        {
            get { return _id ?? (_id = new AngularSingleLineTextField(_driver, _waiter, "field_824")); }
        }

        public AngularMultiLineTextField Title
        {
            get { return _title ?? (_title = new AngularMultiLineTextField(_driver, _waiter, "field_825")); }

        }

        public AngularDatePickerField Created
        {
            get { return _created ?? (_created = new AngularDatePickerField(_driver, _waiter, "field_826")); }
        }

        public AngularDatePickerField LastUpdated
        {
            get { return _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(_driver, _waiter, "field_827")); }
        }

        public AngularDatePickerField Due
        {
            get { return _due ?? (_due = new AngularDatePickerField(_driver, _waiter, "field_828")); }
        }

        public AngularMultiLineTextField Description
        {
            get { return _description ?? (_description = new AngularMultiLineTextField(_driver, _waiter, "field_829")); }
        }

        public AngularMultiLineTextField Notes
        {
            get { return _notes ?? (_notes = new AngularMultiLineTextField(_driver, _waiter, "field_830")); }
        }

        public AngularResourcePickerField Owner
        {
            get { return _owner ?? (_owner = new AngularResourcePickerField(_driver, _waiter, "field_831")); }
        }

        public AngularDropdownListField Status
        {
            get { return _status ?? (_status = new AngularDropdownListField(_driver, _waiter, "field_832")); }
        }

        public void AssertLabelsEqualsToCustomConfig(string label, string customLabel)
        {
            switch (label)
            {
                case "Id":
                    Id.AssertLabelEquals(customLabel);
                    break;
                case "Title":
                    Title.AssertLabelEquals(customLabel);
                    break;
                case "Created":
                    Created.AssertLabelEquals(customLabel);
                    break;
                case "Due":
                    Due.AssertLabelEquals(customLabel);
                    break;
                case "Last Updated":
                    LastUpdated.AssertLabelEquals(customLabel);
                    break;
                case "Description":
                    Description.AssertLabelEquals(customLabel);
                    break;
                case "Notes":
                    Notes.AssertLabelEquals(customLabel);
                    break;
                case "Owner":
                    Owner.AssertLabelEquals(customLabel);
                    break;
                case "Status":
                    Status.AssertLabelEquals(customLabel);
                    break;
                default:
                    Assert.Fail();
                    break;
            }
        }
    }
}
