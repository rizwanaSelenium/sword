﻿namespace PresentationModel.Model.ComplianceTask
{
    public class ComplianceTaskModel
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Created { get; set; }
        public string LastUpdated { get; set; }
        public string Due { get; set; }
        public string Description { get; set; }
        public string Notes { get; set; }
        public string Owner { get; set; }
        public string Status { get; set; }
    }
}
