﻿namespace PresentationModel.Model.ComplianceFolder
{
    public class ComplianceFolderModel
    {
        public string FolderId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Created { get; set; }
        public string LastUpdated { get; set; }
    }
}
