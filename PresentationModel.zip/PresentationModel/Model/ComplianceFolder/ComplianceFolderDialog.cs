﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;

namespace PresentationModel.Model.ComplianceFolder
{
    public class ComplianceFolderDialog : ComplianceComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private AngularSingleLineTextField _id;
        private AngularMultiLineTextField _title;
        private AngularMultiLineTextField _description;
        private AngularDatePickerField _created;
        private AngularDatePickerField _lastUpdated;

        public ComplianceFolderDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Folder")
        {
            _driver = driver;
            _waiter = waiter;
        }

        public AngularSingleLineTextField Id => _id ?? (_id = new AngularSingleLineTextField(_driver, _waiter, "field_836"));

        public AngularMultiLineTextField Title => _title ?? (_title = new AngularMultiLineTextField(_driver, _waiter, "field_837"));

        public AngularMultiLineTextField Description => _description ?? (_description = new AngularMultiLineTextField(_driver, _waiter, "field_840"));

        public AngularDatePickerField Created => _created ?? (_created = new AngularDatePickerField(_driver, _waiter, "field_838"));

        public AngularDatePickerField LastUpdated => _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(_driver, _waiter, "field_839"));

        public void AssertLabelsEqualsToCustomConfig(string label, string customLabel)
        {
            switch (label)
            {
                case "Id":
                    Id.AssertLabelEquals(customLabel);
                    break;
                case "Title":
                    Title.AssertLabelEquals(customLabel);
                    break;
                case "Description":
                    Description.AssertLabelEquals(customLabel);
                    break;
                case "Created":
                    Created.AssertLabelEquals(customLabel);
                    break;
                case "LastUpdate":
                    LastUpdated.AssertLabelEquals(customLabel);
                    break;
                default:
                    Assert.Fail();
                    break;
            }
        }
    }
}
