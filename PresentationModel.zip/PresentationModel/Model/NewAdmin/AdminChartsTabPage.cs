﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminChartsTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _chartColours;
        public WebDriverLinkControl ChartColours
        {
            get
            {
                return _chartColours ?? (_chartColours = new WebDriverLinkControl(Driver, Waiter, "Chart Colours"));
            }
        }

        private WebDriverLinkControl _waterfall;
        public WebDriverLinkControl Waterfall
        {
            get
            {
                return _waterfall ?? (_waterfall = new WebDriverLinkControl(Driver, Waiter, "Waterfall"));
            }
        }

        private WebDriverLinkControl _quadSheetChart;
        public WebDriverLinkControl QuadSheetChart
        {
            get
            {
                return _quadSheetChart ?? (_quadSheetChart = new WebDriverLinkControl(Driver, Waiter, "Quad Sheet Chart"));
            }
        }

        private WebDriverLinkControl _pid;
        public WebDriverLinkControl Pid
        {
            get
            {
                return _pid ?? (_pid = new WebDriverLinkControl(Driver, Waiter, "PID"));
            }
        }

        // Second Section
        private WebDriverLinkControl _riskConnectivitySettings;
        public WebDriverLinkControl RiskConnectivitySettings
        {
            get
            {
                return _riskConnectivitySettings ?? (_riskConnectivitySettings = new WebDriverLinkControl(Driver, Waiter, "Risk Connectivity Settings"));
            }
        }

        private WebDriverLinkControl _enterpriseConnectivityModel;
        public WebDriverLinkControl EnterpriseConnectivityModel
        {
            get
            {
                return _enterpriseConnectivityModel ?? (_enterpriseConnectivityModel = new WebDriverLinkControl(Driver, Waiter, "Enterprise Connectivity Model"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true));
            }
        }

        public AdminChartsTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Charts")
        {
            // Wait until URL contains "Charts"
            waiter.Until(u => u.Url.Contains("Charts"));
        }
    }
}
