﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using TechTalk.SpecFlow;

namespace PresentationModel.Model.NewAdmin.FieldsAndWorkflow
{
    public class LabelSetConfiguration : WebDriverArmPage
    {
        private IWebElement _field;

        private IWebElement _areaDropDownList;

        private WebDriverButton _newLabelSetButton;
        public WebDriverButton NewLabelSetButton
        {
            get { return _newLabelSetButton ?? (_newLabelSetButton = new WebDriverButton(Driver, Waiter, "RootView_New_btn")); }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn")); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn")); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn")); }
        }

        public LabelSetConfiguration(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "LabelSetConfiguration.aspx")
        {

        }

        public void SetLabelSetName(string name)
        {
            Waiter.Until(d => Driver.FindElement(By.Id("RootView_LabelSet_tb")).Displayed);
            WaitUntilUiSpinnerIsNotDisplayed();
            IWebElement nameField = Driver.FindElement(By.Id("RootView_LabelSet_tb"));
            if (nameField != null)
            {
                nameField.SendKeys(name);
            }

        }

        public void SelectLabelSetValue(string name)
        {
            IWebElement dropDownList = Driver.FindElement(By.Id("RootView_LabelSet_cb"));
            if (dropDownList != null)
            {
                SelectElement dropdown = new SelectElement(dropDownList);
                dropdown.SelectByText(name);
            }
            WaitUntilPageIsReady();
        }

        public void SelectAreaValue(string value)
        {
            Waiter.Until(d => Driver.FindElement(By.Id("RootView_LabelSet_tb")).Displayed || Driver.FindElement(By.Id("RootView_LabelSet_cb")).Displayed);
            WaitUntilUiSpinnerIsNotDisplayed();
            _areaDropDownList = null;

            WaitUntilPageIsReady();

            _areaDropDownList = GetSelectField("Area");

            if (_areaDropDownList != null)
            {
                SelectElement dropdown = new SelectElement(_areaDropDownList);
                dropdown.SelectByText(value);
            }

            WaitUntilPageIsReady();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public void SelectLanguageValue(string value)
        {
            IWebElement dropDownList = GetSelectField("Language");
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", dropDownList);
            if (dropDownList != null)
            {
                SelectElement dropdown = new SelectElement(dropDownList);
                dropdown.SelectByText(value);
            }
            WaitUntilPageIsReady();
        }

        public void SetTranslationValue(string trans, string field, Table contentTable)
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            List<IWebElement> tables = Driver.FindElements(By.CssSelector(".tablecontrol .grid-table.tablePage")).Where(x => x.Displayed).ToList();

            foreach (var table in tables)
            {
                    List<IWebElement> tableRows = table.FindElements(By.CssSelector(".grid-row")).ToList();
                    int i = 0;
                    foreach (var content in contentTable.Rows)
                    {
                        var keys = content.Keys.ToList();
                        var values = content.Values.ToList();
                        var value = values[keys.IndexOf(trans)];
                        var column = values[keys.IndexOf(field)];

                        var row = tableRows[i];
                        System.Diagnostics.Debug.WriteLine(i + " - " + row.Text);
                        row.FindElement(By.Id(i + "_DefaultLabel")).FindElement(By.TagName("span")).Click();
                        var english = row.FindElement(By.Id(i + "_English")).FindElement(By.TagName("input"));
                        var translation = row.FindElement(By.Id(i + "_Translation")).FindElement(By.TagName("input"));
                        if (trans == "Custom Labels")
                        {
                            if (english == null)
                            {
                                Assert.Fail("default value for '" + column + "' does not exist");
                            }
                            english.Clear();
                            english.SendKeys(value);
                        }
                        else
                        {
                            if (translation == null)
                            {
                                Assert.Fail("default value for '" + column + "' does not exist");
                            }
                            translation.Clear();
                            translation.SendKeys(value);
                        }
                        i++;
                    }      
            }

            FocusWindow();
        }

        public void CheckTranslationValue(int index, string column, string value, bool customLabel)
        {
            List<IWebElement> tables = Driver.FindElements(By.CssSelector(".tablecontrol .grid-table.tablePage")).ToList();
            foreach (var table in tables)
            {
                if (table.Displayed)
                {
                    List<IWebElement> tableRows = table.FindElements(By.CssSelector(".grid-row")).ToList();
                    var row = tableRows[index];
                    System.Diagnostics.Debug.WriteLine(index + " - " + row.Text);
                    if (customLabel)
                    {
                        var english = row.FindElement(By.Id(index + "_English")).FindElement(By.TagName("span"));
                        if (english == null)
                        {
                            Assert.Fail("default value for '" + column + "' does not exist");                 
                        }
                        Assert.AreEqual(value, english.Text);
                    }
                    else
                    {
                        var translation = row.FindElement(By.Id(index + "_Translation")).FindElement(By.TagName("span"));
                        if (translation == null)
                        {
                            Assert.Fail("default value for '" + column + "' does not exist");
                        }
                        Assert.AreEqual(value, translation.Text);
                    }
                }
            }
        }

        public void NavigateToPage(int page)
        {
            var pager = Driver.FindElement(By.CssSelector(".grid-footer")).FindElement(By.TagName("input"));
            if (pager != null)
            {
                pager.Clear();
                pager.SendKeys(page.ToString());
            }
            WaitUntilPageIsReady();
        }

        public void NextPage()
        {
            Driver.FindElement(By.CssSelector(".grid-footer [alt='Next Page']")).Click();
            WaitUntilPageIsReady();
        }

        private IWebElement GetSelectField(string fieldName)
        {
            _field = null;

            _field = Driver.FindElements(By.CssSelector(".select-cont [title='"+ fieldName + "']")).First();
            if (_field == null)
            {
                Assert.Fail(" " + fieldName + " is not available in the layout section");
            }
            return _field;
        }
    }
}
