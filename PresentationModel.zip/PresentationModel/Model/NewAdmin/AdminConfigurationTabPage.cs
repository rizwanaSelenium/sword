﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.NewAdmin.Configuration;

namespace PresentationModel.Controls.NewAdmin
{
   public class AdminConfigurationTabPage : WebDriverArmPage
   {
        // First Section
        private WebDriverLinkControl _pid;
        public WebDriverLinkControl Pid
        {
            get
            {
                return _pid ?? (_pid = new WebDriverLinkControl(Driver, Waiter, "PID"));
            }
        }

        private WebDriverLinkControl _scoringCategories;
        public WebDriverLinkControl ScoringCategories
        {
            get
            {
                return _scoringCategories ?? (_scoringCategories = new WebDriverLinkControl(Driver, Waiter, "Scoring Categories"));
            }
        }

       private WebDriverLinkControl _scoringScheme;
       public WebDriverLinkControl ScoringScheme
       {
           get
           {
               return _scoringScheme ?? (_scoringScheme = new WebDriverLinkControl(Driver, Waiter, "Scoring Scheme"));
           }
       }

       private WebDriverLinkControl _scoringSchemeGroups;
       public WebDriverLinkControl ScoringSchemeGroups
       {
           get
           {
               return _scoringSchemeGroups ?? (_scoringSchemeGroups = new WebDriverLinkControl(Driver, Waiter, "Scoring Scheme Groups"));
           }
       }

       private WebDriverLinkControl _weightedScoring;
       public WebDriverLinkControl WeightedScoring
       {
           get
           {
               return _weightedScoring ?? (_weightedScoring = new WebDriverLinkControl(Driver, Waiter, "Weighted Scoring"));
           }
       }

        // Second Section
        private WebDriverLinkControl _provision;
       public WebDriverLinkControl Provision
       {
           get
           {
               return _provision ?? (_provision = new WebDriverLinkControl(Driver, Waiter, "Provision"));
           }
       }

        // Third Section
       private WebDriverLinkControl _columns;

       public WebDriverLinkControl Columns
       {
           get
           {
               return _columns ?? (_columns = new WebDriverLinkControl(Driver, Waiter, "Columns"));
           }
       }

       private WebDriverLinkControl _bowTie;
       public WebDriverLinkControl BowTie
       {
           get { return _bowTie ?? (_bowTie = new WebDriverLinkControl(Driver, Waiter, "BowTie")); }
       }

       private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn",true)); }
        } 
        public AdminConfigurationTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter,"Configuration")
        {
            // Wait until URL contains "Configuration"
            waiter.Until(d => d.Url.Contains("Configuration"));
            waiter.Until(d => !d.IsAjaxRequestInProgress());
            waiter.Until(d => d.FindElement(By.CssSelector("div.row")).Displayed);
        }
       

        public void GetHyperLinkText(string text)
        {
          
            WeightedScoring.AssertTextContains(text);
        }

        public void AssertFieldNotVisible(string text)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            try
            {
                var isPresent = Driver.FindElement(By.LinkText(text)).Displayed;
                Assert.IsFalse(isPresent, "Expected field to be not present but it was");
            }
            catch (NoSuchElementException)
            {
                // If we don't find the field, do nothing as we are not expecting it to be present
            }
        }

        public WebDriverWeightedScoringConfigurationPage OpenWeightedScoringConfigPage()
        {
            WeightedScoring.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new WebDriverWeightedScoringConfigurationPage(Driver, Waiter);
        }

        public void CloseConfigurationPage()
        {
            WaitUntilPageIsReady();
            CloseButton.IsEnabled();
            CloseButton.Click();
        }   
    }
}
