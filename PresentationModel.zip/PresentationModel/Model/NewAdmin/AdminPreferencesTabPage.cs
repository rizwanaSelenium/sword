﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminPreferencesTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _systemSettings;
        public WebDriverLinkControl SystemSettings
        {
            get
            {
                return _systemSettings ?? (_systemSettings = new WebDriverLinkControl(Driver, Waiter, "System Settings"));
            }
        }

        private WebDriverLinkControl _businessAreaSettings;
        public WebDriverLinkControl BusinessAreaSettings
        {
            get
            {
                return _businessAreaSettings ?? (_businessAreaSettings = new WebDriverLinkControl(Driver, Waiter, "Business Area Settings"));
            }
        }

        private WebDriverLinkControl _scheduledTasks;
        public WebDriverLinkControl ScheduledTasks
        {
            get
            {
                return _scheduledTasks ?? (_scheduledTasks = new WebDriverLinkControl(Driver, Waiter, "Scheduled Tasks"));
            }
        }

        // Third Section
        private WebDriverLinkControl _tutorial;
        public WebDriverLinkControl Tutorial
        {
            get
            {
                return _tutorial ?? (_tutorial = new WebDriverLinkControl(Driver, Waiter, "Tutorial"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true));
            }
        }

        public AdminPreferencesTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Preferences")
        {
            // Wait for URL to contain "Preferences"
            Waiter.Until(d => d.Url.Contains("Preferences"));
        }
    }
}
