﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.NewAdmin.International
{
    public class ListTranslationPage : WebDriverArmPage
    {

        public ListTranslationPage(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ListTranslation.aspx")
        {

        }
    }
}
