﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminMaintenanceTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _license;
        public WebDriverLinkControl License
        {
            get
            {
                return _license ?? (_license = new WebDriverLinkControl(Driver, Waiter, "License"));
            }
        }

        private WebDriverLinkControl _userSessions;
        public WebDriverLinkControl UserSessions
        {
            get
            {
                return _userSessions ?? (_userSessions = new WebDriverLinkControl(Driver, Waiter, "User Sessions"));
            }
        }

        private WebDriverLinkControl _sessionHistory;
        public WebDriverLinkControl SessionHistory
        {
            get
            {
                return _sessionHistory ?? (_sessionHistory = new WebDriverLinkControl(Driver, Waiter, "Session History"));
            }
        }

        // Second Section
        private WebDriverLinkControl _alertQueue;
        public WebDriverLinkControl AlertQueue
        {
            get
            {
                return _alertQueue ?? (_alertQueue = new WebDriverLinkControl(Driver, Waiter, "Alert Queue"));
            }
        }

        private WebDriverLinkControl _alertHistory;
        public WebDriverLinkControl AlertHistory
        {
            get
            {
                return _alertHistory ?? (_alertHistory = new WebDriverLinkControl(Driver, Waiter, "Alert History"));
            }
        }

        // Third Section
        private WebDriverLinkControl _applicationLog;
        public WebDriverLinkControl ApplicationLog
        {
            get
            {
                return _applicationLog ?? (_applicationLog = new WebDriverLinkControl(Driver, Waiter, "Application Log"));
            }
        }

        private WebDriverLinkControl _purgeLogs;
        public WebDriverLinkControl PurgeLogs
        {
            get
            {
                return _purgeLogs ?? (_purgeLogs = new WebDriverLinkControl(Driver, Waiter, "Purge Logs"));
            }
        }

        // Fourth Section
        private WebDriverLinkControl _purgeHistory;
        public WebDriverLinkControl PurgeHistory
        {
            get
            {
                return _purgeHistory ?? (_purgeHistory = new WebDriverLinkControl(Driver, Waiter, "Purge History"));
            }
        }

        private WebDriverLinkControl _migrateFilters;
        public WebDriverLinkControl MigrateFilters
        {
            get
            {
                return _migrateFilters ?? (_migrateFilters = new WebDriverLinkControl(Driver, Waiter, "Migrate Filters"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CLoseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true));
            }
        }

        public AdminMaintenanceTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Maintenance")
        {
            // Wait until URL contains "Maintenance"
            waiter.Until(u => u.Url.Contains("Maintenance"));
        }
    }
}
