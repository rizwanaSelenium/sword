﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.NewAdmin.FieldsAndWorkflow;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminFieldsAndWorkflowTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _labelSet;
        public WebDriverLinkControl LabelSet
        {
            get { return _labelSet ?? (_labelSet = new WebDriverLinkControl(Driver, Waiter, "Label Set")); }
        }
        private WebDriverLinkControl _dropDownLists;
        public WebDriverLinkControl DropDownLists
        {
            get
            {
                return _dropDownLists ?? (_dropDownLists = new WebDriverLinkControl(Driver, Waiter, "Drop Down Lists"));
            }
        }

        private WebDriverLinkControl _configurationDataSets;
        public WebDriverLinkControl ConfigurationDataSets
        {
            get
            {
                return _configurationDataSets ?? (_configurationDataSets = new WebDriverLinkControl(Driver, Waiter, "Configuration Data Sets"));
            }
        }

        // Second Section
        private WebDriverLinkControl _riskFields;
        public WebDriverLinkControl RiskFields
        {
            get
            {
                return _riskFields ?? (_riskFields = new WebDriverLinkControl(Driver, Waiter, "Risk Fields"));
                                                                                                            
            }
        }

        private WebDriverLinkControl _riskFieldsAndLayout;
        public WebDriverLinkControl RiskFieldsAndLayout
        {
            get
            {
                return _riskFieldsAndLayout ?? (_riskFieldsAndLayout = new WebDriverLinkControl(Driver, Waiter, "Risk Screen Layout"));
            }
        }

        private WebDriverLinkControl _scoringScreenLayout;
        public WebDriverLinkControl ScoringScreenLayout
        {
            get
            {
                return _scoringScreenLayout ?? (_scoringScreenLayout = new WebDriverLinkControl(Driver, Waiter, "Scoring Screen Layout"));
            }
        }

        private WebDriverLinkControl _responseFields;
        public WebDriverLinkControl ResponseFields
        {
            get
            {
                return _responseFields ?? (_responseFields = new WebDriverLinkControl(Driver, Waiter, "Response Fields"));
            }
        }

        private WebDriverLinkControl _responseScreenLayout;
        public WebDriverLinkControl ResponseScreenLayout
        {
            get
            {
                return _responseScreenLayout ?? (_responseScreenLayout = new WebDriverLinkControl(Driver, Waiter, "Response Screen Layout"));
            }
        }

        private WebDriverLinkControl _requirementFields;
        public WebDriverLinkControl RequirementFields
        {
            get
            {
                return _requirementFields ?? (_requirementFields = new WebDriverLinkControl(Driver, Waiter, "Requirement Fields"));
            }
        }

        private WebDriverLinkControl _incidentFieldsAndWorkflow;
        public WebDriverLinkControl IncidentFieldsAndWorkflow
        {
            get
            {
                return _incidentFieldsAndWorkflow ?? (_incidentFieldsAndWorkflow = new WebDriverLinkControl(Driver, Waiter, "Incident Fields and Workflow"));
            }
        }

        private WebDriverLinkControl _auditFieldsAndWorkflow;
        public WebDriverLinkControl AuditFieldsAndWorkflow
        {
            get
            {
                return _auditFieldsAndWorkflow ?? (_auditFieldsAndWorkflow = new WebDriverLinkControl(Driver, Waiter, "Audit Fields and Workflow"));
            }
        }

        // Third section
        private WebDriverLinkControl _screenFieldLayout;
        public WebDriverLinkControl ScreenFieldLayout
        {
            get
            {
                return _screenFieldLayout ?? (_screenFieldLayout = new WebDriverLinkControl(Driver, Waiter, "Screen Field Layout"));
            }
        }

        private WebDriverLinkControl _armRiskExpressColumns;
        public WebDriverLinkControl ArmRiskExpressColumns
        {
            get
            {
                return _armRiskExpressColumns ?? (_armRiskExpressColumns = new WebDriverLinkControl(Driver, Waiter, "ARM Risk Express Columns"));
            }
        }

        private WebDriverLinkControl _desktopColumnSearch;
        public WebDriverLinkControl DesktopColumnSearch
        {
            get
            {
                return _desktopColumnSearch ?? (_desktopColumnSearch = new WebDriverLinkControl(Driver, Waiter, "Desktop Column Search"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true)); }
        }

        public AdminFieldsAndWorkflowTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "FieldsAndWorkflow")
                                                                                                                   
        {
            // Wait until URL contains "Workflow"
            FocusNewWindow();
            waiter.Until(d => d.Url.Contains("FieldsAndWorkflow"));
        }

        public FieldsAndLayout OpenRiskFieldsAndLayoutPage()
        {
            RiskFieldsAndLayout.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new FieldsAndLayout(Driver, Waiter);
        }

        public LabelSetConfiguration OpenLabelSetDialog()
        {
            LabelSet.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new LabelSetConfiguration(Driver, Waiter);
        }

        public FieldsAndLayout OpenScoringScreenLayoutPage()
        {
            ScoringScreenLayout.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new FieldsAndLayout(Driver, Waiter);
        }
    }
}
