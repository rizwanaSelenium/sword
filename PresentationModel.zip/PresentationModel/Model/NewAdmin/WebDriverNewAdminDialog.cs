﻿using System;
using PresentationModel.Controls;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using PresentationModel.Controls.NewAdmin;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Admin.Configuration;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.Admin.Security;
using PresentationModel.Model.Admin.SystemParameters;

namespace PresentationModel.Model.NewAdmin
{
    public class WebDriverNewAdminDialog : WebDriverArmPage
    {
        private WebDriverLinkControl _preferencesTab;
        public WebDriverLinkControl PreferencesTab
        {
            get
            {
                return _preferencesTab ?? (_preferencesTab = new WebDriverLinkControl(Driver, Waiter, "Preferences"));
            }
        }

        private WebDriverLinkControl _configurationTab;
        public WebDriverLinkControl ConfigurationTab
        {
            get
            {
                return _configurationTab ?? (_configurationTab = new WebDriverLinkControl(Driver, Waiter, "Configuration"));
            }
        }

        private WebDriverLinkControl _fieldsAndWorkFlowTab;
        public WebDriverLinkControl FieldsAndWorkFlowTab
        {
            get
            {
                return _fieldsAndWorkFlowTab ?? (_fieldsAndWorkFlowTab = new WebDriverLinkControl(Driver, Waiter, "Fields and Workflow"));
            }
        }

        private WebDriverLinkControl _internationalTab;
        public WebDriverLinkControl InternationalTab
        {
            get
            {
                return _internationalTab ?? (_internationalTab = new WebDriverLinkControl(Driver, Waiter, "International"));
            }
        }

        private WebDriverLinkControl _chartsTab;
        public WebDriverLinkControl ChartsTab
        {
            get
            {
                return _chartsTab ?? (_chartsTab = new WebDriverLinkControl(Driver, Waiter, "Charts"));
            }
        }

        private WebDriverLinkControl _securityTab;
        public WebDriverLinkControl SecurityTab
        {
            get
            {
                return _securityTab ?? (_securityTab = new WebDriverLinkControl(Driver, Waiter, "Security"));
            }
        }

        private WebDriverLinkControl _integrationTab;
        public WebDriverLinkControl IntegrationTab
        {
            get
            {
                return _integrationTab ?? (_integrationTab = new WebDriverLinkControl(Driver, Waiter, "Integration"));
            }
        }

        private WebDriverLinkControl _maintenanceTab;
        public WebDriverLinkControl MaintenanceTab
        {
            get
            {
                return _maintenanceTab ?? (_maintenanceTab = new WebDriverLinkControl(Driver, Waiter, "Maintenance"));
            }
        }

        private WebDriverLinkControl _mobileTab;
        public WebDriverLinkControl MobileTab
        {
            get
            {
                return _mobileTab ?? (_mobileTab = new WebDriverLinkControl(Driver, Waiter, "Mobile"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "Close"));
            }
        }

        public WebDriverNewAdminDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "admin")
        {
            // Wait for URL Direct
            Waiter.Until(d => d.Url.Contains("admin" + "/" + "menu"));
            Waiter.Until(d => d.Url.Contains("Preferences"));
            WaitUntilUiSpinnerIsNotDisplayed();
            // Wait Until The Admin Loading... Element is not displayed
            WaitUntilAdminLoadingNotDisplayed();

        }

        private AdminPreferencesTabPage _preferencesTabPage;
        public AdminPreferencesTabPage PreferencesTabPage
        {
            get
            {
                FocusWindow();
                PreferencesTab.Click();
   
                WaitUntilPageIsReady();

                _preferencesTabPage = new AdminPreferencesTabPage(Driver, Waiter);
                return _preferencesTabPage;
            }
        }

        private AdminConfigurationTabPage _configurationTabPage;
        public AdminConfigurationTabPage ConfigurationTabPage
        {
            get
            {
                FocusWindow();
                _configurationTab.Click();
                WaitUntilPageIsReady();

                _configurationTabPage = new AdminConfigurationTabPage(Driver, Waiter);
                return _configurationTabPage;
            }
        }
       
        private AdminFieldsAndWorkflowTabPage _fieldsAndWorkflowTabPage;
        public AdminFieldsAndWorkflowTabPage FieldsAndWorkflowTabPage
        {
            get
            {
                FocusWindow();
                FieldsAndWorkFlowTab.Click();
                WaitUntilPageIsReady();
                
                _fieldsAndWorkflowTabPage = new AdminFieldsAndWorkflowTabPage(Driver, Waiter);
                return _fieldsAndWorkflowTabPage;
            }
        }

        private AdminInternationalTabPage _internationalTabPage;
        public AdminInternationalTabPage InternationalTabPage
        {
            get
            {
                FocusWindow();
                InternationalTab.Click();
                WaitUntilPageIsReady();

                _internationalTabPage = new AdminInternationalTabPage(Driver, Waiter);
                return _internationalTabPage;
            }
        }

        private AdminChartsTabPage _chartsTabPage;
        public AdminChartsTabPage ChartsTabPage
        {
            get
            {
                FocusWindow();
                ChartsTab.Click();
                WaitUntilPageIsReady();

                _chartsTabPage = new AdminChartsTabPage(Driver, Waiter);
                return _chartsTabPage;

            }
        }

        private AdminSecurityTabPage _securityTabPage;
        public AdminSecurityTabPage SecurityTabPage
        {
            get
            {
                FocusWindow();
                SecurityTab.Click();
                WaitUntilPageIsReady();

                _securityTabPage = new AdminSecurityTabPage(Driver, Waiter);
                return _securityTabPage;
            }
        }

        private AdminIntegrationTabPage _integrationTabPage;
        public AdminIntegrationTabPage IntegrationTabPage
        {
            get
            {
                FocusWindow();
                IntegrationTab.Click();
                WaitUntilPageIsReady();

                _integrationTabPage = new AdminIntegrationTabPage(Driver, Waiter);
                return _integrationTabPage;
            }
        }

        private AdminMaintenanceTabPage _maintenanceTabPage;
        public AdminMaintenanceTabPage MaintenanceTabPage
        {
            get
            {
                FocusWindow();
                _maintenanceTab.Click();
                WaitUntilPageIsReady();

                _maintenanceTabPage = new AdminMaintenanceTabPage(Driver, Waiter);
                return _maintenanceTabPage;
            }
        }

        private AdminMobileTabPage _mobileTabPage;
        public AdminMobileTabPage MobileTabPage
        {
            get
            {
                FocusWindow();
                _mobileTab.Click();
                WaitUntilPageIsReady();

                _mobileTabPage = new AdminMobileTabPage(Driver, Waiter);
                return _mobileTabPage;
            }
        }

        public WebDriverSystemSettingsDialog SystemSettings()
        {
            FocusWindow();
            PreferencesTabPage.SystemSettings.Click();

            return OpenChildDialog<WebDriverSystemSettingsDialog>();
        }

        public WebdriverBusinessAreaSettingsDialog BusinessAreaSettings()
        {
            FocusWindow();
            PreferencesTabPage.BusinessAreaSettings.Click();

            return OpenChildDialog<WebdriverBusinessAreaSettingsDialog>();
        }

        public WebDriverImpactCategoriesListConfig ScoringCategories()
        {
            FocusWindow();
            ConfigurationTabPage.ScoringCategories.Click();

            return OpenChildDialog<WebDriverImpactCategoriesListConfig>();
        }

        public WebDriverScoringSchemeConfigDialog ScoringScheme()
        {
            FocusWindow();
            ConfigurationTabPage.ScoringScheme.Click();

            return OpenChildDialog<WebDriverScoringSchemeConfigDialog>();
        }

        public WebDriverScoringGroupsConfigDialog ScoringSchemeGroups()
        {
            FocusWindow();
            ConfigurationTabPage.ScoringSchemeGroups.Click();

            return OpenChildDialog<WebDriverScoringGroupsConfigDialog>();
        }

        public WebDriverGridColumnConfigDialogue Columns()
        {
            FocusWindow();
            ConfigurationTabPage.Columns.Click();

            return OpenChildDialog<WebDriverGridColumnConfigDialogue>();
        }

        public AdminConfigurationTabPage OpenConfigurationpage()
        {
            ConfigurationTab.Click();
            return new AdminConfigurationTabPage(Driver, Waiter);
        }

        public WebdriverDropDownListsDialog DropDownLists()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.DropDownLists.Click();

            return OpenChildDialog<WebdriverDropDownListsDialog>();
        }

        public WebdriverConfigurationDataSetsDialog ConfigurationDataSets()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.ConfigurationDataSets.Click();

            return OpenChildDialog<WebdriverConfigurationDataSetsDialog>();
        }

        public ResponseScreenLayout ResponseScreenLayout()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.ResponseScreenLayout.Click();

            return OpenChildDialog<ResponseScreenLayout>();
        }

        public WebDriverRequirementFieldConfig RequirementFields()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.RequirementFields.Click();

            return OpenChildDialog<WebDriverRequirementFieldConfig>();
        }

        public WebDriverAuditConfig AuditFieldsAndWorkflow()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.AuditFieldsAndWorkflow.Click();

            return OpenChildDialog<WebDriverAuditConfig>();
        }

        public WebDriverRiskExpressGridColumnConfigDialogue ArmRiskExpressColumns()
        {
            FocusWindow();
            FieldsAndWorkflowTabPage.ArmRiskExpressColumns.Click();

            return OpenChildDialog<WebDriverRiskExpressGridColumnConfigDialogue>();
        }

        public WebDriverCurrencySystemSettingsDialog ConfigureMulticurrency()
        {
            FocusWindow();
            InternationalTabPage.ConfigureMulticurrency.Click();

            return OpenChildDialog<WebDriverCurrencySystemSettingsDialog>();
        }

        public WebdriverWaterfallDefaultsConfigurationDialog Waterfall()
        {
            FocusWindow();
            ChartsTabPage.Waterfall.Click();

            return OpenChildDialog<WebdriverWaterfallDefaultsConfigurationDialog>();
        }

        public WebDriverChartsQuadSheetConfigurationDialog ChartsQuadSheetChart()
        {
            FocusWindow();
            ChartsTabPage.QuadSheetChart.Click();

            return OpenChildDialog<WebDriverChartsQuadSheetConfigurationDialog>();
        }

        public WebDriverChartsPidConfigurationDialog ChartsPid()
        {
            FocusWindow();
            ChartsTabPage.Pid.Click();

            return OpenChildDialog<WebDriverChartsPidConfigurationDialog>();
        }

        public WebDriverResourceListDialog UsersAndResources()
        {
            FocusWindow();
            SecurityTabPage.UsersAndResources.Click();

            return OpenChildDialog<WebDriverResourceListDialog>();
        }

        public WebDriverResourceEditDialog OpenedResource()
        {
            FocusWindow();
            return OpenChildDialog<WebDriverResourceEditDialog>();
        }

        public WebdriverUsersGroupsDefaultsDialog ResourceAndUserGroupsDefault()
        {
            FocusWindow();
            SecurityTabPage.ResourceAndUserGroups.Click();

            return OpenChildDialog<WebdriverUsersGroupsDefaultsDialog>();
        }

        public WebDriverAssignRolesToUsersDialogue AssignRolesToUsers()
        {
            FocusWindow();
            SecurityTabPage.AssignRolesToUsers.Click();

            return OpenChildDialog<WebDriverAssignRolesToUsersDialogue>();
        }

        public WebDriverAssignRolesToUsersDialogue SavedAssignRolesToUsersDialogue()
        {
            return OpenChildDialog<WebDriverAssignRolesToUsersDialogue>();
        }

        public WebDriverRolesConfigDialog RoleConfiguration()
        {
            FocusWindow();
            SecurityTabPage.RoleConfiguration.Click();

            return OpenChildDialog<WebDriverRolesConfigDialog>();
        }

        public WebDriverBusinessAreaAccess BusinessAreaAccess()
        {
            FocusWindow();
            SecurityTabPage.BusinessAreaAccess.Click();

            return OpenChildDialog<WebDriverBusinessAreaAccess>();
        }

        public WebdriverDropdownListsConfigDialog SecurityAttributes()
        {
            FocusWindow();
            SecurityTabPage.SecurityAttributes.Click();

            return OpenChildDialog<WebdriverDropdownListsConfigDialog>();
        }

        public WebdriverRiskSecurityGroupDialog RiskAccess()
        {
            FocusWindow();
            SecurityTabPage.RiskAccess.Click();

            return OpenChildDialog<WebdriverRiskSecurityGroupDialog>();
        }


        public WebDriverInterfaceAccessDialog InterfaceAccess()
        {
            FocusWindow();
            SecurityTabPage.InterfaceAccess.Click();

            return OpenChildDialog<WebDriverInterfaceAccessDialog>();
        }

        public WebDriverInterfaceAccessDialog SavedInterfaceAccessDialogue()
        {
            return OpenChildDialog<WebDriverInterfaceAccessDialog>();
        }

        public WebDriverDataSourcesDialog ConfigureServerDataSources()
        {
            FocusWindow();
            IntegrationTabPage.ConfigureServerDataSources.Click();

            return OpenChildDialog<WebDriverDataSourcesDialog>();
        }

        public WebDriverIntegrationSecurityDialog IntegrationSecurity()
        {
            FocusWindow();
            IntegrationTabPage.IntegrationSecurity.Click();

            return OpenChildDialog<WebDriverIntegrationSecurityDialog>();
        }

        public WebDriverLicenceDialog License()
        {
            FocusWindow();
            MaintenanceTabPage.License.Click();

            return OpenChildDialog<WebDriverLicenceDialog>();
        }

        public WebdriverViewAlertQueueDialog AlertQueue()
        {
            FocusWindow();
            MaintenanceTabPage.AlertQueue.Click();

            return OpenChildDialog<WebdriverViewAlertQueueDialog>();
        }

        public override void Close()
        {
            FocusNewWindow();
            Waiter.Until(d => CloseButton.IsDisplayed());
            CloseButton.Click();
            WaitUntilUiSpinnerIsNotDisplayed();

            bool adminDialogueDisplayed = true;

            // Wait for the URL redirect to no longer contain "admin"
            for (var i = 0; i < 60; i++)
            {
                Thread.Sleep(1000);
                var currentUrl = Driver.Url;
                if (currentUrl.Contains("admin") || currentUrl.Contains("menu"))
                {
                    if (i == 30)
                    {
                        CloseButton.Click(); 
                        WaitUntilUiSpinnerIsNotDisplayed();
                    } //try clicking again if we get to 30 seconds to ensure the button recived the click
                }
                else
                {
                    adminDialogueDisplayed = false;
                    break;
                }
            }

            if (adminDialogueDisplayed)
            {
                Console.WriteLine("* ** *** ** * ** *** ** * ** *** ** * ** *** ** * ** *** ** * **");
                Console.WriteLine("* Was waiting for Admin Dialogue to CLOSE but it remained OPEN *");
                Console.WriteLine("* ** *** ** * ** *** ** * ** *** ** * ** *** ** * ** *** ** * **");
            }

        }

        private void WaitUntilAdminLoadingNotDisplayed()
        {
            bool adminLoadingElementDisplayed = true;

            for (var i = 0; i < 5; i++)
            {
                Thread.Sleep(1000);
                var adminLoadingElements = Driver.FindElements(By.XPath("//div[@class='block-ui-container']")).Any(x => x.Displayed);
                if (!adminLoadingElements)
                {
                    adminLoadingElementDisplayed = false;
                    break;
                }
            }
            if (adminLoadingElementDisplayed)
            {
                Assert.Fail("Was waiting for the Admin Loading... Element to stop being displayed, but it WAS still displayed");
            }
        }
    }
}
