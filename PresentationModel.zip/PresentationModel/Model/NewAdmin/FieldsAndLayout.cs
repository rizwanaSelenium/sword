﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.NewAdmin
{
    public class FieldsAndLayout : WebDriverArmPage
    {
        private WebDriverDropDown _recordType;

        public WebDriverDropDown RecordType
        {
            get { return _recordType ?? (_recordType = new WebDriverDropDown(Driver, Waiter, "selectRecordType")); }
        }

        private WebDriverDropDown _interface;
        public WebDriverDropDown Interface
        {
            get { return _interface ?? (_interface = new WebDriverDropDown(Driver, Waiter, "selectInterface")); }
        }

        private WebDriverButton _addRow;
        public WebDriverButton AddRow
        {
            get { return _addRow ?? (_addRow = new WebDriverButton(Driver, Waiter, "addRowButton")); }
        }

        private WebDriverButton _dividerRow;
        public WebDriverButton DividerRow
        {
            get
            {
                return _dividerRow ??
                       (_dividerRow = new WebDriverButton(Driver, Waiter, "addDividerRowButton"));
            }
        }

        private WebDriverButton _save;

        public WebDriverButton Save
        {
            get { return _save ?? (_save = new WebDriverButton(Driver, Waiter, "Save")); }
        }

        private WebDriverButton _close;

        public new WebDriverButton Close
        {
            get { return _close ?? (_close = new WebDriverButton(Driver, Waiter, "Cancel")); }
        }

        private WebDriverButton _reset;

        public WebDriverButton Reset
        {
            get { return _reset ?? (_reset = new WebDriverButton(Driver, Waiter, "Reset")); }
        }

        private WebDriverButton _clear;

        public WebDriverButton Clear
        {
            get { return _clear ?? (_clear = new WebDriverButton(Driver, Waiter, "Clear")); }
        }

        private WebDriverButton _ok;

        public WebDriverButton OK
        {
            get { return _ok ?? (_ok = new WebDriverButton(Driver, Waiter, "Ok")); }
        }

        private WebDriverButton _help;

        public WebDriverButton Help
        {
            get { return _help ?? (_help = new WebDriverButton(Driver, Waiter, "Help")); }
        }

        private IList<IWebElement> _availableFields;

        public IList<IWebElement> AvailableFields
        {
            get
            {
                return _availableFields ??
                       (_availableFields = Driver.FindElements(By.CssSelector("arm-screen-config div.card")).ToList());
            }
        }

        private IList<IWebElement> _listOfFieldsInARow;

        public IList<IWebElement> ListOfFieldsInARow
        {
            get
            {
                return _listOfFieldsInARow ??
                       (_listOfFieldsInARow = Driver.FindElements(By.CssSelector("arm-field-config div.rowField.fieldConfig.dotted-border")).ToList());
            }
        }

        private IList<IWebElement> _removeRows;

        public IList<IWebElement> RemoveRows
        {
            get
            {
                return _removeRows ??
                       (_removeRows = Driver.FindElements(By.ClassName("removeRow")).ToList());
            }
        }
        private IList<IWebElement> _listOfRowsWithDragHandle;

        public IList<IWebElement> ListOfRowsWithDragHandle
        {
            get
            {
                return _listOfRowsWithDragHandle ??
                       (_listOfRowsWithDragHandle = Driver.FindElements(By.CssSelector("i.fa.fa-arrows.dragHandle.drag-handle")).ToList());
            }
        }
        private IList<IWebElement> _listOfDroppableAreasInARow;

        public IList<IWebElement> ListOfDroppableAreasInARow
        {
            get
            {
                return _listOfDroppableAreasInARow ??
                       (_listOfDroppableAreasInARow = Driver.FindElements(By.CssSelector("div.rowdrop")).ToList());
            }
        }

        private IList<IWebElement> _listOfRows;

        public IList<IWebElement> ListOfRows
        {
            get
            {
                return _listOfRows ??
                       (_listOfRows = Driver.FindElements(By.CssSelector("div.row.screenfieldrow")).ToList());
            }
        }
        private IWebElement _layoutScreenTitle;

        public IWebElement LayoutScreenTitle
        {
            get
            {
                return _layoutScreenTitle ?? (_layoutScreenTitle = Driver.FindElement(By.CssSelector("h3.panel-title")));
            }
        }
        public FieldsAndLayout(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "admin")
        {

        }

        public IList<IWebElement> GetAvailableFieldsByType(string type)
        {
            IList<IWebElement> fieldsByType = null;
            foreach (var fields in AvailableFields)
            {
                var labelName = fields.FindElement(By.TagName("label")).Text;
                if (labelName.Contains(type))

                {
                    bool treeExpanded = fields.FindElement(By.TagName("a")).GetAttribute("aria-expanded").Equals("true");
                    if (treeExpanded)
                    {
                        fieldsByType = fields.FindElements(By.CssSelector("div.screenfield-available.drag-handle"));
                    }
                    else
                    {
                        fields.FindElement(By.CssSelector("div.expander-header")).Click();
                        fieldsByType = fields.FindElements(By.CssSelector("div.screenfield-available.drag-handle"));
                    }
                }

            }
            Assert.True(fieldsByType != null, "Field type of " + type + " is not available in the available field section");

            return fieldsByType;
        }

        public void DragAndDropAvailableFieldsToTheLayoutSection(string fieldNameToDrag, string fieldType,
             int rowNumberToDrop)
        {
            IList<IWebElement> availableFields = GetAvailableFieldsByType(fieldType);
            IWebElement field = availableFields.Select(x => x).FirstOrDefault(x => x.Text.Equals(fieldNameToDrag));
            if (field == null)
            {
                Assert.Fail(" " + fieldNameToDrag + "is not available in the available fields section");
            }
            else
            {
                if (IsThereSpaceToDropFieldInTheRow(rowNumberToDrop))
                {
                    IList<IWebElement> fieldRows = GetFieldRows();
                    IWebElement fieldToDrop =
                        fieldRows[rowNumberToDrop].FindElements(By.CssSelector("div.fieldDrop")).First();
                    IWebElement fieldToDrag = field;
                    DragAndDropAction(fieldToDrag, fieldToDrop);
                }
                else
                {
                    Assert.Fail("" + rowNumberToDrop + "row does not have any space. Choose different row to drop");
                }
            }
        }

        private bool IsThereSpaceToDropFieldInTheRow(int rowNumberToDrop)
        {
            IList<IWebElement> fieldRows = GetFieldRows();
            IList<IWebElement> rowFieldsList =
                fieldRows[rowNumberToDrop].FindElements(By.CssSelector("arm-field-config div.rowField.fieldConfig"))
                    .ToArray();
            int totalColsUsed = GetTotalColumnsUsed(rowFieldsList);

            return totalColsUsed < 12;
        }

        private int GetTotalColumnsUsed(IList<IWebElement> rowFieldsList)
        {
            var totalWidthUsed = 0;

            if (rowFieldsList.Count > 0)
            {
                foreach (var fields in rowFieldsList)
                {
                    string existingFieldsWidthInTheRow = fields.GetAttribute("colSpan");
                    int width = Convert.ToInt32(existingFieldsWidthInTheRow);
                    totalWidthUsed = width + totalWidthUsed;
                }
            }
            return totalWidthUsed;
        }

        public void AssertFieldIsDraggedFromAvailableFieldsToTheLayout(string fieldNameToDrag, int rowNumberToDrop)
        {
            IList<IWebElement> fieldRows = GetFieldRows();
            IList<IWebElement> fieldNames = fieldRows[rowNumberToDrop].FindElements(By.TagName("label"));
            var fieldHasBeenDragged = fieldNames.Any(x => x.Text.Equals(fieldNameToDrag));
            if (fieldHasBeenDragged)
            {
                var fieldDraggedClass =
                    fieldRows[rowNumberToDrop].FindElement(By.TagName("arm-field-config")).GetAttribute("class");
                Assert.IsTrue(fieldDraggedClass.Contains("recentlyAdded"),
                    "field " + fieldNameToDrag + " is not highlighted as recently added");
            }
            else
            {
                Assert.Fail("" + fieldNameToDrag + " is not dragged to the row number" + rowNumberToDrop + "");
            }
        }

        public void AssertDraggedFieldIsNotHighlightedAfterClickingSave(string fieldNameToDrag, int rowNumberToDrop)
        {
            IList<IWebElement> fieldRows = GetFieldRows();
            IList<IWebElement> fieldNames = fieldRows[rowNumberToDrop].FindElements(By.TagName("label"));
            var fieldHasBeenDragged = fieldNames.Any(x => x.Text.Equals(fieldNameToDrag));
            if (fieldHasBeenDragged)
            {
                var fieldDraggedClass =
                    fieldRows[rowNumberToDrop].FindElement(By.TagName("arm-field-config")).GetAttribute("class");
                Assert.False(fieldDraggedClass.Contains("recentlyAdded"),
                    "field " + fieldNameToDrag + " is still highlighted as recently added");
            }
            else
            {
                Assert.Fail("" + fieldNameToDrag + " is not dragged to the row number" + rowNumberToDrop + "");
            }
        }


        public void AssertFieldIsDraggedToTheLayout(string fieldNameToDrag, int rowNumberToDrop)
        {
            IList<IWebElement> fieldRows = GetFieldRows();
            IList<IWebElement> fieldNames = fieldRows[rowNumberToDrop].FindElements(By.TagName("label"));
            var fieldHasBeenDragged = fieldNames.Any(x => x.Text.Equals(fieldNameToDrag));
            if (fieldHasBeenDragged)
            {
                Console.WriteLine("field " + fieldNameToDrag + " is dragged successfully to the" + rowNumberToDrop +
                                  " row");
            }

            else
            {
                Assert.Fail("" + fieldNameToDrag + " is not dragged to the row number" + rowNumberToDrop + "");
            }
        }

        public bool ListsAreTheSame(IList<IWebElement> sourceRowElementsBeforeDragAndDrop, IList<IWebElement> sourceRowElementsAfterDragAndDrop)
        {
            List<string> elementsOnlyInList1 =
                sourceRowElementsBeforeDragAndDrop.Select(x => x.Text)
                    .Except(sourceRowElementsAfterDragAndDrop.Select(x => x.Text))
                    .ToList();
            List<string> elementsOnlyInList2 =
                sourceRowElementsAfterDragAndDrop.Select(x => x.Text)
                    .Except(sourceRowElementsBeforeDragAndDrop.Select(x => x.Text))
                    .ToList();
            return (elementsOnlyInList1.Count == 0 && elementsOnlyInList2.Count == 0);
        }

        public IList<IWebElement> GetElementsFromRow(int rowNumber)
        {
            IList<IWebElement> listOfFieldRows = GetFieldRows();
            IList<IWebElement> listOfElementsInTheRow =
                listOfFieldRows[rowNumber].FindElements(By.TagName("arm-field-design"));
            return listOfElementsInTheRow;
        }

        public IList<IWebElement> GetFieldRows()
        {
            IList<IWebElement> listOfFieldRows = Driver.FindElements(By.CssSelector("div.row.screenfieldrow"));
            return listOfFieldRows;
        }

        public void DragAndDropRow(int rowNumber, int rowNumberToDrop)
        {
            DragAndDropAction(ListOfRowsWithDragHandle[rowNumber], ListOfDroppableAreasInARow[rowNumberToDrop]);
        }

        public void RemoveFieldFromLayout(string fieldName)
        {
            foreach (var configField in ListOfFieldsInARow)
            {
                IList<IWebElement> fieldNames = configField.FindElements(By.TagName("arm-field-singlelinetext-design"));
                bool fieldNameMatched = fieldNames.Any(x => x.Text.Equals(fieldName));

                if (fieldNameMatched.Equals(true))
                {
                    configField.FindElement(By.CssSelector("button.removeField")).Click();
                }
            }
        }

        public void RemoveRowFromLayout(int rowNumberToDelete)
        {
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", RemoveRows[rowNumberToDelete - 1]);
            RemoveRows[rowNumberToDelete - 1].Click();
        }

        public void RemoveDividerRowFromLayout(int dividerRowNumberToDelete)
        {
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", RemoveRows[dividerRowNumberToDelete]);
            RemoveRows[dividerRowNumberToDelete].Click();
        }

        public void AssertDividerRowIsAddedToTheLayout(int rowNumber)
        {
            IList<IWebElement> fieldRows = GetFieldRows();
            bool dividedRow = string.IsNullOrEmpty(fieldRows[rowNumber].FindElement(By.TagName("arm-field-config")).Text);
            Assert.IsTrue(dividedRow, "Divided Row is not to the layout screen");
        }

        public void DragAndDropFieldsWithInTheLayout(string fieldNameToDrag, int rowNumberToDrop)
        {
            IWebElement field = GetField(fieldNameToDrag);

            if (field == null)
            {
                Assert.Fail(" " + fieldNameToDrag + "is not available in the layout section");
            }
            else
            {
                if (IsThereSpaceToDropFieldInTheRow(rowNumberToDrop))
                {
                    IList<IWebElement> fieldRows = GetFieldRows();
                    IWebElement fieldToDrop =
                        fieldRows[rowNumberToDrop].FindElements(By.CssSelector("div.fieldDrop")).First();
                    IWebElement fieldToDrag = field.FindElement(By.CssSelector("div.fieldHeader"));
                    
                    DragAndDropAction(fieldToDrag, fieldToDrop);
                }
                else
                {
                    Assert.Fail("" + rowNumberToDrop + "row does not have any space. Choose different row to drop");
                }
            }
        }

        public void SelectMandatoryOrReadOnlyCheckBoxForField(string fieldName, string checkBoxToSelect)
        {
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", GetFieldCheckBox(fieldName, checkBoxToSelect));
            IWebElement checkBox = GetFieldCheckBox(fieldName, checkBoxToSelect);
            Assert.True(checkBox.Enabled, "Field " + fieldName + "   " + checkBoxToSelect + " check box is not enabled");
            if (!checkBox.Selected)
            {
                checkBox.Click();
            }
        }

        public void UnselectMandatoryOrReadOnlyCheckBoxForField(string fieldName, string checkBoxToSelect)
        {
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", GetFieldCheckBox(fieldName, checkBoxToSelect));
            IWebElement checkBox = GetFieldCheckBox(fieldName, checkBoxToSelect);
            Assert.True(checkBox.Enabled, "Field " + fieldName + "   " + checkBoxToSelect + " check box is not enabled");
            if (checkBox.Selected)
            {
                checkBox.Click();
            }
        }

        private IWebElement GetField(string fieldName)
        {
            IWebElement field = ListOfFieldsInARow.Select(x => x).FirstOrDefault(y => y.Text.Contains(fieldName));
            if (field == null)
            {
                Assert.Fail(" " + fieldName + " is not available in the layout section");
            }
            return field;
        }

        public IWebElement GetFieldCheckBox(string fieldName, string checkBoxName)
        {
            IWebElement field = GetField(fieldName);
            IWebElement checkBox = field.FindElements(By.CssSelector("div.fieldHeader div.checkbox"))
                    .First(x => x.Text.Equals(checkBoxName))
                    .FindElement(By.TagName("input"));

            return checkBox;
        }

        public void AssertCheckBoxIsSelected(string fieldName, string checkBoxName)
        {
            bool checkBox = GetFieldCheckBox(fieldName, checkBoxName).Selected;
            Assert.IsTrue(checkBox, "field " + fieldName + " " + checkBoxName + " check box is not selected");
        }

        public void AssertCheckBoxIsNotSelected(string fieldName, string checkBoxName)
        {
            bool checkBox = GetFieldCheckBox(fieldName, checkBoxName).Selected;
            Assert.IsFalse(checkBox, "field " + fieldName + " " + checkBoxName + " check box is not selected");
        }

        private IWebElement GetFieldDefaultValueDropdownList(string fieldName)
        {
            IWebElement field = GetField(fieldName);
            IWebElement dropDownList = field.FindElement(By.TagName("select"));
            return dropDownList;
        }

        public void AssertSelectedDefaultValueIsDisplayedInTheDropdownList(string fieldName, string defaultValue)
        {
            IWebElement dropDownList = GetFieldDefaultValueDropdownList(fieldName);
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", dropDownList);
            SelectElement defaultValueDropdownList = new SelectElement(dropDownList);
            bool selectedDefaultValue = defaultValueDropdownList.SelectedOption.Text.Equals(defaultValue);
            Assert.IsTrue(selectedDefaultValue,
                "field " + fieldName + " does not display selected " + defaultValue + " ");
        }

        private IWebElement GetFieldDefaultValueTextBox(string fieldName)
        {
            IWebElement field = GetField(fieldName);
            IWebElement textBox =
                field.FindElements(By.TagName("arm-field-design"))
                    .First(x => x.Text.Equals(fieldName))
                    .FindElement(By.TagName("input"));

            return textBox;
        }

        public void SelectDefaultValueForField(string fieldName, string defaultValue)
        {
            IWebElement dropdownList = GetFieldDefaultValueDropdownList(fieldName);
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", dropdownList);
            if (dropdownList != null)
            {
                SelectElement dropdown = new SelectElement(dropdownList);
                dropdown.SelectByText(defaultValue);
            }
            else
            {
                IWebElement textBox = GetFieldDefaultValueTextBox(fieldName);
                if (textBox != null)
                {
                    textBox.SendKeys(defaultValue);
                }
                else
                {
                    Assert.Fail("default value for '" + fieldName + "' does not exist");
                }
            }
        }

        public void DragAndDropAction(IWebElement fieldToDrag, IWebElement fieldToDrop)
        {
            Actions builder = new Actions(Driver);
            builder.ClickAndHold(fieldToDrag);
            builder.MoveByOffset(30, 30);
            builder.Build().Perform();
            Js.ExecuteScript("arguments[0].scrollIntoView(true);", fieldToDrop);
            Actions actions1 = new Actions(Driver);
            actions1.Release(fieldToDrop).Perform();
        }

        public void AssertLayoutScreenTitle(string expectedLayoutScreenTitle)
        {
            Assert.AreEqual(expectedLayoutScreenTitle, LayoutScreenTitle.Text);
        }

        public void CloseLayoutScreen()
        {
            Close.Click();
            AcceptAlert();
        }


    }
}
