﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminIntegrationTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _configureServerDataSources;
        public WebDriverLinkControl ConfigureServerDataSources
        {
            get
            {
                return _configureServerDataSources ?? (_configureServerDataSources = new WebDriverLinkControl(Driver, Waiter, "Configure Server Data Sources"));
            }
        }

        private WebDriverLinkControl _integrationSecurity;
        public WebDriverLinkControl IntegrationSecurity
        {
            get
            {
                return _integrationSecurity ?? (_integrationSecurity = new WebDriverLinkControl(Driver, Waiter, "Integration Security"));
            }
        }

        private WebDriverLinkControl _integrationOptions;
        public WebDriverLinkControl IntegrationOptions
        {
            get
            {
                return _integrationOptions ?? (_integrationOptions = new WebDriverLinkControl(Driver, Waiter, "Integration Options"));
            }
        }

        // Second Section
        private WebDriverLinkControl _responseLinkageLinkedProjects;
        public WebDriverLinkControl ResponseLinkageLinkedProjects
        {
            get
            {
                return _responseLinkageLinkedProjects ?? (_responseLinkageLinkedProjects = new WebDriverLinkControl(Driver, Waiter, "Response Linkage Linked "));
            }
        }

        private WebDriverLinkControl _responseLinkageFilterColumns;
        public WebDriverLinkControl ResponseLinkageFilterColumns
        {
            get
            {
                return _responseLinkageFilterColumns ?? (_responseLinkageFilterColumns = new WebDriverLinkControl(Driver, Waiter, "Response Linkage Filter Columns"));
            }
        }

        // Third Section
        private WebDriverLinkControl _armToArmDataMasking;
        public WebDriverLinkControl ArmToArmDataMasking
        {
            get
            {
                return _armToArmDataMasking ?? (_armToArmDataMasking = new WebDriverLinkControl(Driver, Waiter, "ARM to ARM  Data Masking"));
            }
        }

        private WebDriverLinkControl _armToArmPendingJobs;
        public WebDriverLinkControl ArmToArmPendingJobs
        {
            get
            {
                return _armToArmPendingJobs ?? (_armToArmPendingJobs = new WebDriverLinkControl(Driver, Waiter, "ARM to ARM Pending Jobs"));
            }
        }

        private WebDriverLinkControl _armToArmExportStaticData;
        public WebDriverLinkControl ArmToArmExportStaticData
        {
            get
            {
                return _armToArmExportStaticData ?? (_armToArmExportStaticData = new WebDriverLinkControl(Driver, Waiter, "ARM to ARM Export Static Data"));
            }
        }

        private WebDriverLinkControl _armToArmStaticDataMapping;
        public WebDriverLinkControl ArmToArmStaticDataMapping
        {
            get
            {
                return _armToArmStaticDataMapping ?? (_armToArmStaticDataMapping = new WebDriverLinkControl(Driver, Waiter, "ARM to ARM Static Data Mapping"));
            }
        }

        private WebDriverLinkControl _armToArmImportScoringSchemes;
        public WebDriverLinkControl ArmToArmImportScoringSchemes
        {
            get
            {
                return _armToArmImportScoringSchemes ?? (_armToArmImportScoringSchemes = new WebDriverLinkControl(Driver, Waiter , "ARM to ARM Import "));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true)); }
        }

        public AdminIntegrationTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Integration")
        {
            // Wait until URL contains "Integration"
            waiter.Until(u => u.Url.Contains("Integration"));
        }
    }
}
