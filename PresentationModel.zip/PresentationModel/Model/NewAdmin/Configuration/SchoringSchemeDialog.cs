﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using NUnit.Framework;
using PresentationModel.Controls;

namespace PresentationModel.Model.NewAdmin.Configuration
{
    public class SchoringSchemeDialog : WebDriverArmPage
   {
       private readonly IWebElement _scoringSchemeHeader;
       private readonly IWebElement _scoringSchemeGrid;
       private WebDriverButton _oKButton;

       public SchoringSchemeDialog(IWebDriver driver, WebDriverWait waiter)
           : base(driver, waiter,
               "WeightedScoringConfig")
       {
           _scoringSchemeHeader = Driver.FindElement(By.CssSelector("div.panel"));
           _scoringSchemeGrid = Driver.FindElement(By.Id("schemeGrid"));
          
        }

       public void AssertScoringSchemeHeaderText()
       {
        string headerText = Convert.ToString(_scoringSchemeHeader.Text);
        Assert.True(headerText.Contains("Scoring Schemes for"));           
       }


       private IList<IWebElement> ScoringSchemeRows()
       {
           return _scoringSchemeGrid.FindElements(By.CssSelector("div.ui-grid-row"));
       }


       public IWebElement ScoringSchemeRowElement(string schemeName, string option)
       {
           var scoringSchemeGridRows = ScoringSchemeRows();
           IWebElement temp = null;
           string classContains = "";
           if (option == "Check")
               classContains = "ng-not-empty";
           else if ((option == "Uncheck"))
               classContains = "ng-empty";
           foreach (var row in scoringSchemeGridRows)
           {
               if (row.Text == schemeName)
               {
                   var classvalue = row.FindElement(By.CssSelector("input.ng-pristine")).GetAttribute("class");
                   if (classvalue.Contains(classContains))
                   {
                       temp = row;
                   }
               }
           }
           return temp;
       }



       public void CheckScoringScheme(string schemeName)
       {          
           var scoringSchemeRow = ScoringSchemeRowElement(schemeName, "Check");
           if (scoringSchemeRow != null)
               scoringSchemeRow.FindElement(By.CssSelector("div.scheme-check-box")).Click();
           else
               Console.WriteLine("The scoring scheme is already linked to weight type"); 
       }

       
       public void UnCheckScoringScheme(string schemeName)
       {          
          var scoringSchemeRow= ScoringSchemeRowElement(schemeName, "UnCheck");
           if (scoringSchemeRow != null)
           {
               scoringSchemeRow.FindElement(By.CssSelector("div.scheme-check-box")).Click();
           }
           else
           {
               Console.WriteLine("The scoring scheme is not linked to weight type");
           }
       }

       private void AcceptScoringSchemeUpdate()
       {
           _oKButton = new WebDriverButton(Driver, Waiter, "button#OK", true);
           _oKButton.Click();
       }

       public void LinkScoringScheme(string schemeName)
       {
           CheckScoringScheme(schemeName);
           AcceptScoringSchemeUpdate();
       }

       public void UnLinkScoringScheme(string schemeName)
       {
           UnCheckScoringScheme(schemeName);
           AcceptScoringSchemeUpdate();
       }

       public void VerifySchoreingSchemeLinked(string schemeName)
       {           
           try
           {
               var scoringSchemeRow = ScoringSchemeRowElement(schemeName, "Check");

               if (scoringSchemeRow == null)
                   Assert.Fail("The Scoring Scheme" + schemeName + "is not linked");
           }
           finally
           {
               AcceptScoringSchemeUpdate();
           }
       }

       public void VerifySchoreingSchemeUnLinked(string schemeName)
       {       
           try
           {
               var scoringSchemeRow = ScoringSchemeRowElement(schemeName, "UnCheck");

               if (scoringSchemeRow == null)
                   Assert.Fail("The Scoring Scheme" + schemeName + "is not linked");
           }
           finally
           {
               AcceptScoringSchemeUpdate();
           }
       }
    }
}
