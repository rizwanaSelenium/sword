﻿using System;

using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

using System.Collections.Generic;
using System.Text.RegularExpressions;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;


namespace PresentationModel.Model.NewAdmin.Configuration
{
    public class WebDriverWeightedScoringConfigurationPage : WebDriverArmPage

    {
        private WebDriverButton _okButton;

        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "OK")); }
        }

        private WebDriverButton _saveButton;

        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "Save")); }

        }

        private WebDriverButton _closeButton;

        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "Cancel")); }

        }

        private WebDriverButton _helpButton;

        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "Help")); }
        }

        private WebDriverButton _weightBandNewButton;

        public WebDriverButton WeightBandNewButton
        {
            get { return _weightBandNewButton ?? (_weightBandNewButton = new WebDriverButton(Driver, Waiter, "newBand")); }
        }

        private WebDriverButton _weightTypeNewButton;

        public WebDriverButton WeightTypeNewButton
        {
            get { return _weightTypeNewButton ?? (_weightTypeNewButton = new WebDriverButton(Driver, Waiter, "newType")); }
        }

        private readonly IWebElement _weightTypeGrid;
        private readonly IWebElement _weightBandGrid;
        private readonly IWebElement _weightScoreGrid;
        private readonly IWebElement _weightTypesHeader;
        private readonly IWebElement _weightBandsHeader;
        public readonly IWebElement WeightScoreDropDown;

        public WebDriverWeightedScoringConfigurationPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter,
            "WeightedScoringConfig")
        {
           Waiter.Until(d => Driver.FindElement(By.CssSelector("div.ui-grid-canvas")).Displayed);           
           _weightTypeGrid = Driver.FindElement(By.Id("typeGrid"));
           _weightBandGrid = Driver.FindElement(By.Id("weightBandGrid"));
           _weightScoreGrid = Driver.FindElement(By.Id("weightedScoreBandGrid"));
           _weightTypesHeader = Driver.FindElement(By.XPath("//div[1]/div/h3"));
           _weightBandsHeader = Driver.FindElement(By.XPath("//div[2]/div/h3"));
           WeightScoreDropDown = Driver.FindElement(By.CssSelector("div.col-sm-2 select.form-control"));
        }

        public void AssertWeightTypeGridExists()
        {

            bool gridStatus = _weightTypeGrid.Displayed;
            if (!gridStatus)
            {
                Assert.Fail("the weight type grid is not present");
            }
        }

        public void AssertWeightTypeGridHeaderIs(string expectedHeader)
        {

            Boolean headerTextStatus = _weightTypesHeader.Text.Equals(expectedHeader);
            if (!headerTextStatus)
            {
                Assert.Fail("the weight type grid header is as expected--" + expectedHeader);
            }
        }


        private IList<IWebElement> WeightTypeGridRows()
        {
            IList<IWebElement>  weightTypeGridField =
                    _weightTypeGrid.FindElements(By.CssSelector(".ui-grid-row"));
            return weightTypeGridField;
        }

        private IList<IWebElement> WeightBandGridRows()
        {
            IList<IWebElement> weightBandGridRows =
                    _weightBandGrid.FindElements(By.CssSelector(".ui-grid-row"));
            return weightBandGridRows;
        }

        private IList<IWebElement> WeightScoreGridRows()
        {
            IList<IWebElement> weightScoreGridRows =
                    _weightScoreGrid.FindElements(By.CssSelector(".ui-grid-row"));
            return weightScoreGridRows;
        }


        private IWebElement GridSelectedRow(IWebElement element)
        {
           IWebElement gridSelectedRow =
                    element.FindElement(By.CssSelector("div.ui-grid-row-selected"));
            return gridSelectedRow;
        }

        private IList<IWebElement> ColumnsOfTheGridRow(IWebElement element)
        {
            IList<IWebElement> gridRowColumns =
                    element.FindElements(By.CssSelector("div.ui-grid-cell"));
            return gridRowColumns;
        }


       public void VerifyWeightTypeExists(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + weightType);               
                }
        }

        public void VerifyWeightTypeNotExists(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = true;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                        flag = false;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("The weight type is in the grid--" + weightType);
                }
        }

        public void OpenScoringSchemeForWeightType(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                        element.Click();
                        element.FindElement(By.CssSelector("i.fa")).Click();
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + weightType);
                }
        }

        public int ScoringSchemeLinkedCount(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                int scringCount = 0;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                       char[] split1 = new char[] { '(' };
                       string[] count1 = rowText[1].Split(split1, StringSplitOptions.RemoveEmptyEntries);
                       char[] split2 = new char[] { ')' };
                       string[] count2 = count1[0].Split(split2, StringSplitOptions.RemoveEmptyEntries);
                        scringCount = Convert.ToInt16(count2[0]);        
                       break;
                    }
                }
                return scringCount;
        }
       

        public void UpdateWeightType(string currentWeightType, string newWeightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(currentWeightType))
                    {
                        Actions action = new Actions(Driver);
                        action.MoveToElement(element).Perform();
                        action.DoubleClick(element).Perform();
                        action.DoubleClick(element).Perform();
                        action.SendKeys(Keys.Backspace).Perform();
                        action.SendKeys(newWeightType).Perform();
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + currentWeightType);
                }
        }

        public void VerifyBlankWeightTypeIsHighlighted()
        {
                Waiter.Until(d => d.FindElement(By.CssSelector("div.ui-grid-row-selected")));
                var selectedRow = _weightTypeGrid.FindElement(By.CssSelector("div.ui-grid-row-selected"));
                int emptyweightTypes =
                    selectedRow.FindElements(By.CssSelector("div.ng-invalid")).Count;
                Boolean flag = false;
                if (emptyweightTypes > 0)
                    flag = true;

                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid");
                }
        }

        public void VerifyBlankWeightTypeRecordAdded()
        {
            Boolean flag = false;
            IList<IWebElement> weightTypeGridRows = WeightTypeGridRows();
            foreach (var row in weightTypeGridRows)
            {
                if (row.Text.Trim() == "(0)")
                {
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                Assert.Fail("Blank row is not added to WeightType Grid");
            }
        }

        public void VerifyBlankWeightBandRecordAdded()
        {
            Boolean flag = false;
            IList<IWebElement> weightBandGridRows = WeightBandGridRows();  
            if(weightBandGridRows.Count==1 && weightBandGridRows[1].Text.Trim() == "")
            {
                    flag = true;                  
            }
            if (!flag)
            {
                Assert.Fail("Blank row is not added to WeightBand Grid");
            }
        }

        public void VerifyBlankWeightScoreRecordsAdded()
        {
            Boolean flag = false;
            int blankScoreRows = 0;
            IList<IWebElement> weightScoreGridRows = WeightScoreGridRows();
            if (weightScoreGridRows.Count == 2)
            {
                foreach (var row in weightScoreGridRows)
                {
                    if (row.Text.Trim() == "(0)")
                    {
                        blankScoreRows++;
                    }
                }
            }
            if (blankScoreRows == 2)
            {
                flag = true;
            }
            if (!flag)
            {
                Assert.Fail("Blank row is not added to WeightScore Grid");
            }
        }

        public void VerifyBlankWeightBandRecordAddedForSelectedWeightType()
        {
            Boolean flag = false;
            var weightBandRow = GridSelectedRow(_weightBandGrid);
            if (weightBandRow.Text.Trim() == "")
                {
                    flag = true;                  
                }
            
            if (!flag)
            {
                Assert.Fail("Blank row is not added to Weight Band Grid");
            }

        }

        public void VerifyByDefaultFirstWeightTypeIsSelected()
        {
                var weightTypeGridRow = WeightTypeGridRows();
                Boolean flag = false;
                if (weightTypeGridRow.Count > 0)
                {
                  String[] selectedweightType = Regex.Split(weightTypeGridRow[0].Text, "\r\n");
                  String[] weightBandsHeaderText = Regex.Split(_weightBandsHeader.Text, "Weight Bands");
                  if (weightBandsHeaderText[0].Trim().Equals(selectedweightType[0]))
                         {
                             flag = true;
                         }                     
                }
                if (!flag)
                {
                    Assert.Fail("By Default first weight type in the grid is not selected");
                }
        }

        public void VerifyWeightTypeCanBeEdited()
        {
                var weightTypeGridField = WeightTypeGridRows();                    
                Boolean flag = false;
                if (weightTypeGridField.Count > 0)
                {
                    String[] weightTypeOriginal = Regex.Split(weightTypeGridField[0].Text, "\r\n");
                    Actions action = new Actions(Driver);
                    action.MoveToElement(weightTypeGridField[0]).Perform();
                    action.DoubleClick(weightTypeGridField[0]).Build();
                    action.DoubleClick(weightTypeGridField[0]).Perform();
                    action.SendKeys(weightTypeGridField[0], "Updated").Build().Perform();
                    weightTypeGridField[1].Click();
                    String[] weightTypeUpdated = Regex.Split(weightTypeGridField[0].Text, "\r\n");
                    if (weightTypeUpdated[0] == weightTypeOriginal[0] + "Updated")
                    {
                        flag = true;
                    }
                }

                if (!flag)
                {
                    Assert.Fail("user not able to update the weight type grid");
                }
        }

        public void CloseAndRespondToPrompt(string response)
        {
            CloseButton.Click();
            RespondToModalDialog(response);
        }

        public void AddNewWeightType(string weightType, string weightBand, string weightScore)
        {
            AddWeightType(weightType);
            AddWeightBandForNewWeightType(weightBand);
            AddWeightScoreForNewWeightType(weightScore);
        }

        public void VerifyNewWeightTypeIsAdded(string weightType, string weightBand, string weightScore)
        {
           VerifyWeightTypeExists(weightType);
           SelectWeightType(weightType);
           VerifyWeightBandExists(weightBand);
           VerifyWeightScoreExists(weightScore+"1");
           VerifyWeightScoreExists(weightScore+"2");
        }

        public void DeleteWeightType(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                       element.Click();
                       var trash = element.FindElement(By.CssSelector("i.glyphicon"));
                        trash.Click();
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + weightType);
                }
        }

        public void DeleteAllWeightTypesContaining(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Contains(weightType))
                    {
                        element.Click();
                        var trash = element.FindElement(By.CssSelector("i.glyphicon"));
                        trash.Click();
                        flag = true;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + weightType);
                }
        }

        public void AddWeightType(string weightTypeName)
        {   
            WeightTypeNewButton.Click();          
            var weightTypeRow = GridSelectedRow(_weightTypeGrid);
            MoveToElementAndType(weightTypeRow, weightTypeName);
        }

        public void AddWeightBand(string weightBandName)
        {       WeightBandNewButton.Click();    
            var weightBandRow = GridSelectedRow(_weightBandGrid);
            MoveToElementAndType(weightBandRow, weightBandName);          
            var rowColumns = ColumnsOfTheGridRow(weightBandRow);
            MoveToElementAndType(rowColumns[1], "11");
        }

        public void AddWeightBandWithInvalidFactor(string weightBandName, string factorValue )
        {
            WeightBandNewButton.Click();
            var weightBandRow = GridSelectedRow(_weightBandGrid);
            MoveToElementAndType(weightBandRow, weightBandName);
            var rowColumns = ColumnsOfTheGridRow(weightBandRow);
            MoveToElementAndType(rowColumns[1], factorValue);
        }

        public void AddWeightBandForNewWeightType(string weightBandName)
        {
             var weightBandRow=   WeightBandGridRows();
            if (weightBandRow.Count == 1)
            {
                MoveToElementAndType(weightBandRow[0], weightBandName);               
                var rowColumns = ColumnsOfTheGridRow(weightBandRow[0]);
                MoveToElementAndType(rowColumns[1], "11");
            }
             else
                {
                    Assert.Fail("There is no  weight Band blank row added");
                }
        }

        public void DeleteWeightBand(string weightBandName)
        {
                var weightBandGridRows = WeightBandGridRows();
                Boolean flag = false;
                foreach (var element in weightBandGridRows)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightBandName))
                    {
                        element.Click();
                        var trash = element.FindElement(By.CssSelector("i.glyphicon"));
                        trash.Click();
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("The weight Band" + weightBandName +" is not in the grid");
                }
        }

      public  void MoveToElementAndType(IWebElement element,string inputText)
        {
            Actions action = new Actions(Driver);
            action.MoveToElement(element).Perform();
            action.DoubleClick(element).Perform();
            action.DoubleClick(element).Perform();
            action.SendKeys(inputText).Perform();
        }

        public void AddWeightScoreForNewWeightType(string weightScoreName)
        {
                IList<IWebElement> weightScoreRows = WeightScoreGridRows();
                int i = 1;

                if (weightScoreRows.Count == 2)
                {
                    foreach (var element in weightScoreRows)
                    {

                        MoveToElementAndType(element, weightScoreName + Convert.ToString(i));
                        i = i + 1;
                    }
                }
                else
                {
                    Assert.Fail("There are no 2 weight score blank rows added");
                }
        }

        public void AddAdditionalWeightScore(string weightScrorName)
        {
            SelectElement selectedValue = new SelectElement(WeightScoreDropDown);
           int currentWeightScoreCount = Convert.ToInt32(selectedValue.SelectedOption.Text);
          currentWeightScoreCount= currentWeightScoreCount + 1;
          WeightScoreDropDown.SendKeys(Convert.ToString(currentWeightScoreCount));
           IList<IWebElement> weightScoreRows = WeightScoreGridRows();
           MoveToElementAndType(weightScoreRows[currentWeightScoreCount - 1], weightScrorName);
       }


        public void OpenScoringSchemeforSelectedWeightType()
        {           
                Boolean flag = false;                  
                   var weightTypeRow = GridSelectedRow(_weightTypeGrid);
                   if (weightTypeRow != null)
                    {
                        weightTypeRow.Click();
                        weightTypeRow.FindElement(By.CssSelector("i.fa")).Click();
                        flag = true;
                    }
                
                if (!flag)
                {
                    Assert.Fail("Any weight type is not selected" );
                }
        }

        public void SelectWeightType(string weightType)
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = false;
                foreach (var element in weightTypeGridField)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightType))
                    {
                        element.Click();
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("the weight type is not in the grid--" + weightType);
                }
        }

        public void VerifyWeightBandExists(string weightBand)
        {
                var weightBandGridRows = WeightBandGridRows();
                Boolean flag = false;
                foreach (var element in weightBandGridRows)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightBand))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("The weight Band for the selected weight type is not in the grid--" + weightBand);
                }
        }

        public void VerifyWeightBandNotExists(string weightBand)
        {
                var weightBandGridRows = WeightBandGridRows();
                Boolean flag = true;
                foreach (var element in weightBandGridRows)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightBand))
                    {
                        flag = false;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("The weight Band "+ weightBand +"for the selected weight type is in the grid");
                }
        }

        public void VerifyWeightScoreExists(string weightScore)
        {
                var weightScoreGridRows = WeightScoreGridRows();
                Boolean flag = false;
                foreach (var element in weightScoreGridRows)
                {
                    String[] rowText = Regex.Split(element.Text, "\r\n");
                    if (rowText[0].Equals(weightScore))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                {
                    Assert.Fail("The weight score for the selected weight type is not in the grid--" + weightScore);
                }
        }

          public void VerifyScoringSchemeButtonAvailableInTheGrid()
        {
                var weightTypeGridField = WeightTypeGridRows();
                Boolean flag = true;
                foreach (var element in weightTypeGridField)
                {                 
                    IList<IWebElement> weightTypeGridCells = ColumnsOfTheGridRow(element);
                    var scoringSchemeButton = weightTypeGridCells[1].FindElement(By.CssSelector("i.fa")).Displayed;
                    if (!scoringSchemeButton)
                    {
                        flag = false;
                        break;
                    }
                }
                if(!flag)
                {
                    Assert.Fail("The scoring scheme button is not in the grid");
                }
        }

        public void ClickWeightTypeNewButton()
        {
            WeightTypeNewButton.Click();
            WaitUntilPageIsReady();
        }

        public void SaveWeightType()
        {
            SaveButton.Click();
            WaitUntilPageIsReady();
        }
        public void CloseWeightType()
        {
            OkButton.AssertEnabled();
            OkButton.Click();
        }

        public void CancelWeightType()
        {
            CloseButton.AssertEnabled();
            CloseButton.Click();
        }

        public void VerifyButtonDisabled(String buttonName)
        {
          if(buttonName.ToUpper()=="SAVE")
             SaveButton.AssertDisabled();
          else if (buttonName.ToUpper() == "OK")
            OkButton.AssertDisabled();
        }
    }
}
