﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminSecurityTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _usersAndResources;
        public WebDriverLinkControl UsersAndResources
        {
            get
            {
                return _usersAndResources ?? (_usersAndResources = new WebDriverLinkControl(Driver, Waiter, "Users and Resources"));
            }
        }

        private WebDriverLinkControl _groups;
        public WebDriverLinkControl Groups
        {
            get
            {
                return _groups ?? (_groups = new WebDriverLinkControl(Driver, Waiter, "Groups"));
            }
        }

        private WebDriverLinkControl _resourceAndUserGroupsDefault;
        public WebDriverLinkControl ResourceAndUserGroups
        {
            get
            {
                return _resourceAndUserGroupsDefault ?? (_resourceAndUserGroupsDefault = new WebDriverLinkControl(Driver, Waiter, "Resource And User Groups Default"));
            }
        }

        // Second Section
        private WebDriverLinkControl _assignRolesToUsers;
        public WebDriverLinkControl AssignRolesToUsers
        {
            get
            {
                return _assignRolesToUsers ?? (_assignRolesToUsers = new WebDriverLinkControl(Driver, Waiter, "Assign Roles To Users"));
            }
        }

        private WebDriverLinkControl _roleConfiguration;
        public WebDriverLinkControl RoleConfiguration
        {
            get
            {
                return _roleConfiguration ?? (_roleConfiguration = new WebDriverLinkControl(Driver, Waiter, "Role Configuration"));
            }
        }

        // Third Section
        private WebDriverLinkControl _businessAreaAccess;
        public WebDriverLinkControl BusinessAreaAccess
        {
            get
            {
                return _businessAreaAccess ??
                       (_businessAreaAccess = new WebDriverLinkControl(Driver, Waiter, "Business Area Access"));
            }
        }

        private WebDriverLinkControl _securityAttributes;
        public WebDriverLinkControl SecurityAttributes
        {
            get
            {
                return _securityAttributes ?? (_securityAttributes = new WebDriverLinkControl(Driver, Waiter, "Security Attributes"));
            }
        }

        private WebDriverLinkControl _riskAccess;
        public WebDriverLinkControl RiskAccess
        {
            get
            {
                return _riskAccess ?? (_riskAccess = new WebDriverLinkControl(Driver, Waiter, "Risk Access"));
            }
        }

        private WebDriverLinkControl _interfaceAccess;
        public WebDriverLinkControl InterfaceAccess
        {
            get
            {
                return _interfaceAccess ?? (_interfaceAccess = new WebDriverLinkControl(Driver, Waiter, "Interface Access"));
            }
        }

        private WebDriverLinkControl _scoringSchemeAccess;

        public WebDriverLinkControl ScoringSchemeAccess
        {
            get
            {
                return _scoringSchemeAccess ?? (_scoringSchemeAccess = new WebDriverLinkControl(Driver, Waiter, "Scoring Scheme Access"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true)); }
        }

        public AdminSecurityTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Security")
        {
            // Wait until URL contains "Security"
            waiter.Until(u => u.Url.Contains("Security"));
        }
    }
}
