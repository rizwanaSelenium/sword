﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.NewAdmin.International;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminInternationalTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _multiCurrency;
        public WebDriverLinkControl MultiCurrency
        {
            get
            {
                return _multiCurrency ?? (_multiCurrency = new WebDriverLinkControl(Driver, Waiter, "Multi Currency"));
            }
        }

        private WebDriverLinkControl _configureMulticurrency;
        public WebDriverLinkControl ConfigureMulticurrency
        {
            get
            {
                return _configureMulticurrency ?? (_configureMulticurrency = new WebDriverLinkControl(Driver, Waiter, "Configure Multicurrency"));
            }
        }

        // Third Section
        private WebDriverLinkControl _listTranslation;
        public WebDriverLinkControl ListTranslation
        {
            get
            {
                return _listTranslation ?? (_listTranslation = new WebDriverLinkControl(Driver, Waiter, "List Translation"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true));
            }
        }

        public AdminInternationalTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "International")
        {
            // Wait until URL contains "International"
            waiter.Until(u => u.Url.Contains("International"));
        }

        public ListTranslationPage OpenListTranslationDialog()
        {
            ListTranslation.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new ListTranslationPage(Driver, Waiter);
        }
    }
}
