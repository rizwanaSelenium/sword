﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.NewAdmin
{
    public class AdminMobileTabPage : WebDriverArmPage
    {
        // First Section
        private WebDriverLinkControl _fieldMappings;
        public WebDriverLinkControl FieldMappings
        {
            get
            {
                return _fieldMappings ?? (_fieldMappings = new WebDriverLinkControl(Driver, Waiter, "Field Mappings"));
            }
        }

        private WebDriverLinkControl _registrationEmailConfiguration;

        public WebDriverLinkControl RegistrationEmailConfiguration
        {
            get
            {
                return _registrationEmailConfiguration ?? (_registrationEmailConfiguration = new WebDriverLinkControl(Driver, Waiter, "Registration Email Configuration"));
            }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "button.btn", true));
            }
        }

        public AdminMobileTabPage(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Mobile")
        {
            // Wait until URL contains "Mobile"
            waiter.Until(u => u.Url.Contains("Mobile"));
        }
    }
}
