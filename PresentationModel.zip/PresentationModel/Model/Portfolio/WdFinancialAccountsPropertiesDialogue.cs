﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Portfolio
{
    public class WdFinancialAccountsPropertiesDialogue : WebDriverItemDialog
    {
        private WebDriverDropDown _configurationDropDown;
        public new WebDriverDropDown ConfigurationDropDown
        {
            get
            {
                return _configurationDropDown ?? (_configurationDropDown = new WebDriverDropDown(Driver, Waiter, "RootView_Header_ConfigDataSet"));
            }

        }

        private WebDriverDropDown _scoringSchemeGroupDropDown;
        public new WebDriverDropDown ScoringSchemeGroupDropDown
        {
            get
            {
                return _scoringSchemeGroupDropDown ?? (_scoringSchemeGroupDropDown = new WebDriverDropDown(Driver, Waiter, "RootView_Header_ScoringSchemeGroup"));
            }

        }

        private WebDriverDropDown _classificationsDropDown;
        public new WebDriverDropDown ClassificationsDropDown
        {
            get
            {
                return _classificationsDropDown ?? (_classificationsDropDown = new WebDriverDropDown(Driver, Waiter, "select#ClassificationsId", true));
            }
        }

        public WdFinancialAccountsPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            waiter.Until(d => ClassificationsDropDown.GetValue().Length > 0);
        }
    }
}
