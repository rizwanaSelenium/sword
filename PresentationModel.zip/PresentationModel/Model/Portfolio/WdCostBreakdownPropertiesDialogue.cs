﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Portfolio
{
    public class WdCostBreakdownPropertiesDialogue : WebDriverItemDialog
    {
        public WdCostBreakdownPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {


        }
    }
}
