﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Item;
namespace PresentationModel.Model.Portfolio
{
    public class WebDriverRequirementPropertiesDialogue : WebDriverItemDialog
    {
        public WebDriverRequirementPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {

        }

        private  WebDriverDropDown _requirementsCustomList1;
        public WebDriverDropDown RequirementsCustomList1
        {
            get
            {
                return _requirementsCustomList1 ?? (_requirementsCustomList1 = new WebDriverDropDown(Driver, Waiter, "input#RiskReviewPeriod", true));
            }
        }

        private WebDriverDropDown _requirementsCustomList2;
        public WebDriverDropDown RequirementsCustomList2
        {
            get
            {
                return _requirementsCustomList2 ?? (_requirementsCustomList2 = new WebDriverDropDown(Driver, Waiter, "input#RiskReviewPeriod", true));
            }
        }


        private WebDriverDropDown _requirementsCustomList3;
        public WebDriverDropDown RequirementsCustomList3
        {
            get
            {
                return _requirementsCustomList3 ?? (_requirementsCustomList3 = new WebDriverDropDown(Driver, Waiter, "input#RiskReviewPeriod", true));
            }
        }



        }
       
    
}
