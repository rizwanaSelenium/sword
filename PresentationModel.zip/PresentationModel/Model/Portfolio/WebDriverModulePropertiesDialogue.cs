﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Portfolio
{
    public class WebDriverModulePropertiesDialogue : WebDriverItemDialog
    {
        public WebDriverModulePropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {

        }
    }
}
