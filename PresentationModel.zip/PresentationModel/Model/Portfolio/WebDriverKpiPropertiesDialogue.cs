﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Portfolio
{
    public class WebDriverKpiPropertiesDialogue : WebDriverItemDialog
    {
        public WebDriverKpiPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
        }
    }
}
