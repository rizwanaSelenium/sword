﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;
namespace PresentationModel.Model.Portfolio
{
    public class WebDriverAssetPropertiesDialogue : WebDriverItemDialog
    {
        public WebDriverAssetPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
        }
    }
}

