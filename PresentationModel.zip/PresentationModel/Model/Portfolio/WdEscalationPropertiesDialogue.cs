﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Portfolio
{
    public class WdEscalationPropertiesDialogue : WebDriverItemDialog
    {

        public WdEscalationPropertiesDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
        }
    }
}
