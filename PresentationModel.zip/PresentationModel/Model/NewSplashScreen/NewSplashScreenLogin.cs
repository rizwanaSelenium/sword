﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.NewSplashScreen
{
    public class NewSplashScreenLogin : WebDriverArmPage
    {
        public WdImage SplashWelcomeMessage { get; set; }

        private WebDriverDropDown _instanceText;
        public WebDriverDropDown InstanceText
        {
            get
            {
                _instanceText = new WebDriverDropDown(Driver, Waiter, "select[id='instanceDropDown']", true);
                return _instanceText;
            }
        }

        private WebDriverDropDown _businessAreaText;
        public WebDriverDropDown BusinessAreaText
        {
            get
            {
                _businessAreaText = new WebDriverDropDown(Driver, Waiter, "select[id='businessAreaDropDown']", true);
                return _businessAreaText;
            }
        }

        private WebDriverButton _startButton;
        public WebDriverButton StartButton
        {
            get
            {
                _startButton = new WebDriverButton(Driver, Waiter, "img[title='ARM Desktop']", true);
                return _startButton;
            }
        }

        private WebDriverButton _complianceButton;
        public WebDriverButton ComplianceButton
        {
            get
            {
                return _complianceButton = new WebDriverButton(Driver, Waiter, "img[title='SWORD Compliance Manager']", true);
            }
        }

        public NewSplashScreenLogin(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "arm")
        {
            SplashWelcomeMessage = new WdImage(driver, waiter);
            WaitUntilPageIsReady();
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public void ClickOnDesktopIcon()
        {
            StartButton.Click();
            WaitUntilUiSpinnerIsNotDisplayed();
            for (var i = 0; i < 2; i++)
            {
                try
                {
                    Waiter.Until(d => d.FindElements(By.CssSelector("div.treenode.tree-root div.treenode")).Count >= 1);
                    break;
                }
                catch (Exception ex)
                {
                    if (i == 1)
                    {
                        if (ex is WebDriverTimeoutException)
                        {
                            throw new WebDriverTimeoutException("** Error ** Timed out waiting for tree nodes to be displayed. " + ex);
                        }

                        if (ex is StaleElementReferenceException)
                        {
                            throw new StaleElementReferenceException("** Error ** Stale element from splash screen trying to load desktop. " + ex);
                        }

                        throw new Exception("** Error ** Another error on splash screen. " + ex);
                    }
                    Console.WriteLine("** Alert ** Failed once moving away from the splash screen will attempt to click application icon again.");
                }
            }
        }

        public void ClickOnComplianceManagerIcon()
        {
            ComplianceButton.Click();
            WaitUntilUiSpinnerIsNotDisplayed();
            for (var i = 0 ; i < 3 ; i++)
            {
                try
                {
                    Waiter.Until(d => d.FindElements(By.CssSelector("img[title='SWORD Compliance Manager']")).Count(e => e.Displayed) == 0);
                    break;
                }
                catch (Exception ex)
                {
                    if (i == 1)
                    {
                        if (ex is WebDriverTimeoutException)
                        {
                            throw new WebDriverTimeoutException("** Error ** Timed out waiting to move away from splash screen to compliance. " + ex);
                        }

                        if (ex is StaleElementReferenceException)
                        {
                            throw new StaleElementReferenceException("** Error ** Stale element while trying to load compliance from splash screen. " + ex);
                        }

                        throw new Exception("** Error ** Another error on splash screen. " + ex);
                    }
                    Console.WriteLine("** Alert ** Failed once moving away from the splash screen.");
                }
                WaitUntilUiSpinnerIsNotDisplayed();
            }
        }

        public bool ArmCurrentAlreadySelected()
        {
            WaitUntilInstanceTextIsVisible();
            return InstanceText.GetValue().Equals("ARM Current");
        }

        public void SelectInstance(string instance, int instanceNo)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());

            InstanceText.Click();

            var options = InstanceText.FindElements(By.CssSelector("option[value='" + instanceNo + ": Object']")).ToList();

            if (options.Count == 1)
            {
                options.First().Click();
                Waiter.Until(d => !d.IsAjaxRequestInProgress());
            }
            if (options.Count == 0)
            {
                if (InstanceText.FindElements(By.CssSelector("option[value='" + 0 + ": Object']")).First().Text != "ARM Current")
                {
                    Assert.Fail("Instance with ID " + instanceNo + " not found");
                }
            }
            if (options.Count > 1)
            {
                Assert.Fail("Multiple Instances with ID: " + instanceNo + " found Login Failed");
            }
        }

        public void SelectBusinessArea(string businessArea, int businessAreaId)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilBusinessAreaTextIsVisible();

            bool businessAreaFoundInOptions = false;

            var options = BusinessAreaText.FindElements(By.CssSelector("option")).ToList();

            foreach (var option in options)
            {
                if (option.Text == businessArea)
                {
                    option.Click();
                    Waiter.Until(d => !d.IsAjaxRequestInProgress());
                    businessAreaFoundInOptions = true;
                    break;
                }
            }

            if (!businessAreaFoundInOptions)
            {
                Assert.Fail("Business Area: {0} with ID {1} not found within Business Area Drop Down options", businessArea, businessAreaId);
            }

        }

        public void ClickSwordLogo()
        {
           SwordLogo.Click();
        }

        private void WaitUntilInstanceTextIsVisible()
        {
            // When the New Splash Screen is interacted with, Elements are redrawn
            // So we need to search for them and ensure that they are visible first, before
            // trying to interact with them
            bool instanceTextIsVisible = false;
            for (var i = 0; i < 60; i++)
            {
              
                var instanceTexts = Driver.FindElements(By.CssSelector("div select#instanceDropDown"));
                if (instanceTexts.Count == 1)
                {
                    instanceTextIsVisible = true;
                    break;
                }
                Thread.Sleep(500);
            }
            if (!instanceTextIsVisible)
            {
                Assert.Fail("Was waiting for the Instance Text to be displayed, but it wasn't displayed");
            }
        }

        private void WaitUntilBusinessAreaTextIsVisible()
        {
            // When the New Splash Screen is interacted with, Elements are redrawn
            // So we need to search for them and ensure that they are visible first, before
            // trying to interact with them
            bool businessAreaTextIsVisible = false;
            for (var i = 0; i < 20; i++)
            {
              
                var businesAreaTexts = Driver.FindElements(By.CssSelector("div select#businessAreaDropDown"));
                if (businesAreaTexts.Count == 1)
                {
                    businessAreaTextIsVisible = true;
                    break;
                }
                Thread.Sleep(500);

            }
            if (!businessAreaTextIsVisible)
            {
                Assert.Fail("Was waiting for the Business Area Text to be displayed, but it wasn't displayed");
            }
        }
    }
}
