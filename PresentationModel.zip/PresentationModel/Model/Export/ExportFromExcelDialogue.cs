﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Export
{
    public class ExportFromExcelDialogue : WebDriverArmPage
    {
        // Export From Excel Dialogue is shared by the Export Risks (Excel)
        // and Export Audits (Excel) functions, but the controls are different
        // so those controls that are specific to one or the other have been made
        // private so the same Dialogue can be used by both functions

        // Shared controls
        public WebDriverTextField Item { get; set; }

        public WebDriverButton ExportButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        // Export Risk Controls
        private WebDriverTextField _idPrefix;
        public WebDriverTextField IdPrefix
        {
            get
            {
                return _idPrefix ??
                       (_idPrefix = new WebDriverTextField(Driver, Waiter, "ETEV_ExportIDPrefix"));
            }
        }

        private WebDriverTickBoxControl _includePrivateRisks;
        public WebDriverTickBoxControl IncludePrivateRisks
        {
            get
            {
                return _includePrivateRisks ?? (_includePrivateRisks = new WebDriverTickBoxControl(Driver, Waiter, "ETEV_IncludePrivateRisks"));
            }
        }

        private WebDriverRadioButton _exportImpactValueTypeQuantitativeValuesOnly;
        public WebDriverRadioButton ExportImpactValueTypeQuantitativeValuesOnly
        {
            get
            {
                return _exportImpactValueTypeQuantitativeValuesOnly ??
                       (_exportImpactValueTypeQuantitativeValuesOnly = new WebDriverRadioButton(Driver, Waiter, "ETEV_ExportImpactValueType"));
            }
        }

        private WebDriverRadioButton _qualitativeValuesOnly;
        public WebDriverRadioButton QualitativeValuesOnly
        {
            get
            {
                return _qualitativeValuesOnly ??
                       (_qualitativeValuesOnly = new WebDriverRadioButton(Driver, Waiter, "ETEV_ExportImpactValue"));
            }
        }

        private WebDriverDropDown _exportTemplateFileDropDown;
        public WebDriverDropDown ExportTemplateFileDropDown
        {
            get
            {
                return _exportTemplateFileDropDown ??
                       (_exportTemplateFileDropDown = new WebDriverDropDown(Driver, Waiter, "ETEV_ExportTemplateName"));
            }
        }

        // Export Audit Controls
        private WebDriverDropDown _fileNameDropDown;
        public WebDriverDropDown FileNameDropDown
        {
            get
            {
                return _fileNameDropDown ?? (_fileNameDropDown = new WebDriverDropDown(Driver, Waiter, "ETEV_ExportTemplateName"));
            }
        }

        public ExportFromExcelDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ExportToExcel.aspx")
        {
            Item = new WebDriverTextField(driver, waiter, "div#ETEV_ExportItem input#ETEV_ExportItem_tb", true);

            ExportButton = new WebDriverButton(driver, waiter, "ETEV_Export_btn");
            CancelButton = new WebDriverButton(driver, waiter, "ETEV_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "ETEV_Help_btn");

            // Wait for page Initial Data Load, then page is ready, then JavaScript
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void ClickCancel()
        {
            FocusWindow();
            var currentWindowHandle = Driver.CurrentWindowHandle;

            CancelButton.AssertEnabled();
            CancelButton.Click();

            Waiter.Until(d => !d.WindowHandles.Contains(currentWindowHandle));
        }

        public void AssertNoBackButton()
        {
            try
            {
                Driver.FindElement(By.CssSelector("button#ETEV_Back_btn"));
                Assert.Fail("Back button found on Export To Excel Dialogue - should not be present");
            }
            catch (NoSuchElementException)
            {
                // If we don't find the button, do nothing as we are not expecting it to be present
            }
        }

        public void AssertNoNextButton()
        {
            try
            {
                Driver.FindElement(By.CssSelector("button#ETEV_Next_btn"));
                Assert.Fail("Next button found on Export From Excel Dialogue - should not be present");
            }
            catch (NoSuchElementException)
            {
                // If we don't find the button, do nothing as we are not expecting it to be present
            }
        }
    }
}
