﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Help
{
    public class WebDriverHelpPage : WebDriverArmPage
    {
        public WebDriverHelpPage(IWebDriver driver, WebDriverWait waiter, string pageName) : base(driver, waiter, pageName)
        {
        }
    }
}
