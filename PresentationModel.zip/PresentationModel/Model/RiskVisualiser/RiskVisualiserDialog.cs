﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.RiskVisualiser
{
  public  class  RiskVisualiserDialog : WebDriverArmPage
    {
        
        public RiskVisualiserDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            
        }

        public void AssertRiskTitle(string title)
        {
            FocusWindow();
            Waiter.Until(d => Driver.FindElement(By.CssSelector("g.node")).Displayed);
            Assert.IsTrue(Driver.FindElements(By.CssSelector("title")).Any(x => x.Text == title));

        }

        public void AddNewRisk(string riskTitle)
        {
            FocusWindow();
            var riskT= Driver.FindElement(By.CssSelector("input[ng-model='vm.data.title']"));
            riskT.SendKeys(riskTitle);
            riskT.SendKeys(Keys.Return);
        }

        public void AddNewResponse(string responseTitle)
        {
            FocusWindow();
            var riskT = Driver.FindElement(By.CssSelector("input[ng-model='vm.data.title']"));
            riskT.SendKeys(responseTitle);
            riskT.SendKeys(Keys.Return);
        }

        public void ClickOnRiskEditButton()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g.element-node.editable rect"));
            builder.MoveToElement(elements[0]).Perform();
            elements[0].Click();
        }

        public void ClickOnNewRiskButton()
        {
            FocusWindow();
            IWebElement element = Driver.FindElement(By.CssSelector("button#OK"));
            Waiter.Until(d => element.Displayed);
            element.Click();
        }
        public void ClickOnAddResponseButton()
        {
            Actions builder = new Actions(Driver);
            var elements=   Driver.FindElements(By.CssSelector("g.node-add-button.right-side"));
            builder.MoveToElement(elements[0]).Perform();
            elements[0].Click();

        }
        public void ClickOnEvalOrDefEditButton()
        {
            Thread.Sleep(1000);
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='element_node editable'] rect"));
            Thread.Sleep(1500);
            builder.MoveToElement(elements[0]).Perform();
            elements[0].Click();

        }
        public void ClickOnEditButton()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> nodeElements = Driver.FindElements(By.CssSelector("g.node"));
            var responseNode = nodeElements[1];
            Thread.Sleep(1000);
            builder.MoveToElement(responseNode.FindElement(By.CssSelector("g text")));
            builder.Click();
            builder.Perform();
        }
        public void ClickOnPlanEditButton()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf'] g text"));
            builder.MoveToElement(elements[1]).Perform();
            elements[1].Click();

        }
        public void ClickOnAssessmentButton(string s)
        {
            Thread.Sleep(500);
            switch (s)
            {
                case "Current Assessment":
                    Actions builder = new Actions(Driver);
                    IList<IWebElement> elements =
                        Driver.FindElements(By.CssSelector("small[class='text-center ng-binding']"));
                    builder.MoveToElement(elements[1]).Perform();
                    elements[1].Click();
                    break;
                case "Target Assessment" :
                     Actions builder1 = new Actions(Driver);
                    IList<IWebElement> elements1 =
                        Driver.FindElements(By.CssSelector("small[class='text-center ng-binding']"));
                    builder1.MoveToElement(elements1[2]).Perform();
                    elements1[2].Click();
                    break;
                case "Probability":
                    Driver.FindElement(By.CssSelector("button[title='Significant Probability']")).Click();
                    break;
                case "Cost":
                    Driver.FindElement(By.CssSelector("button[title='Moderate Cost']")).Click();
                    break;
                case "Time":
                    Driver.FindElement(By.CssSelector("button[title='Minimum Time']")).Click();
                    break;
                case "Inherent Assessment":
                    Actions builder2 = new Actions(Driver);
                    IList<IWebElement> elements2 =
                        Driver.FindElements(By.CssSelector("small[class='text-center ng-binding']"));
                    builder2.MoveToElement(elements2[0]).Perform();
                    elements2[0].Click();
                    break;

              }
        }

        public void MoveToPlanElement()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
            builder.MoveToElement(elements[0]).Perform();
        }
        public void ClickOnAddEvalOrDeficiencyButton()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("text.add-icon"));
            builder.MoveToElement(elements[1]).Perform();
            elements[1].Click();
        }

        public void ClickOnAddTestButton()
        {
            Thread.Sleep(1000);
            Actions builder=new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("text[class='node-add-button']"));
            builder.MoveToElement(elements[1]).Perform();
            elements[1].Click();
        }

        public void ClickOnAddRatingOrRemediationPlanButton()
        {
            Actions builder = new Actions(Driver);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("text[class='node-add-button']"));
            builder.MoveToElement(elements[1]).Perform();
            elements[1].Click();
        }
        public string GetRiskIdOnRiskVisulaiserMap()
        {
            string riskId = Driver.FindElement(By.CssSelector("input[name='customRiskRef']")).GetAttribute("value");
            return riskId;
        }

        public string GetRiskNameOnRiskVisulaiserMap()
        {
            FocusWindow();
            Thread.Sleep(1000);
            string riskName = Driver.FindElement(By.CssSelector("input[name='riskName']")).GetAttribute("value");
            return riskName;
        }
        public string GetRiskStatusOnRiskVisulaiserMap()
        {
            IWebElement element =
                Driver.FindElement(By.Id("riskStatus_selectiontext"));
            string riskStatus = element.Text;
            return riskStatus;
        }

        public string GetRiskOwnerOnRiskVisulaiserMap()
        {
            string riskOwner = Driver.FindElement(By.CssSelector("input[id='riskOwner']")).GetAttribute("value");
            return riskOwner;
        }

        public void SelectResponseType()
        {
            Thread.Sleep(500);
            IList<IWebElement> elements =
                 Driver.FindElements(By.CssSelector("a.dropdown-toggle"));
            Waiter.Until(d => elements);
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", elements[0]);


            IWebElement type1 = Driver.FindElement(By.XPath("//li[2]/div/span"));
            type1.Click();

        }

        public void SelectEvalOrDeficiency(string type)
        {
            ReadOnlyCollection<IWebElement> listElements = new ReadOnlyCollection<IWebElement>(new List<IWebElement>());
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(1000);
                listElements = Driver.FindElements(By.XPath("//g[contains(@class,'node-add-menu-button')]"));
                if (listElements.Any())
                {
                    break;
                }
            }

            if (listElements.Any())
            {
                switch (type)
                {
                    case "Evaluation":
                        listElements[0].Click();
                        break;
                    case "Deficiency":

                        listElements[1].Click();
                        break;
                } 
            }
            else
            {
                Assert.Fail("Webdriver could not find Evaluation or Deficiency Picker");
            }

        }
        public void SelectRatingOrRemediationPlan(string type)
        {
            ReadOnlyCollection<IWebElement> listElements = new ReadOnlyCollection<IWebElement>(new List<IWebElement>());
            for (int i = 0; i < 5; i++)
            {
                Thread.Sleep(1000);
                listElements = Driver.FindElements(By.XPath("//g[contains(@class,'node-add-menu-button')]/text"));
                if (listElements.Any())
                {
                    break;
                }
            }

            if (listElements.Any())
            {
                    switch (type)
                    {
                        case "Rating":
                            listElements[0].Click();
                            break;
                        case "Remediaton Plan":
                            listElements[1].Click();
                            break;
                    }
            }
            else
            {
                Assert.Fail("Webdriver could not find Rating or Remediation Picker");
            }

        }

        public void EnterGrossOrNetExposure(string type)
        {
            IList<IWebElement> elements = Driver.FindElements(By.CssSelector("input[name='title-input']"));
            Waiter.Until(d => elements);
            switch (type)
            {
                case "Gross":
                    elements[0].SendKeys("100");
                    break;
                case "Net":
                    elements[1].SendKeys("75");
                    break;
            }
        }

        public void EnterEvalOrDeficiencyTitle(string title)
        {
            Thread.Sleep(500);
            FocusWindow();
            var riskT = Driver.FindElement(By.CssSelector("input[ng-model='vm.data.title']"));
            riskT.SendKeys(title);
            riskT.SendKeys(Keys.Return);
        }

        public void UpdateEvalTitle(string title)
        {
            Thread.Sleep(500);
            IWebElement element = Driver.FindElement(By.CssSelector("input[name='evaluationName']"));
            element.Clear();
            element.SendKeys(title);
        }
        public void EnterRemediationPlanTitle()
        {
            Thread.Sleep(500);
            IWebElement element = Driver.FindElement(By.CssSelector("input[name='title-input']"));
            element.Clear();
            element.SendKeys("Test Remediation");
        }
        public void SetResponseOwner(string owner)
        {
            Thread.Sleep(500);
            IWebElement element = Driver.FindElement(By.CssSelector("input[id='responseOwner']"));
            element.Clear();
            element.SendKeys(owner);

            Thread.Sleep(1500);

            IWebElement textToSelect = Driver.FindElement(By.CssSelector("a.ng-scope > span.ng-binding"));
            Waiter.Until(d => textToSelect);

            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", textToSelect);
        }

        public void SelectResponseDueDate()
        {
            IWebElement element = Driver.FindElement(By.Id("responseDueDate"));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", element);

            Thread.Sleep(1000);
            IWebElement date = Driver.FindElement(By.XPath("//button[@class='btn btn-default btn-sm active']"));
            executor.ExecuteScript("arguments[0].click();", date);
        }
        public void UpdateResponseDueDate()
        {
            IWebElement element = Driver.FindElement(By.Id("responseDueDate"));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", element);

            Thread.Sleep(1000);
            IWebElement date = Driver.FindElement(By.XPath("//button[@class='btn btn-default btn-sm btn-info active']"));
            executor.ExecuteScript("arguments[0].click();", date);
        }

        public void ClickOnOkButton()
        {
            Thread.Sleep(1000);
            IWebElement element = Driver.FindElement(By.Id("okButton"));

            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", element);
        }

        public void EnterPlanTitle(string title)
        {
            IWebElement element = Driver.FindElement(By.CssSelector("input[name='planName']"));
            Waiter.Until(d => element);
            element.Clear();
            element.SendKeys(title);
        }
       
        public void EnterResponseTitle(string title)
        {
            IWebElement element = Driver.FindElement(By.CssSelector("input[name='title-input']"));
            element.Clear();
            element.SendKeys(title);
        }

        public void EnterRiskTitle(string title)
        {
            IWebElement element = Driver.FindElement(By.CssSelector("input[name='riskName']"));
            Waiter.Until(e => element.Displayed);
            element.Clear();
            element.SendKeys(title);
        }


        public void SelectResponseStatus(string status)
        {
            Thread.Sleep(1000);
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("a.dropdown-toggle"));
            elements[1].Click();

            IWebElement type1 = Driver.FindElement(By.XPath("//div[3]/div[2]/div/div/treecontrol/ul/li[2]/div/span"));
            type1.Click();
            Thread.Sleep(1000);
        }

        public void SelectRiskStatus(string status)
        {
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("a.dropdown-toggle"));
            elements[1].Click();

            IWebElement type1 = Driver.FindElement(By.XPath("//div[4]/div[2]/div/div/treecontrol/ul/li[2]/div/span"));
            type1.Click();
             
            Thread.Sleep(1000);
        }

        public void EnterRiskStatusChangeReason()
        {
            Thread.Sleep(1000);
            IWebElement element = Driver.FindElement(By.CssSelector("div[class='messagebox ng-scope']"));
            if (element.Displayed)
            {
                IWebElement textElement =
                    Driver.FindElement(By.CssSelector("textarea[data-ng-model='modalOptions.inputData']"));
                textElement.Clear();
                textElement.SendKeys("Test");
                IWebElement okButton = Driver.FindElement(By.CssSelector("button[class='btn-arm ng-binding']"));

                IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
                executor.ExecuteScript("arguments[0].click();", okButton);
                Thread.Sleep(1000);
            }
        }

        public void SetOwner(string owner)
        {
            IWebElement element = Driver.FindElement(By.CssSelector("input[id='responseOwner']"));
            element.Clear();
            element.SendKeys(owner);

            Thread.Sleep(1000);

            IWebElement textToSelect = Driver.FindElement(By.CssSelector("a.ng-scope > span.ng-binding"));
            Waiter.Until(d => textToSelect);

            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", textToSelect);

        }
        public void SetRiskOwner(string owner)
        {
            IWebElement element = Driver.FindElement(By.CssSelector("input[id='riskOwner']"));
            element.Clear();
            element.SendKeys(owner);

            Thread.Sleep(1500);

            IWebElement textToSelect = Driver.FindElement(By.CssSelector("a.ng-scope > span.ng-binding ng-scope"));
            Waiter.Until(d => textToSelect);

            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", textToSelect);

        }
        public void SelectDate()
        {
            IWebElement element = Driver.FindElement(By.Id("responseDueDate"));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)Driver;
            executor.ExecuteScript("arguments[0].click();", element);

            Thread.Sleep(1500);
            IWebElement date = Driver.FindElement(By.XPath("//button[@class='btn btn-default btn-sm active']"));
            executor.ExecuteScript("arguments[0].click();", date);

        }

        public void AssertAddResponseButton()
        {
            FocusWindow();
            IList<IWebElement> elements =
                 Driver.FindElements(By.CssSelector("g[class='node node--leaf'] g line"));
            Assert.IsTrue(elements.Count==0);
        }

        public void AssertResponseTitle(string title)
        {
            try
            {
                FocusWindow();
                Assert.IsTrue(Driver.FindElements(By.CssSelector("title")).Any(x => x.Text == title));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                Assert.Fail(e.Message);
            }
            
        }
        public void AssertResponseTitleOnUpdate(string title)
        {
            try
            {
                FocusWindow();
                IList<IWebElement> elements =
                    Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
                Waiter.Until(d => elements[0]);
                string titleOnDialog = elements[0].Text;
                Assert.IsTrue(titleOnDialog.Contains(title));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                Assert.Fail(e.Message);
            }

        }
        public void AssertPlanTitle(string title)
        {
            FocusWindow();
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
            string titleOnDialog = elements[0].Text;
            Assert.IsTrue(titleOnDialog.Contains(title));
        }

        public void AssertEvaluationTitleOnUpdate(string title)
        {
            FocusWindow();
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='element_node editable']"));
            Waiter.Until(d => elements[0]);
            string titleOnDialog = elements[0].Text;
            Assert.IsTrue(titleOnDialog.Contains(title));
        }
        public void AssertTestTitle(string title)
        {
            FocusWindow();
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
            Thread.Sleep(500);
            Assert.IsTrue(elements[2].Displayed);
            string titleOnDialog = elements[2].Text;
            Assert.IsTrue(titleOnDialog.Contains(title));
        }

        public void AssertRatingValue()
        {
            FocusWindow();
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
            Thread.Sleep(500);
            Assert.IsTrue(elements[2].Displayed);
            string titleOnDialog = elements[2].Text;
            Assert.IsTrue(titleOnDialog.Contains("GE:"));
        }
        public void AssertRemediationTitle()
        {
            FocusWindow();
            IList<IWebElement> elements =
                Driver.FindElements(By.CssSelector("g[class='node node--leaf']"));
            Thread.Sleep(500);
            Assert.IsTrue(elements[2].Displayed);
            string titleOnDialog = elements[2].Text;
            Assert.IsTrue(titleOnDialog.Contains("Remediation"));
        }
    }
}
