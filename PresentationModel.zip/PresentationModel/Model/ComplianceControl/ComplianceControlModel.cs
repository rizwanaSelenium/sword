﻿namespace PresentationModel.Model.ComplianceControl
{
    public class ComplianceControlModel
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Created { get; set; }
        public string SourceUpdated { get; set; }
        public string Due { get; set; }
        public string ApprovalDate { get; set; }
        public string LastUpdated { get; set; }
        public string Archived { get; set; }
        public string Description { get; set; }
        public string MaxText1 { get; set; }
        public string MaxText2 { get; set; }
        public string MaxText3 { get; set; }
        public string MaxText4 { get; set; }
        public string Category { get; set; }
        public string Owner { get; set; }
        public string Approver { get; set; }
        public string ComplianceStatus { get; set; }
        public string ApprovalStatus { get; set; }
        public string ApplicableAreas { get; set; }
        public string DesignEffectiveness { get; set; }
        public string OperatingEffectiveness { get; set; }
        public string Tree1 { get; set; }
        public string Tree2 { get; set; }
        public string MultiSelect1 { get; set; }
        public string MultiSelect2 { get; set; }
        public string MultiSelect3 { get; set; }
    }
}
