﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;

namespace PresentationModel.Model.ComplianceControl
{
    public class ComplianceControlDialog : ComplianceComponent
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private AngularSingleLineTextField _id;
        private AngularMultiLineTextField _title;
        private AngularDatePickerField _created;
        private AngularDatePickerField _due;
        private AngularDatePickerField _lastUpdated;
        private AngularDatePickerField _sourceUpdated;
        private AngularDatePickerField _approvalDate;
        private AngularMultiLineTextField _description;
        private AngularResourcePickerField _owner;
        private AngularCheckboxField _archived;
        private AngularMultiLineTextField _maxText1;
        private AngularMultiLineTextField _maxText2;
        private AngularMultiLineTextField _maxText3;
        private AngularMultiLineTextField _maxText4;
        private AngularDropdownListField _category;
        private AngularResourcePickerField _approver;
        private AngularDropdownListField _complianceStatus;
        private AngularDropdownListField _approvalStatus;
        private AngularMultiSelectTreeTableField _applicableAreas;
        private AngularDropdownListField _designEffectiveness;
        private AngularDropdownListField _operatingEffectiveness;
        private AngularMultiSelectTreeField _tree1;
        private AngularMultiSelectTreeField _tree2;
        private AngularMultiSelectDropdownField _multiSelect1;
        private AngularMultiSelectDropdownField _multiSelect2;
        private AngularMultiSelectDropdownField _multiSelect3;
        private AngularSingleLineTextField _assessmentTitle;
        private AngularDropdownListField _recurrence;
        private AngularDatePickerField _nextPublishDate;
        private AngularSingleLineTextField _assessmentSubject;
        private AngularMultiLineTextField _assessmentBody;
        private AngularSurveyQuestionCreator _assessmentQuestion;

        public ComplianceControlDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Control")
        {
            _driver = driver;
            _waiter = waiter;
        }

        public AngularSingleLineTextField Id
        {
            get { return _id ?? (_id = new AngularSingleLineTextField(_driver, _waiter, "field_865")); }
        }

        public AngularMultiLineTextField Title
        {
            get { return _title ?? (_title = new AngularMultiLineTextField(_driver, _waiter, "field_866")); }

        }

        public AngularDatePickerField Created
        {
            get { return _created ?? (_created = new AngularDatePickerField(_driver, _waiter, "field_867")); }
        }

        public AngularDatePickerField SourceUpdated
        {
            get { return _sourceUpdated ?? (_sourceUpdated = new AngularDatePickerField(_driver, _waiter, "field_868")); }
        }

        public AngularDatePickerField Due
        {
            get { return _due ?? (_due = new AngularDatePickerField(_driver, _waiter, "field_869")); }
        }

        public AngularDatePickerField ApprovalDate
        {
            get { return _approvalDate ?? (_approvalDate = new AngularDatePickerField(_driver, _waiter, "field_870")); }
        }

        public AngularDatePickerField LastUpdated
        {
            get { return _lastUpdated ?? (_lastUpdated = new AngularDatePickerField(_driver, _waiter, "field_871")); }
        }

        public AngularCheckboxField Archived
        {
            get { return _archived ?? (_archived = new AngularCheckboxField(_driver, _waiter, "field_872")); }
        }

        public AngularMultiLineTextField Description
        {
            get { return _description ?? (_description = new AngularMultiLineTextField(_driver, _waiter, "field_873")); }
        }

        public AngularMultiLineTextField MaxText1
        {
            get { return _maxText1 ?? (_maxText1 = new AngularMultiLineTextField(_driver, _waiter, "field_874")); }
        }

        public AngularMultiLineTextField MaxText2
        {
            get { return _maxText2 ?? (_maxText2 = new AngularMultiLineTextField(_driver, _waiter, "field_875")); }
        }

        public AngularMultiLineTextField MaxText3
        {
            get { return _maxText3 ?? (_maxText3 = new AngularMultiLineTextField(_driver, _waiter, "field_876")); }
        }

        public AngularMultiLineTextField MaxText4
        {
            get { return _maxText4 ?? (_maxText4 = new AngularMultiLineTextField(_driver, _waiter, "field_877")); }
        }

        public AngularDropdownListField Category
        {
            get { return _category ?? (_category = new AngularDropdownListField(_driver, _waiter, "field_878")); }
        }

        public AngularResourcePickerField Owner
        {
            get { return _owner ?? (_owner = new AngularResourcePickerField(_driver, _waiter, "field_879")); }
        }

        public AngularResourcePickerField Approver
        {
            get { return _approver ?? (_approver = new AngularResourcePickerField(_driver, _waiter, "field_880")); }
        }

        public AngularDropdownListField ComplianceStatus
        {
            get { return _complianceStatus ?? (_complianceStatus = new AngularDropdownListField(_driver, _waiter, "field_881")); }
        }

        public AngularDropdownListField ApprovalStatus
        {
            get { return _approvalStatus ?? (_approvalStatus = new AngularDropdownListField(_driver, _waiter, "field_882")); }
        }

        public AngularMultiSelectTreeTableField ApplicableAreas
        {
            get { return _applicableAreas ?? (_applicableAreas = new AngularMultiSelectTreeTableField(_driver, _waiter, "field_883_object")); }
        }

        public AngularDropdownListField DesignEffectiveness
        {
            get { return _designEffectiveness ?? (_designEffectiveness = new AngularDropdownListField(_driver, _waiter, "field_884")); }
        }

        public AngularDropdownListField OperatingEffectiveness
        {
            get { return _operatingEffectiveness ?? (_operatingEffectiveness = new AngularDropdownListField(_driver, _waiter, "field_889")); }
        }

        public AngularMultiSelectTreeField Tree1
        {
            get { return _tree1 ?? (_tree1 = new AngularMultiSelectTreeField(_driver, _waiter, "field_890")); }
        }

        public AngularMultiSelectTreeField Tree2
        {
            get { return _tree2 ?? (_tree2 = new AngularMultiSelectTreeField(_driver, _waiter, "field_891")); }
        }

        public AngularMultiSelectDropdownField MultiSelect1
        {
            get { return _multiSelect1 ?? (_multiSelect1 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_892")); }
        }

        public AngularMultiSelectDropdownField MultiSelect2
        {
            get { return _multiSelect2 ?? (_multiSelect2 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_893")); }
        }

        public AngularMultiSelectDropdownField MultiSelect3
        {
            get { return _multiSelect3 ?? (_multiSelect3 = new AngularMultiSelectDropdownField(_driver, _waiter, "field_894")); }
        }

        public AngularSingleLineTextField AssessmentTitle
        {
            get { return _assessmentTitle ?? (_assessmentTitle = new AngularSingleLineTextField(_driver, _waiter, "field_857")); }
        }

        public AngularDropdownListField Recurrence
        {
            get { return _recurrence ?? (_recurrence = new AngularDropdownListField(_driver, _waiter, "field_854")); }
        }

        public AngularDatePickerField NextPublishDate
        {
            get { return _nextPublishDate ?? (_nextPublishDate = new AngularDatePickerField(_driver, _waiter, "field_855")); }
        }

        public AngularSingleLineTextField AssessmentSubject
        {
            get { return _assessmentSubject ?? (_assessmentSubject = new AngularSingleLineTextField(_driver, _waiter, "field_858")); }
        }

        public AngularMultiLineTextField AssessmentBody
        {
            get { return _assessmentBody ?? (_assessmentBody = new AngularMultiLineTextField(_driver, _waiter, "field_859")); }
        }

        public AngularSurveyQuestionCreator AssessmentQuestion
        {
            get { return _assessmentQuestion ?? (_assessmentQuestion = new AngularSurveyQuestionCreator(_driver, _waiter, "field_860")); }
        }

        public new void ClearParameters()
        {
            _id = null;
            _title = null;
            _created = null;
            _sourceUpdated = null;
            _due = null;
            _approvalDate = null;
            _lastUpdated = null;
            _archived = null;
            _description = null;
            _maxText1 = null;
            _maxText2 = null;
            _maxText3 = null;
            _maxText4 = null;
            _category = null;
            _owner = null;
            _approver = null;
            _complianceStatus = null;
            _approvalStatus = null;
            _applicableAreas = null;
            _designEffectiveness = null;
            _operatingEffectiveness = null;
            _tree1 = null;
            _tree2 = null;
            _multiSelect1 = null;
            _multiSelect2 = null;
            _multiSelect3 = null;
        }

        public void AssertLabelsEqualsToCustomConfig(string label, string customLabel)
        {
            switch (label)
            {
                case "Id":
                    Id.AssertLabelEquals(customLabel);
                    break;
                case "Title":
                    Title.AssertLabelEquals(customLabel);
                    break;
                case "Created":
                    Created.AssertLabelEquals(customLabel);
                    break;
                case "Source Updated":
                    SourceUpdated.AssertLabelEquals(customLabel);
                    break;
                case "Due":
                    Due.AssertLabelEquals(customLabel);
                    break;
                case "Approval Date":
                    ApprovalDate.AssertLabelEquals(customLabel);
                    break;
                case "Last Updated":
                    LastUpdated.AssertLabelEquals(customLabel);
                    break;
                case "Description":
                    Description.AssertLabelEquals(customLabel);
                    break;
                case "Max Text 1":
                    MaxText1.AssertLabelEquals(customLabel);
                    break;
                case "Max Text 2":
                    MaxText2.AssertLabelEquals(customLabel);
                    break;
                case "Max Text 3":
                    MaxText3.AssertLabelEquals(customLabel);
                    break;
                case "Max Text 4":
                    MaxText4.AssertLabelEquals(customLabel);
                    break;
                case "Category":
                    Category.AssertLabelEquals(customLabel);
                    break;
                case "Owner":
                    Owner.AssertLabelEquals(customLabel);
                    break;
                case "Approver":
                    Approver.AssertLabelEquals(customLabel);
                    break;
                case "Compliance Status":
                    ComplianceStatus.AssertLabelEquals(customLabel);
                    break;
                case "Approval Status":
                    ApprovalStatus.AssertLabelEquals(customLabel);
                    break;
                case "Design Effectiveness":
                    DesignEffectiveness.AssertLabelEquals(customLabel);
                    break;
                case "Operating Effectiveness":
                    OperatingEffectiveness.AssertLabelEquals(customLabel);
                    break;
                default:
                    Assert.Fail();
                    break;
            }
        }
    }
}
