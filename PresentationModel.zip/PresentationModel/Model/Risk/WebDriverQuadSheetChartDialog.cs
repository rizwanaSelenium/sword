﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
   public class WebDriverQuadSheetChartDialog : WebDriverArmPage   
    {
        //Old Window but still exists in ARM

       public WebDriverChartControl QuadSheetChartControl;

        public WebDriverQuadSheetChartDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "QuadSheetChart.aspx")
        {
            QuadSheetChartControl = new WebDriverChartControl(driver, waiter, "div#QuadSheetChartControl_bodyRightTop", true); 
          
        }
    }

  }

