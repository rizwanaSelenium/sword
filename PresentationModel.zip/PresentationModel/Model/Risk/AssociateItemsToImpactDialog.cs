﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
    public class AssociateItemsToImpactDialog : WebDriverArmPage
    {
        // Old window but still used in ARM

        private TreeGridControl _tree;
        public TreeGridControl Tree
        {
            get { return _tree ?? (_tree = new TreeGridControl(Driver, Waiter, "AssociateItemsView")); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get {  return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "AssociateItemsView_Save_btn")); }
        }

        private WebDriverTableControl _grid;
        public WebDriverTableControl Grid
        {
            get {  return _grid ?? (_grid = new WebDriverTableControl(Driver, Waiter, "AssociateItemsView_LinkedTable")); }
        }

        private WebDriverDropDown _portfolioDropDown;
        public WebDriverDropDown PortfolioDropDown
        {
            get { return _portfolioDropDown ?? (_portfolioDropDown = new WebDriverDropDown(Driver, Waiter, "div.armcontrol#AssociateItemsView_PortfolioTreeTypes select", true)); }
        }

        public AssociateItemsToImpactDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "AssociateItems.aspx")
        {
        }

        public void SelectNode(int itemId)
        {
            Tree.SelectNode(itemId);
        }

        public void DeselectNode(int itemId)
        {
            Tree.DeselectNode(itemId);
        }

        public void Save()
        {
            SaveButton.Click();
        }

       
    }
}
