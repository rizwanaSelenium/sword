﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
    public class RiskApprovalModal
    {
        //Old window but still in ARM 

        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        private WebDriverTextAreaControl _reasonText;
        public WebDriverTextAreaControl ReasonText
        {
            get { return _reasonText ?? (_reasonText = new WebDriverTextAreaControl(_driver, _waiter, "textarea#AV_Grids_RiskList_ApproveRisks_ApprovalComment_tb", true)); }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(_driver, _waiter, "AV_Grids_RiskList_ApproveRisks_OK_btn")); }
        }

        public RiskApprovalModal(IWebDriver driver, WebDriverWait waiter)
        {
            _driver = driver;
            _waiter = waiter;
        }

        public void Ok()
        {
            OkButton.Click();
            _waiter.Until(d => d.IsAjaxRequestInProgress());
        }
    }
}
