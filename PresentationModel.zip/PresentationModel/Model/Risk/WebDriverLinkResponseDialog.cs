﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
    public class WebDriverLinkResponseDialog : WebDriverArmPage
    {
        //Old Window but still in ARM 

        public WebDriverButton LinkButton { get; set; }
        public WebDriverButton CloseButton { get; private set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverDropDown FilterDropDown { get; set; }
        

        public WebDriverLinkResponseDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "LinkResponse.aspx")
        {
            LinkButton = new WebDriverButton(Driver, Waiter, "LRV_Link_btn");
            CloseButton = new WebDriverButton(Driver, Waiter, "LRV_Close_btn");
            HelpButton = new WebDriverButton(Driver, Waiter, "LRV_Help_btn");
            FilterDropDown = new WebDriverDropDown(Driver, Waiter, "select#LRV_Filter_cb", true);
            
        }
      
        public void LinkResponseWithTitle(string responseTitleToSelect)
        {
            var responseListTable = Driver.FindElement(By.CssSelector("table#LRV_ResponseTable_content"));
            var responses = responseListTable.FindElements(By.CssSelector("tr.grid-row"));
            bool responseFound = false;
            foreach (var response in responses)
            {            
                if (response.FindElement(By.CssSelector("td[id$='_Name']")).Text.Equals(responseTitleToSelect))
                {
                    responseFound = true;
                    response.FindElement(By.CssSelector("input.grid-checkbox")).Click();
                    break;
                }                
            }
            if (!responseFound)
            {
                Assert.Fail("response: " + responseTitleToSelect + " Not Found");
            }
            else
            {
                LinkButton.Click();
            }
        }

        public new void AcceptAlert()
        {
            RespondToUiPrompt("Yes");
        }
    }
}
