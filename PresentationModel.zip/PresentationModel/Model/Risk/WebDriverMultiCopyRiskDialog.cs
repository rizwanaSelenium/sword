﻿using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
   public class WebDriverMultiCopyRiskDialog : WebDriverArmPage
    {
        //Old Window but still exists in ARM

       public WebDriverMultiCopyRiskDialog(IWebDriver driver, WebDriverWait waiter)
           : base(driver, waiter, "MultiCopyRisk.aspx")
        {
        }

        private WebDriverButton _individualCopyButton;
        public WebDriverButton IndividualCopyButton
        {
            get { return _individualCopyButton ?? (_individualCopyButton = new WebDriverButton(Driver, Waiter, "RootView_CopyIndividual_btn")); }
        }
        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn")); }
        }
        public void CheckFolderToCopy(string folderName)
        {
         
            bool folderFound = false;
            IWebElement element = Driver.FindElement(By.CssSelector("div#RootView_ActivityTree div#treenode_1_div"));
            var labelElement = element.FindElements(By.CssSelector("span.tree-label"));

            foreach (var item in labelElement)
            {
               if(item.Text.Contains(folderName))
               {
                   folderFound = true;
                    string id = item.GetAttribute("data-itemid");
                                                
                    string css = "input#treenode_" + id + "_cb";
                   WebDriverTickBoxControl checkbox=new WebDriverTickBoxControl(Driver,Waiter,css,true,false);
                   checkbox.Check();
                  
                }
                    
            }
            if (!folderFound)
            {
                Assert.Fail("Could not find" + folderName);
            }

        }

        public void OkCopyWarningMessage()
        {
            FocusWindow();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var prompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            prompt.FindElement(By.CssSelector("button[title='Yes']")).Click();
            Thread.Sleep(20000);
           
        }

        public void SelectRiskFromRisksTable(string riskToCheck)
        {
            var risks = Driver.FindElements(By.CssSelector("tr.grid-row"));
            foreach (var risk in risks)
            {
                if (risk.FindElement(By.CssSelector("td[id$='_Name']")).Text.Contains(riskToCheck))
                {
                   
                    risk.FindElement(By.CssSelector("td[id$='_Name']")).Click();
                }
              
            }
         
        }
    }
}
