﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
    public class WebdriverRiskSecurityDialog : WebDriverArmControl
    {
        private WebDriverButton _okButton;

        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "btnOK")); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "btnCancel")); }
        }

        private WebDriverTickBoxControl _groupSecurityEnabledCheckBox;
        public WebDriverTickBoxControl GroupSecurityEnabledCheckBox
        {
            get
            {
                _groupSecurityEnabledCheckBox = new WebDriverTickBoxControl(Driver, Waiter, "input#chkSecurityEnabled", true,false);
                return _groupSecurityEnabledCheckBox;
            }
        }


        private WebDriverTickBoxControl _additionalSecurityAttributesCheckBox;
        public WebDriverTickBoxControl AdditionalSecurityAttributesCheckBox
        {
            get
            {
                _additionalSecurityAttributesCheckBox = new WebDriverTickBoxControl(Driver,Waiter, "input#chkSecurityAttrsEnabled", true,false);
                return _additionalSecurityAttributesCheckBox;
            }
        }


        private WebDriverDropDown _doesNotNeedAttributes;
        public WebDriverDropDown DoesNotNeedAttributes
        {
            get
            {
                _doesNotNeedAttributes = new WebDriverDropDown(Driver, Waiter, "select#availableAttrs", true,false);
                return _doesNotNeedAttributes;
            }
        }

        private WebDriverDropDown _needAttributes;
        public WebDriverDropDown NeedAttributes
        {
            get
            {
                _needAttributes = new WebDriverDropDown(Driver, Waiter, "select#currentAttrs", true,false);
                return _needAttributes;
            }
        }

        private WebDriverButton _addButton;
        public WebDriverButton AddButton
        {
            get { return _addButton ?? (_addButton = new WebDriverButton(Driver, Waiter, "btnAdd")); }
        }

        private WebDriverButton _removeButton;
        public WebDriverButton RemoveButton
        {
            get { return _removeButton ?? (_removeButton = new WebDriverButton(Driver, Waiter, "btnRemove")); }
        }

        public WebdriverRiskSecurityDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter,null)
        {

        }

      
    }
}
