﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Risk
{
    public class WebDriverUnLinkResponseDialog : WebDriverArmPage
    {
        //Old window but still exists

        public WebDriverButton UnLinkButton { get; set; }
        public WebDriverButton CancelButton { get; private set; }
        public WebDriverButton HelpButton { get; set; }
       


        public WebDriverUnLinkResponseDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "UnlinkResponseFromPlan.aspx")
        {
            UnLinkButton = new WebDriverButton(Driver, Waiter, "ULRPV_Unlink_btn");
            CancelButton = new WebDriverButton(Driver, Waiter, "ULRPV_Cancel_btn");
            HelpButton = new WebDriverButton(Driver, Waiter, "ULRPV_Help_btn");
            
            
        }
      
        public void UnLinkResponseWithTitle(string responseTitleToSelect)
        {
            var responseListTable = Driver.FindElement(By.CssSelector("table#ULRPV_ResponsesTable_content"));
            var responses = responseListTable.FindElements(By.CssSelector("tr.grid-row"));
            bool responseFound = false;
            foreach (var response in responses)
            {            
                if (response.FindElement(By.CssSelector("td[id$='_Name']")).Text.Equals(responseTitleToSelect))
                {
                    responseFound = true;
                    response.FindElement(By.CssSelector("input.grid-checkbox")).Click();
                    break;
                }                
            }
            if (!responseFound)
            {
                Assert.Fail("response: " + responseTitleToSelect + " Not Found");
            }
            else
            {
               UnLinkButton.Click(); 
            }
        }

        public new void AcceptAlert()
        {
            RespondToUiPrompt("Yes");
        }
    }
}
