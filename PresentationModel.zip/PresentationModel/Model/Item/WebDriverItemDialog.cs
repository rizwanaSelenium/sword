﻿using System;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Item
{
    /// <summary>
    /// Base class for all the item dialogs which contains all the fields and button shared by the items
    /// </summary>
    public abstract class WebDriverItemDialog : WebDriverArmControl, IDisposable
    {
        private WebDriverTextField _id;
        public new WebDriverTextField Id
        {
            get
            {
                return _id ?? (_id = new WebDriverTextField(Driver, Waiter, "input[data-field='displayId']", true));
            }
        }

        private AngularSingleLineTextField _name;
        public AngularSingleLineTextField Name
        {
            get
            {
                return _name ?? (_name = new AngularSingleLineTextField(Driver, Waiter, "Name"));
            }
        }

        private MvcResourcePicker _ownerManager;
        public MvcResourcePicker OwnerManager
        {
            get
            {
                return _ownerManager ?? (_ownerManager = new MvcResourcePicker(Driver, Waiter, "Owner"));
            }
        }

        private WdMvcDropDown _configurationDropDown;
        public WdMvcDropDown ConfigurationDropDown
        {
            get
            {
                return _configurationDropDown ?? (_configurationDropDown = new WdMvcDropDown(Driver, Waiter, "", "ConfigSetId"));
            }

        }

        private WdMvcDropDown _scoringSchemeGroupDropDown;
        public WdMvcDropDown ScoringSchemeGroupDropDown
        {
            get
            {
                return _scoringSchemeGroupDropDown ?? (_scoringSchemeGroupDropDown = new WdMvcDropDown(Driver, Waiter, "", "ScoringSchemeGroupId"));
            }

        }

        private WdMvcDropDown _classificationsDropDown;
        public WdMvcDropDown ClassificationsDropDown
        {
            get
            {
                return _classificationsDropDown ?? (_classificationsDropDown = new WdMvcDropDown(Driver, Waiter, "", "ClassificationsId"));
            }
        }
        
        private WdMvcDropDown _caveatDropDown;
        public WdMvcDropDown CaveatDropDown
        {
            get
            {
                return _caveatDropDown ?? (_caveatDropDown = new WdMvcDropDown(Driver, Waiter, "folderdetails", "CaveatId"));
            }
        }

        private WebDriverTextAreaControl _description;
        public WebDriverTextAreaControl Description
        {
            get
            {
                return _description ?? (_description = new WebDriverTextAreaControl(Driver, Waiter, "textarea#Description", true));
            }
        }

        private WebDriverTextAreaControl _comments;
        public WebDriverTextAreaControl Comments
        {
            get
            {
                return _comments ?? (_comments = new WebDriverTextAreaControl(Driver, Waiter, "textarea#Comments", true));
            }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get
            {
                return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='new']", true));
            }
        }
        private WebDriverButton _attributesButton;
        public WebDriverButton AttributesButton
        {
            get
            {
                return _attributesButton ?? (_attributesButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='attributes']", true));
            }
        }

        private WebDriverDropDown _currencyDropDown;
        public WebDriverDropDown CurrencyDropDown
        {

            get
            {
                return _currencyDropDown ?? (_currencyDropDown = new WebDriverDropDown(Driver, Waiter, "select#itemCurrency", true));
            }
        }

        private WebDriverButton _editButton;
        public WebDriverButton EditButton
        {
            get
            {
                return _editButton ?? (_editButton = new WebDriverButton(Driver, Waiter, "btnItemCurrencyEdit"));
            }
        }

        private WebDriverTickBoxControl _applyConfigToChildrenCheckBox;
        public WebDriverTickBoxControl ApplyConfigToChildrenCheckBox
        {
            get
            {
                return _applyConfigToChildrenCheckBox ?? (_applyConfigToChildrenCheckBox = new WebDriverTickBoxControl(Driver, Waiter, "input#ApplyConfigurationToChildren", true, false));
            }
        }

        private WebDriverTickBoxControl _applyScoringToChildrenCheckBox;
        public WebDriverTickBoxControl ApplyScoringToChildrenCheckBox
        {
            get
            {
                return _applyScoringToChildrenCheckBox ?? (_applyScoringToChildrenCheckBox = new WebDriverTickBoxControl(Driver, Waiter, "input#ApplyScoringSchemeGroupToChildren", true, false));
            }
        }

        private CollapsiblePanelControl _dates;
        public CollapsiblePanelControl Dates
        {
            get
            {
                return _dates ?? (_dates = new CollapsiblePanelControl(Driver, Waiter, "folderdates"));
            }
        }

        private CollapsiblePanelControl _threePointEstimates;
        public CollapsiblePanelControl ThreePointEstimates
        {
            get
            {
                return _threePointEstimates ?? (_threePointEstimates = new CollapsiblePanelControl(Driver, Waiter, "threepointestimates"));
            }
        }

        private CollapsiblePanelControl _finance;
        public CollapsiblePanelControl Finance
        {
            get
            {
                return _finance ?? (_finance = new CollapsiblePanelControl(Driver, Waiter, "assetfinance"));
            }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='saveAndClose']", true)); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='save']", true)); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='cancel']", true)); }    
        }

        private WebDriverButton _linksButton;
        public WebDriverButton LinksButton
        {
            get { return _linksButton ?? (_linksButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='links']", true)); }    
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, ".itemproperties button[data-command='help']", true)); }
        }

        protected WebDriverItemDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "div.itemproperties")
        {
            ExpandAllSections();
        }

        private void ExpandAllSections()
        {
            var panelHeaders = Driver.FindElements(By.CssSelector("a.collapsible-panel-link.collapsed"));
            foreach (var panel in panelHeaders)
            {
                var panelHeadersCount = Driver.FindElements(By.CssSelector("a.collapsible-panel-link.collapsed")).Count;
                panel.Click();
                try
                {
                    Waiter.Until( d => Driver.FindElements(By.CssSelector("a.collapsible-panel-link.collapsed")).Count < panelHeadersCount);
                }
                catch (TimeoutException tex)
                {
                    throw new WebDriverTimeoutException("Trying to expand Item dialog sections failed. 'ExpandAllSections()'. " + tex);
                }
            }
        }

        private void CollapseAllSections()
        {
            var panelHeaders = Driver.FindElements(By.CssSelector("a.collapsible-panel-link span.collapse-icon"));
            foreach (var panel in panelHeaders)
            {
                var panelHeadersCount = Driver.FindElements(By.CssSelector("a.collapsible-panel-link span.collapse-icon"))
                        .Where(x => x.Displayed).ToList().Count;
                panel.Click();
                try
                {
                    Waiter.Until(d => Driver.FindElements(By.CssSelector("a.collapsible-panel-link span.collapse-icon"))
                        .Where(x => x.Displayed).ToList().Count < panelHeadersCount);
                }
                catch (TimeoutException tex)
                {
                    throw new WebDriverTimeoutException("Trying to collapse Item dialog sections failed. 'CollapseAllSections()'. " + tex);
                }
            }
        }

        public void Save()
        {
            SaveButton.Click();
            Waiter.Until(i => !Id.GetValue().Equals("0"));
            Waiter.Until(s => !SaveButton.IsEnabled());
            Waiter.Until(o => OkButton.IsEnabled());
        }

        public void FocusWindow()
        {
            string thisWindowHandle = Driver.CurrentWindowHandle;
            if (Driver.WindowHandles.Contains(thisWindowHandle))
                Driver.SwitchTo().Window(thisWindowHandle);
        }

        public void RespondToModalDialog(string buttonText)
        {
            FocusWindow();
            Waiter.Until(d => d.FindElement(By.CssSelector("div.modal-content")));
            var prompt = Driver.FindElement(By.CssSelector("div.modal-content"));
            prompt.FindElement(By.CssSelector("div.modal-footer"));
            var buttons=   prompt.FindElements(By.CssSelector("button.btn-arm"));
            foreach (var button in buttons)
            {
                if (button.Text == buttonText)
                {
                    button.Click();
                   break;
                }
            }
            var originalTimeout = Waiter.Timeout;
            Waiter.Timeout = TimeSpan.FromSeconds(120);
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            Waiter.Timeout = originalTimeout;
        }

        public void Close()
        {
            bool cancelButtonDisplayed = true;
            for (var i = 0; i < 5; i++)
            {
                Thread.Sleep(500);
                Cancel();
                var cancelButtons = Driver.FindElements(By.CssSelector(".itemproperties button[data-command='cancel']")).Where(x => x.Displayed).ToList();
                if (cancelButtons.Count == 0)
                {
                    cancelButtonDisplayed = false;
                    break;
                }
                Console.WriteLine("Cancel Item Dialog Button Still Visible on " + (i + 1) + " attempt");

            }
            if (cancelButtonDisplayed)
            {
                Assert.Fail("Was waiting for the Cancel button to no longer be visible to indicate the Item Dialogue had closed, but the Cancel Button was still visible");
            }
        }

        public void Cancel()
        {
            for (int i = 0; i <= 5; i++)
            {
                Thread.Sleep(1000);
                if (CancelButton.IsEnabled())
                {
                    CancelButton.Click();
                    break;
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Close();
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
