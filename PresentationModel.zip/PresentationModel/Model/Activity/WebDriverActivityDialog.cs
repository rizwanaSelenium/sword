﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Help;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Activity
{
    public class WebDriverActivityDialog : WebDriverItemDialog
    {
        private AngularSingleLineTextField _wbsItem;
        public AngularSingleLineTextField WbsItem
        {
            get { return _wbsItem ?? (_wbsItem = new AngularSingleLineTextField(Driver, Waiter, "WBSItem")); }
        }

        private WdMvcDropDown _nodeStatus;
        public WdMvcDropDown NodeStatus
        {
            get { return _nodeStatus ?? (_nodeStatus = new WdMvcDropDown(Driver, Waiter, "folderdetails", "NodeStatusId")); }
        }

        private WebDriverTickBoxControl _importanceIsMilestone;
        public WebDriverTickBoxControl ImportanceIsMilestone
        {
            get
            {
                return _importanceIsMilestone ??
                       (_importanceIsMilestone = new WebDriverTickBoxControl(Driver, Waiter, "fieldset#folderdetails div.formrow div.formfield input[id='IsMilestone'][type='checkbox']", true));
            }
        }

        private WebDriverTickBoxControl _importanceCriticalPath;
        public WebDriverTickBoxControl ImportanceCriticalPath
        {
            get
            {
                return _importanceCriticalPath ??
                       (_importanceCriticalPath = new WebDriverTickBoxControl(Driver, Waiter, "fieldset#folderdetails div.formrow div.formfield input[id='IsMilestone'][type='checkbox']", true));
            }
        }

        private WebDriverTickBoxControl _importanceSummaryTask;
        public WebDriverTickBoxControl ImportanceSummaryTask
        {
            get
            {
                return _importanceSummaryTask ??
                       (_importanceSummaryTask = new WebDriverTickBoxControl(Driver, Waiter, "fieldset#folderdetails div.formrow div.formfield input[id='IsMilestone'][type='checkbox']", true));
            }
        }

        private AngularSingleLineTextField _customProjectTextField;
        public AngularSingleLineTextField CustomProjectTextField
        {
            get
            {
                return _customProjectTextField ??
                       (_customProjectTextField = new AngularSingleLineTextField(Driver, Waiter, "CustomProjectTextField"));
            }
        }

        private CollapsiblePanelControl _detailsExpandControl;
        public CollapsiblePanelControl DetailsExpandControl
        {
            get
            {
                return _detailsExpandControl ??
                       (_detailsExpandControl = new CollapsiblePanelControl(Driver, Waiter, "folderdetails"));
            }
        }

        private CollapsiblePanelControl _datesExpandControl;
        public CollapsiblePanelControl DatesExpandControl
        {
            get
            {
                return _datesExpandControl ??
                       (_datesExpandControl = new CollapsiblePanelControl(Driver, Waiter, "folderdates"));
            }
        }

        private CollapsiblePanelControl _threePointEstimatesExpandControl;
        public CollapsiblePanelControl ThreePointEstimatesExpandControl
        {
            get
            {
                return _threePointEstimatesExpandControl ??
                       (_threePointEstimatesExpandControl = new CollapsiblePanelControl(Driver, Waiter, "folder3points"));
            }
        }

        private CollapsiblePanelControl _relatedRisksExpandControl;
        public CollapsiblePanelControl RelatedRisksExpandControl
        {
            get
            {
                return _relatedRisksExpandControl ??
                       (_relatedRisksExpandControl = new CollapsiblePanelControl(Driver, Waiter, "relatedrisks"));
            }
        }

        public WebDriverActivityDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            WaitUntilPlanningApplicationIsDisplayed();
            waiter.Until(d => ConfigurationDropDown.GetValue().Length > 0);
        }

       

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();
            
            using (var page = new WebDriverHelpPage(Driver, Waiter, "Activities.htm"))
            {
                page.AssertUrlEndsWith("Activities.htm");
            }
        }

        private void WaitUntilPlanningApplicationIsDisplayed()
        {
            bool planningApplicationDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var planningApplications = Driver.FindElements(By.CssSelector("input#PlanningApplicationName")).Where(x => x.Displayed).ToList();
                if (planningApplications.Count > 0)
                {
                    planningApplicationDisplayed = true;
                    break;
                }
            }

            if (!planningApplicationDisplayed)
            {
                Assert.Fail("Was waiting for the Activity Properties Dialogue Planning Application Field to be Displayed, but it was not displayed");
            }
        }
    }
}
