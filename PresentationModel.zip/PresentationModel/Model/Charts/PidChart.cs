﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class PidChart : WebDriverArmPage
    {
        private readonly string _inherentPointColor = "#787878";
        private readonly string _inherentPointBoarderColor = "#000000";
        private readonly string _currentPointColor = "#000000";
        private readonly string _currentPointBoarderColor = "#FFFFFF";
        private readonly string _targetPointColor = "#FFFFFF";
        private readonly string _targetPointBoarderColor = "#000000";

        private WebDriverButton _okModalButton;
        public WebDriverButton OkModalButton { get { return _okModalButton ?? (_okModalButton = new WebDriverButton(Driver, Waiter, "modalOk"));} }

        private WebDriverButton _closeModalButton;
        public WebDriverButton CloseModalButton { get { return _closeModalButton ?? (_closeModalButton = new WebDriverButton(Driver, Waiter, "modalClose")); } }

        private WebDriverButton _helpModalButton;
        public WebDriverButton HelpModalButton { get { return _helpModalButton ?? (_helpModalButton = new WebDriverButton(Driver, Waiter, "modalHelp")); } }

        private WebDriverButton _modifyButton;
        public WebDriverButton ModifyButton { get { return _modifyButton ?? (_modifyButton = new WebDriverButton(Driver, Waiter, "Modify")); } }

        private WebDriverButton _settingsButton;
        public WebDriverButton SettingsButton { get { return _settingsButton ?? (_settingsButton = new WebDriverButton(Driver, Waiter, "Settings")); } }

        private WebDriverButton _exportButton;
        public WebDriverButton ExportButton { get { return _exportButton ?? (_exportButton = new WebDriverButton(Driver, Waiter, "Export")); } }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton { get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "Close")); } }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton { get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "Help")); } }

        private WebDriverButton _settingsModalResetButton;
        public WebDriverButton SettingsModalResetButton { get { return _settingsModalResetButton ?? (_settingsModalResetButton = new WebDriverButton(Driver, Waiter, "modalSettingsReset")); } }

        private WebDriverButton _settingsModalCloseButton;
        public WebDriverButton SettingsModalCloseButton { get { return _settingsModalCloseButton ?? (_settingsModalCloseButton = new WebDriverButton(Driver, Waiter, "modalSettingsClose")); } }

        private IList<IWebElement> _assessmentTypes;
        public IList<IWebElement> AssessmentTypes
        {
            get
            {
                
                return _assessmentTypes ??
                       (_assessmentTypes = Driver.FindElement(By.CssSelector("div[id='assessmentTypes']")).FindElements(By.CssSelector("div[id*='show']")));
            }
        }

        private IWebElement _divPlotModes;
        public IWebElement DivPlotModes
        {
            get
            {
                return _divPlotModes ??
                       (_divPlotModes = Driver.FindElement(By.CssSelector("div[id='divPlotModes']")));

            }
        }

        private IList<IWebElement> _plotModes;
        public IList<IWebElement> PlotModes
        {
            get
            {
                return _plotModes ??
                       (_plotModes = Driver.FindElements(By.CssSelector("div[class='radio radio-success paddingleft']")));

            }
        }

        private IList<IWebElement> _plotModesCheckboxes;
        public IList<IWebElement> PlotModesCheckboxes
        {
            get
            {
                return _plotModesCheckboxes ??
                       (_plotModesCheckboxes = Driver.FindElements(By.CssSelector("input[id*='PlotRadio']")));

            }
        }

        private IList<IWebElement> _drivingImpacts;
        public IList<IWebElement> DrivingImpacts
        {
            get
            {
                return _drivingImpacts ??
                       (_drivingImpacts =
                           Driver.FindElements(By.CssSelector("div[id='drivingImpacts']")));

            }
        }

        private IList<IWebElement> _drivingImpactsCheckBoxes;
        public IList<IWebElement> DrivingImpactsCheckBoxes
        {
            get
            {
                return _drivingImpactsCheckBoxes ??
                       (_drivingImpactsCheckBoxes =
                           Driver.FindElements(By.CssSelector("input[ng-change*='vm.toggleImpacts($index)']")));

            }
        }

        private HighChart _chart;
        public HighChart Chart { get { return _chart ?? (_chart = new HighChart(Driver, Waiter, "container"));} }

        private WebDriverDropDown _riskTypes;
        public WebDriverDropDown RiskTypes {get { return _riskTypes ?? (_riskTypes = new WebDriverDropDown(Driver, Waiter, "select#riskTypes", true));}}
        
        private WebDriverDropDown _scoringSchemes;
        public WebDriverDropDown ScoringSchemes { get { return _scoringSchemes ?? (_scoringSchemes = new WebDriverDropDown(Driver, Waiter, "select#scoringScheme", true)); } }

        private IList<PidChartHeatmapCell> _heatmap;
        public IList<PidChartHeatmapCell> Heatmap
        {
            get
            {
                return _heatmap ??
                       (_heatmap = Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-series rect"))
                               .Select(x => new PidChartHeatmapCell(x)).ToList());
            }
        }

        private IList<PidChartCountLabel> _countLabels;
        public IList<PidChartCountLabel> CountLabels 
        { 
            get 
            { 
                return _countLabels ?? 
                    (_countLabels = Chart.FindElements(By.CssSelector("svg g.highcharts-data-labels g"))
                        .Select(x => new PidChartCountLabel(x)).ToList());
            } 
        }

        private IList<PidChartPoint> _points;
        public IList<PidChartPoint> Points
        {
            get
            {
                return _points ??
                    (_points = Chart.FindElements(By.CssSelector("svg g.highcharts-markers path"))
                        .Select(x => new PidChartPoint(x)).ToList());
            }
        }

        private IWebElement _xAxisLabel;
        public IWebElement XAxisLabel
        {
            get
            {
                return _xAxisLabel ??
                       (_xAxisLabel = Driver.FindElement(By.CssSelector(".highcharts-xaxis-title")));

            }
        }

        private IWebElement _yAxisLabel;
        public IWebElement YAxisLabel
        {
            get
            {
                return _yAxisLabel ??
                       (_yAxisLabel = Driver.FindElement(By.CssSelector(".highcharts-yaxis-title")));

            }
        }

        public PidChart(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "PIDChart")
        {
            WaitUntilPageIsReady();
        }

        public void OkModal()
        {
            OkModalButton.Click();

            Waiter.Until(o => !OkModalButton.IsDisplayed());

            bool modalIsDisplayed = true;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var modalDialogues = Driver.FindElements(By.CssSelector("div.modal-form-arm")).Where(x => x.Displayed).ToList();

                if (modalDialogues.Count == 0)
                {
                    modalIsDisplayed = false;
                    break;
                }
            }

            if (modalIsDisplayed)
            {
                Assert.Fail("Was waiting for the PID Chart Options Modal Dialogue to sop being displayed, but it was still Displayed");
            }

            WaitUntilPageIsReady();
        }

        public void AssertHeatmapCellCount(int expected)
        {
            Assert.AreEqual(expected, Heatmap.Count());
        }

        private PidChartHeatmapCell GetCell(int x, int y)
        {
            var rowCount = Heatmap.Count(c => c.MinX == 0);

            return Heatmap[(x * rowCount) + y];
        }

        public void AssertCellHasColour(int x, int y, string expectedColour)
        {
            var cellFillColour = "";
            var cell = GetCell(x, y);

            //Transform the colour of the cell on the page into a hex string, like #FFFFFF
            if (cell.FillColour.StartsWith("rgb"))
            {
                    var cellColourParts = cell.FillColour
                    .Replace("rgb(", "").Replace(")", "").Replace("#", "").Replace(" ", "")
                    .Split(',');
            
                    cellFillColour = "#" + string.Join("", cellColourParts.Select(c => int.Parse(c).ToString("X2")));
            }
            else if (cell.FillColour.StartsWith("#"))
            {
                cellFillColour = cell.FillColour;
            }
            Assert.AreEqual(expectedColour.ToLower(), cellFillColour.ToLower());
        }

        public void AssertCellHasColor(int cellX, int cellY, string expectedLabelColour)
        {
            var containingCell = GetCell(cellX, cellY);

            var cellContainsLabel = CountLabels.Any(l =>
                l.X >= containingCell.MinX
                && l.X <= containingCell.MaxX
                && l.Y >= containingCell.MinY
                && l.Y <= containingCell.MaxY
                && l.FillColour.ToLower().Equals(expectedLabelColour.ToLower()));

            if(!cellContainsLabel)
                Assert.Fail("Cell does not contain specified color at {0}, {1}. Expected colour {2} ", cellX, cellY, expectedLabelColour);
        }

        public void AssertCellHasCountLabel(int cellX, int cellY, int expectedLabelCount)
        {
            var containingCell = GetCell(cellX, cellY);

            var cellContainsLabel = CountLabels.Any(l =>
                l.X >= containingCell.MinX
                && l.X <= containingCell.MaxX
                && l.Y >= containingCell.MinY
                && l.Y <= containingCell.MaxY
                && l.Count == expectedLabelCount);

            if (!cellContainsLabel)
                Assert.Fail("Cell does not contain specified count label at {0}, {1}. Expected count {2}", cellX, cellY, expectedLabelCount);
        }

        public void AssertCellHasPoint(int cellX, int cellY, string assessmentPoint)
        {
            string expectedFillColour = "";
            string expectedBorderColour = "";
            if (assessmentPoint.ToLower() == "current")
            {
                expectedFillColour = _currentPointColor; expectedBorderColour = _currentPointBoarderColor;
            }
            else if (assessmentPoint.ToLower() == "target")
            {
                expectedFillColour = _targetPointColor; expectedBorderColour = _targetPointBoarderColor;
            }
            else if (assessmentPoint.ToLower() == "inherent")
            {
                expectedFillColour = _inherentPointColor; expectedBorderColour = _inherentPointBoarderColor;
            }

            var containingCell = GetCell(cellX, cellY);
            var cellContainsPoint = Points.Any(p =>
                p.X >= containingCell.MinX
                && p.X <= containingCell.MaxX
                && p.Y >= containingCell.MinY
                && p.Y <= containingCell.MaxY
                && p.FillColour.ToLower().Equals(expectedFillColour.ToLower())
                && p.BorderColour.ToLower().Equals(expectedBorderColour.ToLower()));

            if(!cellContainsPoint)
                Assert.Fail("Cell does not contain {0} point in cell {1}, {2}", assessmentPoint, cellX, cellY);
        }

        public void AssertCellDoesNotHavePoint(int cellX, int cellY, string assessmentPoint)
        {
            string expectedFillColour = "";
            string expectedBorderColour = "";
            if (assessmentPoint.ToLower() == "current")
            {
                expectedFillColour = _currentPointColor; expectedBorderColour = _currentPointBoarderColor;
            }
            else if (assessmentPoint.ToLower() == "target")
            {
                expectedFillColour = _targetPointColor; expectedBorderColour = _targetPointBoarderColor;
            }
            else if (assessmentPoint.ToLower() == "inherent")
            {
                expectedFillColour = _inherentPointColor; expectedBorderColour = _inherentPointBoarderColor;
            }

            var containingCell = GetCell(cellX, cellY);
            var cellContainsPoint = Points.Any(p =>
                p.X >= containingCell.MinX
                && p.X <= containingCell.MaxX
                && p.Y >= containingCell.MinY
                && p.Y <= containingCell.MaxY
                && !p.FillColour.ToLower().Equals(expectedFillColour.ToLower())
                && !p.BorderColour.ToLower().Equals(expectedBorderColour.ToLower()));

            if (!cellContainsPoint)
                Assert.Fail("Cell contains point {0} in cell {1}, {2} ", assessmentPoint, cellX, cellY);
        }

        public void AssertCorrectAssessmentTypesAreShown(bool singleRisk)
        {
            bool inherentDisplayed = false;
            bool currentDisplayed = false;
            bool targetDisplayed = false;

            Waiter.Until(x => AssessmentTypes.Count > 1);

            foreach (var type in AssessmentTypes)
            {
                if (type.Text == "Inherent")
                {
                    if (type.Displayed)
                    {
                        inherentDisplayed = true;
                    }
                }
                else if (type.Text == "Current")
                {
                    if (type.Displayed)
                    {
                        currentDisplayed = true;
                    }
                }
                else if (type.Text == "Target")
                {
                    if (type.Displayed)
                    {
                        targetDisplayed = true;
                    }
                }

                else if (type.Text != "Show Arrows")
                {
                    Assert.Fail("An unexpected option was found on the screen, option had the ID " + type.GetAttribute("id"));
                }
            }
            Assert.IsTrue(inherentDisplayed, "Expected Inherent assessment type option to be displayed in the PID settings.");
            Assert.IsTrue(currentDisplayed, "Expected Current assessment type option to be displayed in the PID settings.");
            Assert.IsTrue(targetDisplayed, "Expected Target assessment type option to be displayed in the PID settings.");
        }

        public void AssertSingleRiskShowArrowsOption(bool sinlgeRisk)
        {
            bool showArrowsDisplayed = false;
            foreach (var type in AssessmentTypes)
            {
                if (type.GetAttribute("id").Equals("showArrowsDiv") && sinlgeRisk)
                {
                    showArrowsDisplayed = true;
                    break;
                }
                if (type.GetAttribute("id").Equals("showArrowsDiv") && !sinlgeRisk)
                {
                    Assert.Fail("Show Arrows option was displayed in the PID settings menu for multiple Risks but should not have been.");
                }
            }
            if (!showArrowsDisplayed)
            {
                Assert.Fail("The Show Arrows option was not found in the Single Risk PID settings.");
            }
        }

        public void AssertAssessmentTypesChecked(params string[] selectedOptions)
        {
            foreach (var option in selectedOptions)
            {
                foreach (var type in AssessmentTypes)
                {
                    var myOption = option;
                    if (myOption.StartsWith("Show "))
                    {
                        myOption = myOption.Replace("Show ", "");
                    }
                    myOption = "show" + char.ToUpper(myOption[0]) + myOption.Substring(1).ToLower() + "Div";
                    if (myOption.Equals(type.GetAttribute("id")) && type.Selected)
                    {
                            Assert.Fail("The option " + myOption + " was not selected but was expected to be.");
                    }
                }
            }
        }

        public void AssertCorrectPlotModesAreShown()
        {
            foreach (var mode in PlotModes)
            {
                Assert.IsTrue(mode.Displayed);
            }
        }

        public void AssertCorrectPlotModesAreCheckedAndEnabled(bool singleRisk)
        {
            if (singleRisk)
            {
                Assert.IsTrue(DivPlotModes.GetAttribute("disabled").Equals("true"));
                foreach (var mode in PlotModesCheckboxes)
                {
                    if(mode.GetAttribute("id").Equals("pointPlotRadio"))
                        Assert.IsTrue(mode.Selected);
                    else
                        Assert.IsFalse(mode.Selected);
                }
            }
            else
            {
                Assert.IsTrue(string.IsNullOrEmpty(DivPlotModes.GetAttribute("disabled")));
                foreach (var mode in PlotModesCheckboxes)
                {
                    if (mode.GetAttribute("id").Equals("countPlotRadio"))
                        Assert.IsTrue(mode.Selected);
                    else
                        Assert.IsFalse(mode.Selected);
               }
            }
        }

        public void AssertDrivingImpactsAreDisabled()
        {
            foreach (var impact in DrivingImpacts)
            {
                Assert.IsTrue(impact.GetAttribute("disabled").Equals("true"));
            }
        }

        public void AssertDrivingImpactsAreEnabled()
        {
            foreach (var impact in DrivingImpacts)
            {
                Assert.IsTrue(string.IsNullOrEmpty(impact.GetAttribute("disabled")));
            }
        }

        public void DeSelectAssessmentType(string optionToSelect)
        {
            if (optionToSelect.StartsWith("Show "))
            {
                optionToSelect = optionToSelect.Replace("Show ", "");
            }
            optionToSelect = "show" + char.ToUpper(optionToSelect[0]) + optionToSelect.Substring(1).ToLower() + "Div";
            foreach (var type in AssessmentTypes)
            {
                if (optionToSelect.Equals(type.GetAttribute("id")))
                {
                    for (var i = 0; i < 30; i++)
                    {
                        Thread.Sleep(1000);
                        if (type.FindElement(By.CssSelector("input[type='checkbox']")).Selected)
                        {
                            type.FindElement(By.CssSelector("input[id='" + optionToSelect.Replace("Div", "") + "']")).Click();
                        }
                        else { break;}
                    }
                }
            }
        }

        public void SelectAssessmentType(string optionToSelect)
        {

            if (optionToSelect.StartsWith("Show "))
            {
                optionToSelect = optionToSelect.Replace("Show ", "");
            }
            optionToSelect = "show" + char.ToUpper(optionToSelect[0]) + optionToSelect.Substring(1).ToLower() + "Div";
            foreach (var type in AssessmentTypes)
            {
                if (optionToSelect.Equals(type.GetAttribute("id")))
                {
                    for (var i = 0; i < 30; i++)
                    {
                        Thread.Sleep(1000);
                        if (!type.FindElement(By.CssSelector("input[type='checkbox']")).Selected)
                        {
                            type.FindElement(By.CssSelector("input[id='" + optionToSelect.Replace("Div", "") + "']")).Click();
                        }
                        else { break; }
                    }
                }
            }

        }

        public void SelectPlotMode(string id)
        {
            var plotMode = PlotModesCheckboxes.Single(type => type.GetAttribute("id").Equals(id));
            if (!plotMode.Selected)
            { plotMode.Click();}
        }

        public void DeSelectDrivingImpact(string id)
        {
            var impact = DrivingImpactsCheckBoxes.Single(type => type.GetAttribute("id").Equals(id));
            if (impact.Selected)
            { impact.Click();}
        }

        public void SelectDrivingImpact(string id)
        {
            var impact = DrivingImpactsCheckBoxes.Single(type => type.GetAttribute("id").Equals(id));
            if (!impact.Selected)
            { impact.Click();}
        }

        public string GetTitle()
        {
            return Driver.FindElement(By.CssSelector("header.panel-heading h3")).Text;
        }

        public void AssertPidChartYaxisLabel(string expected)
        {
            Assert.AreEqual(expected, YAxisLabel.Text, "Expected PID y axis title to be {0} but it was {1}.", expected, YAxisLabel.Text);
        }

        public void AssertPidChartXaxisLabel(string expected)
        {
            Assert.AreEqual(expected, XAxisLabel.Text, "Expected PID x axis title to be {0} but it was {1}.", expected, XAxisLabel.Text);
        }
    }

    public class PidChartHeatmapCell
    {
        public string FillColour { get; set; }
        public int MinX { get; set; }
        public int MaxX { get; set; }
        public int MinY { get; set; }
        public int MaxY { get; set; }

        public PidChartHeatmapCell(IWebElement element)
        {
            FillColour = element.GetAttribute("fill");
            
            MinX = Convert.ToInt32(element.GetAttribute("x"));
            MaxX = MinX + Convert.ToInt32(element.GetAttribute("width"));
            MinY = Convert.ToInt32(element.GetAttribute("y"));
            MaxY = MinY + Convert.ToInt32(element.GetAttribute("height"));
        }
    }

    public class PidChartCountLabel
    {
        public int X { get; set; }
        public int Y { get; set; }
        public string FillColour { get; set; }
        public int Count { get; set; }

        public PidChartCountLabel(IWebElement element)
        {
            var transformString = element.GetAttribute("transform").Split('(', ' ', ')');
            X = Convert.ToInt32(transformString[1]);
            Y = Convert.ToInt32(transformString[2]);
            FillColour = element.FindElement(By.CssSelector("rect")).GetAttribute("fill");
            Count = Convert.ToInt32(element.FindElement(By.CssSelector("text tspan")).Text);
        }
    }

    public class PidChartPoint
    {
        public int X { get; set; }
        public int Y { get; set; }
        public string FillColour { get; set; }
        public string BorderColour { get; set; }

        public PidChartPoint(IWebElement element)
        {
            var positionString = element.GetAttribute("d").Split('M','C', ' ');
            X = (int) Convert.ToDouble(positionString[2]);
            Y = (int) Convert.ToDouble(positionString[3]);
            FillColour = element.GetAttribute("fill");
            BorderColour = element.GetAttribute("stroke");
        }
    }
}
