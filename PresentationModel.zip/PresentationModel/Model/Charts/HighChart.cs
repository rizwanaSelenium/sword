﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class HighChart : WebDriverArmControl
    {
        public HighChart(IWebDriver driver, WebDriverWait waiter, string containerId) : base(driver, waiter, "div#" + containerId)
        {

        }

        public string GetXAxisLabel()
        {
            return Element.FindElement(By.CssSelector("text.highcharts-xaxis-title")).Text;
        }

        public string GetYAxisLabel()
        {
            return Element.FindElement(By.CssSelector("text.highcharts-yaxis-title")).Text;
        }

        public string GetTitle()
        {
            return Element.FindElement(By.CssSelector("text.highcharts-title tspan")).Text;
        }

        public int BaseLineTrackerYPoint
        {
            get
            {
                return Element.FindElement(By.XPath("//g[contains(@class, 'highcharts-markers highcharts-series-3 highcharts-tracker')]")).FindElement(By.CssSelector("text")).Location.Y;
            }
        }
    }
}
