﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdQuadSheetChartDialogue : WebDriverArmPage
    {
        public WdQuadSheetChartField Id { get; set; }
        public WdQuadSheetChartField Title { get; set; }
        public WdQuadSheetChartField BusinessArea { get; set; }

        public WdQuadSheetChartField Owner { get; set; }
        public WdQuadSheetChartField Printed { get; set; }

        public WdQuadSheetChartField Description { get; set; }

        public WdQuadSheetChartField ScoringRiskLevel { get; set; }
        public WdQuadSheetChartField ScoringProbabiity { get; set; }
        public WdQuadSheetChartField ScoringScore { get; set; }
        public WdQuadSheetChartField ScoringCost { get; set; }
        public WdQuadSheetChartField ScoringScoringScheme { get; set; }
        public WdQuadSheetChartField ScoringTime { get; set; }
        public WdQuadSheetChartField ScoringReputation { get; set; }
        public WdQuadSheetChartField ScoringDescription { get; set; }

        public WdQuadSheetChartField HighLevelDescription { get; set; }

        public WdQuadSheetChartField FallbackPlanDescription { get; set; }

        public WebDriverButton SaveAsButton { get; set; }
        public WebDriverDropDown SaveFormatTypes { get; set; }
        public WebDriverButton CopyButton { get; set; }
        public WebDriverButton PrintButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverTickBoxControl ShowColours { get; set; }
        public WebDriverTickBoxControl ShowPid { get; set; }
        public WebDriverTickBoxControl TruncateToFit { get; set; }
        public WebDriverTextField FontSize { get; set; }
        
        public WdQuadSheetChartDialogue(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "QuadSheetChart.aspx")
        {
            Id = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_tableContent", "QuadSheetChartControl_lblId");
            Title = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_tableContent", "QuadSheetChartControl_lblTitle");
            BusinessArea = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_tableContent", "QuadSheetChartControl_lblFolderName");

            Owner = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_tableContent", "QuadSheetChartControl_lblOwner");
            Printed = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_tableContent", "QuadSheetChartControl_lblDate");

            Description = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_bodyLeftTop", "QuadSheetChartControl_lblDescription");

            ScoringRiskLevel = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblRiskLevel");
            ScoringProbabiity = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblProbability");
            ScoringScore = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblScore");
            ScoringCost = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblImpCat1");
            ScoringScoringScheme = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblScoringScheme");
            ScoringTime = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblImpCat2");
            ScoringReputation = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_rigthTopTable", "QuadSheetChartControl_lblImpCat3");
            ScoringDescription = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_bodyRightTop", "QuadSheetChartControl_lblScoringDesc");

            HighLevelDescription = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_bodyLeftBottom", "QuadSheetChartControl_lblHighLevelDesc");

            FallbackPlanDescription = new WdQuadSheetChartField(driver, waiter, "QuadSheetChartControl_bodyRightBottom", "QuadSheetChartControl_lblFallbackPlanDesc");

            SaveAsButton = new WebDriverButton(driver, waiter, "button#QuadSheetChartControl_btnSave", true);
            SaveFormatTypes = new WebDriverDropDown(driver, waiter, "select#QuadSheetChartControl_SaveFormatTypes", true);
            CopyButton = new WebDriverButton(driver, waiter, "button#QuadSheetChartControl_btnCopy__btn", true);
            PrintButton = new WebDriverButton(driver, waiter, "button#QuadSheetChartControl_btnPrint__btn", true);
            CloseButton = new WebDriverButton(driver, waiter, "button#QuadSheetChartControl_btnClose__btn", true);
            HelpButton = new WebDriverButton(driver, waiter, "button#QuadSheetChartControl_btnHelp__btn", true);
            ShowColours = new WebDriverTickBoxControl(driver, waiter, "input#QuadSheetChartControl_chShowColours_cb", true);
            ShowPid = new WebDriverTickBoxControl(driver, waiter, "input#QuadSheetChartControl_chShowPid_cb", true);
            TruncateToFit = new WebDriverTickBoxControl(driver, waiter, "input#QuadSheetChartControl_chTruncateToFit_cb", true);
            FontSize = new WebDriverTextField(driver, waiter, "input#QuadSheetChartControl_txtFontSize", true);

            // Wait for page is ready, then JavaScript
            WaitUntilPageIsReady();
        }

        public void AssertPrintedIsToday()
        {
            var todayDay = DateTime.Now.ToString("dd");
            var todayMonth = DateTime.Now.ToString("MMMM");
            var todayYear = DateTime.Now.Year.ToString();
            var todayString = todayDay + " " + todayMonth + " " + todayYear;
            Assert.AreEqual(todayString, Printed.GetText());
        }
    }
}
