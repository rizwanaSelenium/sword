﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdSensitivityChartDialogue : WebDriverArmPage
    {
        public WdTableGridHeaderItem IdHeader { get; set; }
        public WdTableGridHeaderItem TitleHeader { get; set; }
        public WdTableGridHeaderItem CvHeader { get; set; }
        public WdTableGridHeaderItem ExpandedValueHeader { get; set; }
        public WdTableGridHeaderItem ScHeader { get; set; }

        public WdTableGridItem IdValue { get; set; }
        public WdTableGridItem TitleValue { get; set; }
        public WdTableGridItem CvValue { get; set; }
        public WdTableGridItem ExpandedValueValue { get; set; }
        public WdTableGridItem ScValue { get; set; }

        public WebDriverTextField Cv { get; set; }
        public WebDriverTextField EvThreshold { get; set; }
        public WebDriverTickBoxControl ShowOpportunityAsNegative { get; set; }

        public WebDriverButton ExportButton { get; set; }
        public WebDriverButton SaveAsButton { get; set; }
        public WebDriverButton CopyChartButton { get; set; }
        public WebDriverButton PrintButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WdSensitivityChartDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "SensitivityChart.aspx")
        {
            AssertNoErrorMessageDisplayed();

            IdHeader = new WdTableGridHeaderItem(driver, waiter, "V_Chart_DataGrid", 1);
            TitleHeader = new WdTableGridHeaderItem(driver, waiter, "V_Chart_DataGrid", 2);
            CvHeader = new WdTableGridHeaderItem(driver, waiter, "V_Chart_DataGrid", 3);
            ExpandedValueHeader = new WdTableGridHeaderItem(driver, waiter, "V_Chart_DataGrid", 4);
            ScHeader = new WdTableGridHeaderItem(driver, waiter, "V_Chart_DataGrid", 5);

            IdValue = new WdTableGridItem(driver, waiter, "V_Chart_DataGrid", 1, 1);
            TitleValue = new WdTableGridItem(driver, waiter, "V_Chart_DataGrid", 1, 2);
            CvValue = new WdTableGridItem(driver, waiter, "V_Chart_DataGrid", 1, 3);
            ExpandedValueValue = new WdTableGridItem(driver, waiter, "V_Chart_DataGrid", 1, 4);
            ScValue = new WdTableGridItem(driver, waiter, "V_Chart_DataGrid", 1, 5);

            Cv = new WebDriverTextField(driver, waiter, "V_CVThreshold");
            EvThreshold = new WebDriverTextField(driver, waiter, "V_EMVThreshold");
            ShowOpportunityAsNegative = new WebDriverTickBoxControl(driver, waiter, "V_ShowOpportunityAsNegative");

            ExportButton = new WebDriverButton(driver, waiter, "V_Export_btn");
            SaveAsButton = new WebDriverButton(driver, waiter, "V_SaveAs_btn");
            CopyChartButton = new WebDriverButton(driver, waiter, "V_Copy_btn");
            PrintButton = new WebDriverButton(driver, waiter, "V_Print_btn");
            CloseButton = new WebDriverButton(driver, waiter, "V_Close_btn");
            HelpButton = new WebDriverButton(driver, waiter, "V_Help_btn");

            // Wait for page Initial Data Load, then page is ready, then JavaScript
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertNoErrorMessageDisplayed()
        {
            var errorMessages = Driver.FindElements(By.CssSelector("span#ErrorMessage")).Count;
            if (errorMessages > 0)
            {
                Assert.Fail("Chart caused Error Message To Be Displayed: " + Driver.FindElement(By.CssSelector("span#ErrorMessage")).Text);
            }
        }

        public void AssertSensitivityChartDisplayed()
        {
            Assert.True(Driver.FindElement(By.CssSelector("img#V_Chart_Chart")).Displayed);
        }
    }
}
