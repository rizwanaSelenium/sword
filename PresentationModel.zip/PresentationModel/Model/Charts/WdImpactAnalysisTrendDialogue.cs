﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdImpactAnalysisTrendDialogue : WebDriverArmPage
    {
        public WebDriverTextField ViewDataOnlyFromDay { get; set; }
        public WebDriverDropDown ViewDataOnlyFromMonth { get; set; }
        public WebDriverTextField ViewDataOnlyFromYear { get; set; }

        public WebDriverTextField ToDay { get; set; }
        public WebDriverDropDown ToMonth { get; set; }
        public WebDriverTextField ToYear { get; set; }

        public WebDriverButton ApplyButton { get; set; }
        public WebDriverButton ResetButton { get; set; }

        public WebDriverButton SaveChartButton { get; set; }
        public WebDriverDropDown SaveFormatTypes { get; set; }
        public WebDriverButton CopyChartButton { get; set; }
        public WebDriverButton PrintButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WdImpactAnalysisTrendDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ImpactAnalysisTrendChart.aspx")
        {
            AssertNoErrorMessageDisplayed();

            ViewDataOnlyFromDay = new WebDriverTextField(driver, waiter, "input#IATCControl_dpFrom_day", true);
            ViewDataOnlyFromMonth = new WebDriverDropDown(driver, waiter, "select#IATCControl_dpFrom_month", true);
            ViewDataOnlyFromYear = new WebDriverTextField(driver, waiter, "input#IATCControl_dpFrom_year", true);

            ToDay = new WebDriverTextField(driver, waiter, "input#IATCControl_dpTo_day", true);
            ToMonth = new WebDriverDropDown(driver, waiter, "select#IATCControl_dpTo_month", true);
            ToYear = new WebDriverTextField(driver, waiter, "input#IATCControl_dpTo_year", true);

            ApplyButton = new WebDriverButton(driver, waiter, "IATCControl_btnApply__btn");
            ResetButton = new WebDriverButton(driver, waiter, "IATCControl_btnReset__btn");

            SaveChartButton = new WebDriverButton(driver, waiter, "IATCControl_btSaveChart");
            SaveFormatTypes = new WebDriverDropDown(driver, waiter, "select#IATCControl_SaveFormatTypes", true);
            CopyChartButton = new WebDriverButton(driver, waiter, "IATCControl_btnCopy");
            PrintButton = new WebDriverButton(driver, waiter, "btnPrint");
            CloseButton = new WebDriverButton(driver, waiter, "btnClose");
            HelpButton = new WebDriverButton(driver, waiter, "btnHelp");

            // Wait for page is ready, then JavaScript
            WaitUntilPageIsReady();
        }

        public void AssertNoErrorMessageDisplayed()
        {
            var errorMessages = Driver.FindElements(By.CssSelector("span#ErrorMessage")).Count;
            if (errorMessages > 0)
            {
                Assert.Fail("Chart caused Error Message To Be Displayed: " + Driver.FindElement(By.CssSelector("span#ErrorMessage")).Text);
            }
        }

        public void AssertImpactAnalysisTrendChartDisplayed()
        {
            Assert.True(Driver.FindElement(By.CssSelector("img#IATCControl_Chart1")).Displayed);
        }

        public void AssertViewDataOnlyFromDateIsToday()
        {
            var todayDay = DateTime.Now.Day.ToString();
            var todayMonth = DateTime.Now.ToString("MMMM");
            var todayYear = DateTime.Now.Year.ToString();
            Assert.AreEqual(todayDay, ViewDataOnlyFromDay.GetValue());
            Assert.AreEqual(todayMonth, ViewDataOnlyFromMonth.GetValue());
            Assert.AreEqual(todayYear, ViewDataOnlyFromYear.GetValue());
        }

        public void AssertToDateIsToday()
        {
            var todayDay = DateTime.Now.Day.ToString();
            var todayMonth = DateTime.Now.ToString("MMMM");
            var todayYear = DateTime.Now.Year.ToString();
            Assert.AreEqual(todayDay, ToDay.GetValue());
            Assert.AreEqual(todayMonth, ToMonth.GetValue());
            Assert.AreEqual(todayYear, ToYear.GetValue());
        }
    }
}
