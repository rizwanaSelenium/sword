﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdImpactAnalysisChartDialogue : WebDriverArmPage
    {
        public WebDriverTextField Item { get; set; }
        public WebDriverTextField Slices { get; set; }
        public WebDriverTextField ImpactCategory { get; set; }
        public WebDriverTextField Iterations { get; set; }

        public WebDriverButton ExportButton { get; set; }
        public WebDriverButton ReportButton { get; set; }
        public WebDriverButton CumulativeGraphButton { get; set; }
        public WebDriverButton SensitivityButton { get; set; }
        public WebDriverTickBoxControl Aspect { get; set; }
        public WebDriverTickBoxControl ShowMarks { get; set; }
        public WebDriverTickBoxControl ShowEstimate { get; set; }
        public WebDriverTickBoxControl ShowStdDev { get; set; }
        public WebDriverTextField StandardDeviation { get; set; }

        public WebDriverButton ModifyButton { get; set; }
        public WebDriverButton AgainButton { get; set; }
        public WebDriverButton SaveAsButton { get; set; }
        public WebDriverButton CopyChartButton { get; set; }
        public WebDriverButton PrintButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverTickBoxControl SaveCheckbox { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WdImpactAnalysisChartDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Process_Fr.asp")
        {
            MainFrame();
            AssertNoErrorMessageDisplayed();

            Item = new WebDriverTextField(driver, waiter, "ImpactAnalysisView_txtItemName");
            Slices = new WebDriverTextField(driver, waiter, "ImpactAnalysisView_txtNumberOfSlices");
            ImpactCategory = new WebDriverTextField(driver, waiter, "ImpactAnalysisView_txtImpactCategory");
            Iterations = new WebDriverTextField(driver, waiter, "ImpactAnalysisView_txtNumberOfIterations");

            ExportButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Export_btn");
            ReportButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Report_btn");
            CumulativeGraphButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_CumulativeAndMonteCarlo_btn");
            SensitivityButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Sensitivity_btn");
            Aspect = new WebDriverTickBoxControl(driver, waiter, "ImpactAnalysisView_chkBxChart3DAspect");
            ShowMarks = new WebDriverTickBoxControl(driver, waiter, "ImpactAnalysisView_chkBxShowMarks");
            ShowEstimate = new WebDriverTickBoxControl(driver, waiter, "ImpactAnalysisView_chkBxShowEstimate");
            ShowStdDev = new WebDriverTickBoxControl(driver, waiter, "ImpactAnalysisView_chkBxShowStandardDeviation");
            StandardDeviation = new WebDriverTextField(driver, waiter, "div.armcontrol#ImpactAnalysisView_StandardDeviation input[type='text']", true);

            ModifyButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Modify_btn");
            AgainButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Again_btn");
            SaveAsButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_SaveAs_btn");
            CopyChartButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Copy_btn");
            PrintButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Print_btn");
            SaveButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Save_btn");
            SaveCheckbox = new WebDriverTickBoxControl(driver, waiter, "ImpactAnalysisView_chkSaveCheck");
            CloseButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Close_btn");
            HelpButton = new WebDriverButton(driver, waiter, "ImpactAnalysisView_Help_btn");

            // Wait for page Initial Data Load, then page is ready, then JavaScript
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertNoErrorMessageDisplayed()
        {
            var errorMessages = Driver.FindElements(By.CssSelector("span#ErrorMessage")).Count;
            if (errorMessages > 0)
            {
                Assert.Fail("Chart caused Error Message To Be Displayed: " + Driver.FindElement(By.CssSelector("span#ErrorMessage")).Text);
            }
        }

        public void AssertImpactAnalysisChartDisplayed()
        {
            Assert.True(Driver.FindElement(By.CssSelector("img#ImpactAnalysisView_Chart_Chart")).Displayed);
        }

        public WdSensitivityChartDialogue Sensitivity()
        {
            SensitivityButton.AssertEnabled();
            SensitivityButton.Click();

            return OpenChildDialog<WdSensitivityChartDialogue>();
        }

        public void MainFrame()
        {
            Driver.SwitchTo().Frame("FrMain");
        }

        public void ClickCumulativeGraphButton()
        {
            CumulativeGraphButton.AssertEnabled();
            CumulativeGraphButton.Click();

            AssertNoErrorMessageDisplayed();

            AssertImpactAnalysisChartDisplayed();
        }

        public void Save()
        {
            SaveButton.AssertEnabled();
            SaveButton.Click();

            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var prompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            Assert.AreEqual("Results saved", prompt.FindElement(By.CssSelector("td+td")).Text);
            prompt.FindElement(By.CssSelector("button[title='OK']")).Click();
        }
    }
}
