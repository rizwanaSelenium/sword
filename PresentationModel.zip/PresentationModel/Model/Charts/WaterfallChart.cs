﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WaterfallChart : WebDriverArmPage
    {
        private HighChart _chart;

        public HighChart Chart
        {
            get { return _chart ?? (_chart = new HighChart(Driver, Waiter, "container")); }
        }

        private WebDriverButton _settingsButton;

        public WebDriverButton SettingsButton
        {
            get { return _settingsButton ?? (_settingsButton = new WebDriverButton(Driver, Waiter, "Settings")); }
        }

        private WebDriverButton _modalCloseButton;

        public WebDriverButton ModalCloseButton
        {
            get { return _modalCloseButton ?? (_modalCloseButton = new WebDriverButton(Driver, Waiter, "modalClose")); }
        }

        public WebDriverButton SaveButton;
        public WebDriverButton CloseButton;

        public IList<IWebElement> ChartOptions
        {
            get { return Driver.FindElements(By.CssSelector("div#settingsModal div.checkbox input[type='checkbox']")); }
        }

        public WebDriverDropDown BaselineLegendOptions;

       private IList<WaterfallChartColorBands> _colorBand;

        public IList<WaterfallChartColorBands> ColorBand
        {
            get
            {
                return _colorBand ??
                       (_colorBand =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-series rect"))
                               .Select(x => new WaterfallChartColorBands(x)).ToList());
            }
        }

        private IList<WaterfallChartResponsePoints> _responsePoints;

        public IList<WaterfallChartResponsePoints> ResponsePoints
        {
            get
            {
                return _responsePoints ??
                       (_responsePoints =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-markers path"))
                               .Select(x => new WaterfallChartResponsePoints(x)).ToList());
            }
        }

        private IList<WaterfallChartBaseLineStartPoint> _baselineStartPoint;

        public IList<WaterfallChartBaseLineStartPoint> BaseLineStartPoint
        {
            get
            {
                return _baselineStartPoint ??
                       (_baselineStartPoint =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-markers text"))
                               .Select(x => new WaterfallChartBaseLineStartPoint(x)).ToList());
            }
        }

        private IList<IWebElement> _responsePointsClick;

        public IList<IWebElement> ResponsePointsClick
        {
            get
            {
                return _responsePointsClick ??
                       (_responsePointsClick =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-markers path"))
                               .ToList());
            }
        }

        private IList<WaterfallChartResponseLines> _responseLines;

        public IList<WaterfallChartResponseLines> ResponseLines
        {
            get
            {
                return _responseLines ??
                       (_responseLines =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-series-group g.highcharts-series path"))
                               .Select(x => new WaterfallChartResponseLines(x)).ToList());
            }
            set { _responseLines = value; }
        }

        private IList<WaterfallChartResponseLabels> _responseLabelsX;

        public IList<WaterfallChartResponseLabels> ResponseLabelsX
        {
            get
            {
                return _responseLabelsX ??
                       (_responseLabelsX =
                           Chart.FindElements(By.CssSelector("svg g.highcharts-axis path:not([zIndex=\"7\"])"))
                               .Select(x => new WaterfallChartResponseLabels(x)).ToList());
            }
        }

      private IList<WaterfallChartResponseLabels> _responseLabelsY;

        public IList<WaterfallChartResponseLabels> ResponseLabelsY
        {
            get
            {
                return _responseLabelsY ??
                       (_responseLabelsY = Chart.FindElements(By.CssSelector("svg g.highcharts-grid path"))
                           .Select(x => new WaterfallChartResponseLabels(x)).ToList());
            }
        }

        private IList<WaterfallChartLegendLines> _legendLines;

        public IList<WaterfallChartLegendLines> LegendLines
        {
            get
            {
                return _legendLines ??
                       (_legendLines =
                           Chart.FindElements(By.CssSelector("div div.highcharts-legend div.highcharts-legend-item span"))
                               .Select(x => new WaterfallChartLegendLines(x)).ToList());
            }
        }

        public IList<IWebElement> LegendLineOptions
        {
            get
            {
                return
                    Chart.FindElements(By.CssSelector("div div.highcharts-legend div.highcharts-legend-item span"))
                        .ToList();
            }
        }

        private IList<VerticalLine> _verticalLines;

        public IList<VerticalLine> VerticalLines
        {
            get
            {
                return _verticalLines ??
                       (_verticalLines =
                           Chart.FindElements(By.CssSelector("svg path[zIndex='6']"))
                               .Select(x => new VerticalLine(x))
                               .ToList());
            }
        }

        private IList<WaterfallChartResponseToolTip> _responsetooltip;

        public IList<WaterfallChartResponseToolTip> ResponseToolTip
        {
            get
            {
                return _responsetooltip ??
                       (_responsetooltip = Chart.FindElements(By.CssSelector("svg g.highcharts-tooltip text title"))
                           .Select(x => new WaterfallChartResponseToolTip(x)).ToList());
            }
        }

        private IList<WaterfallChartLabels> _actualLabels;

        public IList<WaterfallChartLabels> ActualLabels
        {
            get
            {
                return _actualLabels ??
                       (_actualLabels = Chart.FindElements(By.CssSelector("svg g.labels"))
                           .Select(x => new WaterfallChartLabels(x)).ToList());
            }
        }

        private IList<WaterfallChartLabels> _baselineLabels;
        public IList<WaterfallChartLabels> BaseLineLabels
        {
            get
            {
                return _baselineLabels ??
                       (_baselineLabels = Chart.FindElements(By.CssSelector("svg g.labels"))
                           .Select(x => new WaterfallChartLabels(x)).ToList());
            }
        }
        private IList<IWebElement> _tableGridHeader;
        public IList<IWebElement> TabelGridHeader
        {
            get
            {
                return _tableGridHeader ??
                       (_tableGridHeader =
                           Chart.FindElements(By.CssSelector("div#stepLegend span[class='ui-grid-header-cell-label ng-binding']")).ToList());

            }
        }

        private IList<IWebElement> _tableGridCellValues;
        public IList<IWebElement> TabelGridCellValues
        {
            get
            {
                return _tableGridCellValues ??
                       (_tableGridCellValues =
                           Chart.FindElements(By.CssSelector("div#stepLegend div[role='gridcell']")).ToList());

            }
        }

        public WaterfallChart(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "WaterfallChart")
        {
            SaveButton = new WebDriverButton(Driver, Waiter, "Export");
            CloseButton = new WebDriverButton(Driver, Waiter, "Close");
        
            WaitUntilPageIsReady();
        }

        public string GetTitle()
        {
            return Driver.FindElement(By.CssSelector("header.panel-heading h3")).Text;
        }

        public void Settings()
        {
            SettingsButton.Click();
            WaitUntilPageIsReady();
        }

        public void ModalClose()
        {
            ModalCloseButton.Click();
            WaitUntilPageIsReady();
        }

        public void OpenDetailDialog()
        {
            ResponsePointsClick.First().Click();
        }


        public class WaterfallChartColorBands
        {
            public string FillColour { get; set; }

            public WaterfallChartColorBands(IWebElement element)
            {
                FillColour = element.GetAttribute("fill");

            }
        }

        public class WaterfallChartResponsePoints
        {
            public int X { get; set; }
            public int Y { get; set; }
            public string FillColour { get; set; }
            public string BorderColour { get; set; }
            public string D { get; set; }
            public bool Visible { get; set; }

            public WaterfallChartResponsePoints(IWebElement element)
            {
                FillColour = element.GetAttribute("fill");
                BorderColour = element.GetAttribute("stroke");
                Visible = element.Displayed;
                var positionString = element.GetAttribute("d").Split('M', 'L', ' ');
                D = element.GetAttribute("d").Split(null).ToString();
                X = (int) Convert.ToDouble(positionString[2]);
                Y = (int) Convert.ToDouble(positionString[3]);
            }
        }

        public class WaterfallChartBaseLineStartPoint
        {
            public int X { get; set; }
            public int Y { get; set; }
            public string FillColour { get; set; }
            public bool Visible { get; set; }
            public string Text { get; set; }

            public WaterfallChartBaseLineStartPoint(IWebElement element)
            {
                FillColour = element.GetAttribute("fill");
                Visible = element.Displayed;
                Text = element.Text;
                X = (int) Convert.ToDouble(element.GetAttribute("x"));
                Y = (int) Convert.ToDouble(element.GetAttribute("y"));
            }
        }

        public class WaterfallChartResponseLines
        {
            public int X { get; set; }
            public int Y { get; set; }
            public string FillColour { get; set; }
            public string LineColour { get; set; }
            public bool Visible { get; set; }

            public WaterfallChartResponseLines(IWebElement element)
            {
                var positionString = element.GetAttribute("d").Split('M', 'L', ' ');
        
                Y = (int) Math.Round(Convert.ToDouble(positionString[3]), MidpointRounding.AwayFromZero);
                X = (int) Convert.ToDouble(positionString[2]);
        
                FillColour = element.GetAttribute("fill");
                LineColour = element.GetAttribute("stroke");
                Visible = element.Displayed;
            }
        }

        public class WaterfallChartResponseLabels
        {
            public int X { get; set; }
            public int Y { get; set; }

            public WaterfallChartResponseLabels(IWebElement element)
            {
                var positionString = element.GetAttribute("d").Split('M', 'L', ' ');
          
                 X = (int)Math.Round(Convert.ToDouble(positionString[2]),MidpointRounding.AwayFromZero);
                Y = (int) Math.Round(Convert.ToDouble(positionString[3]), MidpointRounding.AwayFromZero);
            }
        }

        public class WaterfallChartLegendLines
        {
            public string LegendItemText { get; set; }
            public string FillColour { get; set; }

            public WaterfallChartLegendLines(IWebElement element)
            {
                LegendItemText = element.Text;
                var fill = element.GetAttribute("style").Split(';').GetValue(11).ToString().Split(':').GetValue(1);
                FillColour = ((string) fill).Trim();
            }
        }

        public class VerticalLine
        {
            public string StrokeColour { get; set; }
            public string StrokeDashArray { get; set; }
            public bool Visible { get; set; }
            public int X { get; set; }
            public int Y { get; set; }

            public VerticalLine(IWebElement element)
            {
                StrokeColour = element.GetAttribute("stroke");
                StrokeDashArray = element.GetAttribute("stroke-dasharray");
                Visible = element.Displayed;
                var positionString = element.GetAttribute("d").Split('M', 'L', ' ');
                X = (int) Convert.ToDouble(positionString[2]);
                Y = (int) Math.Round(Convert.ToDouble(positionString[3]));
            }
        }

        public class WaterfallChartResponseToolTip
        {
            public bool Visible { get; set; }
            public string ToolTipText { get; set; }

            public WaterfallChartResponseToolTip(IWebElement element)
            {
                Visible = element.Displayed;
                ToolTipText = element.Text;
            }
        }

        public class WaterfallChartLabels
        {
            public int X1 { get; set; }
            public string LabelText { get; set; }
            public bool Visible { get; set; }

            public WaterfallChartLabels(IWebElement element)
            {
                X1 = (int) Math.Round(Convert.ToDouble(element.FindElement(By.TagName("line")).GetAttribute("x1")));
                LabelText = element.Text;
                Visible = element.Displayed;
            }
        }

        public void AssertLegendItemIsNotSelected(string legendItemToVerify)
        {
            var legendItemIsNotSelected = LegendLines.Any(x => x.LegendItemText.Equals(legendItemToVerify) && x.FillColour.Equals("#ccc"));
            Assert.True(legendItemIsNotSelected, "legend item " + legendItemToVerify + "should not be selected");
        }

        public void AssertLegendItemIsSelected(string legendItemToVerify)
        {
            var legendItems = LegendLines.Select(x => new {x.LegendItemText, x.FillColour});
            var legendItemIsSelected =
                legendItems.Single(x => x.LegendItemText.Equals(legendItemToVerify) && x.FillColour.Equals("#333333"));
            if (legendItemIsSelected != null)
                Assert.True(true, "legend item " + legendItemToVerify + "should be selected");
        }

        public void AssertLegendItemIsNotDisplayed(string legendItemToVerify)
        {
            var legendItemIsNotDisplayed = LegendLineOptions.Any(item => item.Text.Contains(legendItemToVerify));
            Assert.False(legendItemIsNotDisplayed, "legend item " + legendItemToVerify + "should not be displayed");

        }

        public void TurnOnLegendOption(string legendItemToTurnOn)
        {
            LegendLineOptions.Single(item => item.Text.Equals(legendItemToTurnOn)).Click();
        }

        public void TurnOffLegendOption(string legendItemToTurnOff)
        {
            var legendItem = LegendLineOptions.Single(item => item.Text.Equals(legendItemToTurnOff));
            var legendItemColor = legendItem.GetAttribute("style").Split(';', ':').GetValue(23).ToString().Trim();
            if (legendItemColor.Equals("#333333"))
            {
                legendItem.Click();
            }
        }

        public void ChartOptionsOn(string option)
        {
        
            ChartOptions.Single(x => x.GetAttribute("id") == option).Click();
        }

        public void ChartOptionsOff()
        {
                var test = ChartOptions.Where(x => string.IsNullOrEmpty(x.GetAttribute("disabled")));
                foreach (var variable in test)
                {
                    if (variable.Selected)
                    {
                        variable.Click();
                    }
                }
        }

        public void ChartOptionsOff(string option)
        {
            ChartOptions.Single(x => x.GetAttribute("id") == option).Click();
        }

        public void AssertChartDisplaysActionResponsePoints(string expectedFillColor, string expectedBorderColor)
        {
            var actionResponsePoints =
                ResponsePoints.Any(
                    l =>
                        l.FillColour.ToLower().Equals(expectedFillColor.ToLower()) &&
                        l.BorderColour.ToLower().Equals(expectedBorderColor.ToLower()));
            if (!actionResponsePoints)
            {
                Assert.Fail("Chart does not contain specified action response points. Expected colour {0} and {1}", expectedFillColor, expectedBorderColor);
            }
        }

        public void AssertChartDisplaysOriginalPlanLine(string expectedOrginalLineColor,
            string expectedResponsePointFillColor, string expectedResponsePointBorderColor)
        {
            var originalResponseLine =
                ResponseLines.Where(x => x.Visible)
                    .Select(x => x.LineColour)
                    .Any(x => x.Equals(expectedOrginalLineColor));
            var originalResponsePoints = ResponsePoints.Where(x => x.Visible)
                .Select(x => new {x.FillColour, x.BorderColour})
                .All(
                    x =>
                        x.BorderColour.Equals(expectedResponsePointBorderColor) &&
                        x.FillColour.Equals(expectedResponsePointFillColor));
            if (!originalResponseLine || !originalResponsePoints)
                Assert.Fail(
                    "Chart does not contain specified original Line and response points. Expected colour {0}, {1} and {2}",
                    expectedOrginalLineColor, expectedResponsePointFillColor, expectedResponsePointBorderColor);
        }


        public void AssertResponseLineIsNotDisplayed(string expectedOrginalLineColor,
            string expectedResponsePointFillColor, string expectedResponsePointBorderColor)
        {
            var originalResponseLine =
                ResponseLines.Where(x => x.Visible)
                    .Select(x => x.LineColour)
                    .Any(x => x.Equals(expectedOrginalLineColor));
            var originalResponsePoints = ResponsePoints.Where(x => x.Visible)
                .Select(x => new {x.FillColour, x.BorderColour})
                .All(
                    x =>
                        x.FillColour.Equals(expectedResponsePointFillColor) &&
                        x.BorderColour.Equals(expectedResponsePointBorderColor));
            if (originalResponseLine || originalResponsePoints)
                Assert.Pass("Chart does not contain specified original Line. Expected colour {0}, {1} and {2}",
                    expectedOrginalLineColor, expectedResponsePointFillColor, expectedResponsePointBorderColor);
        }


        public void AssertChartDisplaysColorBands(string expectedColorBand1, string expectedColorBand2,
            string expectedColorBand3)
        {
            var colorBand1 = ColorBand.Any(c => c.FillColour.ToLower().Equals(expectedColorBand1.ToLower()));
            var colorBand2 = ColorBand.Any(c => c.FillColour.ToLower().Equals(expectedColorBand2.ToLower()));
            var colorBand3 = ColorBand.Any(c => c.FillColour.ToLower().Equals(expectedColorBand3.ToLower()));
            if (!colorBand1 && !colorBand2 && !colorBand3)
                Assert.Fail("Chart does not contain specified color bands. Expected colour {0},{1} and {2}",
                    expectedColorBand1, expectedColorBand2, expectedColorBand3);

        }

        public void AssertTodayDateLineColor(string expectedStrokeColor, string expectedStrokeLine)
        {
            var verticalLine = VerticalLines.Where(x => x.Visible).Select(x => new {x.StrokeColour, x.StrokeDashArray});
            var verifyTodaysDateLine =
                verticalLine.Any(
                    x => x.StrokeColour.Equals(expectedStrokeColor) && x.StrokeDashArray.Equals(expectedStrokeLine));
            if (!verifyTodaysDateLine)
                Assert.Fail(
                    "Chart does not contain specified today's date Line. Expected colour and stroke {0} and {1}",
                    expectedStrokeColor, expectedStrokeLine);
        }

        public void AssertFirstFallBackResponseLineColor(string expectedStrokeColor)
        {
            var responseLine = VerticalLines.Where(x => x.Visible).Select(x => x);
            var verifyFalBackResponseLine = responseLine.Any(x => x.StrokeColour.Equals(expectedStrokeColor));
            if (!verifyFalBackResponseLine)
                Assert.Fail("Chart does not contain specified Fall back response Line. Expected colour and stroke {0}",
                    expectedStrokeColor);
        }

        public void AssertToolTip(string expectedToolTipText)
        {
            var actualTooltipList =
                Driver.FindElement(By.CssSelector("div.highcharts-tooltip")).Text.Split('\r', '\n').ToList();
            var actualTooltipText = string.Join(" ", actualTooltipList.ToArray());
            Assert.AreEqual(expectedToolTipText, actualTooltipText);

        }


        public void AssertChartDisplaysResponseLineAndResponsePointsInTheCorrectColor(string expectedResponseLineColor,
            string expectedResponsePointBorderColor,
            string expectedResponsePointFillColor)
        {
            var responseLine =
                ResponseLines.Where(x => x.Visible)
                    .Select(x => x.LineColour)
                    .Any(x => x.Equals(expectedResponseLineColor));
            var visibleResponsePoints =
                ResponsePoints.Where(x => x.Visible).Select(x => new {x.FillColour, x.BorderColour});
            var visibleResponsePointColor =
                visibleResponsePoints.Any(
                    x =>
                        x.FillColour.Equals(expectedResponsePointFillColor) &&
                        x.BorderColour.Equals(expectedResponsePointBorderColor));
            if (!responseLine || !visibleResponsePointColor)
                Assert.Fail(
                    "Chart does not contain specified original Line and response points. Expected colour {0} , {1} and {2}",
                    responseLine, expectedResponsePointBorderColor, expectedResponsePointFillColor);
        }

        public void AssertChartDisplaysActualResponseLine(string expectedResponseLineColor)
        {
            var responseLine =
                ResponseLines.Where(x => x.Visible)
                    .Select(x => x.LineColour)
                    .Any(x => x.Equals(expectedResponseLineColor));
            if (!responseLine)
                Assert.Fail(
                    "Chart does not contain specified actual Line and actual response points. Expected colour {0}",
                    responseLine);
        }

        public void AssertChartDisplaysActualResponsePointsInTheCorrectColor(string expectedResponsePointFillColor)
        {
            var visibleResponsePoints = ResponsePoints.Where(x => x.Visible).Select(x => x.FillColour);
            var visibleResponsePointColor = visibleResponsePoints.All(x => x.Equals(expectedResponsePointFillColor));
            if (!visibleResponsePointColor)
                Assert.Fail(
                    "Chart does not contain specified actual Line and actual response points. Expected colour {0}"
                    , expectedResponsePointFillColor);
        }

        public void AssertActualResponsePointsAreNotDisplayed(string expectedResponsePointFillColor,
            string expectedResponsePointBorderColor)
        {
            var actualResponsePoints = Chart.FindElements(By.CssSelector("svg g.highcharts-markers[zIndex = '3'] path"));
            if (!actualResponsePoints.Count().Equals(0))
            {
                Assert.Fail("Actual Response Points should not be dislayed in the Chart");
            }

        }

        public void AssertChartDisplaysProjectedLine(string expectedLineColour)
        {
            var chartDislaysLine = ResponseLines.Any(l => l.LineColour.ToLower().Equals(expectedLineColour.ToLower()));
            if (!chartDislaysLine)
                Assert.Fail("Chart does not contain specified projected line color. Expected colour {0} ",
                    expectedLineColour);
        }

        public void AssertRiskScoreScaleInverted()
        {
            if (Chart.BaseLineTrackerYPoint < 0)
                Assert.Fail("Risk score scale inversion failed.");
        }

        public void AssertChartDisplaysBaselinePointsInTheCorrectColor(string expectedResponsePointFillColor)
        {

            var visibleResponsePoints = ResponsePoints.Where(x => x.Visible).Select(x => new {x.D, x.FillColour});
            var visibleResponsePointColor = visibleResponsePoints.All(x => x.FillColour.Equals(expectedResponsePointFillColor));
            if (!visibleResponsePointColor)
                Assert.Fail(
                    "Chart does not contain specified actual Line and actual response points. Expected colour {0}"
                    , expectedResponsePointFillColor);
        }


        public void AssertLineStartsFromCorrectDate(string expectedPoint)
        {
            var responseLineStartX = GetActualResponseStartLineAndResponsePoint().ResponseLineStartX;
            var responsePoint = GetActualResponseStartLineAndResponsePoint().ResponsePoint;
            var responseStartX = GetActualResponseStartLineAndResponsePoint().ResponseStartX;
            //Waterfall translates by 71 and 53
            Assert.AreEqual(responseStartX, responseLineStartX + 71);
            Assert.AreEqual(expectedPoint, Math.Round(responsePoint * 100) / 100f);
       }

        public void AssertResponsePointsArePlottedBasedonBaseLineDueDateForEachResponse()
        {
            var responseStartX = ResponseLabelsX.OrderBy(x => x.X).Select(x => x.X).ToList();
            var responsePoints = ResponsePoints.Where(x => x.Visible).OrderBy(x => x.X).Select(x => x.X).ToList();
            
            int i = 1;
            foreach (var point in responsePoints)
            {
                var actualpoint = point + 71;

                if (responseStartX[i].Equals(actualpoint))
                {
                    Console.WriteLine(
                        "--------Response Points are plotted based on baseline due date for that response---------------");
                }

                else
                {
                    Assert.Fail("Response points are not plotted correctly");
                }

                i++;
            }
        }
        public void AssertBaseLineStartsFromCorrectDate(double expectedPoint)
        {
            var responseLineStartX = GetActualResponseStartLineAndResponsePoint().ResponseLineStartX;
            var responsePoint = GetActualResponseStartLineAndResponsePoint().ResponsePoint;
            var baseLineStaringPoint = BaseLineStartPoint.OrderBy(x => x.X)
                .Select(x => new { x.FillColour, x.X })
                .First();
            var actualResponsePoint = Math.Round(responsePoint*100)/100f;
            Assert.AreEqual(expectedPoint,actualResponsePoint );
            Assert.AreEqual(responseLineStartX, baseLineStaringPoint.X + 5);
            Assert.IsTrue(baseLineStaringPoint.FillColour.Equals("black"), "Baseline should start from planned start date");

        }

        public struct Result
{
    public int ResponseLineStartX;
    public int ResponseStartX;
    public double ResponsePoint;
}
        public Result GetActualResponseStartLineAndResponsePoint()
        {
            var responseStartX = ResponseLabelsX.Min(x => x.X);
            var responseStartY = ResponseLabelsY.OrderBy(x => x.Y).Select(x => x.Y);
            var responseLineStartX = ResponseLines.Where(x => x.Visible).Select(x => x.X).First();
            var responseLineStartY = ResponseLines.Where(x => x.Visible).Select(x => x.Y).First();

            responseLineStartY += 53;
            
            int y1 = -1, y2 = Int32.MaxValue, i = 9;
            double point = 0;
            foreach (int val in responseStartY)
            {
                if (val <= responseLineStartY && val > y1 || y1 == -1)
                    y1 = val;
                if (val >= responseLineStartY && val < y2)
                {
                    y2 = val;
                    point = i / 10.0;
                }
                i--;
            }

            if (!(responseLineStartY == y1 || responseLineStartY == y2))
            {
                point += Convert.ToDouble(y2 - responseLineStartY) / Convert.ToDouble(y2 - y1) / 10;
            }
       
            var result = new Result
            {
                ResponseLineStartX = responseLineStartX,
                ResponsePoint = point,
                ResponseStartX = responseStartX
            };
            return result;


        }
    }
}





