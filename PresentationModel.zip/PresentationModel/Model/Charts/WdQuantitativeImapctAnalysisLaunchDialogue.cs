﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdQuantitativeImapctAnalysisLaunchDialogue : WebDriverArmPage
    {
        private WebDriverTextField _item;
        public WebDriverTextField Item
        {
            get
            {
                return _item ?? (_item = new WebDriverTextField(Driver, Waiter, "input[name='bbsItemName']", true));
            }
        }

        public WebDriverTickBoxControl ActivityUncertainty { get; set; }
        public WebDriverTickBoxControl RisksCurrentThreatOnly { get; set; }
        public WebDriverTickBoxControl RisksCurrentThreatAndOpportunity { get; set; }
        public WebDriverTickBoxControl RisksTargetThreatOnly { get; set; }
        public WebDriverTickBoxControl RisksTargetThreatAndOpportunity { get; set; }
        public WebDriverTickBoxControl RisksTargetAndPlanCostsThreatOnly { get; set; }
        public WebDriverTickBoxControl RisksTargetAndPlanCostsThreatAndOpportunity { get; set; }

        public WebDriverTextField NumberOfSlices { get; set; }
        public WebDriverTextField NumberOfIterations { get; set; }
        public WebDriverTextField FixedSeed { get; set; }

        public WebDriverTextField EstimateImpactValue { get; set; }
        public WebDriverTextField EstimateConfidenceLevel { get; set; }
        public WebDriverTickBoxControl UseActivityBudget { get; set; }

        public WebDriverTextField ConfidenceLevel1 { get; set; }
        public WebDriverTextField ConfidenceLevel2 { get; set; }
        public WebDriverTextField ConfidenceLevel3 { get; set; }

        public WebDriverDropDown ImpactCategories { get; set; }
        public WebDriverRadioButton SummaryAndStandaloneRisks { get; set; }
        public WebDriverRadioButton DetailAndStandaloneRisks { get; set; }

        public WebDriverTickBoxControl CorrelatedProbability { get; set; }

        public WebDriverTickBoxControl IncludeSummaryTasks { get; set; }
        public WebDriverTickBoxControl AbsoluteDataInExport { get; set; }

        public WebDriverButton RunButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WdQuantitativeImapctAnalysisLaunchDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Process_Fr.asp")
        {
            driver.SwitchTo().Frame("FrMain");

            ActivityUncertainty = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimUncertainty'][type='checkbox']", true);
            RisksCurrentThreatOnly = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimCurrentThreat'][type='checkbox']", true);
            RisksCurrentThreatAndOpportunity = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimCurrent'][type='checkbox']", true);
            RisksTargetThreatOnly = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimTargetThreat'][type='checkbox']", true);
            RisksTargetThreatAndOpportunity = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimTarget'][type='checkbox']", true);
            RisksTargetAndPlanCostsThreatOnly = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimTargetIncThreat'][type='checkbox']", true);
            RisksTargetAndPlanCostsThreatAndOpportunity = new WebDriverTickBoxControl(driver, waiter, "input[name='chkSimTargetInc'][type='checkbox']", true);

            NumberOfSlices = new WebDriverTextField(driver, waiter, "input[name='numbSlices']", true);
            NumberOfIterations = new WebDriverTextField(driver, waiter, "input[name='numbIterations']", true);
            FixedSeed = new WebDriverTextField(driver, waiter, "input[name='fixedSeed']", true);

            EstimateImpactValue = new WebDriverTextField(driver, waiter, "input[name='EstImpact']", true);
            EstimateConfidenceLevel = new WebDriverTextField(driver, waiter, "input[name='confLevelEst']", true);
            UseActivityBudget = new WebDriverTickBoxControl(driver, waiter, "input[name='chkUseActivityBudget'][type='checkbox']", true);

            ConfidenceLevel1 = new WebDriverTextField(driver, waiter, "input[name='confLevel1']", true);
            ConfidenceLevel2 = new WebDriverTextField(driver, waiter, "input[name='confLevel2']", true);
            ConfidenceLevel3 = new WebDriverTextField(driver, waiter, "input[name='confLevel3']", true);

            ImpactCategories = new WebDriverDropDown(driver, waiter, "select[name='selImpactCategory']", true);
            SummaryAndStandaloneRisks = new WebDriverRadioButton(driver, waiter, "input[name='SummaryDetail'][id='radioSummaryOnly'][type='radio']", true);
            DetailAndStandaloneRisks = new WebDriverRadioButton(driver, waiter, "input[name='SummaryDetail'][id='radioDetailOnly'][type='radio']", true);

            CorrelatedProbability = new WebDriverTickBoxControl(driver, waiter, "input[name='chkCorrelatedImpacts'][type='checkbox']", true);

            IncludeSummaryTasks = new WebDriverTickBoxControl(driver, waiter, "input[name='chkIncSummActs'][type='checkbox']", true);
            AbsoluteDataInExport = new WebDriverTickBoxControl(driver, waiter, "input[name='chkAbsDataExport'][type='checkbox']", true);

            RunButton = new WebDriverButton(driver, waiter, "button#btnRun", true);
            CancelButton = new WebDriverButton(driver, waiter, "button#btnClose", true);
            HelpButton = new WebDriverButton(driver, waiter, "button#btnHelp", true);

            // Wait for page is ready, then JavaScript
            WaitUntilPageIsReady();
        }

        public WdImpactAnalysisChartDialogue Run()
        {
            RunButton.AssertEnabled();
            RunButton.Click();

            return OpenChildDialog<WdImpactAnalysisChartDialogue>();
        }

        public void MainFrame()
        {
            Driver.SwitchTo().Frame("FrMain");
        }
    }
}
