﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Charts
{
    public class WdQuantSchedAnalysisResultsChartDialogue : WebDriverArmPage
    {
        public WdSaChartSpanTextField Item { get; set; }
        public WdSaChartSpanTextField SimulationType { get; set; }
        public WdSaChartSpanTextField EstimateConfidence { get; set; }
        public WdSaChartSpanTextField AdditionalAnalysis { get; set; }
        public WdSaChartSpanTextField FinalActivityDate { get; set; }
        public WdSaChartSpanTextField NumberOfSlices { get; set; }
        public WdSaChartSpanTextField NumberOfIterations { get; set; }
        public WdSaChartSpanTextField Seed { get; set; }

        public WebDriverButton ExportResultsButton { get; set; }
        public WebDriverButton ReportButton { get; set; }
        public WebDriverButton CumulativeGraphButton { get; set; }
        public WebDriverButton CriticalityButton { get; set; }
        public WebDriverButton SensitivityButton { get; set; }
        public WebDriverButton CrucialityButton { get; set; }
        public WebDriverTickBoxControl ShowStandardDeviation { get; set; }
        public WebDriverTextField ScheduleAnalysisChartControl { get; set; }

        public WebDriverTickBoxControl Aspect { get; set; }
        public WebDriverTickBoxControl ShowMarks { get; set; }
        public WebDriverTickBoxControl ShowEstimate { get; set; }

        public WebDriverButton ModifyButton { get; set; }
        public WebDriverButton AgainButton { get; set; }
        public WebDriverButton SaveAsButton { get; set; }
        public WebDriverDropDown SaveFormatTypes { get; set; }
        public WebDriverButton CopyChartButton { get; set; }
        public WebDriverButton PrintButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverTickBoxControl SaveCheckbox { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WdQuantSchedAnalysisResultsChartDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Process_Fr.asp")
        {
            MainFrame();
            AssertNoErrorMessageDisplayed();

            Item = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbName");
            SimulationType = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbSimulationType");
            EstimateConfidence = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbEstimateConfidence");
            AdditionalAnalysis = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbAdditionalAnalysis");
            FinalActivityDate = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbFinalActivityDate");
            NumberOfSlices = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbNumberOfSlices");
            NumberOfIterations = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbNumberOfIterations");
            Seed = new WdSaChartSpanTextField(driver, waiter, "ScheduleAnalysisChartControl_lbSeed");

            ExportResultsButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btnExportRes__btn", true);
            ReportButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btnReport__btn", true);
            CumulativeGraphButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btSwapGraph__btn", true);
            CriticalityButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btCriticality__btn", true);
            SensitivityButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btSensitivity__btn", true);
            CrucialityButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btCruciality__btn", true);
            ShowStandardDeviation = new WebDriverTickBoxControl(driver, waiter, "input[id='ScheduleAnalysisChartControl_cbShowStdDev_cb'][type='checkbox']", true);
            ScheduleAnalysisChartControl = new WebDriverTextField(driver, waiter, "input#ScheduleAnalysisChartControl_tbStdDevs_tb", true);

            Aspect = new WebDriverTickBoxControl(driver, waiter, "input[id='ScheduleAnalysisChartControl_cbAspectView_cb'][type='checkbox']", true);
            ShowMarks = new WebDriverTickBoxControl(driver, waiter, "input[id='ScheduleAnalysisChartControl_cbShowMarks_cb'][type='checkbox']", true);
            ShowEstimate = new WebDriverTickBoxControl(driver, waiter, "input[id='ScheduleAnalysisChartControl_cbShowEstimate_cb'][type='checkbox']", true);

            ModifyButton = new WebDriverButton(driver, waiter, "button#btnModify", true);
            AgainButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btAgain__btn", true);
            SaveAsButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btSaveChart", true);
            SaveFormatTypes = new WebDriverDropDown(driver, waiter, "select#ScheduleAnalysisChartControl_SaveFormatTypes", true);
            CopyChartButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btnCopyChart", true);
            PrintButton = new WebDriverButton(driver, waiter, "button#btnPrint", true);
            SaveButton = new WebDriverButton(driver, waiter, "button#ScheduleAnalysisChartControl_btnSpecialSave__btn", true);
            SaveCheckbox = new WebDriverTickBoxControl(driver, waiter, "input[id='ScheduleAnalysisChartControl_chkSavedRes_cb'][type='checkbox']", true);
            CloseButton = new WebDriverButton(driver, waiter, "button#btnClose", true);
            HelpButton = new WebDriverButton(driver, waiter, "button#btnHelp", true);

            // Wait for page is ready, then JavaScript
            WaitUntilPageIsReady();
        }

        public void AssertNoErrorMessageDisplayed()
        {
            var errorMessages = Driver.FindElements(By.CssSelector("span#ErrorMessage")).Count;
            if (errorMessages > 0)
            {
                Assert.Fail("Chart caused Error Message To Be Displayed: " + Driver.FindElement(By.CssSelector("span#ErrorMessage")).Text);
            }
        }

        public void MainFrame()
        {
            Driver.SwitchTo().Frame("FrMain");
        }

        public void AssertQuantitativeScheduleAnalysisChartDisplayed()
        {
            Assert.True(Driver.FindElement(By.CssSelector("img#ScheduleAnalysisChartControl_Chart1")).Displayed);
        }
    }
}
