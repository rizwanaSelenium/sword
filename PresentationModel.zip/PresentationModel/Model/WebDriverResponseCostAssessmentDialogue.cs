﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model
{
    //This is an old window but still currently in ARM

    public class WebDriverResponseCostAssessmentDialogue : WebDriverArmPage
    {
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; private set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; private set; }
         
        public WebDriverResponseCostAssessmentDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ResponseCost.aspx")
        {
            OkButton = new WebDriverButton(Driver, Waiter, "ResponseCostView1_OK_btn");
            SaveButton = new WebDriverButton(Driver, Waiter, "ResponseCostView1_Save_btn");
            NewButton = new WebDriverButton(Driver, Waiter, "ResponseCostView1_New_btn");
            CancelButton = new WebDriverButton(Driver, Waiter, "ResponseCostView1_Cancel_btn");
            HelpButton = new WebDriverButton(Driver, Waiter, "ResponseCostView1_Help_btn");
           
        }

        private WebDriverDatePicker _responseCostFromDate;
        public WebDriverDatePicker ResponseCostFromDate
        {
            get { return _responseCostFromDate ?? (_responseCostFromDate = new WebDriverDatePicker(Driver, Waiter, "td[id='0_FromDate']", true)); }
        }

        private WebDriverDatePicker _responseCostToDate;
        public WebDriverDatePicker ResponseCostToDate
        {
            get { return _responseCostToDate ?? (_responseCostToDate = new WebDriverDatePicker(Driver, Waiter, "td[id='0_ToDate']", true)); }
        }

        private AngularSingleLineTextField _probability;
        public AngularSingleLineTextField Probability
        {
            get
            {
                return _probability ?? (_probability = new AngularSingleLineTextField(Driver, Waiter, "0_Probability", false, false));
            }
        }

        private AngularCostField _min;
        public AngularCostField Min
        {
            get
            {
                return _min ?? (_min = new AngularCostField(Driver, Waiter, "0_MinimumCost", false, false));
            }
        }

        private AngularCostField _expectedCost;
        public AngularCostField ExpectedCost
        {
            get
            {
                return _expectedCost ?? (_expectedCost = new AngularCostField(Driver, Waiter, "0_ExpectedCost", false, false));
            }
        }

        private AngularCostField _max;
        public AngularCostField Max
        {
            get
            {
                return _max ?? (_max = new AngularCostField(Driver, Waiter, "0_MaximumCost", false, false));
            }
        }

        private AngularCostField _plannedCost;
        public AngularCostField PlannedCost
        {
            get
            {
                return _plannedCost ?? (_plannedCost = new AngularCostField(Driver, Waiter, "0_PlannedCost", false, false));
            }
        }

        private AngularCostField _costThreat;
        public AngularCostField CostThreat
        {
            get
            {
                return _costThreat ?? (_costThreat = new AngularCostField(Driver, Waiter, "0_CostThreat", false, false));
            }
        }

        private AngularCostField _actualCost;
        public AngularCostField ActualCost
        {
            get
            {
                return _actualCost ?? (_actualCost = new AngularCostField(Driver, Waiter, "0_ActualCost", false, false));
            }
        }

        private AngularButton _yesButtonBlockedDialog;

        public AngularButton YesButtonBlockedDialog
        {
            get
            {
                return _yesButtonBlockedDialog ??
                       (_yesButtonBlockedDialog = new AngularButton(Driver, Waiter, "body[class='is-blocked'] div[id='UIPrompt'] button[title='Yes']"));
            }
        }

        private AngularButton _noButtonBlockedDialog;

        public AngularButton NoButtonBlockedDialog
        {
            get
            {
                return _noButtonBlockedDialog ??
                       (_noButtonBlockedDialog = new AngularButton(Driver, Waiter, "body[class='is-blocked'] div[id='UIPrompt'] button[tittle='No']"));
            }
        }

        public void AddNewResponseCost(int plannedCost,int actualCost)
        {
            var responseCostTableControl = Driver.FindElement(By.CssSelector("table#ResponseCostView1_ResponseCost_content"));
            WaitUntilPageIsReady();
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_Probability'] div input")).SendKeys("10");
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_MinimumCost'] div input")).SendKeys("10");
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_ExpectedCost'] div input")).SendKeys("30");
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_MaximumCost'] div input")).SendKeys("20");
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_PlannedCost'] div input")).SendKeys(Convert.ToString(plannedCost));
            responseCostTableControl.FindElement(By.CssSelector("td[id='0_ActualCost'] div input")).SendKeys(Convert.ToString(actualCost));
            ResponseCostToDate.PickDate(DateTime.Now.AddDays(3));
            ResponseCostToDate.Click();
            SaveButton.Click();
            RespondToUiPrompt("Yes");
            OkButton.Click();
        }

        public void AssertCostsIsNull()
        {
            var responseCostTableControl = Driver.FindElement(By.CssSelector("table#ResponseCostView1_ResponseCost_content"));
            WaitUntilPageIsReady();

         
            Assert.True(responseCostTableControl.FindElement(By.CssSelector("td[id='0_PlannedCost'] p span")).Text.Equals("0"));         
         
           Assert.True(responseCostTableControl.FindElement(By.CssSelector("td[id='0_ActualCost'] p span")).Text.Equals("0"));
           OkButton.Click();
        }
     
    }
}
