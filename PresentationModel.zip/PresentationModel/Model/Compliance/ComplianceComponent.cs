﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.ComplianceFolder;
using PresentationModel.Model.ComplianceRisk;
using PresentationModel.Model.ComplianceControl;
using PresentationModel.Model.ComplianceTask;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.Obligation;

namespace PresentationModel.Model.Compliance
{
    public class ComplianceComponent : WebDriverArmPage
    {
        private WebDriverButton _newButton;
        private WebDriverButton _saveButton;
        private WebDriverButton _cancelButton;
        private WebDriverButton _helpButton;
        private AngularModal _messagePrompt;
        private AngularTree _tree;
        private AngularIcon _deleteButton;
        private AngularIcon _addButton;
        private AngularIcon _addFolderIcon;
        private AngularIcon _addObligationIcon;
        private AngularIcon _addRiskIcon;
        private AngularIcon _addTaskIcon;
        private AngularIcon _addControlIcon;
        private AngularIcon _copyIcon;
        private AngularIcon _cutIcon;
        private AngularIcon _pasteIcon;
        private AngularIcon _pasteAsChildIcon;
        private AngularIcon _deleteIcon;
        private AngularIcon _importIcon;
        private AngularIcon _linkPolicyIcon;
        private AngularTab _historyButton;
        private AngularTab _detailsTab;
        private WebDriverButton _addAssessmentButton;

        public ComplianceComponent(IWebDriver driver, WebDriverWait waiter, string pageName) : base(driver, waiter, pageName)
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            WaitForComplianceTreeToLoad();
        }

        public ComplianceComponent(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "")
        { 
            WaitForComplianceTreeToLoad();
        }

        public WebDriverButton NewButton
        {
            get { return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, "new_btn")); }
        }

        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "save_btn")); }
        }

        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "cancel_btn")); }
        }

        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "help_btn")); }
        }

        public AngularModal MessagePrompt
        {
            get { return _messagePrompt ?? (_messagePrompt = new AngularModal(Driver, Waiter)); }
        }

        public AngularTree Tree
        {
            get { return _tree ?? (_tree = new AngularTree(Driver, Waiter, "arm-compliance-tree")); }
        }

        public AngularIcon DeleteButton
        {
            get { return _deleteButton ?? (_deleteButton = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "delete")); }
        }

        public AngularIcon AddButton
        {
            get { return _addButton ?? (_addButton = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "new")); }
        }

        public AngularIcon AddFolderIcon
        {
            get { return _addFolderIcon ?? (_addFolderIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "newfolder")); }
        }

        public AngularIcon AddObligationIcon
        {
            get { return _addObligationIcon ?? (_addObligationIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "new")); }
        }

        public AngularIcon AddRiskIcon
        {
            get { return _addRiskIcon ?? (_addRiskIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "newRisk")); }
        }

        public AngularIcon AddTaskIcon
        {
            get { return _addTaskIcon ?? (_addTaskIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "newTask")); }
        }

        public AngularIcon AddControlIcon
        {
            get { return _addControlIcon ?? (_addControlIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "newControl")); }
        }

        public AngularIcon CopyIcon
        {
            get { return _copyIcon ?? (_copyIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "copy")); }
        }

        public AngularIcon CutIcon
        {
            get { return _cutIcon ?? (_cutIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "cut")); }
        }

        public AngularIcon PasteIcon
        {
            get { return _pasteIcon ?? (_pasteIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "paste")); }
        }

        public AngularIcon PasteAsChildIcon
        {
            get { return _pasteAsChildIcon ?? (_pasteAsChildIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "pasteAsChild")); }
        }

        public AngularIcon DeleteIcon
        {
            get { return _deleteIcon ?? (_deleteIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "delete")); }
        }

        public AngularIcon ImportIcon
        {
            get { return _importIcon ?? (_importIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "import")); }
        }

        public AngularIcon LinkPolicyIcon
        {
            get { return _linkPolicyIcon ?? (_linkPolicyIcon = new AngularIcon(Driver, Waiter, "arm-compliance-tree-icons", "linkPolicy")); }
        }

        public AngularTab HistoryButton
        {
            get { return _historyButton ?? (_historyButton = new AngularTab(Driver, Waiter, "navmenu-history")); }
        }

        public AngularTab DetailsTab
        {
            get { return _detailsTab ?? (_detailsTab = new AngularTab(Driver, Waiter, "navmenu-detail")); }
        }

        public WebDriverButton AddAssessmentButton
        {
            get { return _addAssessmentButton ?? (_addAssessmentButton = new WebDriverButton(Driver, Waiter, "AddAssessmentBtn")); }
        }

        public bool IsAssessmentButtonVisible()
        {
            return Driver.FindElements(By.Id("AddAssessmentBtn")).Count > 0;
        }

        public ComplianceHistoryModel GetHistoryDialog
        {
            get
            {
                return new ComplianceHistoryModel(Driver, Waiter);
            }
        }

        public ComplianceControlDialog GetControlDialog
        {
            get
            {
                return new ComplianceControlDialog(Driver, Waiter);
            }
        }

        public ComplianceTaskDialog GetTaskdialog
        {
            get
            {
                DetailsTab.Click();
                return new ComplianceTaskDialog(Driver, Waiter);
            }
        }

        public ComplianceFolderDialog GetFolderdialog
        {
            get
            {
                WaitUntilPageIsReady();
                DetailsTab.Click();
                return new ComplianceFolderDialog(Driver, Waiter);
            }
        }

        public ComplianceRiskComponent RiskComponent
        {
            get
            {
                return new ComplianceRiskComponent(Driver, Waiter);
            }
        }

        public ObligationDialog ObligationPage()
        {
            return new ObligationDialog(Driver, Waiter);
        }

        public ObligationDialog GetOpenedObligationPage()
        {
            WaitUntilPageIsReady();
            return new ObligationDialog(Driver, Waiter);
        }

        public ComplianceControlDialog OpenComplianceControlPage()
        {
            WaitUntilPageIsReady();
            return new ComplianceControlDialog(Driver, Waiter);
        }

        public ComplianceTaskDialog OpenComplianceTaskPage()
        {
            WaitUntilPageIsReady();
            return new ComplianceTaskDialog(Driver, Waiter);
        }

        public ComplianceRiskComponent GetOpenedRiskPage()
        {
            WaitUntilPageIsReady();
            return new ComplianceRiskComponent(Driver, Waiter);
        }

        public WebDriverNewAdminDialog NavigateToArmAdmin(string baseUrl, string assignedInstanceId, IWebDriver driver)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            driver.Navigate().GoToUrl(string.Format("http://{0}/{1}/1/admin/menu", baseUrl, assignedInstanceId));
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new WebDriverNewAdminDialog(driver, Waiter);
        }

        public WebDriverDesktop NavigateToArm(string baseUrl, string assignedInstanceId, IWebDriver driver)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            driver.Navigate().GoToUrl(string.Format("http://{0}/arm.aspx?inst={1}&ba=1", baseUrl, assignedInstanceId));
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new WebDriverDesktop(driver, Waiter);
        }

        public void ClearParameters()
        {
            _tree = null;
            _deleteButton = null;
            _messagePrompt = null;
        }

        public ComplianceComponent GetOpenedComplianceManager()
        {
            return new ComplianceComponent(Driver, Waiter, "compliance");
        }

        public void WaitForComplianceTreeToLoad()
        {
            for (var i = 0 ; i < 3 ; i++)
            {
                try
                {
                    Waiter.Until(d => d.FindElements(By.CssSelector("div.angular-tree-component div.tree-node-leaf")).Count >= 1);
                    break;
                }
                catch (Exception ex)
                {
                    if (i == 2)
                    {
                        if (ex is WebDriverTimeoutException)
                        {
                            throw new WebDriverTimeoutException("** Error ** Timed out while waiting for compliance tree to be displayed. " + ex);
                        }

                        if (ex is StaleElementReferenceException)
                        {
                            throw new StaleElementReferenceException("** Error ** Stale element while trying to load compliance. " + ex);
                        }

                        throw new Exception("** Error ** Another error waiting for the compliance tree to load. " + ex);
                    }
                    Console.WriteLine("Failed waiting for the compliance tree will try again.");
                }
                WaitUntilUiSpinnerIsNotDisplayed();
            }
        }
    }
}
