﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Model.Compliance
{
    public class ComplianceHistoryModel : ComplianceComponent
    {
        public string RecordId { get; set; }
        public string User { get; set; }
        public string Function { get; set; }
        public List<KeyValuePair<int, string>> Columns;


        public ComplianceHistoryModel(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "history")
        {

        }

        public void VerifyHistoryData(dynamic expectedValue, string columnname, string recordId)
        {
            Waiter.Until(d => d.FindElement(By.ClassName("ui-grid-canvas")));

            var table = Driver.FindElement(By.ClassName("ui-grid-canvas"));
            var complianceHistoryRecords = table.FindElements(By.ClassName("ui-grid-row"));

            var complianceHistoryRecord = complianceHistoryRecords.First();
            if (complianceHistoryRecord != null)
            {
                if (Columns == null)
                    Columns = GetColumns(complianceHistoryRecord);

                switch (columnname)
                {
                    case "user":
                        Assert.AreEqual(expectedValue, Columns[1].Value);
                        break;
                    case "function":
                        Assert.AreEqual(expectedValue, Columns[2].Value);
                        break;
                }
            }
            else
            {
                Assert.Fail("Record of Id: {0} not found in table", recordId);
            }

        }

        private List<KeyValuePair<int, string>> GetColumns(IWebElement complianceHistoryRecord)
        {
            var columns = new List<KeyValuePair<int, string>>();
            var text = complianceHistoryRecord.Text;

            for (var i = 0; i < 4; i++)
            {
                var columnEnding = text.IndexOf("\r\n", StringComparison.Ordinal) == -1 ? text.Length : text.IndexOf("\r\n", StringComparison.Ordinal);
                var column = new KeyValuePair<int, string>(i, text.Substring(0, columnEnding));
                columns.Add(column);
                if (i < 3)
                    text = text.Substring(columnEnding + 2);
            }

            return columns;
        }
    }
}
