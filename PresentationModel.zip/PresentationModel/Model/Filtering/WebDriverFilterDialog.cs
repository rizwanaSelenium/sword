﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Filtering
{
    public class WebDriverFilterDialog : WebDriverArmPage
    {
        private WebDriverDropDown _filterName;
        public WebDriverDropDown FilterName
        {
            get { return _filterName ?? (_filterName = new WebDriverDropDown(Driver, Waiter, "V_FilterNameDropDown")); }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get { return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, "V_New_btn")); }
        }

        private WebDriverButton _deleteButton;
        public WebDriverButton DeleteButton
        {
            get { return _deleteButton ?? (_deleteButton = new WebDriverButton(Driver, Waiter, "V_Delete_btn")); }
        }

        public WebDriverFilterDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "filterbuilder.aspx")
        {
            // Wait for page Initial Data Load, then page is ready, then Ajax Complete
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            Driver.WaitForAjaxToComplete();
            WaitForFilterNameToBeDisplayed();
        }

        public WebDriverNewFilterDialogue New()
        {
            NewButton.AssertEnabled();
            NewButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            return new WebDriverNewFilterDialogue(Driver, Waiter);
        }

        public void Delete()
        {
            DeleteButton.AssertEnabled();
            DeleteButton.Click();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            Driver.FindElement(By.CssSelector("div#UIPrompt")).FindElement(By.CssSelector("button[title='Yes']")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            Driver.WaitForAjaxToComplete();
            WaitForFilterNameToBeDisplayed();
        }

        private void WaitForFilterNameToBeDisplayed()
        {
            bool filterNameDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var filterNames = Driver.FindElements(By.CssSelector("div.armcontrol#" + "V_FilterNameDropDown")).Where(x => x.Displayed).ToList();
                if (filterNames.Count > 0)
                {
                    filterNameDisplayed = true;
                    break;
                }
            }

            if (!filterNameDisplayed)
            {
                Assert.Fail("Was waiting for the Filter Dialogue Filter Name Field to be Displayed, but it was not displayed");
            }
        }
    }

    public class WebDriverNewFilterDialogue : WebDriverArmPage
    {
        private WebDriverTextField _filterName;
        public WebDriverTextField FilterName
        {
            get
            {
                return _filterName ?? (_filterName = new WebDriverTextField(Driver, Waiter, "V_FilterNameDropDown"));
            }
        }

        private WebDriverButton _filterNameEditButton;
        public WebDriverButton FilterNameEditButton
        {
            get
            {
                return _filterNameEditButton ?? (_filterNameEditButton = new WebDriverButton(Driver, Waiter, "V_FilterNameDropDown_Icon_btn"));
            }
        }

        private WebDriverRadioButton _privateRadioButton;
        public WebDriverRadioButton PrivateRadioButton
        {
            get
            {
                return _privateRadioButton ?? (_privateRadioButton = new WebDriverRadioButton(Driver, Waiter, "V_PrivateOption"));
            }
        }

        private WebDriverRadioButton _publicRadioButton;
        public WebDriverRadioButton PublicRadioButton
        {
            get
            {
                return _publicRadioButton ?? (_publicRadioButton = new WebDriverRadioButton(Driver, Waiter, "V_PublicOption"));
            }
        }

        private WebDriverRadioButton _allNodesRadioButton;
        public WebDriverRadioButton AllNodesRadioButton
        {
            get
            {
                return _allNodesRadioButton ?? (_allNodesRadioButton = new WebDriverRadioButton(Driver, Waiter, "V_AllNodes"));
            }
        }

        private WebDriverRadioButton _currentNodeRadioButton;
        public WebDriverRadioButton CurrentNodeRadioButton
        {
            get
            {
                return _currentNodeRadioButton ?? (_currentNodeRadioButton = new WebDriverRadioButton(Driver, Waiter, "V_CurrentNode"));
            }
        }

        private WebDriverRadioButton _selectTreeNodesRadioButton;
        public WebDriverRadioButton SelectTreeNodesRadioButton
        {
            get
            {
                return _selectTreeNodesRadioButton ?? (_selectTreeNodesRadioButton = new WebDriverRadioButton(Driver, Waiter, "V_SelectNode"));
            }
        }

        private WebDriverTickBoxControl _excludeAssociated;
        public WebDriverTickBoxControl ExcludeAssociated
        {
            get
            {
                return _excludeAssociated ?? (_excludeAssociated = new WebDriverTickBoxControl(Driver, Waiter, "V_ExcludeAssociatedRecords"));
            }
        }

        private WebDriverDropDown _knowledgeBaseOrLive;
        public WebDriverDropDown KnowledgeBaseOrLive
        {
            get
            {
                return _knowledgeBaseOrLive ?? (_knowledgeBaseOrLive = new WebDriverDropDown(Driver, Waiter, "V_NodeStatus"));
            }
        }

        private WebDriverDropDown _includeChildrenToLevel;
        public WebDriverDropDown IncludeChildrenToLevel
        {
            get
            {
                return _includeChildrenToLevel ?? (_includeChildrenToLevel = new WebDriverDropDown(Driver, Waiter, "V_IncludeChildrenToDepth"));
            }
        }

        private WebDriverDropDown _treeType;
        public WebDriverDropDown TreeType
        {
            get
            {
                return _treeType ?? (_treeType = new WebDriverDropDown(Driver, Waiter, "V_TreeType"));
            }
        }

        private WdCategoryPicker _selectNodes;
        public WdCategoryPicker SelectNodes
        {
            get
            {
                return _selectNodes ?? (_selectNodes = new WdCategoryPicker(Driver, Waiter, "V_ItemTree"));
            }
        }

        private WdFilterMenu _selectFilterCriteriaDropDown;
        public WdFilterMenu SelectFilterCriteriaDropDown
        {
            get
            {
                return _selectFilterCriteriaDropDown ?? (_selectFilterCriteriaDropDown = new WdFilterMenu(Driver, Waiter, "V_FieldCriteria"));
            }
        }

        private WdFilterOperatorItem _operator;
        public WdFilterOperatorItem Operator
        {
            get { return _operator ?? (_operator = new WdFilterOperatorItem(Driver, Waiter, "operator")); }
        }

        private WebDriverButton _addCriteriaButton;
        public WebDriverButton AddCriteriaButton
        {
            get
            {
                return _addCriteriaButton ?? (_addCriteriaButton = new WebDriverButton(Driver, Waiter, "V_FieldCriteria_AddCriteria_btn"));
            }
        }

        private WebDriverButton _runFilterButton;
        public WebDriverButton RunFilterButton
        {
            get { return _runFilterButton ?? (_runFilterButton = new WebDriverButton(Driver, Waiter, "V_Run_btn")); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "V_Save_btn")); }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get { return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, "V_New_btn")); }
        }

        private WebDriverButton _clearButton;
        public WebDriverButton ClearButton
        {
            get { return _clearButton ?? (_clearButton = new WebDriverButton(Driver, Waiter, "V_Clear_btn")); }
        }

        private WebDriverButton _deleteButton;
        public WebDriverButton DeleteButton
        {
            get { return _deleteButton ?? (_deleteButton = new WebDriverButton(Driver, Waiter, "V_Delete_btn")); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "V_Cancel_btn")); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "V_Help_btn")); }
        }

        public WebDriverNewFilterDialogue(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "filterbuilder.aspx")
        {
            // Wait for page Initial Data Load, then page is ready, then Ajax Complete
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            Driver.WaitForAjaxToComplete();
            WaitForFilterNameTextFieldToBeDisplayed();
        }

        public void Save()
        {
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => !d.Title.Contains(" * "));

            Waiter.Until(d => d.IsInitialDataLoadComplete());
            Driver.WaitForAjaxToComplete();
            WaitUntilUiSpinnerIsNotDisplayed();
            WaitForFilterNameDropDownToBeDisplayed();
        }

        private void WaitForFilterNameDropDownToBeDisplayed()
        {
            bool filterNameDropDownDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var filterNameDropDowns = Driver.FindElements(By.CssSelector("div.armcontrol#" + "V_FilterNameDropDown")).Where(x => x.Displayed).ToList();
                if (filterNameDropDowns.Count > 0)
                {
                    filterNameDropDownDisplayed = true;
                    break;
                }
            }

            if (!filterNameDropDownDisplayed)
            {
                Assert.Fail("Was waiting for the Filter Dialogue Filter Name Drop Down Field to be Displayed, but it was not displayed");
            }
        }

        private void WaitForFilterNameTextFieldToBeDisplayed()
        {
            bool filterNameTextFieldDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var filterNameTextFields = Driver.FindElements(By.CssSelector("div.armcontrol#" + "V_FilterNameDropDown" + " input#" + "V_FilterNameDropDown" + "_tb")).Where(x => x.Displayed).ToList();
                if (filterNameTextFields.Count > 0)
                {
                    filterNameTextFieldDisplayed = true;
                    break;
                }
            }

            if (!filterNameTextFieldDisplayed)
            {
                Assert.Fail("Was waiting for the Filter Dialogue Filter Name Text Field to be Displayed, but it was not displayed");
            }
        }
    }
}
