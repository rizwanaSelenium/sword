﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Incident_Desktop
{
    public class WebDriverIncidentPasteHereDialog : WebDriverArmPage
    {
        //Old window but still in ARM

        public WebDriverTickBoxControl IncludeInvestigation { get; set; }
        public WebDriverTickBoxControl IncludeResponses { get; set; }
        public WebDriverTickBoxControl IncludeRegulatoryAuthorities { get; set; }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton CancelButton { get; set;}

        public WebDriverIncidentPasteHereDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "CopyIncidentSettings.aspx")
        {
            IncludeInvestigation = new WebDriverTickBoxControl(Driver, Waiter, "input#RootView_IncludeInvestigation_chk", true);
            IncludeResponses = new WebDriverTickBoxControl(Driver, Waiter, "input#RootView_IncludeResponses_chk", true);
            IncludeRegulatoryAuthorities = new WebDriverTickBoxControl(Driver, Waiter, "input#RootView_IncludeRegulatoryAuthorities_chk", true);

            OkButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn");
            CancelButton = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn");

            WaitUntilPageIsReady();
        }
    }
}
