﻿namespace PresentationModel.Model.ComplianceRisk
{
    public class ComplianceRiskModel
    {
        public string Id { get; set; }
        public string RiskTitle { get; set; }
        public string Owner { get; set; }
        public string Status { get; set; }
        public string Category { get; set; }
        public string Source { get; set; }
        public string InterestedParties { get; set; }
        public string Phase { get; set; }
        public string RaisedBy { get; set; }
        public string Cause { get; set; }
        public string Effect { get; set; }
        public string Description { get; set; }
        public string Comments { get; set; }
    }
}
