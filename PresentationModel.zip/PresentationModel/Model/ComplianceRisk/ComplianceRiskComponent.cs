﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.Desktop;

namespace PresentationModel.Model.ComplianceRisk
{
    public class ComplianceRiskComponent : ComplianceComponent
    {
        public ComplianceRiskComponent(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "risk")
        {

        }

        public RiskDetailComponent Risk
        {
            get
            {
                return new RiskDetailComponent(Driver, Waiter);
            }
        }

        public ImpactComponent Impact
        {
            get
            {
                return new ImpactComponent(Driver, Waiter);
            }
        }
    }
}
