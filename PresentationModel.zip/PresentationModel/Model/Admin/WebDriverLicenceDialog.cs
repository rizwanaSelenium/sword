﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin
{
    public class WebDriverLicenceDialog : WebDriverArmPage
    {
        public WebDriverButton HelpButton;

        private WebDriverTextField _visualiserTextFieldLabel;
        public WebDriverTextField ArmRiskVisualiserTextFieldLabel
        {
            get { return _visualiserTextFieldLabel ?? (_visualiserTextFieldLabel = new WebDriverTextField(Driver, Waiter, "LV_ArmRiskVisualiserUsers"));}
        }

        private WebDriverTextField _visualiserTextField;
        public WebDriverTextField ArmRiskVisualiserTextField
        {
            get {  return _visualiserTextField ?? (_visualiserTextField = new WebDriverTextField(Driver, Waiter, "input#LV_ArmRiskVisualiserUsers_tb", true));}
        }

        public WebDriverLicenceDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Licensing.aspx")
        {
            HelpButton = new WebDriverButton(driver, waiter, "LV_Help_btn");
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();

            using (var page = new WebDriverHelpPage(Driver, Waiter, "Licence_Management.htm"))
            {
                page.AssertUrlEndsWith("Licence_Management.htm");
            }
        }
    }
}