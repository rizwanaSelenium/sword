﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebdriverRiskSecurityGroupDialog : WebDriverArmPage
    {
        public WebDriverDropDown BusinessAreaDropDown { get; set; }
        public WebDriverDropDown GroupDropDown { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        
        private WebDriverTickBoxControl _groupSecurityEnabledCheckBox;
        public WebDriverTickBoxControl GroupSecurityEnabledCheckBox
        {
            get
            {
                _groupSecurityEnabledCheckBox = new WebDriverTickBoxControl(Driver, Waiter, "input[name='[0].GroupSecurityEnabled']", true);
                return _groupSecurityEnabledCheckBox;
            }
        }

        public WebdriverRiskSecurityGroupDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            BusinessAreaDropDown = new WebDriverDropDown(driver, waiter, "select#CurrentBusinessAreaId", true,false);
            GroupDropDown = new WebDriverDropDown(driver, waiter, "select#CurrentGroupId", true,false);
            SaveButton = new WebDriverButton(driver, waiter, "input#btnSave", true);
            CloseButton = new WebDriverButton(driver, waiter, "button#btnClose", true);
            HelpButton = new WebDriverButton(driver, waiter, "a#help", true);
        }
    }
}
