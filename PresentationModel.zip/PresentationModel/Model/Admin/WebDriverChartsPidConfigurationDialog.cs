﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebDriverChartsPidConfigurationDialog : WebDriverArmPage
    {
        public WebDriverTickBoxControl AlwaysShowBothSidesOfPid;
        public WebDriverTickBoxControl AlwaysShowBothSidesOfAggregatePid;
        public WebDriverButton Cancel;
        public WebDriverButton Save;

        public WebDriverChartsPidConfigurationDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            AlwaysShowBothSidesOfPid = new WebDriverTickBoxControl(Driver, Waiter, "input#ShowBothSidesOfPID", true);
            AlwaysShowBothSidesOfAggregatePid = new WebDriverTickBoxControl(Driver, Waiter, "input#ShowBothSidesOfAggregatePID", true);
            Cancel = new WebDriverButton(Driver, Waiter, "a#Cancel", true);
            Save = new WebDriverButton(Driver, Waiter, "a#Save", true);
        }

    }
}