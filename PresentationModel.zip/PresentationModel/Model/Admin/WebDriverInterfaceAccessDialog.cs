﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin
{
    public class WebDriverInterfaceAccessDialog : WebDriverArmPage
    {
        private WebDriverTableControl _interfacesTable;
        public WebDriverTableControl InterfacesTable
        {
            get
            {
                _interfacesTable = new WebDriverTableControl(Driver, Waiter, "IAV_InterfaceTable");
                return _interfacesTable;
            }
        }

        private WebDriverTableControl _licensedUsersTable;
        public WebDriverTableControl LicensedUsersTable
        {
            get
            {
                _licensedUsersTable = new WebDriverTableControl(Driver, Waiter, "IAV_UserTable");
                return _licensedUsersTable;
            }
        }

        public WebDriverButton AddButton;

        public WebDriverButton OkButton;
        public WebDriverButton SaveButton;
        public WebDriverButton CloseButton;
        public WebDriverButton HelpButton;

        public WebDriverInterfaceAccessDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "InterfaceAccess.aspx")
        {
            AddButton = new WebDriverButton(driver, waiter, "IAV_Add_btn");

            OkButton = new WebDriverButton(driver, waiter, "IAV_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "IAV_Save_btn");
            CloseButton = new WebDriverButton(driver, waiter, "IAV_Close_btn");
            HelpButton = new WebDriverButton(driver, waiter, "IAV_Help_btn");
        }

        public void InterfaceTableAssertTotalLicenses(string interfaceName, string totalLicenses)
        {
            switch (interfaceName)
            {
                case "ARM Desktop":
                    InterfacesTable.AssertCellText(0, 0, "ARM Desktop");
                    InterfacesTable.AssertCellText(0, 1, totalLicenses);
                    break;
                case "ARM Apps":
                    InterfacesTable.AssertCellText(1, 0, "ARM Apps");
                    InterfacesTable.AssertCellText(1, 1, totalLicenses);
                    break;
                case "ARM Unplugged":
                    InterfacesTable.AssertCellText(2, 0, "ARM Unplugged");
                    InterfacesTable.AssertCellText(2, 1, totalLicenses);
                    break;
                case "ARM API":
                    InterfacesTable.AssertCellText(3, 0, "ARM API");
                    InterfacesTable.AssertCellText(3, 1, totalLicenses);
                    break;
                case "ARM Risk Express":
                    InterfacesTable.AssertCellText(4, 0, "ARM Risk Express");
                    InterfacesTable.AssertCellText(4, 1, totalLicenses);
                    break;
                default:
                    Assert.Fail("Interface Name: " + interfaceName + " Not Found In Interfaces Table");
                    break;
            }
        }

        public void InterfaceTableAssertRemainingLicenses(string interfaceName, string remainingLicenses)
        {
            switch (interfaceName)
            {
                case "ARM Desktop":
                    InterfacesTable.AssertCellText(0, 0, "ARM Desktop");
                    InterfacesTable.AssertCellText(0, 2, remainingLicenses);
                    break;
                case "ARM Apps":
                    InterfacesTable.AssertCellText(1, 0, "ARM Apps");
                    InterfacesTable.AssertCellText(1, 2, remainingLicenses);
                    break;
                case "ARM Unplugged":
                    InterfacesTable.AssertCellText(2, 0, "ARM Unplugged");
                    InterfacesTable.AssertCellText(2, 2, remainingLicenses);
                    break;
                case "ARM API":
                    InterfacesTable.AssertCellText(3, 0, "ARM API");
                    InterfacesTable.AssertCellText(3, 2, remainingLicenses);
                    break;
                case "ARM Risk Express":
                    InterfacesTable.AssertCellText(4, 0, "ARM Risk Express");
                    InterfacesTable.AssertCellText(4, 2, remainingLicenses);
                    break;
                default:
                    Assert.Fail("Interface Name: " + interfaceName + " Not Found In Interfaces Table");
                    break;
            }
        }

        public void ClickRowInInterfacesTableWithName(string interfaceName)
        {
            switch (interfaceName)
            {
                case "ARM Desktop":
                    InterfacesTable.AssertCellText(0, 0, "ARM Desktop");
                    InterfacesTable.ClickRow(0);
                    Waiter.Until(d => d.IsInitialDataLoadComplete());
                    WaitUntilPageIsReady();
                    break;
                case "ARM Apps":
                    InterfacesTable.AssertCellText(1, 0, "ARM Apps");
                    InterfacesTable.ClickRow(1);
                    Waiter.Until(d => d.IsInitialDataLoadComplete());
                    WaitUntilPageIsReady();
                    break;
                case "ARM Unplugged":
                    InterfacesTable.AssertCellText(2, 0, "ARM Unplugged");
                    InterfacesTable.ClickRow(2);
                    Waiter.Until(d => d.IsInitialDataLoadComplete());
                    WaitUntilPageIsReady();
                    break;
                case "ARM API":
                    InterfacesTable.AssertCellText(3, 0, "ARM API");
                    InterfacesTable.ClickRow(3);
                    Waiter.Until(d => d.IsInitialDataLoadComplete());
                    WaitUntilPageIsReady();
                    break;
                case "ARM Risk Express":
                    InterfacesTable.AssertCellText(4, 0, "ARM Risk Express");
                    InterfacesTable.ClickRow(4);
                    Waiter.Until(d => d.IsInitialDataLoadComplete());
                    WaitUntilPageIsReady();
                    break;
                default:
                    Assert.Fail("Interface Name: " + interfaceName + " Not Found In Interfaces Table");
                    break;
            }
        }

        public void SelectInterface(int rowNumber)
        {
            InterfacesTable.ClickRow(rowNumber);
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

        public ViewResourcesDialog ResourcesDialogue()
        {
            FocusWindow();
            AddButton.AssertEnabled();
            AddButton.Click();
            return OpenChildDialog<ViewResourcesDialog>();
        }

        public void Save()
        {
            FocusWindow();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void DeleteSelectedLicensedUsers()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("td#IAV_UserTable_delImg")));
            Driver.FindElement(By.CssSelector("td#IAV_UserTable_delImg")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertLicences(int rowNumber, int colNumber, string expected)
        {
            var savedDialog = new WebDriverInterfaceAccessDialog(Driver, Waiter);
            savedDialog.InterfacesTable.AssertCellText(rowNumber, colNumber, expected);

        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.AssertEnabled();
            HelpButton.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Assign_Interfaces_To_Users.htm"))
            {
                helpPage.AssertUrlEndsWith("Assign_Interfaces_To_Users.htm");
            }
        }

    }
}
