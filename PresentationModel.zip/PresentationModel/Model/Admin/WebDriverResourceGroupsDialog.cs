﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebDriverResourceGroupsDialog : WebDriverArmPage
    {
        public WebDriverTableCell GroupsTableControl;
        public WebDriverButton NewButton { get; set; }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WebDriverTableCell ResourcesTableControl;

        private WebDriverButton _insertButton;
        public WebDriverButton InsertButton
        {
            get
            {
                _insertButton = new WebDriverButton(Driver, Waiter, "tr td div span img[alt='Insert']", true);
                return _insertButton;
            }
        }

        private WebDriverButton _editButton;
        public WebDriverButton EditButton
        {
            get
            {
                _editButton = new WebDriverButton(Driver, Waiter, "tr td div span img[alt='Edit']", true);
                return _editButton;
            }
        }

        private WebDriverButton _updateButton;
        public WebDriverButton UpdateButton
        {
            get
            {
                _updateButton = new WebDriverButton(Driver, Waiter, "tr td div span img[alt='Update']", true);
                return _updateButton;
            }
        }

        private WebDriverButton _deleteButton;
        public WebDriverButton DeleteButton
        {
            get
            {
                _deleteButton = new WebDriverButton(Driver, Waiter, "tr td div span img[alt='Delete']", true);
                return _deleteButton;
            }
        }

        public WebDriverResourceGroupsDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "UserGroupsConfig.aspx")
        {
            GroupsTableControl = new WebDriverTableCell(driver, waiter, "table#UserGroupsConfigControl_UserGroupsGridControl_UserGroupGrid");
            NewButton = new WebDriverButton(driver, waiter, "UserGroupsConfigControl_NewGroup__btn");

            OkButton = new WebDriverButton(driver, waiter, "UserGroupsConfigControl_btnOk__btn");
            SaveButton = new WebDriverButton(driver, waiter, "UserGroupsConfigControl_btnSave__btn");
            CancelButton = new WebDriverButton(driver, waiter, "UserGroupsConfigControl_btnCancel__btn");
            HelpButton = new WebDriverButton(driver, waiter, "UserGroupsConfigControl_btnHelp__btn");

            ResourcesTableControl = new WebDriverTableCell(driver, waiter, "table#UserGroupsConfigControl_ResourceGrid");
        }

        public void EnterName(string name)
        {
            var cell = new WebDriverTableCell(Driver, Waiter, "table#UserGroupsConfigControl_UserGroupsGridControl_UserGroupGrid tr td table tr td[class='DataCell DataCell SortedDataCell EditDataCell'] input ");
            cell.EnterCellText(name);
        }

        private WebDriverTickBoxTableCell _checkBoxTableCell;
        public WebDriverTickBoxTableCell CheckBoxTableCell
        {
            get  
            {
                _checkBoxTableCell = new WebDriverTickBoxTableCell(Driver, Waiter, "table#UserGroupsConfigControl_ResourceGrid tr td table tr.Row td[class='DataCell AdminCheckBox'] div");
                return _checkBoxTableCell;
            }
        }

        public void Delete()
        {
            DeleteButton.AssertEnabled();
            DeleteButton.Click();
            Driver.SwitchTo().Alert().Accept();
        }

        public void Search(string name)
        {
            var cell = new WebDriverTableCell(Driver, Waiter, "table#UserGroupsConfigControl_UserGroupsGridControl_UserGroupGrid tr td table tr td div input ");
            cell.SearchName(name);
            cell.SearchName(Keys.Enter);
            Waiter.Until(d => !d.IsAjaxRequestInProgress());

        }
    }
}
