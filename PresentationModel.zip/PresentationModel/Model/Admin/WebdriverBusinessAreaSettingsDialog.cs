﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;


namespace PresentationModel.Model.Admin
{
    public class WebdriverBusinessAreaSettingsDialog : WebDriverArmPage
    {
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverTextField NumericPrecisionField { get; set; }
        public WebDriverTextField CostPrecisionField { get; set; }
        public WebDriverDropDown FormatTypeDropDown { get; set; }
        public WebDriverTickBoxControl UpdateImpactScoreTickBoxControl { get; set; }
        public WebDriverTickBoxControl WarnAchievedScoreReductionTickBoxControl { get; set; }
        public WebDriverTickBoxControl InherentScoreChangeComments { get; set; }
        public WebDriverTickBoxControl CurrentRiskScoreChangeComments { get; set; }
        public WebDriverTickBoxControl TargetRiskScoreChangeComments { get; set; }
        public WebDriverTickBoxControl RiskStatusChangeComments { get; set; }
        public WebDriverTickBoxControl EscalationChangeComments { get; set; }
        public WebDriverTickBoxControl FrequencyRisk { get; set; }
        public WebDriverDropDown RiskApprovalType { get; set; }
        public WebDriverDropDown RiskReviewType { get; set; }
        public WebDriverDropDown ScheduleUnit { get; set; }
        public WebDriverTextField CorporateBlackFlagLimit { get; set; }

        public WebdriverBusinessAreaSettingsDialog(IWebDriver driver, WebDriverWait waiter) 
            : base(driver, waiter, "Index")
        {
            OkButton = new WebDriverButton(driver, waiter, "OK");
            SaveButton = new WebDriverButton(driver, waiter, "Save");
            CancelButton = new WebDriverButton(driver, waiter, "Cancel");
            HelpButton = new WebDriverButton(driver, waiter, "Help");
            NumericPrecisionField = new WebDriverTextField(driver, waiter, "input#NumericFieldPrecision", true);
            CostPrecisionField = new WebDriverTextField(driver, waiter, "input#CostFieldPrecision", true);
            FormatTypeDropDown = new WebDriverDropDown(driver, waiter, "select#FormatType", true);
            RiskApprovalType = new WebDriverDropDown(driver, waiter, "select#RiskApprovalType", true);
            RiskReviewType = new WebDriverDropDown(driver, waiter, "select#ReviewPeriodType", true);
            UpdateImpactScoreTickBoxControl = new WebDriverTickBoxControl(driver, waiter, "input#EnableAdvancedMitigation", true,false);
            WarnAchievedScoreReductionTickBoxControl = new WebDriverTickBoxControl(driver, waiter, "input#EnableReductionWarning", true,false);
            InherentScoreChangeComments = new WebDriverTickBoxControl(driver, waiter, "input#EnableInherentScoreComments", true,false);
            CurrentRiskScoreChangeComments = new WebDriverTickBoxControl(driver, waiter, "input#EnableCurrentScoreComments", true,false);
            TargetRiskScoreChangeComments = new WebDriverTickBoxControl(driver, waiter, "input#EnableTargetScoreComments", true,false);
            RiskStatusChangeComments = new WebDriverTickBoxControl(driver, waiter, "input#EnableRiskStatusComments", true,false);
            EscalationChangeComments = new WebDriverTickBoxControl(driver, waiter, "input#EnableEscalationComments", true,false);
            FrequencyRisk = new WebDriverTickBoxControl(driver, waiter, "input#EnableFrequency", true,false);
            ScheduleUnit = new WebDriverDropDown(driver, waiter, "select#TimeUnitId", true);
            CorporateBlackFlagLimit = new WebDriverTextField(driver, waiter, "input#CorporateBlackFlagLimit", true);
            
        }

       public void EnableTheFunctionailty(string option)
        {
            switch (option)
            {
                case "Update impact Score when response complete":
                   UpdateImpactScoreTickBoxControl.Check();
                    break;
                case "Inherent risk Score change Comments":
                    InherentScoreChangeComments.Check();
                    break;
                default:
                    Assert.Fail("In Business Area Settings Dialog" + option + " Not Found ");
                    break;
            }
            
        }


       public void DisableTheFunctionailty(string option)
       {
           switch (option)
           {
               case "Update impact Score when response complete":
                   UpdateImpactScoreTickBoxControl.Uncheck();
                   break;
               case "Inherent risk Score change Comments":
                   InherentScoreChangeComments.Uncheck();
                   break;
               default:
                   Assert.Fail("In Business Area Settings Dialog" + option + " Not Found ");
                   break;
           }

       }

    }
}
