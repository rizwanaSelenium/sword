﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebDriverChartsQuadSheetConfigurationDialog : WebDriverArmPage
    {
        public WebDriverTickBoxControl TruncateTexttoFit;
        public WebDriverTickBoxControl ShowScoreBandColors;
        public WebDriverTickBoxControl ShowPid;
        public WebDriverTextField HorizontalDividerPosition;
        public WebDriverTextField VerticalDividerPosition;
        public WebDriverTextField FontSize;
        public WebDriverButton Cancel;
        public WebDriverButton Ok;
        public WebDriverButton Help;

        public WebDriverChartsQuadSheetConfigurationDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            TruncateTexttoFit = new WebDriverTickBoxControl(Driver, Waiter, "input#TruncateToFit", true);
            ShowScoreBandColors = new WebDriverTickBoxControl(Driver, Waiter, "input#ShowScoreBandColours", true);
            ShowPid = new WebDriverTickBoxControl(Driver, Waiter, "input#ShowPID", true);
            HorizontalDividerPosition = new WebDriverTextField(Driver, Waiter, "input#HorizontalDividePercentage", true);
            VerticalDividerPosition = new WebDriverTextField(Driver, Waiter, "input#VerticalDividePercentage", true);
            FontSize = new WebDriverTextField(Driver, Waiter, "input#FontSize",true);
            Cancel = new WebDriverButton(Driver, Waiter, "a#Cancel", true);
            Ok = new WebDriverButton(Driver, Waiter, "a#OK", true);
            Help = new WebDriverButton(Driver, Waiter, "a#help", true);
        }

        public void ClickOk()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            Ok.Click();

            Waiter.Until(d => !d.WindowHandles.Contains((currentWindowHandle)));

            if ((Driver.WindowHandles).Contains(currentWindowHandle))
            {
                Driver.SwitchTo().Window(currentWindowHandle);
                Driver.Close();

                    new WebDriverWait(Driver, TimeSpan.FromSeconds(1)).Until(d => d.HasAlertWindow());
                    Driver.SwitchTo().Alert().Accept();
            }
        }
    }
}
