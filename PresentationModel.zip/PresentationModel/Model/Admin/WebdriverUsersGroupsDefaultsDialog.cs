﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebdriverUsersGroupsDefaultsDialog : WebDriverArmPage
    {
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverDropDown RoleDropDown { get; set; }
        public WebDriverTextField DomainTextField { get; set; }
        public WebDriverTextField BlackFlagTextField { get; set; }
        public WebDriverTextField RedFlagTextField { get; set; }

        public WebdriverUsersGroupsDefaultsDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Index")
        {
            SaveButton = new WebDriverButton(driver, waiter, "input#Save", true);
            CancelButton = new WebDriverButton(driver, waiter, "a#cancel", true);
            HelpButton = new WebDriverButton(driver, waiter, "a#help", true);
            RoleDropDown = new WebDriverDropDown(driver, waiter, "select#Role", true);
            DomainTextField = new WebDriverTextField(driver, waiter, "input#Domain", true);
            BlackFlagTextField = new WebDriverTextField(driver, waiter, "input#BlackFlagLimit", true);
            RedFlagTextField = new WebDriverTextField(driver, waiter, "input#RedFlagLimit", true);
        }

        public void ClickSave()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            SaveButton.Click();

            if ((Driver.WindowHandles).Contains(currentWindowHandle))
            {
                Driver.SwitchTo().Window(currentWindowHandle);
                Driver.Close();

                    Waiter.Until(d => d.HasAlertWindow());
             
                    Driver.SwitchTo().Alert().Accept();
            }
        }
    }
}
