﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebDriverIntegrationSecurityDialog : WebDriverArmPage
    {
        public WebDriverDropDown Groups;
        public WebDriverTickBoxControl IntegrationSecurity;
        public WebDriverButton OkButton;
        public WebDriverButton SaveButton;
        public WebDriverButton CancelButton;
        public WebDriverButton HelpButton;

        public WebDriverIntegrationSecurityDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Index")
        {
            Groups = new WebDriverDropDown(driver, waiter, "select#Groups", true);
            IntegrationSecurity = new WebDriverTickBoxControl(driver, waiter, "input[name='[0].EnableCheckBox']", true);
            OkButton = new WebDriverButton(driver, waiter, "input#OK", true);
            SaveButton = new WebDriverButton(driver, waiter, "input#Save",true);
            CancelButton = new WebDriverButton(driver, waiter, "a#cancel",true);
            HelpButton = new WebDriverButton(driver, waiter, "a#help",true);
        }
    }
}