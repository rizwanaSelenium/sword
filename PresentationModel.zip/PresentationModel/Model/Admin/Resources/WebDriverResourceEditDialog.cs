﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.HistorySearch;

namespace PresentationModel.Model.Admin.Resources
{
    
    public class WebDriverResourceEditDialog : WebDriverArmPage
    {
        private WebDriverTextField _lastName;

        public WebDriverTextField LastName
        {
            get { return _lastName ?? (_lastName = new WebDriverTextField(Driver, Waiter, "REV_LastName")); }
        }

        private WebDriverGroupPicker _groups;
        public WebDriverGroupPicker Groups
        {
            get { return _groups ?? (_groups = new WebDriverGroupPicker(Driver, Waiter, "REV_Groups")); }
        }

        private WebDriverTextField _user;
        public WebDriverTextField User
        {
            get { return _user ?? (_user = new WebDriverTextField(Driver, Waiter, "REV_UserName")); }
        }

        private WebDriverTextField _domain;
        public WebDriverTextField Domain
        {
            get { return _domain ?? (_domain = new WebDriverTextField(Driver, Waiter, "REV_Domain")); }
        }

        private WebDriverDropDown _role;
        public WebDriverDropDown Role
        {
            get { return _role ?? (_role = new WebDriverDropDown(Driver, Waiter, "REV_Role")); }
        }

        private WebDriverTickBoxControl _licensedToArmDesktop;
        public WebDriverTickBoxControl LicensedToArmDesktop
        {
            get
            {
                return _licensedToArmDesktop ?? (_licensedToArmDesktop = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMDesktop"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmRiskExpress;
        public WebDriverTickBoxControl LicensedToArmRiskExpress
        {
            get
            {
                return _licensedToArmRiskExpress ?? (_licensedToArmRiskExpress = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMRiskExpress"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmApps;
        public WebDriverTickBoxControl LicensedToArmApps
        {
            get { return _licensedToArmApps ?? (_licensedToArmApps = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMApps")); }
        }

        private WebDriverTickBoxControl _licensedToArmUnplugged;
        public WebDriverTickBoxControl LicensedToArmUnplugged
        {
            get
            {
                return _licensedToArmUnplugged ?? (_licensedToArmUnplugged = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMUnplugged"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmScheduleAnalysis;
        public WebDriverTickBoxControl LicensedToArmScheduleAnalysis
        {
            get
            {
                return _licensedToArmScheduleAnalysis ?? (_licensedToArmScheduleAnalysis = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMScheduleAnalysis"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmWebServiceApi;
        public WebDriverTickBoxControl LicensedToArmWebServiceApi
        {
            get
            {
                return _licensedToArmWebServiceApi ?? (_licensedToArmWebServiceApi = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMWebServiceApi"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmRiskVisualiser;

        public WebDriverTickBoxControl LicensedToArmRiskVisualiser
        {
            get
            {
                return _licensedToArmRiskVisualiser ?? (_licensedToArmRiskVisualiser = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMRiskVisualiser"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmSnappit;
        public WebDriverTickBoxControl LicensedToArmSnappit
        {
            get
            {
                return _licensedToArmSnappit ?? (_licensedToArmSnappit = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMMobileIncident"));
            }
        }

        private WebDriverTickBoxControl _licensedToArmBowTie;
        public WebDriverTickBoxControl LicensedToArmBowTie
        {
            get
            {
                return _licensedToArmBowTie ?? (_licensedToArmBowTie = new WebDriverTickBoxControl(Driver, Waiter, "REV_LicensedToARMBowTie"));
            }
        }

        private WebDriverTextField _redFlagLimit;
        public WebDriverTextField RedFlagLimit
        {
            get { return _redFlagLimit ?? (_redFlagLimit = new WebDriverTextField(Driver, Waiter, "REV_CostLimit")); }
        }

        private WebDriverTextField _blackFlagLimit;
        public WebDriverTextField BlackFlagLimit
        {
            get
            {
                return _blackFlagLimit ?? (_blackFlagLimit = new WebDriverTextField(Driver, Waiter, "REV_BlackFlagLimit"));
            }
        }

        private WebDriverButton _securityAttributesButton;
        public WebDriverButton SecurityAttributesButton
        {
            get
            {
                return _securityAttributesButton ?? (_securityAttributesButton = new WebDriverButton(Driver, Waiter, "REV_SecurityAttributes_btn"));
            }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "REV_OK_btn")); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "REV_Save_btn")); }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get { return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, "REV_New_btn")); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "REV_Cancel_btn")); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "REV_Help_btn")); }
        }

        private WebDriverButton _historyButton;
        public WebDriverButton HistoryButton
        {
            get { return _historyButton ?? (_historyButton = new WebDriverButton(Driver, Waiter, "REV_History_btn")); }
        }

        private WebDriverButton _complianceButton;
        public WebDriverButton ComplianceButton
        {
            get { return _complianceButton ?? (_complianceButton = new WebDriverButton(Driver, Waiter, "REV_Compliance_btn")); }
        }

        private WebDriverTextField _resourceId;
        public WebDriverTextField ResourceId
        {
            get { return _resourceId ?? (_resourceId = new WebDriverTextField(Driver, Waiter, "REV_Key")); }
        }

        public WebDriverResourceEditDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ResourceEntry.aspx")
        {
            WaitUntilPageIsReady();
        }

        public WebDriverGroupPickerDialog UserGroupPickerDialog()
        {
            Groups.Click();
            return OpenChildDialog<WebDriverGroupPickerDialog>();
        }

        public void Save()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            WaitUntilUiSpinnerIsNotDisplayed();
            Waiter.Until(s => !SaveButton.IsEnabled());
        }

        public void SaveWithNoInterfacesOrGroups()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noInterfacePrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noInterfacePromptText = noInterfacePrompt.Text;
            Assert.True(noInterfacePromptText.Contains("No interface allocated to user"));
            noInterfacePrompt.FindElement(By.CssSelector("button[title='Yes']")).Click();

            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noGroupPrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noGroupPromptText = noGroupPrompt.Text;
            Assert.True(noGroupPromptText.Contains("It is recommended that the user is assigned to a user group"));
            noGroupPrompt.FindElement(By.CssSelector("button[title='No']")).Click();
        }

        public void SaveWithNoInterfaces()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noInterfacePrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noInterfacePromptText = noInterfacePrompt.Text;
            Assert.True(noInterfacePromptText.Contains("No interface allocated to user"));
            noInterfacePrompt.FindElement(By.CssSelector("button[title='Yes']")).Click();
        }

        public void SaveWithNoGroups()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noGroupPrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noGroupPromptText = noGroupPrompt.Text;
            Assert.True(noGroupPromptText.Contains("It is recommended that the user is assigned to a user group"));
            noGroupPrompt.FindElement(By.CssSelector("button[title='No']")).Click();
        }

        public IncidentHistorySearchDialog ViewResourceHistory()
        {
            HistoryButton.AssertEnabled();
            HistoryButton.Click();

            return OpenChildDialog<IncidentHistorySearchDialog>();
        }

        public WebdriverResourceSecurityDialog OpenResourceSecurityDialog()
        {
            SecurityAttributesButton.Click();
            return OpenChildDialog<WebdriverResourceSecurityDialog>();
        }

        private WebDriverComplianceResourceAdminDialog _complianceResourceAdmin;
        public WebDriverComplianceResourceAdminDialog OpenResourceAdminDialog()
        {
            FocusWindow();
            ComplianceButton.Click();
            WaitUntilPageIsReady();
            _complianceResourceAdmin = new WebDriverComplianceResourceAdminDialog(Driver, Waiter);
            _complianceResourceAdmin.FocusWindow();
            return _complianceResourceAdmin;
        }

        public override void Close()
        {
            FocusWindow();
            CancelButton.Click();

        }
    }
}
