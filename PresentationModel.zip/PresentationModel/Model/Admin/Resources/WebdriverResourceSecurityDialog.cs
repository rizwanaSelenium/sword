﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebdriverResourceSecurityDialog : WebDriverArmPage
    {
        public WebDriverTableControl DoesNotHaveAttributes { get; set; }
        public WebDriverTableControl HasAttributes { get; set; }
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverButton AddButton { get; set; }
        public WebDriverButton RemoveButton { get; set; }
        public WebDriverTickBoxControl SelectAllAssignedAttributes { get; set; }
        public WebdriverResourceSecurityDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "ResourceSecurityAttrs.aspx")
        {
            var driver1 = driver;
            var waiter1 = waiter;
            DoesNotHaveAttributes = new WebDriverTableControl(driver1, waiter1, "RootView_NonAssignedAttributesTable");
            HasAttributes = new WebDriverTableControl(driver1, waiter1, "RootView_AssignedAttributesTable");
            OkButton = new WebDriverButton(driver1, waiter1, "RootView_OK_btn");
            CancelButton = new WebDriverButton(driver1, waiter1, "RootView_Cancel_btn");
            HelpButton = new WebDriverButton(driver1, waiter1, "RootView_Help_btn");
            AddButton = new WebDriverButton(driver1, waiter1, "RootView_Add_btn");
            RemoveButton = new WebDriverButton(driver1, waiter1, "RootView_Remove_btn");
            SelectAllAssignedAttributes = new WebDriverTickBoxControl(driver1, waiter1, "input#RootView_AssignedAttributesTable_selectAll",true);
        }
    }
}
