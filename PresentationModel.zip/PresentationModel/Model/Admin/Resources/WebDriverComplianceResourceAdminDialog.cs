﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebDriverComplianceResourceAdminDialog : WebDriverArmPage
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;
        private AngularMultiSelectTreeTableField _complianceRiskFolder;

        public WebDriverComplianceResourceAdminDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "ResourceAdmin")
        {
            _driver = driver;
            _waiter = waiter;
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(_driver, _waiter, "ok_btn")); }
        }

        public AngularMultiSelectTreeTableField ComplianceRiskFolder
        {
            get { return _complianceRiskFolder ?? (_complianceRiskFolder = new AngularMultiSelectTreeTableField(_driver, _waiter, "field_833")); }
        }
    }
  }

