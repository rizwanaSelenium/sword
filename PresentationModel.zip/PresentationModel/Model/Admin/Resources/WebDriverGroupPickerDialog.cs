﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebDriverGroupPickerDialog : WebDriverArmPage
    {
        private WebDriverTableControl _groupsTable;
        public WebDriverTableControl GroupsTable
        {
            get
            {
                _groupsTable = new WebDriverTableControl(Driver, Waiter, "GPV_GroupTable");
                return _groupsTable;
            }
        }
        public WebDriverButton SelectButton { get; set; }

        public WebDriverGroupPickerDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "GroupPicker.aspx")
        {
            SelectButton = new WebDriverButton(driver, waiter, "button#GPV_SelectGroups_btn", true);
        }

        public void Select()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            SelectButton.Click();
            Waiter.Until(d => !(d.WindowHandles).Contains(currentWindowHandle));
        }

        public void SelectGroup(string groupToSelect)
        {
            GroupsTable.Search("");
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.Search(groupToSelect);
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.AssertCellText(0, 0, groupToSelect);
            GroupsTable.CheckRow(0);
            Select();
        }

        public void DeselectGroup(string groupToDeselect)
        {
            GroupsTable.Search("");
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.Search(groupToDeselect);
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.AssertCellText(0, 0, groupToDeselect);
            GroupsTable.UncheckRow(0);
        }

        public void DeselectGroupAndCloseGroupPickerDialogue(string groupToDeselect)
        {
            GroupsTable.Search("");
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.Search(groupToDeselect);
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            GroupsTable.AssertCellText(0, 0, groupToDeselect);
            GroupsTable.UncheckRow(0);
            var currentWindowHandle = Driver.CurrentWindowHandle;
            SelectButton.AssertEnabled();
            SelectButton.Click();
            Waiter.Until(d => !(d.WindowHandles).Contains(currentWindowHandle));
        }
    }
}
