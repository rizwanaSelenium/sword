﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebDriverResourceListDialog : WebDriverArmPage
    {
        private WebDriverTableControl _resourcesTable;
        public WebDriverTableControl ResourcesTable
        {
            get
            {
                _resourcesTable = new WebDriverTableControl(Driver, Waiter, "VRV_ResourceTable");
                return _resourcesTable;
            }
        }

        private WebDriverButton _newUserButton;
        public WebDriverButton NewUserButton
        {
            get { return _newUserButton ?? (_newUserButton = new WebDriverButton(Driver, Waiter, "VRV_NewResource_btn")); }
        }

        private WebDriverButton _deleteButton;
        public WebDriverButton DeleteButton
        {
            get { return _deleteButton ?? (_deleteButton = new WebDriverButton(Driver, Waiter, "VRV_DeleteResource_btn")); }
        }

        private WebDriverButton _emailButton;
        public WebDriverButton EmailButton
        {
            get { return _emailButton ?? (_emailButton = new WebDriverButton(Driver, Waiter, "VRV_EmailMultiple_btn")); }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "VRV_Close_btn")); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "VRV_Help_btn")); }
        }
       
        public WebDriverResourceListDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ViewResources.aspx")
        {
            WaitUntilPageIsReady();
        }

        public WebDriverResourceEditDialog UsersEditDialog()
        {
            ResourcesTable.ClickLinkInElement(0, 0);

            return OpenChildDialog<WebDriverResourceEditDialog>();
        }


        public WebDriverResourceEditDialog NewUserDialog()
        {
            NewUserButton.Click();
            return OpenChildDialog<WebDriverResourceEditDialog>();
        }

        public WebDriverEditResourceFormsAuthDialogue NewUserFormsAuthDialogue()
        {
            NewUserButton.Click();
            return OpenChildDialog<WebDriverEditResourceFormsAuthDialogue>();
        }

        public WebDriverResourceEditDialog OpenedResource()
        {
            return OpenChildDialog<WebDriverResourceEditDialog>();
        }

        public WebDriverEditResourceFormsAuthDialogue OpenedFormsAuthResource()
        {
            return OpenChildDialog<WebDriverEditResourceFormsAuthDialogue>();
        }

        public void DeleteResource(string resourceToDelete)
        {
            FocusWindow();
            // Clear the Resource Table Search first & wait for table
            ResourcesTable.Search("");
            WaitForResourceTableToBeReady();
            // Search for the Resource to delete & wait for table
            ResourcesTable.Search(resourceToDelete);
            WaitForResourceTableToBeReady();
            // Check that the 1st entry contains the Resource we want
            ResourcesTable.AssertCellTextContains(0, 0, resourceToDelete);
            // Check the 1st row
            ResourcesTable.CheckRow(0);
            // Press Delete button
            Delete();
            // Wait for prompt and click Yes and wait for table
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            Driver.FindElement(By.CssSelector("div#UIPrompt")).FindElement(By.CssSelector("button[title='Yes']")).Click();
            WaitForResourceTableToBeReady();
            // Clear Resource Table Serach & wait for table
            ResourcesTable.Search("");
            WaitForResourceTableToBeReady();
            // Search for Resource to delete & ensure it is not found
            ResourcesTable.Search(resourceToDelete);
            WaitForResourceTableToBeReady();
            ResourcesTable.AssertCellTextContains(0, 0, "");
        }

        public void DeleteResourceConfirmResourceInUse(string resourceToDelete)
        {
            DeleteResource(resourceToDelete);
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var resourceInUsePrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var resourceInUseTextElement = Driver.FindElement(By.CssSelector("div#UIPrompt td +td"));
            var resourceInUsePromptText = resourceInUseTextElement.Text;
            Assert.True(resourceInUsePromptText.Contains("The following resources have not been deleted as they are in use."));
            resourceInUsePrompt.FindElement(By.CssSelector("input[type='checkbox']")).Click();
            var deleteButton = resourceInUsePrompt.FindElement(By.CssSelector("button"));
            Assert.True(deleteButton.Text.Contains("Delete"));
            deleteButton.Click();
        }

        public void OpenResource(string resourceToOpen)
        {
            FocusWindow();
            ResourcesTable.Search("");
            WaitUntilPageIsReady();
            ResourcesTable.Search(resourceToOpen);
            WaitUntilPageIsReady();
            ResourcesTable.AssertCellTextContains(0, 0, resourceToOpen);
            ResourcesTable.ClickLinkInElement(0, 0);
        }

        public void WaitForResourceTableToBeReady()
        {
            WaitUntilPageIsReady();
        }

        public void Delete()
        {
            DeleteButton.AssertEnabled();
            DeleteButton.Click();
        }

        public void AssertEditbuttonforSelectedResource()
        {
            ResourcesTable.AssertCellTextContains(0,3,"");

        }

        public override void Close()
        {
            FocusWindow();
            CloseButton.Click();
        }
    }
}
