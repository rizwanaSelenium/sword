﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebDriverUserOptionsDialog : WebDriverArmPage
    {
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton Cancel { get; set; }
        public WebDriverButton Help { get; set; }
        public WebDriverButton ClearInstance { get; set; }

        public WebDriverTextField UserName { get; set; }
        public WebDriverTextField Domain { get; set; }
        public WebDriverTextField Role { get; set; }
        public WebDriverTextField Instance { get; set; }
        public WebDriverTextField DesktopPageSize { get; set; }
        public WebDriverTextField SaveFolderPath { get; set; }

        public WebDriverDropDown DefaultBusinessArea { get; set; }
        public WebDriverDropDown DefaultFilter { get; set; }
        public WebDriverDropDown LabelSet { get; set; }
        public WebDriverDropDown Language { get; set; }
        public WebDriverDropDown ExpandTreesToDepth { get; set; }
        public WebDriverDropDown MaxExpandedTreeNodes { get; set; }

        public WebDriverTickBoxControl ShowToolbarIcons { get; set; }
        public WebDriverTickBoxControl AlertDigests { get; set; }

        public WebDriverUserOptionsDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "UserOptions.aspx")
        {
            OkButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn");
            SaveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn");
            Cancel = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn");
            Help = new WebDriverButton(Driver, Waiter, "RootView_Help_btn");

            ClearInstance = new WebDriverButton(Driver, Waiter, "RootView_ClearInstance_btn");

            UserName = new WebDriverTextField(Driver, Waiter, "RootView_UserName");
            Domain = new WebDriverTextField(Driver, Waiter, "RootView_Domain");
            Role = new WebDriverTextField(Driver, Waiter, "RootView_Role");
            Instance = new WebDriverTextField(Driver, Waiter, "RootView_Instance");
            DesktopPageSize = new WebDriverTextField(Driver, Waiter, "RootView_DesktopPageSize");
            SaveFolderPath = new WebDriverTextField(Driver, Waiter, "RootView_SaveFolderPath");

            DefaultBusinessArea = new WebDriverDropDown(Driver, Waiter, "RootView_DefaultBusinessArea");
            DefaultFilter = new WebDriverDropDown(Driver, Waiter, "RootView_DefaultFilter");
            LabelSet = new WebDriverDropDown(Driver, Waiter, "RootView_LabelSet");
            Language = new WebDriverDropDown(Driver, Waiter, "RootView_Language");
            ExpandTreesToDepth = new WebDriverDropDown(Driver, Waiter, "RootView_ExpandTreeToDepth");
            MaxExpandedTreeNodes = new WebDriverDropDown(Driver, Waiter, "RootView_TreeNodeLimit");

            ShowToolbarIcons = new WebDriverTickBoxControl(Driver, Waiter, "RootView_ShowToolbarIcons");
            AlertDigests = new WebDriverTickBoxControl(Driver, Waiter, "RootView_AlertDigests");
        }

        public void AssertHelpPageCorrect()
        {
            Help.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Options.htm"))
            {
                helpPage.AssertUrlEndsWith("Options.htm");
            }
        }

        public void AssertDialogLoadsCorrectly()
        {
            Instance.AssertReadOnly();
            Instance.AssertLabelEquals("Instance:");
            Instance.AssertTooltipEquals("Instance Opened By Default on Entry");

            Role.AssertReadOnly();
            Role.AssertLabelEquals("Role:");
            Role.AssertTooltipEquals("User Role");

            Domain.AssertReadOnly();
            Domain.AssertLabelEquals("Domain:");
            Domain.AssertTooltipEquals("User Domain");

            UserName.AssertReadOnly();
            UserName.AssertLabelEquals("User Name:");
            UserName.AssertTooltipEquals("User Name");

            DefaultBusinessArea.AssertEnabled();
            DefaultBusinessArea.AssertAccessKeyEquals("B");
            DefaultBusinessArea.AssertLabelEquals("Business Area:");
            DefaultBusinessArea.AssertTooltipEquals("No Default");
            DefaultBusinessArea.AssertOptionCountEquals(2);
            DefaultBusinessArea.AssertContainsOptions("Example Organisation", "No Default");

            DefaultFilter.AssertReadOnly();
            DefaultFilter.AssertAccessKeyEquals("f");
            DefaultFilter.AssertLabelEquals("Filter:");
            DefaultFilter.AssertTooltipEquals("No Filter");

            AlertDigests.AssertEnabled();
            AlertDigests.AssertAccessKeyEquals("r");
            AlertDigests.AssertLabelEquals("Alert Digests:");
            AlertDigests.AssertTooltipEquals("Receive email alerts as daily digest");
            AlertDigests.AssertUnchecked();

            Language.AssertEnabled();
            Language.AssertLabelEquals("Language:");
            Language.AssertTooltipEquals("System Default Language");
            Language.AssertContainsOptions("Browser Default", "English");
            Language.AssertEquals("System Default Language");

            SaveFolderPath.AssertEnabled();
            SaveFolderPath.AssertAccessKeyEquals("v");
            SaveFolderPath.AssertLabelEquals("Save Folder:");
            SaveFolderPath.AssertTooltipEquals("Default Chart Save Folder");
            SaveFolderPath.AssertEquals("c:\\");

            DesktopPageSize.AssertEnabled();
            DesktopPageSize.AssertAccessKeyEquals("p");
            DesktopPageSize.AssertLabelEquals("Records per page:");
            DesktopPageSize.AssertTooltipEquals("Number of records per page (max 50)");
            DesktopPageSize.AssertEquals("25");

            LabelSet.AssertEnabled();
            LabelSet.AssertAccessKeyEquals("l");
            LabelSet.AssertLabelEquals("Label Set:");
            LabelSet.AssertTooltipEquals("System Default");
            LabelSet.AssertContainsOptions("Standard Label Set");
            LabelSet.AssertEquals("System Default");

            ShowToolbarIcons.AssertEnabled();
            ShowToolbarIcons.AssertAccessKeyEquals("i");
  
            ShowToolbarIcons.AssertTooltipEquals("Show icon toolbars");
            ShowToolbarIcons.AssertChecked();

            ExpandTreesToDepth.AssertEnabled();
            ExpandTreesToDepth.AssertLabelEquals("Auto Expand Trees To Depth:");
            ExpandTreesToDepth.AssertTooltipEquals("1");
            ExpandTreesToDepth.AssertContainsOptions("1", "2", "3", "4", "5");
            ExpandTreesToDepth.AssertEquals("1");

            MaxExpandedTreeNodes.AssertEnabled();
            MaxExpandedTreeNodes.AssertLabelEquals("Maximum Expanded Tree Nodes:");
            MaxExpandedTreeNodes.AssertTooltipEquals("500");
            MaxExpandedTreeNodes.AssertContainsOptions("500", "600", "700", "800", "900", "1000", "2000", "3000", "4000", "5000");
            MaxExpandedTreeNodes.AssertEquals("500");

            OkButton.AssertEnabled();
            OkButton.AssertTextEquals("OK");
            SaveButton.AssertDisabled();
            SaveButton.AssertTextEquals("Save");
            Cancel.AssertEnabled();
            Cancel.AssertTextEquals("Cancel");
            Help.AssertEnabled();
            Help.AssertTextEquals("Help");
        }

        public void Save()
        {
            SaveButton.Click();
        }

        public void Ok()
        {
            OkButton.Click();
        }
    }
}
