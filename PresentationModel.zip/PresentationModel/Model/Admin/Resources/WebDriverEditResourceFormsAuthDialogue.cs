﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Resources
{
    public class WebDriverEditResourceFormsAuthDialogue : WebDriverArmPage
    {
        public WebDriverTextField LastName { get; private set; }

        public WebDriverTextField Email { get; private set; }

        public WebDriverGroupPicker Groups { get; private set; }

        public WebDriverDropDown Role { get; set; }

        public WebDriverTickBoxControl LicensedToArmDesktop { get; private set; }
        public WebDriverTickBoxControl LicensedToArmApps { get; private set; }
        public WebDriverTickBoxControl LicensedToArmRiskExpress { get; private set; }
        public WebDriverTickBoxControl LicensedToArmWebServiceApi { get; private set; }
        public WebDriverTickBoxControl LicensedToArmUnplugged { get; private set; }
        public WebDriverTickBoxControl LicensedToArmScheduleAnalysis { get; private set; }

        public WebDriverTextField RedFlagLimit { get; set; }
        public WebDriverTextField BlackFlagLimit { get; set; }

        public WebDriverButton SecurityAttributesButton { get; set; }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; private set; }
        public WebDriverButton NewButton { get; private set; }
        public WebDriverButton CancelButton { get; private set; }
        public WebDriverButton HelpButton { get; private set; }

        public WebDriverEditResourceFormsAuthDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ResourceEntry.aspx")
        {
            LastName = new WebDriverTextField(driver, waiter, "REV_LastName");

            Email = new WebDriverTextField(driver, waiter, "REV_Email");

            Groups = new WebDriverGroupPicker(driver, waiter, "REV_Groups");

            Role = new WebDriverDropDown(driver, waiter, "REV_Role");

            LicensedToArmDesktop = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMDesktop");
            LicensedToArmApps = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMApps");
            LicensedToArmRiskExpress = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMRiskExpress");
            LicensedToArmWebServiceApi = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMWebServiceApi");
            LicensedToArmUnplugged = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMUnplugged");
            LicensedToArmScheduleAnalysis = new WebDriverTickBoxControl(driver, waiter, "REV_LicensedToARMScheduleAnalysis");

            RedFlagLimit = new WebDriverTextField(driver, waiter, "REV_CostLimit");
            BlackFlagLimit = new WebDriverTextField(driver, waiter, "REV_BlackFlagLimit");

            SecurityAttributesButton = new WebDriverButton(driver, waiter, "REV_SecurityAttributes_btn");

            OkButton = new WebDriverButton(driver, waiter, "REV_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "REV_Save_btn");
            NewButton = new WebDriverButton(driver, waiter, "REV_New_btn");
            CancelButton = new WebDriverButton(driver, waiter, "REV_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "REV_Help_btn");

            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public WebDriverGroupPickerDialog UserGroupPickerDialog()
        {
            Groups.Click();
            return OpenChildDialog<WebDriverGroupPickerDialog>();
        }

        public void Save()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(s => !SaveButton.IsEnabled());
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void SaveWithNoInterfacesOrGroups()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());

            WaitUntilPageIsReady();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noInterfacePrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noInterfacePromptText = noInterfacePrompt.Text;
            Assert.True(noInterfacePromptText.Contains("No interface allocated to user"));
            noInterfacePrompt.FindElement(By.CssSelector("button[title='Yes']")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());

            WaitUntilPageIsReady();
            var noGroupPrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noGroupPromptText = noGroupPrompt.Text;
            Assert.True(noGroupPromptText.Contains("It is recommended that the user is assigned to a user group"));
            noGroupPrompt.FindElement(By.CssSelector("button[title='No']")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void SaveWithNoInterfaces()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());

            WaitUntilPageIsReady();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noInterfacePrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noInterfacePromptText = noInterfacePrompt.Text;
            Assert.True(noInterfacePromptText.Contains("No interface allocated to user"));
            noInterfacePrompt.FindElement(By.CssSelector("button[title='Yes']")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void SaveWithNoGroups()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());

            WaitUntilPageIsReady();
            Waiter.Until(d => d.FindElement(By.CssSelector("div#UIPrompt")));
            var noGroupPrompt = Driver.FindElement(By.CssSelector("div#UIPrompt"));
            var noGroupPromptText = noGroupPrompt.Text;
            Assert.True(noGroupPromptText.Contains("It is recommended that the user is assigned to a user group"));
            noGroupPrompt.FindElement(By.CssSelector("button[title='No']")).Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }
    }
}
