﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Security
{
    public class WebDriverBusinessAreaAccess : WebDriverArmPage
    {
        public WebDriverButton HistoryButton;
        public WebDriverButton SaveButton;
        public WebDriverButton OkButton;
        public WebDriverButton CancelButton;
        public WebDriverButton HelpButton;
        public WebDriverTableControl BAreaAccessItemTable;

        public WebDriverBusinessAreaAccess(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "BusinessAreaAccess.aspx")
        {
            HistoryButton = new WebDriverButton(driver, waiter, "BusinessAreaAccessControl_btnAudit__btn");
            SaveButton = new WebDriverButton(driver, waiter, "BusinessAreaAccessControl_btnSave__btn");
            OkButton = new WebDriverButton(driver, waiter, "BusinessAreaAccessControl_btnOk__btn");

            CancelButton = new WebDriverButton(driver, waiter, "BusinessAreaAccessControl_btnCancel__btn");
            HelpButton = new WebDriverButton(driver, waiter, "BusinessAreaAccessControl_btnHelp__btn");

            
        }

        public void SelectFolderAssignAccess(string folderName, string access)
        {
            var bFolders = Driver.FindElements(By.XPath("//table[starts-with(@id,'BusinessAreaAccessControl_Tree_item_')]"));
            foreach (var foldername in bFolders)
            {
                if (foldername.Text.Trim().Equals(folderName))
                {
                    var arrowimage = foldername.FindElement(By.XPath(".//img[starts-with(@id,'img_arrow')]"));
                    arrowimage.Click();
                    var accessMenu = Driver.FindElements(By.XPath("//td[starts-with(@id,'BusinessAreaAccessControl_AccessMenu')]"));
                    foreach (var accessRole in accessMenu)
                    {
                        if (accessRole.Text.Trim().Equals(access))
                        {
                            accessRole.Click();
                            AcceptAlert();
                            SaveButton.Click();
                        }
                    }
                }                
            }            
        }
    }
}

