﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.HistorySearch;

namespace PresentationModel.Model.Admin
{
    public class WebdriverIncidentHistoryDataDialog : WebDriverArmPage
    {
        public WebDriverTextField FuctionAreaControl { get; set; }
        public WebDriverTextField UserField { get; set; }
        public WebDriverTextField RecordTypeandIdField { get; set; }
        public IWebElement ShowOnlyChangesFields { get; set; }
        public WebDriverTextField TotalItemsCount { get; set; }
        public WebDriverTextField ItemsPerPageLabel { get; set; }
        public WebDriverButton HomeButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton NextButton { get; set; }
        public WebDriverButton PreviousButton { get; set; }
        public WebDriverTextField HistoryIdField { get; set; }

        public WebdriverIncidentHistoryDataDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Index")
        {
            FuctionAreaControl = new WebDriverTextField(Driver, Waiter, "label#function", true);
            UserField = new WebDriverTextField(Driver, Waiter, "label#resource", true);
            RecordTypeandIdField = new WebDriverTextField(Driver, Waiter, "label#recordType", true);
            ShowOnlyChangesFields = Driver.FindElement(By.CssSelector("input#searchSelectedElement"));
            TotalItemsCount = new WebDriverTextField(Driver, Waiter, "div.ui-grid-pager-count span.ng-binding", true);
            ItemsPerPageLabel = new WebDriverTextField(Driver, waiter, "SPAN.ui-grid-pager-row-count-label", true);
            HomeButton = new WebDriverButton(Driver, Waiter, "Home");
            HelpButton = new WebDriverButton(Driver, Waiter, "Help");
            CloseButton = new WebDriverButton(Driver, Waiter, "Close");
            NextButton = new WebDriverButton(Driver, Waiter, "Next");
            PreviousButton = new WebDriverButton(Driver, Waiter, "Previous");
            HistoryIdField = new WebDriverTextField(Driver, Waiter, "label#historyid", true);
        }

        private WebDriverDropDown _showEntriesControl;

        public WebDriverDropDown ShowEntriesControl
        {
            get
            {
                _showEntriesControl = new WebDriverDropDown(Driver, Waiter, "select", true);
                return _showEntriesControl;
            }
        }

        public void AssertIncidentHistoryOldValueNewValue(string name, string oldvalue, string newvalue)
        {
            var historySearchDetailTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var historySearchTablefield =
                historySearchDetailTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            foreach (var element in historySearchTablefield)
            {
                String[] rowText = Regex.Split(element.Text, "\r\n");
                if (rowText[0].Equals(name))
                {
                    var cell = element.FindElements(By.CssSelector(".ui-grid-cell"));

                    var field = cell[0].Text;

                    string originalValue;
                    try
                    {
                        originalValue = cell[1].Text;
                    }
                    catch (Exception)
                    {
                        originalValue = "";
                    }

                    var newValue = cell[2].Text;

                    Assert.AreEqual(name, field);
                    Assert.AreEqual(oldvalue, originalValue);
                    Assert.AreEqual(newvalue, newValue);
                    break;
                }
            }
        }

        public void AssertIncidentResponseFieldValue(string name, string oldvalue, string value)
        {
            var historySearchDetailTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fields = historySearchDetailTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var row =
                fields.FirstOrDefault(
                    x => x.Text.Contains(name));
            if (row != null)
            {
                var contentCellsOfRow = row.FindElements(By.CssSelector(".ui-grid-cell-contents"));
                var myValue = contentCellsOfRow[1].Text;
                Assert.AreEqual(value, myValue);
            }
            else
            {
                Assert.Fail("No Rows found, skipped check.");
            }
        }

        public void SetItemsPerPage(int itemsPerPage)
        {
            ShowEntriesControl.SetValue(itemsPerPage.ToString());
            WaitUntilUiSpinnerIsNotDisplayed();
        }

        public void AssertUpdatedFieldsHighlighted(string name)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());

            var historySearchDetailTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fields = historySearchDetailTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var row = fields.FirstOrDefault(x => x.Text.Contains(name));

                if (row != null)
                {
                    var contentCellsOfRow1 = row.FindElement(By.CssSelector(".highlight")).Text;


                    if (contentCellsOfRow1.Contains(name))
                    {
                        Assert.Pass("'{0}' field found on dialog  - present", name);
                    }
                }
                else
                {
                    Assert.Fail("'{0}' field not found on dialog  - should not be present", name);
                }
        }

        public IncidentHistorySearchDialog ClickonHomeButtononDetaildiaolg()
        {
            HomeButton.Click();
            return OpenChildDialog<IncidentHistorySearchDialog>();
        }
    }
}
