﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class WebdriverViewAlertQueueDialog : WebDriverArmPage
    {
        public WebDriverTextAreaControl Messages;

        public WebDriverButton PurgeButton { get; set; }
        public WebDriverButton RefreshButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        
        public WebdriverViewAlertQueueDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            Messages = new WebDriverTextAreaControl(driver, waiter, "textarea#NumberOfMessages", true);

            PurgeButton = new WebDriverButton(driver, waiter, "input[value='Purge']", true);
            RefreshButton = new WebDriverButton(driver, waiter, "input#refreshBtn", true);
            CloseButton = new WebDriverButton(driver, waiter, "input[value='Close']", true);
            HelpButton = new WebDriverButton(driver, waiter, "a#help", true);

            WaitUntilPageIsReady();
        }

        public void PurgeMessages()
        {
            var numberOfMessagesInAlertQueue = Messages.GetValue();

            if (numberOfMessagesInAlertQueue != "0")
            {
                Console.WriteLine("Number Of Messages: " + numberOfMessagesInAlertQueue);
                PurgeButton.AssertEnabled();
                PurgeButton.Click();

                AcceptAlert();

                WaitUntilPageIsReady();
            }
        }

        public void AssertNumberOfMessages(string numberOfMessagesExpected)
        {
            var numberOfMessagesInAlertQueue = Messages.GetValue();

            Assert.AreEqual(numberOfMessagesExpected, numberOfMessagesInAlertQueue);
        }

        public void AssertRecipientInRowIs(int rowNumber, string recipientValueExpected)
        {
            AssertEntityInRowIs(rowNumber, recipientValueExpected, 1);
        }

        public void AssertSubjectInRowIs(int rowNumber, string subjectValueExpected)
        {
            AssertEntityInRowIs(rowNumber, subjectValueExpected, 2);
        }

        public void AssertMessageInRowIs(int rowNumber, string messageValueExpected)
        {
            AssertEntityInRowIs(rowNumber, messageValueExpected, 3);
        }

        private void AssertEntityInRowIs(int rowNumber, string valueExpected, int columnNumber)
        {
            var messagesInQueue = Driver.FindElements(By.CssSelector("table#ALertQueueList tbody tr"));

            if (rowNumber > messagesInQueue.Count)
            {
                Assert.Fail("Tried to select Alert Number: " + rowNumber + " but there only: " + messagesInQueue.Count + " Alerts in the View Alert Queue Dialogue");
            }

            var elementsInRow = messagesInQueue[rowNumber - 1].FindElements(By.CssSelector("td"));
            Assert.AreEqual(valueExpected, elementsInRow[columnNumber].Text);
        }
    }
}
