﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverDropdownListsConfigDialog : WebDriverArmPage
    {
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverTableControl DeleteControl { get; set; }

        private WebDriverTickBoxTableCell _checkBoxTableCell;
        public WebDriverTickBoxTableCell CheckBoxTableCell
        {
            get
            {
                _checkBoxTableCell = new WebDriverTickBoxTableCell(Driver, Waiter, "table#LCV_ListTable_content");
                return _checkBoxTableCell;
            }
        }


        private WebDriverTableControl _listTableControl;
        public WebDriverTableControl ListTableControl
        {
            get
            {
                _listTableControl = new WebDriverTableControl(Driver, Waiter, "LCV_ListTable");
                return _listTableControl;
            }

        }
        private WebDriverTickBoxControl _listTableSelectAll;
        public WebDriverTickBoxControl ListTableSelectAll
        {
            get
            {
                _listTableSelectAll = new WebDriverTickBoxControl(Driver, Waiter, "input#LCV_ListTable_selectAll",true);
                return _listTableSelectAll;
            }

        }

        public WebdriverDropdownListsConfigDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "DropDownListConfig.aspx")
        {
            NewButton = new WebDriverButton(driver, waiter,"LCV_LCBV_New_btn");
            SaveButton = new WebDriverButton(driver, waiter, "LCV_LCBV_Save_btn");
            OkButton = new WebDriverButton(driver, waiter, "LCV_LCBV_OK_btn");
            CloseButton = new WebDriverButton(driver, waiter, "LCV_LCBV_Close_btn");
            DeleteControl = new WebDriverTableControl(driver, waiter, "LCV_ListTable");
            
        }

        public void SetDescription(int rowNum, string description)
        {
            ListTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 0, cell =>
            {
                cell.EnterCellText(description);
            });
        }

        public void Save()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#LCV_LCBV_Save_btn")).Enabled);
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
         }

       
    }
}
