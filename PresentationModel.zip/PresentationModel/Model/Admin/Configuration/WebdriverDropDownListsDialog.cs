﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverDropDownListsDialog : WebDriverArmPage
    {
        public WebDriverTabControl RiskTypeControl { get; set; }
        public WebDriverTabControl RiskStatusControl { get; set; }
        public WebDriverTabControl ActivityStatusControl { get; set; }
        public WebDriverTabControl CaveatConfigControl { get; set; }
        public WebDriverTabControl ClassificationsConfigControl { get; set; }
        public WebDriverTabControl RiskCategoryConfigControl { get; set; }
        public WebDriverTabControl IncidentUdfConfigControl { get; set; }
        public WebDriverTabControl IncidentBasicCauseControl { get; set; }
        public WebDriverTabControl PlanStrategyControl { get; set; }
        public WebDriverTabControl GroupsControl { get; set; }
        public WebDriverTabControl ResponseStatusControl { get; set; }
        public WebDriverTabControl ResponsePriorityControl { get; set; }
        public WebDriverTabControl ResponseEffectivenessControl { get; set; }
        public WebDriverTabControl IncidentStatusControl { get; set; }
        public WebDriverTabControl InvestigationQuestionsControl { get; set; }
        public WebDriverTabControl ImpactCategoriesControl { get; set; }
        public WebDriverButton EditButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        
      public WebdriverDropDownListsDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "DropDownList.aspx")
        {
            RiskTypeControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_2 td.DataCell");
            RiskStatusControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_0 td.DataCell");
            ActivityStatusControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_18 td.DataCell");
            CaveatConfigControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_19 td.DataCell");
            ClassificationsConfigControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_20 td.DataCell");
            RiskCategoryConfigControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_1 td.DataCell");
            IncidentUdfConfigControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_61 td.DataCell");
            IncidentBasicCauseControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_62 td.DataCell");
            PlanStrategyControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_25 td.DataCell");
            GroupsControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_11 td.DataCell");
            ResponseStatusControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_33 td.DataCell");
            ResponsePriorityControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_34 td.DataCell");
            ResponseEffectivenessControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_35 td.DataCell");
            IncidentStatusControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_59 td.DataCell");
            InvestigationQuestionsControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_94 td.DataCell");
            ImpactCategoriesControl = new WebDriverTabControl(driver, waiter, "Grid1 tr#Grid1_row_12 td.DataCell");
            EditButton = new WebDriverButton(driver, waiter, "btnEdit__btn");
            CloseButton = new WebDriverButton(driver, waiter, "btnClose");
            HelpButton = new WebDriverButton(driver, waiter, "btnHelp");
        }

        public T EditDialog<T>() where T : WebDriverArmPage
        {
            EditButton.Click();
            return OpenChildDialog<T>();
        }

    }
}
