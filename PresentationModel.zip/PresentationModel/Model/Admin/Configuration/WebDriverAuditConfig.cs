﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverAuditConfig : WebDriverArmPage
    {
        public WebDriverDropDown Record { get; set; }
        public WebDriverDropDown Configuration { get; set; }

        public WebDriverButton OkButton;
        public WebDriverButton SaveButton;
        public WebDriverButton NewButton;
        public WebDriverButton DeleteButton;
        public WebDriverButton CancelButton;
        public WebDriverButton HelpButton;

        public WebDriverAuditTypeConfigDialog AuditDefault
        {
            get
            {
                Record.SetValue("Audit");
                Configuration.SetValue("Default Audit Config");
                Waiter.Until(d => d.IsInitialDataLoadComplete());
                WaitUntilPageIsReady();
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverNewAuditTypeConfigDialog AuditNew
        {
            get
            {
                return new WebDriverNewAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog WastAuditConfig
        {
            get
            {
                Record.SetValue("Audit");
                Configuration.SetValue("WAST Audit Config");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog AuditWorkflowConfigToDelete
        {
            get
            {
                Record.SetValue("Audit");
                Configuration.SetValue("Audit Workflow Config To Delete");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public void AssertAuditConfigNotPresent(string auditWorkflowConfigNotExpected)
        {
            Record.SetValue("Audit");
            Configuration.AssertTextNotPresentInAnyOption(auditWorkflowConfigNotExpected);
        }

        public WebDriverAuditTypeConfigDialog FindingDefault
        {
            get
            {
                Record.SetValue("Finding");
                Configuration.SetValue("Default Finding Config");
                Waiter.Until(d => d.IsInitialDataLoadComplete());
                WaitUntilPageIsReady();
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverNewAuditTypeConfigDialog FindingNew
        {
            get
            {
                return new WebDriverNewAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog WastFindingConfig
        {
            get
            {
                Record.SetValue("Finding");
                Configuration.SetValue("WAST Finding Config");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog FindingWorkflowConfigToDelete
        {
            get
            {
                Record.SetValue("Finding");
                Configuration.SetValue("Finding Workflow Config To Delete");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public void AssertFindingConfigNotPresent(string findingWorkflowConfigNotExpected)
        {
            Record.SetValue("Finding");
            Configuration.AssertTextNotPresentInAnyOption(findingWorkflowConfigNotExpected);
        }

        public WebDriverAuditTypeConfigDialog AuditActionDefault
        {
            get
            {
                Record.SetValue("Audit Action");
                Configuration.SetValue("Default Audit Action Config");
                Waiter.Until(d => d.IsInitialDataLoadComplete());
                WaitUntilPageIsReady();
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverNewAuditTypeConfigDialog AuditActionNew
        {
            get
            {
                return new WebDriverNewAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog WastAuditActionConfig
        {
            get
            {
                Record.SetValue("Audit Action");
                Configuration.SetValue("WAST Aud Act Config");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public WebDriverAuditTypeConfigDialog AuditActionWorkflowConfigToDelete
        {
            get
            {
                Record.SetValue("Audit Action");
                Configuration.SetValue("Audit Action Workflow Config To Delete");
                return new WebDriverAuditTypeConfigDialog(Driver, Waiter, "ACV_Table");
            }
        }

        public void AssertAuditActionConfigNotPresent(string auditWorkflowConfigNotExpected)
        {
            Record.SetValue("Audit Action");
            Configuration.AssertTextNotPresentInAnyOption(auditWorkflowConfigNotExpected);
        }

        public WebDriverAuditConfig(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "AuditConfig.aspx")
        {
            Record = new WebDriverDropDown(driver, waiter, "ACV_Record");
            Configuration = new WebDriverDropDown(driver, waiter, "ACV_Configuration");

            OkButton = new WebDriverButton(driver, waiter, "ACV_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "ACV_Save_btn");
            NewButton = new WebDriverButton(driver, waiter, "ACV_New_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "ACV_Delete_btn");
            CancelButton = new WebDriverButton(driver, waiter, "ACV_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "ACV_Help_btn");

            WaitUntilPageIsReady();
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.AssertEnabled();
            HelpButton.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Field_Workflow_Administration.htm"))
            {
                helpPage.AssertUrlEndsWith("Field_Workflow_Administration.htm");
            }
        }

    }
}
