﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverRiskCategoryConfigDialog : WebDriverArmPage
    {
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton DeleteButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        private WebDriverTreeNode _treeNode;
        public WebDriverTreeNode TreeNode
        {
            get
            {
                WaitUntilPageIsReady();
                _treeNode = new WebDriverTreeNode(Driver, Waiter, "[^='treenode']");
                return _treeNode;
            }

        }

        public WebdriverRiskCategoryConfigDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "TreeListConfig.aspx")
        {
            NewButton = new WebDriverButton(driver, waiter, "TCV_LCBV_New_btn");
            SaveButton = new WebDriverButton(driver, waiter, "TCV_LCBV_Save_btn");
            OkButton = new WebDriverButton(driver, waiter, "TCV_LCBV_OK_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "TCV_LCBV_Delete_btn");
            CloseButton = new WebDriverButton(driver, waiter, "TCV_LCBV_Close_btn");
        }

        public void Delete()
        {
            DeleteButton.Click();
            try
            {
                Driver.SwitchTo().Alert().Accept();
            }
            catch (NoAlertPresentException ex)
            {
                Console.WriteLine(ex);
                throw;
            }
        }
    }
}
