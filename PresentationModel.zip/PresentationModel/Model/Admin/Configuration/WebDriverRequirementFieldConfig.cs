﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverRequirementFieldConfig : WebDriverArmPage
    {
        private WebDriverTableControl _requirementFieldsConfigurationTable;
        public WebDriverTableControl RequirementFieldsConfigurationTable
        {
            get
            {
                _requirementFieldsConfigurationTable = new WebDriverTableControl(Driver, Waiter, "RFCV_ReqCustomFieldConfigTable");
                return _requirementFieldsConfigurationTable;
            }
        }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WebDriverRequirementFieldConfig(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "RequirementFieldConfig.aspx")
        {
            OkButton = new WebDriverButton(driver, waiter, "RFCV_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "RFCV_Save_btn");
            CancelButton = new WebDriverButton(driver, waiter, "RFCV_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "RFCV_Help_btn");

            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.AssertEnabled();
            HelpButton.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Requirement_Configuration.htm"))
            {
                helpPage.AssertUrlEndsWith("Requirement_Configuration.htm");
            }
        }
    }
}
