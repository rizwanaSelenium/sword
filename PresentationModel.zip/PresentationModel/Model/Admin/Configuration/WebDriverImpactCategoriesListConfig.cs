﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverImpactCategoriesListConfig :  WebDriverArmPage
    {
        public WebDriverButton NewButton;
        public WebDriverButton SaveButton;
        public WebDriverButton OkButton;
        public WebDriverButton DeleteButton;
        public WebDriverButton CancelButton;
        public WebDriverButton HelpButton;

        public WebDriverImpactCategoriesListConfig(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ImpactCategoryConfig.aspx")
        {
            NewButton = new WebDriverButton(driver, waiter, "RootView_New_btn");
            SaveButton = new WebDriverButton(driver, waiter, "RootView_Save_btn");
            OkButton = new WebDriverButton(driver, waiter, "RootView_OK_btn");
            DeleteButton = new WebDriverButton(driver, waiter,"RootView_Delete_btn");
            CancelButton = new WebDriverButton(driver, waiter, "RootView_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "RootView_Help_btn");
        }
        private WebDriverTableControl ListTableControlField { get; set; }
        public WebDriverTableControl ListTableControl
        {
            get
            {
                ListTableControlField = new WebDriverTableControl(Driver, Waiter, "RootView_Table");
                return ListTableControlField;
            }

        }

        public void SetDescription(int rowNum, string description)
        {
            ListTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 0, cell =>
            {
                cell.EnterCellText(description);
            });
        }

        public void Save()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#RootView_Save_btn")).Enabled);
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            WaitUntilPageIsReady();
        }
      }
}

