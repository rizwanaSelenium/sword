﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class ResponseScreenLayout : WebDriverArmPage
    {
        private readonly IWebDriver _driver;
        private readonly WebDriverWait _waiter;

        public WebDriverDropDown RecordType => new WebDriverDropDown(_driver, _waiter, "select#selectRecordType", true);
        public WebDriverDropDown ResponseType => new WebDriverDropDown(_driver, _waiter, "select#selectResponseType", true);
        public WebDriverDropDown Interface => new WebDriverDropDown(_driver, _waiter, "select#selectInterface", true);

        public WebDriverTickBoxControl ActiveResponseAction => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(0, "available"), true);
        public WebDriverTickBoxControl ActiveResponseControl => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(1, "available"), true);
        public WebDriverTickBoxControl ActiveResponseFallback => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(2, "available"), true);

        public WebDriverTickBoxControl DefaultResponseAction => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(0, "default"), true);
        public WebDriverTickBoxControl DefaultResponseControl => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(1, "default"), true);
        public WebDriverTickBoxControl DefaultResponseFallback => new WebDriverTickBoxControl(_driver, _waiter, GetCheckboxSelector(2, "default"), true);

        public WebDriverButton OkButton => new WebDriverButton(_driver, _waiter, "Ok");
        public WebDriverButton SaveButton => new WebDriverButton(_driver, _waiter, "Save");
        public WebDriverButton ClearButton => new WebDriverButton(_driver, _waiter, "Clear");
        public WebDriverButton CloseButton => new WebDriverButton(_driver, _waiter, "Cancel");

        public ResponseScreenLayout(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "ResponseScreenLayout")
        {
            _driver = driver;
            _waiter = waiter;
        }

        private static string GetCheckboxSelector(int rowId, string colId)
        {
            return $"arm-grid.responseTypes div.ag-row[row-id=\'{rowId}\'] div.ag-cell[col-id=\'{colId}\'] input[type=\'checkbox\']";
        }
    }
}
