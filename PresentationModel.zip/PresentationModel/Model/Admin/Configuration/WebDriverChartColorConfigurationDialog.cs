﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverChartColorConfigurationDialog : WebDriverArmPage
    {
        public WebDriverButton OkButton { get; set; }
        public WebDriverFormControl ColorFormControl { get; set; }
        private WebDriverDropDown _panelStartColorDropDown;
        public WebDriverDropDown PanelStartColorDropdown
        { 
            get
            {
                _panelStartColorDropDown = new WebDriverDropDown(Driver, Waiter, "select.ng-pristine", true);
                return _panelStartColorDropDown;
            } 
        }
       
        public WebDriverChartColorConfigurationDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Index")
        {
            OkButton = new WebDriverButton(driver, waiter, "a#OK", true);
            ColorFormControl = new WebDriverFormControl(driver, waiter, "form-horizontal");
            
        }

        public void ClickOk()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            OkButton.Click();

            Waiter.Until(d => !d.WindowHandles.Contains((currentWindowHandle)));

            if ((Driver.WindowHandles).Contains(currentWindowHandle))
            {
                Driver.SwitchTo().Window(currentWindowHandle);
                Driver.Close();

                    new WebDriverWait(Driver, TimeSpan.FromSeconds(1)).Until(d => d.HasAlertWindow());
                    Driver.SwitchTo().Alert().Accept();
            }
        }
    }
}
