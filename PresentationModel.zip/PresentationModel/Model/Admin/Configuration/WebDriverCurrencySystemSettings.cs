﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
  public class WebDriverCurrencySystemSettingsDialog : WebDriverArmPage
    {
      public WebDriverTickBoxControl TreeNodeCurrencySelection { get; set; }
      public WebDriverButton OkButton { get; set; }
      public WebDriverCurrencySystemSettingsDialog(IWebDriver driver, WebDriverWait waiter)
          : base(driver, waiter, "CurrencySystemSettings.aspx")
        {
            TreeNodeCurrencySelection = new WebDriverTickBoxControl(driver, waiter, "input#RootView_TreeNodeCurrencyDropdown_chk", true);
            OkButton = new WebDriverButton(driver, waiter, "RootView_OK_btn");
            waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }
    }
}
