﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverConfigurationDataSetsDialog : WebDriverArmPage
    {
        // OLD Window but still in ARM

        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CopyButton { get; set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverButton DeleteButton { get; set; }
        public WebDriverButton MoveRighButton { get; set; }
        public WebDriverButton MoveLeftButton { get; set; }
        
        private WebDriverTableControl _configSetTableControl;
        public WebDriverTableControl ConfigSetTableControl
        {
            get
            {
                _configSetTableControl = new WebDriverTableControl(Driver, Waiter, "RootView_ConfigSetTable");
                return _configSetTableControl;
            }
    
        }

        private WebDriverTickBoxTableCell _checkBoxTableCell;
        public WebDriverTickBoxTableCell CheckBoxTableCell
        {
            get
            {
                _checkBoxTableCell = new WebDriverTickBoxTableCell(Driver, Waiter, "table#RootView_ConfigSetTable_content");
                return _checkBoxTableCell;
            }
        }
        
       public WebdriverConfigurationDataSetsDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ConfigurationSet.aspx")
        {
            SaveButton = new WebDriverButton(driver, waiter, "RootView_Save_btn");
            CopyButton = new WebDriverButton(driver, waiter, "RootView_Copy_btn");
            NewButton = new WebDriverButton(driver, waiter, "RootView_New_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "RootView_Delete_btn");
            HelpButton = new WebDriverButton(driver, waiter, "RootView_Help_btn");
            CancelButton = new WebDriverButton(driver, waiter, "RootView_Cancel_btn");
            MoveRighButton = new WebDriverButton(driver, waiter, "RootView_Add_btn");
            MoveLeftButton = new WebDriverButton(driver, waiter, "RootView_Remove_btn");
        }

        public void SetDescriptionForRow(int rowNum, string description)
        {
            ConfigSetTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 2, cell =>
            {
                cell.EnterCellText(description);
            });
        }

        public void SetNameForRow(int rowNum, string name)
        {
            ConfigSetTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 1, cell =>
            {
                cell.EnterCellText(name);
            });

        }

        public void ClickOkInPrompt()
        {
           RespondToUiPrompt("OK");
        }

        public void Save()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#RootView_Save_btn")).Enabled);
            SaveButton.AssertEnabled();
            SaveButton.Click();
            WaitUntilPageIsReady();
            Waiter.Until(d => !d.FindElement(By.CssSelector("button#RootView_Save_btn")).Enabled);
        }

       }
}
