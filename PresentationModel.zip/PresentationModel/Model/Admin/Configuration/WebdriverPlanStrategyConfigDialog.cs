﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverPlanStrategyConfigDialog : WebDriverArmPage
    {
        // Old window but still in ARM

        public WebDriverButton NewButton { get; set; }
        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverTableCell StrategyListControl { get; set; }

        private WebDriverButton _updateButton;
        public WebDriverButton UpdateButton
        {
            get
            {
                _updateButton = new WebDriverButton(Driver, Waiter, "tr.SelectedRow td[align='center'] div img", true);
                return _updateButton;
            }
        }

        
        private WebDriverTextField _strategyName;
        public WebDriverTextField StrategyName
        {
            get
            {
                _strategyName = new WebDriverTextField(Driver, Waiter, "input[value='']", true);
                return _strategyName;
            }
        }

        private WebDriverTickBoxControl _mitigateControl;
        public WebDriverTickBoxControl MitigateControl
        {
            get
            {
                _mitigateControl = new WebDriverTickBoxControl(Driver, Waiter, "tr.SelectedRow td input#StrategyIsMitigating", true);
                return _mitigateControl;
            }
        }

        private WebDriverButton _editButton;
        public WebDriverButton EditButton
        {
            get
            {
                _editButton = new WebDriverButton(Driver, Waiter, "tr.SelectedRow td div img", true);
                return _editButton;
            }
        }

        private WebDriverButton _deleteButton;
        public WebDriverButton DeleteButton
        {
            get
            {
                _deleteButton = new WebDriverButton(Driver, Waiter, "tr.SelectedRow td div img[alt='Delete']",true);
                return _deleteButton;
            }
        }

        public WebdriverPlanStrategyConfigDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "PlanStrategyConfig.aspx")
        {
            NewButton = new WebDriverButton(driver, waiter, "PlanStrategyConfigControl_btnNew__btn");
            OkButton = new WebDriverButton(driver, waiter, "PlanStrategyConfigControl_btnOK__btn");
            SaveButton = new WebDriverButton(driver, waiter, "PlanStrategyConfigControl_btnSave__btn");
            CancelButton = new WebDriverButton(driver, waiter, "PlanStrategyConfigControl_btnCancel__btn");
            HelpButton = new WebDriverButton(driver, waiter, "btnHelp");
            StrategyListControl = new WebDriverTableCell(driver, waiter, "table#PlanStrategyConfigControl_PlanStrategiesGrid");
            
        }


       public void EnterName(string name)
        {
            var cell = new WebDriverTableCell(Driver, Waiter, "table#PlanStrategyConfigControl_PlanStrategiesGrid table tr.SelectedRow td[align='left'] input");
            cell.EnterCellText(name);
        }

        public void Delete()
        {
            DeleteButton.AssertEnabled();
            DeleteButton.Click();
            Driver.SwitchTo().Alert().Accept();
        }

        public void Update()
        {
            UpdateButton.Click();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
            try
            {
                Waiter.Until(d => d.HasAlertWindow());
                Driver.SwitchTo().Alert().Accept();
            }
            catch (NoAlertPresentException)
            {
                Console.WriteLine("No alert Present");
            }
        }
    }
}
