﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverWaterfallDefaultsConfigurationDialog : WebDriverArmPage
    {
        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "a#Save", true)); }
        }
        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "a#OK", true)); }
        }
        private List<WebDriverTickBoxControl> _chartDefaultOptions;

        public List<WebDriverTickBoxControl> ChartDefaultOptions
        {
            get
            {
                return _chartDefaultOptions ??
                       (_chartDefaultOptions = Driver.FindElements(By.CssSelector("fieldset div.form-group input[type='checkbox']"))
                           .Select(
                               x => new WebDriverTickBoxControl(Driver, Waiter, "input#" + x.GetAttribute("id"), true))
                           .ToList());
            }
        }

       
        public WebdriverWaterfallDefaultsConfigurationDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Index")
        {
        }
       

        public void TurnOnDefaultChartOptions(string option)
        {
            ChartDefaultOptions.Single(x => x.Id == option).Check();
        }

        public void TurnOffDefaultChartOptions(string option)
        {
            ChartDefaultOptions.Single(x => x.Id == option).Uncheck();
        }
    }
}
