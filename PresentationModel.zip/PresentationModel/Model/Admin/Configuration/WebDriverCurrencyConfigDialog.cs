﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
   public class WebDriverCurrencyConfigDialog : WebDriverArmPage
    {
        // Old ARM page but still in ARM

       public WebDriverTextField NameField { get; set; }

       public WebDriverCurrencyConfigDialog(IWebDriver driver, WebDriverWait waiter)
           : base(driver, waiter, "CurrencyConfig.aspx")
        {
            NameField = new WebDriverTextField(driver, waiter, "input#RootView_Name_tb",true);

            waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }
    }
}
