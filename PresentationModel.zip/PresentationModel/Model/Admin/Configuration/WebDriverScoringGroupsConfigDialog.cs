﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverScoringGroupsConfigDialog : WebDriverArmPage
    {
        private WebDriverTableControl _scoringSchemeGroups;
        public WebDriverTableControl ScoringSchemeGroups
        {
            get
            {
                _scoringSchemeGroups = new WebDriverTableControl(Driver, Waiter, "RootView_Groups");
                return _scoringSchemeGroups;
            }
            
        }

        private WebDriverTableControl _availableScoringSchemes;
        public WebDriverTableControl AvailableScoringSchemes
        {
            get
            {
                _availableScoringSchemes = new WebDriverTableControl(Driver, Waiter, "RootView_AvailableSchemes");
                return _availableScoringSchemes;
            }
        }

        private WebDriverTableControl _scoringSchemesInGroup;
        public WebDriverTableControl ScoringSchemesInGroup
        {
            get
            {
                _scoringSchemesInGroup = new WebDriverTableControl(Driver, Waiter, "RootView_GroupSchemes");
                return _scoringSchemesInGroup;
            }
        }

        private WebDriverTickBoxTableCell _availableScoringSchemeCheckBoxTableCell;
        public WebDriverTickBoxTableCell AvailableScoringSchemeCheckBoxTableCell
        {
            get
            {
                _availableScoringSchemeCheckBoxTableCell = new WebDriverTickBoxTableCell(Driver, Waiter, "table#RootView_AvailableSchemes_content tbody tr td");
                                return _availableScoringSchemeCheckBoxTableCell;
            }
        }

        private WebDriverTickBoxTableCell _scoringGroupsCheckBoxTableCell;
        public WebDriverTickBoxTableCell ScoringGroupsCheckBoxTableCell
        {
            get
            {
                _scoringGroupsCheckBoxTableCell = new WebDriverTickBoxTableCell(Driver, Waiter, "div.tablecontrol#RootView_Groups tr.grid-row td");
                return _scoringGroupsCheckBoxTableCell;
            }
        }

        private WebDriverTabControl _scoringScehmesText;
        public WebDriverTabControl ScoringSchemesText
        {
            get
            {
                _scoringScehmesText = new WebDriverTabControl(Driver, Waiter, "RootView_GroupSchemes_content td.grid-cell span");
                return _scoringScehmesText;
            }
        }


        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton MoveRightButton { get; set; }
        public WebDriverButton MoveLeftButton { get; set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton DeleteButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverButton OkButton { get; set; }
        
        public WebDriverScoringGroupsConfigDialog(IWebDriver driver, WebDriverWait waiter )
            : base(driver, waiter, "SchemeGroupAdmin.aspx")
        {
            SaveButton = new WebDriverButton(driver, waiter, "RootView_Save_btn");
            MoveRightButton = new WebDriverButton(driver, waiter, "RootView_Right_btn");
            MoveLeftButton = new WebDriverButton(driver, waiter, "RootView_Left_btn");
            NewButton = new WebDriverButton(driver, waiter, "RootView_New_btn");
            CloseButton = new WebDriverButton(driver, waiter, "RootView_Close_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "RootView_Delete_btn");
            HelpButton = new WebDriverButton(driver, waiter, "RootView_Help_btn");
            OkButton = new WebDriverButton(driver, waiter, "RootView_OK_btn");
        }

        public void SetDescriptionForRow(int rowNum, string description)
        {
            ScoringSchemeGroups.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 1, cell =>
            {
                cell.EnterCellText(description);
            });
        }

        public void SetNameForRow(int rowNum, string name)
        {
            ScoringSchemeGroups.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 0, cell =>
            {
                cell.EnterCellText(name);
            });

        }

        public void Save()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#RootView_Save_btn")).Enabled);
            SaveButton.AssertEnabled();
            SaveButton.Click();
            WaitUntilPageIsReady();
            Waiter.Until(d => !d.FindElement(By.CssSelector("button#RootView_Save_btn")).Enabled);
        }

        

    }
}
