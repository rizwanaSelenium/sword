﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebdriverIncidentConfigurationDialog : WebDriverArmPage
    {
        public WebDriverDropDown SelectRecordDropDown { get; set; }
        public WebDriverDropDown SelectConfigurationDropDown { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton OkButton { get; set; }
        
        public WebdriverIncidentConfigurationDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "IncidentConfig.aspx")
        {
            SelectRecordDropDown = new WebDriverDropDown(driver, waiter, "RSV_Record");
            SelectConfigurationDropDown = new WebDriverDropDown(driver, waiter, "RSV_Configuration");
            NewButton = new WebDriverButton(driver, waiter, "RSV_New_btn");
            OkButton = new WebDriverButton(driver, waiter, "RSV_OK_btn");
            SaveButton = new WebDriverButton(Driver, Waiter, "RSV_Save_btn");
        }

        private WebDriverTableControl ContentTableControlField { get; set; }
        public WebDriverTableControl ContentTableControl
        {
            get
            {
                ContentTableControlField = new WebDriverTableControl(Driver, Waiter, "RSV_Table");
                return ContentTableControlField;
            }
        }

        private WebDriverTickBoxTableCell _visibleCheckbox;
        public WebDriverTickBoxTableCell VisibleCheckbox
        {
            get
            {
                _visibleCheckbox = new WebDriverTickBoxTableCell(Driver, Waiter, "table#RSV_Table_content tbody tr td#0_Visible");
 
                return _visibleCheckbox;
            }

        }

       

    }
}
