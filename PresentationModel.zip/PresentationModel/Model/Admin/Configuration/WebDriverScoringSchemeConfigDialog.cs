﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverScoringSchemeConfigDialog : WebDriverArmPage
    {
        public WebDriverButton HelpButton;
        public WebDriverButton NewButton;
        public WebDriverButton DeleteButton;

        private WebDriverButton _impactCategoryButton;

        public WebDriverButton ImpactCategoryOkButton
        {
            get { return _impactCategoryButton ?? (_impactCategoryButton = new WebDriverButton(Driver, Waiter, "RootView_Categories_OK_btn"));}
        }

        private WebDriverTableControl _scoringSchemeTableControl;

        public WebDriverTableControl ScoringschemeTableControl
        {
            get
            {
                _scoringSchemeTableControl = new WebDriverTableControl(Driver, Waiter, "RootView_Schemes");
                return _scoringSchemeTableControl;
            }
        }

        private WebDriverButton _threatCategoriesButton;

        public WebDriverButton ThreatCategoriesButton
        {
            get
            {
                _threatCategoriesButton = new WebDriverButton(Driver, Waiter,"RootView_Criteria_Threat_CategoriesButton_btn");
                return _threatCategoriesButton;
            }
        }

        private WebDriverButton _quantitativeButton;

        public WebDriverButton QuantitativeButton
        {
            get
            {
                _quantitativeButton = new WebDriverButton(Driver, Waiter, "RootView_Criteria_Quantitative_btn");
                return _quantitativeButton;
            }
        }

        private WebDriverButton _qualititativeButton;

        public WebDriverButton QualititativeButton
        {
            get
            {
                _qualititativeButton = new WebDriverButton(Driver, Waiter, "RootView_Criteria_Qualitative_btn");
                return _qualititativeButton;
            }
        }

        private WebDriverButton _saveButton;

        public WebDriverButton SaveButton
        {
            get
            {
                _saveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn");
                return _saveButton;
            }
        }

        private WebDriverButton _okButton;

        public WebDriverButton OkButton
        {
            get
            {
                _okButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn");
                return _okButton;
            }
        }
        
        private WebDriverTableControl ImpactCategoriesTableControlField { get; set; }
        public WebDriverTableControl ImpactCategoriesTableControl
        {
            get
            {
                ImpactCategoriesTableControlField = new WebDriverTableControl(Driver, Waiter, "RootView_Categories_Table");
                return ImpactCategoriesTableControlField;
            }
        }

        private WebDriverTableControl _probabilityCategoriesTableControl;
        public WebDriverTableControl ProbabilityCategoriesTableControl
        {
            get
            {
                _probabilityCategoriesTableControl = new WebDriverTableControl(Driver, Waiter, "RootView_Criteria_Threat_ProbabilityCriteria");
                return _probabilityCategoriesTableControl;
            }
        }


        private WebDriverTableControl _threatcategoriestablecontrol;
        public WebDriverTableControl ThreatCategoriesTableControl
        {
            get
            {
                _threatcategoriestablecontrol = new WebDriverTableControl(Driver, Waiter, "RootView_Criteria_Threat_ImpactCriteria");
                return _threatcategoriestablecontrol;
            }
        }

        public WebDriverScoringSchemeConfigDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ScoringSchemeConfig.aspx")
        {
            HelpButton = new WebDriverButton(driver, waiter, "RootView_Help_btn");
            NewButton = new WebDriverButton(driver, waiter, "RootView_New_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "RootView_Delete_btn");
        }

        public void SetDescriptionForRow(int rowNum, string description)
        {
            ScoringschemeTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 4, cell =>
            {
                cell.EnterCellText(description);
            });
        }

        public void SetNameForRow(int rowNum, string name)
        {
            ScoringschemeTableControl.PerformActionOnCellElementTextbox<WebDriverTableCell>(rowNum, 3, cell =>
            {
               cell.EnterCellText(name);
            });
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();

            using (var page = new WebDriverHelpPage(Driver, Waiter, "Scoring_Schemes.htm"))
            {
                page.AssertUrlEndsWith("Scoring_Schemes.htm");
            }
        }

        public void AddImpactCategoriesToScoringScheme(int rowNum)
        {
           ThreatCategoriesButton.Click();
           ImpactCategoriesTableControl.CheckRow(rowNum);
        }
    }
}
