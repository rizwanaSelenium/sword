﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.Configuration
{
    public class WebDriverGridColumnConfigDialogue : WebDriverArmPage
    {
        public WebDriverDropDown Grids { get; set; }
        public WebDriverDropDown Configuration { get; set; }

        public WebDriverTickBoxControl Private { get; set; }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton DeleteButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public WebDriverGridColumnConfigDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "GridColumnConfig.aspx")
        {
            Grids = new WebDriverDropDown(driver, waiter, "View_Lists");
            Configuration = new WebDriverDropDown(driver, waiter, "View_Configurations");

            Private = new WebDriverTickBoxControl(driver, waiter, "View_Private");

            OkButton = new WebDriverButton(driver, waiter, "View_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "View_Save_btn");
            NewButton = new WebDriverButton(driver, waiter, "View_New_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "View_Delete_btn");
            CancelButton = new WebDriverButton(driver, waiter, "View_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "View_Help_btn");

            waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.AssertEnabled();
            HelpButton.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Desktop_Column_Configuration.htm"))
            {
                helpPage.AssertUrlEndsWith("Desktop_Column_Configuration.htm");
            }
        }
    }
}
