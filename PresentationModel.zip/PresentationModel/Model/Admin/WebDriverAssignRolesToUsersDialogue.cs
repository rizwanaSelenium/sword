﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin
{
    public class WebDriverAssignRolesToUsersDialogue : WebDriverArmPage
    {
        private WebDriverTableControl _licenseRoleTypesAllocatedTable;
        public WebDriverTableControl LicenseRoleTypesAllocatedTable
        {
            get
            {
                _licenseRoleTypesAllocatedTable = new WebDriverTableControl(Driver, Waiter, "RoleUsersView_AssignUsersToRolesTable");
                return _licenseRoleTypesAllocatedTable;
            }
        }

        private WebDriverTableControl _licenseRoleTypesAvailableTable;
        public WebDriverTableControl LicenseRoleTypesAvailableTable
        {
            get
            {
                _licenseRoleTypesAvailableTable = new WebDriverTableControl(Driver, Waiter, "RoleUsersView_LicensedSeatsAvailable");
                return _licenseRoleTypesAvailableTable;
            }
        }

        private WebDriverTableControl _licensedUsersTable;
        public WebDriverTableControl LicensedUsersTable
        {
            get
            {
                _licensedUsersTable = new WebDriverTableControl(Driver, Waiter, "RoleUsersView_UserTable_title");
                return _licensedUsersTable;
            }
        }

        public WebDriverButton AddButton;

        public WebDriverButton OkButton;
        public WebDriverButton SaveButton;
        public WebDriverButton CloseButton;
        public WebDriverButton HelpButton;

        public WebDriverAssignRolesToUsersDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "RoleUsers.aspx")
        {
            
            
            AddButton = new WebDriverButton(driver, waiter, "RoleUsersView_Add_btn");

            OkButton = new WebDriverButton(driver, waiter, "RoleUsersView_OK_btn");
            SaveButton = new WebDriverButton(driver, waiter, "RoleUsersView_Save_btn");
            CloseButton = new WebDriverButton(driver, waiter, "RoleUsersView_Close_btn");
            HelpButton = new WebDriverButton(driver, waiter, "RoleUsersView_Help_btn");
        }

        public void LicensedRoleTypesAllocatedTableAssertLicenseRoleType(string licenseRoleName, string licenseRoleType)
        {
            switch (licenseRoleName)
            {
                case "ARM Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(0, 0, "ARM Administrator");
                    LicenseRoleTypesAllocatedTable.AssertCellText(0, 1, licenseRoleType);
                    break;
                case "Business Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(1, 0, "Business Administrator");
                    LicenseRoleTypesAllocatedTable.AssertCellText(1, 1, licenseRoleType);
                    break;
                case "Risk Manager":
                    LicenseRoleTypesAllocatedTable.AssertCellText(2, 0, "Risk Manager");
                    LicenseRoleTypesAllocatedTable.AssertCellText(2, 1, licenseRoleType);
                    break;
                case "Browser":
                    LicenseRoleTypesAllocatedTable.AssertCellText(3, 0, "Browser");
                    LicenseRoleTypesAllocatedTable.AssertCellText(3, 1, licenseRoleType);
                    break;
                case "ARM Risk Express 1":
                    LicenseRoleTypesAllocatedTable.AssertCellText(4, 0, "ARM Risk Express 1");
                    LicenseRoleTypesAllocatedTable.AssertCellText(4, 1, licenseRoleType);
                    break;
                case "ARM Risk Express 2":
                    LicenseRoleTypesAllocatedTable.AssertCellText(5, 0, "ARM Risk Express 2");
                    LicenseRoleTypesAllocatedTable.AssertCellText(5, 1, licenseRoleType);
                    break;
                default:
                    Assert.Fail("License Role Name: " + licenseRoleName + " Not Found In Table");
                    break;
            }
        }

        public void LicenseRoleTypesAllocatedTableAssertAllocatedLicenses(string licenseRoleName, string allocatedLicenses)
        {
            switch (licenseRoleName)
            {
                case "ARM Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(0, 0, "ARM Administrator");
                    LicenseRoleTypesAllocatedTable.AssertCellText(0, 2, allocatedLicenses);
                    break;
                case "Business Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(1, 0, "Business Administrator");
                    LicenseRoleTypesAllocatedTable.AssertCellText(1, 2, allocatedLicenses);
                    break;
                case "Risk Manager":
                    LicenseRoleTypesAllocatedTable.AssertCellText(2, 0, "Risk Manager");
                    LicenseRoleTypesAllocatedTable.AssertCellText(2, 2, allocatedLicenses);
                    break;
                case "Browser":
                    LicenseRoleTypesAllocatedTable.AssertCellText(3, 0, "Browser");
                    LicenseRoleTypesAllocatedTable.AssertCellText(3, 2, allocatedLicenses);
                    break;
                case "ARM Risk Express 1":
                    LicenseRoleTypesAllocatedTable.AssertCellText(4, 0, "ARM Risk Express 1");
                    LicenseRoleTypesAllocatedTable.AssertCellText(4, 2, allocatedLicenses);
                    break;
                case "ARM Risk Express 2":
                    LicenseRoleTypesAllocatedTable.AssertCellText(5, 0, "ARM Risk Express 2");
                    LicenseRoleTypesAllocatedTable.AssertCellText(5, 2, allocatedLicenses);
                    break;
                default:
                    Assert.Fail("License Role Name: " + licenseRoleName + " Not Found In Table");
                    break;
            }
        }

        public void ClickRowInLicenseRoleTypesAllocatedTableWithName(string roleName)
        {
            switch (roleName)
            {
                case "ARM Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(0, 0, "ARM Administrator");
                    LicenseRoleTypesAllocatedTable.ClickRow(0);
                    break;
                case "Business Administrator":
                    LicenseRoleTypesAllocatedTable.AssertCellText(1, 0, "Business Administrator");
                    LicenseRoleTypesAllocatedTable.ClickRow(1);
                    break;
                case "Risk Manager":
                    LicenseRoleTypesAllocatedTable.AssertCellText(2, 0, "Risk Manager");
                    LicenseRoleTypesAllocatedTable.ClickRow(2);
                    break;
                case "Browser":
                    LicenseRoleTypesAllocatedTable.AssertCellText(3, 0, "Browser");
                    LicenseRoleTypesAllocatedTable.ClickRow(3);
                    break;
                case "ARM Risk Express 1":
                    LicenseRoleTypesAllocatedTable.AssertCellText(4, 0, "ARM Risk Express 1");
                    LicenseRoleTypesAllocatedTable.ClickRow(4);
                    break;
                case "ARM Risk Express 2":
                    LicenseRoleTypesAllocatedTable.AssertCellText(5, 0, "ARM Risk Express 2");
                    LicenseRoleTypesAllocatedTable.ClickRow(5);
                    break;
                default:
                    Assert.Fail("License Role Name: " + roleName + " Not Found In Table");
                    break;
            }
        }

        public void LicenseRoleTypesAvailableTableAssertLicensed(string licenseRoleType, string licensedValue)
        {
            switch (licenseRoleType)
            {
                case "Administrator":
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 0, "Administrator");
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 1, licensedValue);
                    break;
                case "Enterprise":
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 0, "Enterprise");
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 1, licensedValue);
                    break;
                case "Associate":
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 0, "Associate");
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 1, licensedValue);
                    break;
                case "Read Only":
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 0, "Read Only");
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 1, licensedValue);
                    break;
                default:
                    Assert.Fail("License Role Type: " + licenseRoleType + " Not Found In Table");
                    break;
            }
        }

        public void LicenseRoleTypesAvailableTableAssertAllocated(string licenseRoleType, string allocatedValue)
        {
            switch (licenseRoleType)
            {
                case "Administrator":
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 0, "Administrator");
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 2, allocatedValue);
                    break;
                case "Enterprise":
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 0, "Enterprise");
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 2, allocatedValue);
                    break;
                case "Associate":
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 0, "Associate");
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 2, allocatedValue);
                    break;
                case "Read Only":
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 0, "Read Only");
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 2, allocatedValue);
                    break;
                default:
                    Assert.Fail("License Role Type: " + licenseRoleType + " Not Found In Table");
                    break;
            }
        }

        public void LicenseRoleTypesAvailableTableAssertUnallocated(string licenseRoleType, string unallocatedValue)
        {
            switch (licenseRoleType)
            {
                case "Administrator":
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 0, "Administrator");
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 3, unallocatedValue);
                    break;
                case "Enterprise":
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 0, "Enterprise");
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 3, unallocatedValue);
                    break;
                case "Associate":
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 0, "Associate");
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 3, unallocatedValue);
                    break;
                case "Read Only":
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 0, "Read Only");
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 3, unallocatedValue);
                    break;
                default:
                    Assert.Fail("License Role Type: " + licenseRoleType + " Not Found In Table");
                    break;
            }
        }

        public void LicenseRoleTypesAvailableTableAssertAvailable(string licenseRoleType, string availableValue)
        {
            switch (licenseRoleType)
            {
                case "Administrator":
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 0, "Administrator");
                    LicenseRoleTypesAvailableTable.AssertCellText(0, 4, availableValue);
                    break;
                case "Enterprise":
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 0, "Enterprise");
                    LicenseRoleTypesAvailableTable.AssertCellText(1, 4, availableValue);
                    break;
                case "Associate":
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 0, "Associate");
                    LicenseRoleTypesAvailableTable.AssertCellText(2, 4, availableValue);
                    break;
                case "Read Only":
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 0, "Read Only");
                    LicenseRoleTypesAvailableTable.AssertCellText(3, 4, availableValue);
                    break;
                default:
                    Assert.Fail("License Role Type: " + licenseRoleType + " Not Found In Table");
                    break;
            }
        }

        public ViewResourcesDialog ResourcesDialogue()
        {
            FocusWindow();
            AddButton.AssertEnabled();
            AddButton.Click();
            return OpenChildDialog<ViewResourcesDialog>();
        }

        public void Save()
        {
            FocusWindow();
            SaveButton.AssertEnabled();
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.AssertEnabled();
            HelpButton.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "Assign_Roles_To_Users.htm"))
            {
                helpPage.AssertUrlEndsWith("Assign_Roles_To_Users.htm");
            }
        }
    }
}
