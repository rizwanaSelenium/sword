﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin
{
    public class WebDriverRolesConfigDialog : WebDriverArmPage
    {
        private WebDriverButton _addButton;
        public WebDriverButton AddButton
        {
            get { return _addButton = new WebDriverButton(Driver, Waiter, "RootView_Add_btn");}
        }

        private WebDriverButton _removeButton;
        public WebDriverButton RemoveButton
        {
            get { return _removeButton = new WebDriverButton(Driver, Waiter, "RootView_Remove_btn"); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton = new WebDriverButton(Driver, Waiter, "RootView_Help_btn"); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn"); }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn"); }
        }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get => _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn"));
            set => _cancelButton = value;
        }

        private WebDriverTableControl _roleTable;
        public WebDriverTableControl RoleTable
        {
            get
            {
                _roleTable = new WebDriverTableControl(Driver, Waiter, "RootView_RoleTable");
                return _roleTable;
            }
        }

        private WebDriverTableControl _allowedFunctionsTable;
        public WebDriverTableControl AllowedFunctionsTable
        {
            get
            {
                _allowedFunctionsTable = new WebDriverTableControl(Driver, Waiter, "RootView_AllocatedFunctionsTable");
                    return _allowedFunctionsTable;
            }
        }

        private WebDriverTableControl _notAllowedFunctionsTable;
        public WebDriverTableControl NotAllowedFunctionsTable
        {
            get
            {
                _notAllowedFunctionsTable = new WebDriverTableControl(Driver, Waiter, "RootView_NonAllocatedFunctionsTable");
                return _notAllowedFunctionsTable;
            }
        }

        public WebDriverRolesConfigDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "RoleConfig.aspx")
        {
            FocusNewWindow();
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();

            using (var page = new WebDriverHelpPage(Driver, Waiter, "Roles.htm"))
            {
                page.AssertUrlEndsWith("Roles.htm");
            }
        }

        public void SelectRole(string role)
        {
            RoleTable.Search(role);
            RoleTable.ClickRow(0);
        }

        public void AllowFunctionAndThenSave(string function)
        {
            NotAllowedFunctionsTable.Search("");
            if (NotAllowedFunctionsTable.CheckRowCountIsZero()) return;
            NotAllowedFunctionsTable.Search(function);
            if (NotAllowedFunctionsTable.CheckRowCountIsZero()) return;
            NotAllowedFunctionsTable.SelectAllByUsingSpaceKey();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            AddButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
            Save();
        }

        public void AllowFunction(string function)
        {
            NotAllowedFunctionsTable.Search("");
            if (NotAllowedFunctionsTable.CheckRowCountIsZero()) return;
            NotAllowedFunctionsTable.Search(function);
            if (NotAllowedFunctionsTable.CheckRowCountIsZero()) return;
            NotAllowedFunctionsTable.SelectAllByUsingSpaceKey();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
            AddButton.Click();
        }

        public void DisAllowFunctionAndThenSave(string function)
        {
            AllowedFunctionsTable.Search("");
            if (AllowedFunctionsTable.CheckRowCountIsZero()) return;
            AllowedFunctionsTable.Search(function);
            if (AllowedFunctionsTable.CheckRowCountIsZero()) return;
            AllowedFunctionsTable.SelectAllByUsingSpaceKey();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            RemoveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
            Save();
        }

        public void DisAllowFunction(string function)
        {
            AllowedFunctionsTable.Search("");
            if (AllowedFunctionsTable.CheckRowCountIsZero()) return;
            AllowedFunctionsTable.Search(function);
            if (AllowedFunctionsTable.CheckRowCountIsZero()) return;
            AllowedFunctionsTable.SelectAllByUsingSpaceKey();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
            RemoveButton.Click();
        }

        public void Save()
        {
            Waiter.Until(d => SaveButton.IsEnabled());
            SaveButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void AllowRoleToUser(String userRole)
        {
            NotAllowedFunctionsTable.Search(userRole);
            if (!NotAllowedFunctionsTable.CheckRowCountIsZero())
            {
                AllowFunctionAndThenSave(userRole);
            }
            else
            {
                AllowedFunctionsTable.Search(userRole);
                if (!AllowedFunctionsTable.CheckRowCountIsZero())
                {
                    AllowedFunctionsTable.Search("");
                }
                else
                {
                    Assert.Fail("The specified role is not in allowed or not allowed list");
                }
            }
        }

        public void NotAllowRoleToUser(String userRole)
        {
            AllowedFunctionsTable.Search(userRole);

            if (!AllowedFunctionsTable.CheckRowCountIsZero())
            {
                DisAllowFunctionAndThenSave(userRole);
            }
            else
            {
                NotAllowedFunctionsTable.Search(userRole);
                if (!NotAllowedFunctionsTable.CheckRowCountIsZero())
                {
                    NotAllowedFunctionsTable.Search("");
                }
                else
                {
                    Assert.Fail("The specified role is not in allowed or not allowed list");
                }
            }
        }

        public void AllowAllRoles()
        {
            NotAllowedFunctionsTable.Search("");
            if (NotAllowedFunctionsTable.CheckRowCountIsZero()) return;                       
            NotAllowedFunctionsTable.SelectAllByUsingSpaceKey();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            AddButton.Click();
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();

            Save();
        }

        public override void Close()
        {
            FocusNewWindow();
            Waiter.Until(d => CancelButton.IsDisplayed());
            CancelButton.Click();
        }
    }
}
