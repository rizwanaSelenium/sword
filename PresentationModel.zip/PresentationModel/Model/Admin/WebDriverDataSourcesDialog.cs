﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin
{
    public class WebDriverDataSourcesDialog : WebDriverArmPage
    {
        public WebDriverButton HelpButton;
        public WebDriverButton NewButton;
        public WebDriverButton DeleteButton;
        public WebDriverButton OkButton;
        public WebDriverButton CancelButton;
        public WebDriverTextField DataSourceName;
        public WebDriverTextField UserName;

        private WebDriverTextField _password;
        public WebDriverTextField Password
        {
            get {  return _password ?? (_password = new WebDriverTextField(Driver, Waiter, "input#RootView_Password_tb", true));}
        }

        public WebDriverRadioButton GroupSecurityForNoneOption;
        public WebDriverRadioButton GroupSecurityForArmGroupOption;

        private WebDriverDropDown _projectType;
        public WebDriverDropDown ProjectType
        {
            get { return _projectType ?? (_projectType = new WebDriverDropDown(Driver, Waiter, "RootView_ProjectType"));}
        }
        public WebDriverTableControl DataSources;


        private WebDriverTextField _servername;
        public WebDriverTextField ServerName
        {
            get
            {
                _servername = new WebDriverTextField(Driver, Waiter, "RootView_ServerName");
                return _servername;
            }
        }

        private WebDriverTextField _portnumber;
        public WebDriverTextField PortNumber
        {
            get
            {
                _portnumber = new WebDriverTextField(Driver, Waiter, "RootView_PortNumber");
                return _portnumber;
            }
        }

        private WebDriverTextField _instance;
        public WebDriverTextField Instance
        {
            get
            {
                _instance = new WebDriverTextField(Driver, Waiter, "RootView_Instance");
                return _instance;
            }
        }
        private WebDriverButton _testButton;
        public WebDriverButton TestButton
        {
            get
            {
                _testButton = new WebDriverButton(Driver, Waiter, "RootView_Test_btn");
                return _testButton;
            }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get
            {
                _saveButton = new WebDriverButton(Driver, Waiter, "RootView_Save_btn");
                return _saveButton;
            }
        }

        public WebDriverDataSourcesDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "DataSourcesConfig.aspx")
        {
            HelpButton = new WebDriverButton(driver, waiter, "RootView_Help_btn");
            NewButton = new WebDriverButton(driver, waiter, "RootView_New_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "RootView_Delete_btn");
            OkButton = new WebDriverButton(driver, waiter, "RootView_OK_btn");
            CancelButton = new WebDriverButton(driver, waiter, "RootView_Cancel_btn");
            DataSourceName = new WebDriverTextField(driver, waiter, "RootView_Name");
            UserName = new WebDriverTextField(driver, waiter, "RootView_UserName");
            GroupSecurityForNoneOption = new WebDriverRadioButton(driver, waiter, "RootView_NoSecurity");
            GroupSecurityForArmGroupOption = new WebDriverRadioButton(driver, waiter, "RootView_ArmGroupSecurity");
            DataSources = new WebDriverTableControl(driver, waiter, "RootView_DataSources");
            
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();

            using (var page = new WebDriverHelpPage(Driver, Waiter, "Data_Sources.htm"))
            {
                page.AssertUrlEndsWith("Data_Sources.htm");
            }
        }
    }
}
