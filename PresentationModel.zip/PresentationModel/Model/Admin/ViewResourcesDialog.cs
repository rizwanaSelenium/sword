﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Admin
{
    public class ViewResourcesDialog : WebDriverArmPage
    {
        private WebDriverTableControl _resourcesTable;
        public WebDriverTableControl ResourcesTable
        {
            get {  return _resourcesTable ?? (_resourcesTable = new WebDriverTableControl(Driver, Waiter, "VRV_ResourceTable"));}
        }

        private WebDriverButton _selectButton;
        public WebDriverButton SelectButton
        {
            get { return _selectButton ?? (_selectButton = new WebDriverButton(Driver, Waiter, "VRV_SelectResources_btn")); }
        }

        private WebDriverButton _emailButton;
        public WebDriverButton EmailButton
        {
            get { return _emailButton ?? (_emailButton = new WebDriverButton(Driver, Waiter, "VRV_EmailMultiple_btn")); }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get { return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "VRV_Close_btn")); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "VRV_Help_btn")); }
        }

        public ViewResourcesDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ViewResources.aspx")
        {
        }

        public void CheckCheckBoxForRowWithName(string resourceName, bool assertSingleEntry = false)
        {
            ResourcesTable.Search(resourceName);

            if (assertSingleEntry)
            { ResourcesTable.AssertNumberOfItemsDisplayed(1);}
            ResourcesTable.SelectAll();
        }

        public void SelectCheckedResources()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            SelectButton.AssertEnabled();
            SelectButton.Click();
            Waiter.Until(d => !(d.WindowHandles).Contains(currentWindowHandle));
        }
    }
}
