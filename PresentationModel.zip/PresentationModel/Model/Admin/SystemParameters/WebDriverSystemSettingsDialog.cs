﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.Admin.SystemParameters
{
    public class WebDriverSystemSettingsDialog : WebDriverArmPage
    {
        public WebDriverButton Help { get; set; }
        public WebDriverButton Ok { get; set; }
        public WebDriverButton Save { get; set; }
        public WebDriverButton Cancel { get; set; }
        public WebDriverDropDown AlertHistoryLevel { get; set; }
        public WebDriverTickBoxControl AlertsEnabled { get; set; }
        public WebDriverTickBoxControl ExclusiveEscalationMode { get; set; }
        public WebDriverTickBoxControl ShowReportClassifications { get; set; }
        public WebDriverTickBoxControl ShowReportCaveats { get; set; }
        public WebDriverTickBoxControl DisablePortfolioViews { get; set; }
        public WebDriverRadioButton CostNow { get; set; }
        public WebDriverRadioButton ForecastCost { get; set; }
        public WebDriverTickBoxControl PrependType { get; set; }
        public WebDriverTickBoxControl ClearNextReviewDate { get; set; }
        public WebDriverDropDown DefaultLabelSet { get; set; }
        public WebDriverDropDown LoggingLevel { get; set; }
        public WebDriverTickBoxControl MaskingEnabled { get; set; }
        public WebDriverDropDown ResourceNameFormat { get; set; }
        public WebDriverDropDown Language { get; set; }
        public WebDriverTextField AppLogFileLimit { get; set; }
        public WebDriverTextField ArmUrl { get; set; }
        public WebDriverTextField ReportServerUrl { get; set; }
        public WebDriverTextField ClientSessionTimeout { get; set; }

        public WebDriverSystemSettingsDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "SystemSettings.aspx")
        {
            AlertHistoryLevel = new WebDriverDropDown(Driver, Waiter, "RootView_AlertHistoryLevel");
            AlertsEnabled = new WebDriverTickBoxControl(Driver, Waiter, "RootView_AlertEnabled");
            ExclusiveEscalationMode = new WebDriverTickBoxControl(Driver, Waiter, "RootView_ExclusiveEscalationMode");
            ShowReportClassifications = new WebDriverTickBoxControl(Driver, Waiter, "RootView_ShowReportClassifications");
            ShowReportCaveats = new WebDriverTickBoxControl(Driver, Waiter, "RootView_ShowReportCaveats");
            DisablePortfolioViews = new WebDriverTickBoxControl(Driver, Waiter, "RootView_DisablePortfolioViews");
            CostNow = new WebDriverRadioButton(Driver, Waiter, "RootView_CostNow");
            ForecastCost = new WebDriverRadioButton(Driver, Waiter, "RootView_ForecastCost");
            PrependType = new WebDriverTickBoxControl(Driver, Waiter, "RootView_PrependType");
            ClearNextReviewDate = new WebDriverTickBoxControl(Driver, Waiter, "RootView_ClearNextReviewDate");
            DefaultLabelSet = new WebDriverDropDown(Driver, Waiter, "RootView_DefaultLabelSet");
            Language = new WebDriverDropDown(Driver, Waiter, "RootView_Language");
            LoggingLevel = new WebDriverDropDown(Driver, Waiter, "RootView_LoggingLevel");
            MaskingEnabled = new WebDriverTickBoxControl(Driver, Waiter, "RootView_MaskingEnabled");
            ResourceNameFormat = new WebDriverDropDown(Driver, Waiter, "RootView_ResourceNameFormat");
            AppLogFileLimit = new WebDriverTextField(Driver, Waiter, "RootView_ApplicationLogFileLimit");
            ArmUrl = new WebDriverTextField(Driver, Waiter, "RootView_ARMURLPath");
            ReportServerUrl = new WebDriverTextField(Driver, Waiter, "RootView_ReportServerURLPath");
            ClientSessionTimeout = new WebDriverTextField(Driver, Waiter, "RootView_ClientSessionTimeout");

            Help = new WebDriverButton(Driver, Waiter, "RootView_Help_btn");
            Ok = new WebDriverButton(Driver, Waiter, "RootView_OK_btn");
            Save = new WebDriverButton(Driver, Waiter, "RootView_Save_btn");
            Cancel = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn");
        }

        public void AssertHelpPageCorrect()
        {
            Help.Click();

            using (var helpPage = new WebDriverHelpPage(Driver, Waiter, "System_Parameters.htm"))
            {
                helpPage.AssertUrlEndsWith("System_Parameters.htm");
            }
        }

        public void ChangeSystemSettingsApplicationLogFileLimit(string limit)
        {
            // Overwrite Value With 55 - this should trigger a change
            AppLogFileLimit.SetValue(limit);
            //Wait for the Title to be prefixed with " * " before proceeding
            Waiter.Until((d) => d.Title.StartsWith(" *"));
        }
    }
}
