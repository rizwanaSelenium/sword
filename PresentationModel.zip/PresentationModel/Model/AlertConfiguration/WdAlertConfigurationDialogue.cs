﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.AlertConfiguration
{
    public class WdAlertConfigurationDialogue : WebDriverArmPage
    {
        public WebDriverTextField AlertName;
        public WebDriverDropDown Area;
        public WebDriverDropDown Event;

        public WebDriverDropDown SendTo;

        private WebDriverTextField _email;
        public WebDriverTextField Email
        {
            get
            {
                _email = new WebDriverTextField(Driver, Waiter, "input#sendToEmail", true);
                return _email;
            }
        }

        public WebDriverTickBoxControl EnableAlert;

        public WdAlternatingGrid ParameterList;

        public WebDriverButton SaveButton;

        public WdAlertConfigurationDialogue(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            AlertName = new WebDriverTextField(driver, waiter, "input#alertName", true);
            Area = new WebDriverDropDown(driver, waiter, "select#alertArea", true);
            Event = new WebDriverDropDown(driver, waiter, "select#alertEvent", true);

            SendTo = new WebDriverDropDown(driver, waiter, "select#sendTo", true);

            EnableAlert = new WebDriverTickBoxControl(driver, waiter, "input#enableAlert", true);

            ParameterList = new WdAlternatingGrid(driver, waiter, "div.alternating-grid");

            SaveButton = new WebDriverButton(driver, waiter, "Save");

            WaitUntilPageIsReady();
        }

        public void SelectToSendToExternalEmail()
        {
            SendTo.SetValue("External (specify email address)");
            Waiter.Until(d => d.FindElement(By.CssSelector("div.modal-dialog")).Displayed);

            var securityWarning = Driver.FindElement(By.CssSelector("div.modal-dialog"));
            Assert.AreEqual("Security Warning", securityWarning.FindElement(By.CssSelector("h4.modal-title")).Text);

            var okButton = securityWarning.FindElement(By.CssSelector("button[title='OK']"));
            okButton.Click();
        }

        public void Save()
        {
            WaitUntilPageIsReady();

            Waiter.Until(s => SaveButton.IsEnabled());
            SaveButton.Click();

            Waiter.Until(d => d.FindElement(By.CssSelector("div#alertContainer div.alert-success")).Displayed);
            Waiter.Until(d => !d.FindElement(By.CssSelector("div#alertContainer div.alert-success")).Displayed);

            WaitUntilPageIsReady();
        }

        public void CollapseDetails()
        {
            var collapseDetailIcons = Driver.FindElements(By.CssSelector("div#alertsConfig_Details a.collapsed"));

            if (collapseDetailIcons.Count == 0)
            {
                Driver.FindElement(By.CssSelector("div#alertsConfig_Details span.collapse-icon")).Click();
            }
        }

        public void CollapseAlertFilters()
        {
            var collapseAlertFiltersIcons = Driver.FindElements(By.CssSelector("div#alertsConfig_Filter a.collapsed"));

            if (collapseAlertFiltersIcons.Count == 0)
            {
                Driver.FindElement(By.CssSelector("div#alertsConfig_Filter span.collapse-icon")).Click();
            }
        }
    }
}
