﻿using System.Collections.Generic;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.AuditDetail;
using PresentationModel.Controls;

namespace PresentationModel.Model.Audit
{
    public class WebDriverAuditDetailDialog : WebDriverTabbedDetailDialog
    {
        private WebDriverMenu _menu;

        public WebDriverMenu Menu
        {
            get { return _menu ?? (_menu = new WebDriverMenu(Driver, Waiter, "DV_Menu_menu")); }
        }

        private WebDriverButton _spellCheckButton;
        public WebDriverButton SpellCheckButton
        {
            get
            {
                return _spellCheckButton ?? (_spellCheckButton = new WebDriverButton(Driver, Waiter, "DV_SpellCheck_btn"));
            }
        }

        private WebDriverButton _okButton;
        public WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "DV_OK_btn")); }
        }

        private WebDriverButton _saveButton;
        public WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "DV_Save_btn")); }
        }

        private WebDriverButton _newButton;
        public WebDriverButton NewButton
        {
            get { return _newButton ?? (_newButton = new WebDriverButton(Driver, Waiter, "DV_New_btn")); }
        }

        private WebDriverButton _closeButton;
        public WebDriverButton CloseButton
        {
            get
            {
                return _closeButton ?? (_closeButton = new WebDriverButton(Driver, Waiter, "DV_Close_btn"));
            }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "DV_Help_btn")); }
        }

        private WebDriverButton _maximizeFieldsButton;
        public WebDriverButton MazimizeFieldsButton
        {
            get { return _maximizeFieldsButton ?? (_maximizeFieldsButton = new WebDriverButton(Driver, Waiter, "DV_ExpandCollapseAll_btn")); }
        }

        private WebDriverAuditTabPage _auditTab;
        public WebDriverAuditTabPage AuditTab
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit")
                    SwitchToTab("Audit");
                return _auditTab ?? (_auditTab = new WebDriverAuditTabPage(Driver, Waiter, "DV_DTC_AT"));
            }
        }

        private WebDriverAuditTabPageWorkflow _auditTabWorkflow;
        public WebDriverAuditTabPageWorkflow AuditTabWorkflow
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit")
                    SwitchToTab("Audit");
                return _auditTabWorkflow ??
                       (_auditTabWorkflow = new WebDriverAuditTabPageWorkflow(Driver, Waiter, "DV_DTC_AT"));
            }
        }

        private WebDriverFindingTabPage _findingTab;
        public WebDriverFindingTabPage FindingTab
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Finding")
                    SwitchToTab("Finding");
                return _findingTab ?? (_findingTab = new WebDriverFindingTabPage(Driver, Waiter, "DV_DTC_FT"));
            }
        }

        private WebDriverFindingTabPageFull _findingTabFull;
        public WebDriverFindingTabPageFull FindingTabFull
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Finding")
                    SwitchToTab("Finding");
                return _findingTabFull ??
                       (_findingTabFull = new WebDriverFindingTabPageFull(Driver, Waiter, "DV_DTC_FT"));
            }
        }

        private WebDriverAuditActionTabPage _auditActionTab;
        public WebDriverAuditActionTabPage AuditActionTab
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit Action")
                    SwitchToTab("Audit Action");
                return _auditActionTab ??
                       (_auditActionTab = new WebDriverAuditActionTabPage(Driver, Waiter, "DV_DTC_RT"));
            }
        }

        private WebDriverAuditActionTabPageFull _auditActionTabFull;
        public WebDriverAuditActionTabPageFull AuditActionTabFull
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit Action")
                    SwitchToTab("Audit Action");
                return _auditActionTabFull ??
                       (_auditActionTabFull = new WebDriverAuditActionTabPageFull(Driver, Waiter, "DV_DTC_RT"));
            }
        }

        private WebDriverAuditActionTabPageWorkflow _auditActionTabWorkflow;
        public WebDriverAuditActionTabPageWorkflow AuditActionTabWorkflow
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit Action")
                    SwitchToTab("Audit Action");
                return _auditActionTabWorkflow ??
                       (_auditActionTabWorkflow = new WebDriverAuditActionTabPageWorkflow(Driver, Waiter, "DV_DTC_RT"));
            }
        }

        private WebDriverAuditActionTabPageFullAdditionalFields _auditActionTabFullAdditionalFields;
        public WebDriverAuditActionTabPageFullAdditionalFields AuditActionTabFullAdditionalFields
        {
            get
            {
                FocusWindow();
                if (ActiveTabName() != "Audit Action")
                    SwitchToTab("Audit Action");
                return _auditActionTabFullAdditionalFields ??
                       (_auditActionTabFullAdditionalFields = new WebDriverAuditActionTabPageFullAdditionalFields(Driver, Waiter, "DV_DTC_RT"));
            }
        }

        public WebDriverAuditDetailDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "AuditDetailDialog.aspx")
        {
            HelpPages = new Dictionary<string, string>
            {
                {"Audit", "Audit Detail.htm"},
                {"Finding", "Audit_Findings_Details.htm"},
                {"Audit Action", "Audit_Actions_Details.htm"}
            };

            WaitUntilPageIsReady();
        }

        public void WaitUntilSaveButtonEnabled()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#DV_Save_btn")).Enabled);
        }

        public void CloseWithoutSaving()
        {
            CloseButton.AssertEnabled();
            CloseButton.Click();

            AssertAlertShown();
        }

        public new void Close()
        {
            CloseButton.AssertEnabled();
            CloseButton.Click();
        }

        public override void AssertHelpPageCorrect()
        {
            HelpButton.Click();
            base.AssertHelpPageCorrect();
        }

        public void AssertHelpPageFromHelpMenuCorrect()
        {
            var helpMenu = Menu.GetMenuItemById("MenuHelp");
            helpMenu.Click();
            helpMenu.ClickOption("Active Risk Manager Help");
            base.AssertHelpPageCorrect();
        }

        public void NewFinding()
        {
            SwitchToTab("Finding");
            FindingTab.NewFindingButton.Click();

            Waiter.Until(d => ActiveTabName() == "Finding");
            Waiter.Until(d => FindingTabFull.AuditTitle.IsDisplayed());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

        public void NewAuditAction()
        {
            SwitchToTab("Audit Action");
            AuditActionTab.NewAuditActionButton.Click();

            Waiter.Until(d => ActiveTabName() == "Audit Action");
            Waiter.Until(d => AuditActionTabFull.FindingTitle.IsDisplayed());
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

        public void NewAuditActionFromAuditAction()
        {
            AuditActionTabFull.NewAuditActionButton.Click();

            Waiter.Until(d => ActiveTabName() == "Audit Action");
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

        public void Save()
        {
            Waiter.Until(d => d.FindElement(By.CssSelector("button#DV_Save_btn")).Enabled);
            SaveButton.AssertEnabled();
            SaveButton.Click();

            Waiter.Until(d => !d.Title.StartsWith(" * "));
            WaitUntilUiSpinnerIsNotDisplayed();
            Waiter.Until(s => !SaveButton.IsEnabled());
            Driver.WaitForAjaxToComplete();
        }

        public void DeleteAudit()
        {
            var editMenu = Menu.GetMenuItemById("MenuEdit");

            editMenu.Click();
            editMenu.ClickOption("Delete");

            RespondToUiPrompt("Yes");
        }
    }
}
