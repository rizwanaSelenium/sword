﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Audit
{
    public class WebDriverAuditPasteHereDialog : WebDriverArmPage
    {
        public WebDriverTickBoxControl IncludeFindings { get; set; }
        public WebDriverTickBoxControl IncludeActions { get; set; }

        public WebDriverButton OkButton { get; set; }
        public WebDriverButton CancelButton { get; set; }

        public WebDriverAuditPasteHereDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "CopyAuditSettings.aspx")
        {
            IncludeFindings = new WebDriverTickBoxControl(Driver, Waiter, "input#RootView_IncludeFindings_chk", true);
            IncludeActions = new WebDriverTickBoxControl(Driver, Waiter, "input#RootView_IncludeActions_chk", true);

            OkButton = new WebDriverButton(Driver, Waiter, "RootView_OK_btn");
            CancelButton = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn");

            WaitUntilPageIsReady();
        }
    }
}
