﻿namespace PresentationModel.Controls.AuditDetail
{
    public static class AuditTabDropDownOptions
    {
        public static string[] TypeOptions = { "Undefined", "Type 1", "Type 2", "Type 3" };

        public static string[] CountryOptions = { "Undefined", "Uk", "USA" };

        public static string[] StatusOptions = { "Undefined", "Audit Status 1", "Audit Status 2", "Initiated" };
    }
}
