﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.AuditDetail
{
    public class WebDriverFindingTabPage : WebDriverArmControl
    {
        private WebDriverTableControl _findingGrid;
        public WebDriverTableControl FindingGrid
        {
            get { return _findingGrid ?? (_findingGrid = new WebDriverTableControl(Driver, Waiter, "DV_DTC_FT_FV_Table")); }
        }

        private WebDriverButton _newFindingButton;
        public WebDriverButton NewFindingButton
        {
            get { return _newFindingButton ?? (_newFindingButton = new WebDriverButton(Driver, Waiter, "DV_DTC_FT_FV_New_btn")); }
        }

        public WebDriverFindingTabPage(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, "div#" + id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }

    public class WebDriverFindingTabPageFull : WebDriverFindingTabPage
    {
        private WebDriverTextField _findingTabId;
        public WebDriverTextField FindingTabId
        {
            get { return _findingTabId ?? (_findingTabId = new WebDriverTextField(Driver, Waiter, "DV_DTC_FT_FV_FV_CustomFindingRef")); }
        }

        private WebDriverTextAreaControl _title;
        public WebDriverTextAreaControl Title
        {
            get { return _title ?? (_title = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_Title")); }
        }

        private WebDriverTextAreaControl _auditTitle;
        public WebDriverTextAreaControl AuditTitle
        {
            get
            {
                return _auditTitle ?? (_auditTitle = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_AuditTitle"));
            }
        }

        private WebDriverTextAreaControl _description;
        public WebDriverTextAreaControl Description
        {
            get
            {
                return _description ?? (_description = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_Description"));
            }
        }

        private WebDriverDatePicker _dateOfFinding;
        public WebDriverDatePicker DateOfFinding
        {
            get
            {
                return _dateOfFinding ?? (_dateOfFinding = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_FT_FV_FV_DateOfFinding"));
            }
        }

        private WebDriverTextField _timeOfFinding;
        public WebDriverTextField TimeOfFinding
        {
            get { return _timeOfFinding ?? (_timeOfFinding = new WebDriverTextField(Driver, Waiter, "DV_DTC_FT_FV_FV_TimeOfFinding")); }
        }

        private WebDriverTextField _owner;
        public WebDriverTextField Owner
        {
            get { return _owner ?? (_owner = new WebDriverTextField(Driver, Waiter, "DV_DTC_FT_FV_FV_Owner")); }
        }

        private WebDriverDropDown _reviewStatus;
        public WebDriverDropDown ReviewStatus
        {
            get { return _reviewStatus ?? (_reviewStatus = new WebDriverDropDown(Driver, Waiter, "DV_DTC_FT_FV_FV_ReviewStatus")); }
        }

        private WebDriverTextAreaControl _checklist;
        public WebDriverTextAreaControl Checklist
        {
            get
            {
                return _checklist ??
                       (_checklist = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_CheckList"));
            }
        }

        private WebDriverTextAreaControl _sample;
        public WebDriverTextAreaControl Sample
        {
            get { return _sample ?? (_sample = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_Sample")); }
        }

        private WebDriverTextAreaControl _udfText1;
        public WebDriverTextAreaControl UdfText1
        {
            get { return _udfText1 ?? (_udfText1 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFText1")); }
        }

        private WebDriverTextAreaControl _udfText2;
        public WebDriverTextAreaControl UdfText2
        {
            get
            {
                return _udfText2 ?? (_udfText2 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFText2"));
            }
        }

        private WebDriverTextAreaControl _udfText3;
        public WebDriverTextAreaControl UdfText3
        {
            get { return _udfText3 ?? (_udfText3 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFText3")); }
        }

        private WebDriverTextAreaControl _udfText4;
        public WebDriverTextAreaControl UdfText4
        {
            get { return _udfText4 ?? (_udfText4 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFText4")); }
        }

        private WebDriverTextAreaControl _udftext5;
        public WebDriverTextAreaControl UdfText5
        {
            get { return _udftext5 ?? (_udftext5 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFText5")); }
        }

        private WebDriverDropDown _udfDropDown1;
        public WebDriverDropDown UdfDropDown1
        {
            get { return _udfDropDown1 ?? (_udfDropDown1 = new WebDriverDropDown(Driver, Waiter, "DV_DTC_FT_FV_FV_UserDefinedDropDown1")); }
        }

        private WebDriverDropDown _udfDropDown2;
        public WebDriverDropDown UdfDropDown2
        {
            get { return _udfDropDown2 ?? (_udfDropDown2 = new WebDriverDropDown(Driver, Waiter, "DV_DTC_FT_FV_FV_UserDefinedDropDown2")); }
        }

        private WebDriverDatePicker _udfDate1;
        public WebDriverDatePicker UdfDate1
        {
            get { return _udfDate1 ?? (_udfDate1 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFDate1")); }
        }

        private WebDriverDatePicker _udfDate2;
        public WebDriverDatePicker UdfDate2
        {
            get { return _udfDate2 ?? (_udfDate2 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_FT_FV_FV_UDFDate2")); }
        }

        private WebDriverTextField _udfResource1;
        public WebDriverTextField UdfResource1
        {
            get { return _udfResource1 ?? (_udfResource1 = new WebDriverTextField(Driver, Waiter, "DV_DTC_FT_FV_FV_UserDefinedResource1")); }
        }

        private WebDriverTextField _udfResource2;
        public WebDriverTextField UdfResource2
        {
            get { return _udfResource2 ?? (_udfResource2 = new WebDriverTextField(Driver, Waiter, "DV_DTC_FT_FV_FV_UserDefinedResource2")); }
        }

        public WebDriverFindingTabPageFull(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }
}
