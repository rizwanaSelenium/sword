﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.AuditDetail
{
    public class WebDriverAuditTabPage : WebDriverArmControl
    {
        private WebDriverTextField _auditTabId;
        public WebDriverTextField AuditTabId
        {
            get { return _auditTabId ?? (_auditTabId = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_CustomAuditRef")); }
        }

        private WebDriverTextAreaControl _title;
        public WebDriverTextAreaControl Title
        {
            get { return _title ?? (_title = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Title")); }
        }

        private WebDriverDropDown _type;
        public WebDriverDropDown Type
        {
            get { return _type ?? (_type = new WebDriverDropDown(Driver, Waiter, "DV_DTC_AT_AV_AuditType")); }
        }

        private WebDriverTextField _contact;
        public WebDriverTextField Contact
        {
            get { return _contact ?? (_contact = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Contact")); }
        }

        private WebDriverDropDown _country;
        public WebDriverDropDown Country
        {
            get { return _country ?? (_country = new WebDriverDropDown(Driver, Waiter, "DV_DTC_AT_AV_Country")); }
        }

        private WebDriverTextAreaControl _location;
        public WebDriverTextAreaControl Location
        {
            get { return _location ?? (_location = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Location")); }
        }

        private WebDriverTextAreaControl _description;
        public WebDriverTextAreaControl Description
        {
            get { return _description ?? (_description = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Description")); }
        }

        private WebDriverDatePicker _plannedStartDate;
        public WebDriverDatePicker PlannedStartDate
        {
            get { return _plannedStartDate ?? (_plannedStartDate = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_PlannedStartDate")); }
        }

        private WebDriverDatePicker _plannedCompletionDate;
        public WebDriverDatePicker PlannedCompletionDate
        {
            get
            {
                return _plannedCompletionDate ?? (_plannedCompletionDate = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_PlannedCompletionDate"));
            }
        }

        private WebDriverDropDown _status;
        public WebDriverDropDown Status
        {
            get
            {
                return _status ?? (_status = new WebDriverDropDown(Driver, Waiter, "DV_DTC_AT_AV_AuditStatus"));
            }
        }

        private WebDriverTextField _manager;
        public WebDriverTextField Manager
        {
            get { return _manager ?? (_manager = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Manager")); }
        }

        private WebDriverTextField _auditTeam;
        public WebDriverTextField AuditTeam
        {
            get { return _auditTeam ?? (_auditTeam = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_AuditTeam")); }
        }

        private WebDriverTextAreaControl _objectives;
        public WebDriverTextAreaControl Objectives
        {
            get { return _objectives ?? (_objectives = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Objectives")); }
        }

        private WebDriverTextAreaControl _scope;
        public WebDriverTextAreaControl Scope
        {
            get { return _scope ?? (_scope = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Scope")); }
        }

        private WebDriverTextField _reviewer1;
        public WebDriverTextField Reviewer1
        {
            get { return _reviewer1 ?? (_reviewer1 = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Reviewer1")); }
        }

        private WebDriverDatePicker _reviewDate1;
        public WebDriverDatePicker ReviewDate1
        {
            get { return _reviewDate1 ?? (_reviewDate1 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_ReviewDate1")); }
        }

        private WebDriverTextAreaControl _references;
        public WebDriverTextAreaControl References
        {
            get { return _references ?? (_references = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_References")); }
        }

        private WebDriverTextAreaControl _observations;
        public WebDriverTextAreaControl Observations
        {
            get { return _observations ?? (_observations = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Observations")); }
        }

        private WebDriverTextAreaControl _positives;
        public WebDriverTextAreaControl Positives
        {
            get { return _positives ?? (_positives = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Positives")); }
        }

        private WebDriverTextAreaControl _conclusions;
        public WebDriverTextAreaControl Conclusions
        {
            get { return _conclusions ?? (_conclusions = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_Conclusions")); }
        }

        private WebDriverTextAreaControl _executiveSummary;
        public WebDriverTextAreaControl ExecutiveSummary
        {
            get
            {
                return _executiveSummary ?? (_executiveSummary = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_ExecutiveSummary"));
            }
        }

        private WebDriverTextField _reviewer2;
        public WebDriverTextField Reviewer2
        {
            get { return _reviewer2 ?? (_reviewer2 = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Reviewer2")); }
        }

        private WebDriverDatePicker _reviewDate2;
        public WebDriverDatePicker ReviewDate2
        {
            get { return _reviewDate2 ?? (_reviewDate2 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_ReviewDate2")); }
        }

        private WebDriverTextField _reviewer3;
        public WebDriverTextField Reviewer3
        {
            get { return _reviewer3 ?? (_reviewer3 = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Reviewer3")); }
        }

        private WebDriverDatePicker _reviewDate3;
        public WebDriverDatePicker ReviewDate3
        {
            get { return _reviewDate3 ?? (_reviewDate3 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_ReviewDate3")); }
        }

        private WebDriverTextField _reviewer4;
        public WebDriverTextField Reviewer4
        {
            get { return _reviewer4 ?? (_reviewer4 = new WebDriverTextField(Driver, Waiter, "DV_DTC_AT_AV_Reviewer4")); }
        }

        private WebDriverDatePicker _reviewDate4;
        public WebDriverDatePicker ReviewDate4
        {
            get
            {
                return _reviewDate4 ??
                       (_reviewDate4 = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_AT_AV_ReviewDate4"));
            }
        }

        public WebDriverAuditTabPage(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, "div#" + id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }

    public class WebDriverAuditTabPageWorkflow : WebDriverAuditTabPage
    {
        private WebDriverTextAreaControl _udfText1;
        public WebDriverTextAreaControl UdfText1
        {
            get
            {
                return _udfText1 ?? (_udfText1 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_UDFText1"));
            }
        }

        private WebDriverTextAreaControl _udfText2;
        public WebDriverTextAreaControl UdfText2
        {
            get
            {
                return _udfText2 ?? (_udfText2 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_AT_AV_UDFText2"));
            }
        }

        public WebDriverAuditTabPageWorkflow(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, id)
        {
            WaitForElementToAppear();
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }
}
