﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace PresentationModel.Controls.AuditDetail
{
    public class WebDriverAuditActionTabPage : WebDriverArmControl
    {
        private WebDriverTableControl _auditActionGrid;
        public WebDriverTableControl AuditActionGrid
        {
            get
            {
                return _auditActionGrid ?? (_auditActionGrid = new WebDriverTableControl(Driver, Waiter, "DV_DTC_RT_RV_Table"));
            }
        }

        private WebDriverButton _newAuditActionButton;
        public WebDriverButton NewAuditActionButton
        {
            get { return _newAuditActionButton ?? (_newAuditActionButton = new WebDriverButton(Driver, Waiter, "DV_DTC_RT_RV_New_btn")); }
        }

        public WebDriverAuditActionTabPage(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, "div#" + id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }

    public class WebDriverAuditActionTabPageFull : WebDriverAuditActionTabPage
    {
        private WebDriverTextField _auditActionTabId;
        public WebDriverTextField AuditActionTabId
        {
            get
            {
                return _auditActionTabId ?? (_auditActionTabId = new WebDriverTextField(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomAuditActionRef"));
            }
        }

        private WebDriverTextAreaControl _title;
        public WebDriverTextAreaControl Title
        {
            get { return _title ?? (_title = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_Title")); }
        }

        private WebDriverTextAreaControl _findingTitle;
        public WebDriverTextAreaControl FindingTitle
        {
            get
            {
                return _findingTitle ?? (_findingTitle = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_FindingTitle"));
            }
        }

        private WebDriverTextAreaControl _description;
        public WebDriverTextAreaControl Description
        {
            get { return _description ?? (_description = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_Description")); }
        }

        private WebDriverDropDown _processBeingAudited;
        public WebDriverDropDown ProcessBeingAudited
        {
            get
            {
                return _processBeingAudited ?? (_processBeingAudited = new WebDriverDropDown(Driver, Waiter, "DV_DTC_RT_RV_AV_Process"));
            }
        }

        private WebDriverDropDown _status;
        public WebDriverDropDown Status
        {
            get { return _status ?? (_status = new WebDriverDropDown(Driver, Waiter, "DV_DTC_RT_RV_AV_Status")); }
        }

        private WebDriverDropDown _priority;
        public WebDriverDropDown Priority
        {
            get { return _priority ?? (_priority = new WebDriverDropDown(Driver, Waiter, "DV_DTC_RT_RV_AV_Priority")); }
        }

        private WebDriverTextField _processOwner;
        public WebDriverTextField ProcessOwner
        {
            get
            {
                return _processOwner ?? (_processOwner = new WebDriverTextField(Driver, Waiter, "DV_DTC_RT_RV_AV_ProcessOwner"));
            }
        }

        private WebDriverDatePicker _dueDate;
        public WebDriverDatePicker DueDate
        {
            get { return _dueDate ?? (_dueDate = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_RT_RV_AV_DueDate")); }
        }

        private WebDriverDatePicker _plannedDueDate;
        public WebDriverDatePicker PlannedDueDate
        {
            get
            {
                return _plannedDueDate ?? (_plannedDueDate =
                           new WebDriverDatePicker(Driver, Waiter, "DV_DTC_RT_RV_AV_BaselineDueDate"));
            }
        }

        private WebDriverDatePicker _completionDate;
        public WebDriverDatePicker CompletionDate
        {
            get
            {
                return _completionDate ?? (_completionDate = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_RT_RV_AV_CompletionDate"));
            }
        }

        private WebDriverTextAreaControl _auditorComment;
        public WebDriverTextAreaControl AuditorComment
        {
            get
            {
                return _auditorComment ?? (_auditorComment = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_AuditorComment"));
            }
        }

        private WebDriverDatePicker _reviewDate;
        public WebDriverDatePicker ReviewDate
        {
            get
            {
                return _reviewDate ?? (_reviewDate = new WebDriverDatePicker(Driver, Waiter, "DV_DTC_RT_RV_AV_ReviewDate"));
            }
        }

        private WebDriverDropDown _reviewStatus;
        public WebDriverDropDown ReviewStatus
        {
            get { return _reviewStatus ?? (_reviewStatus = new WebDriverDropDown(Driver, Waiter, "DV_DTC_RT_RV_AV_ReviewStatus")); }
        }

        private WebDriverTextAreaControl _ownerComment;
        public WebDriverTextAreaControl OwnerComment
        {
            get { return _ownerComment ?? (_ownerComment = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_ActionOwnerComment")); }
        }

        private WebDriverTextAreaControl _udfText1;
        public WebDriverTextAreaControl UdfText1
        {
            get
            {
                return _udfText1 ??
                       (_udfText1 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomField1"));
            }
        }

        private WebDriverTextAreaControl _udfText2;
        public WebDriverTextAreaControl UdfText2
        {
            get { return _udfText2 ?? (_udfText2 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomField2")); }
        }

        private WebDriverTextAreaControl _udfText3;
        public WebDriverTextAreaControl UdfText3
        {
            get
            {
                return _udfText3 ?? (_udfText3 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomField3"));
            }
        }

        private WebDriverTextAreaControl _udfText4;
        public WebDriverTextAreaControl UdfText4
        {
            get { return _udfText4 ?? (_udfText4 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomField4")); }
        }

        public WebDriverAuditActionTabPageFull(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

    }

    public class WebDriverAuditActionTabPageFullAdditionalFields : WebDriverAuditActionTabPageFull
    {
        private WebDriverTextAreaControl _udfText5;
        public WebDriverTextAreaControl UdfText5
        {
            get { return _udfText5 ?? (_udfText5 = new WebDriverTextAreaControl(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomField5")); }
        }

        private WebDriverTextField _customResource1;
        public WebDriverTextField CustomResource1
        {
            get
            {
                return _customResource1 ?? (_customResource1 = new WebDriverTextField(Driver, Waiter, "DV_DTC_RT_RV_AV_CustomResource1"));
            }
        }

        public WebDriverAuditActionTabPageFullAdditionalFields(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }

    }

    public class WebDriverAuditActionTabPageWorkflow : WebDriverAuditActionTabPageFullAdditionalFields
    {
        public WebDriverAuditActionTabPageWorkflow(IWebDriver driver, WebDriverWait waiter, string id)
            : base(driver, waiter, id)
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());
        }
    }
}
