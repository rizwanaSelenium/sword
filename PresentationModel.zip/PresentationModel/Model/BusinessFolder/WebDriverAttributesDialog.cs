﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using NUnit.Framework;
using PresentationModel.Model.Item;
using TechTalk.SpecFlow;

namespace PresentationModel.Model.BusinessFolder
{
    public class WebDriverAttributesDialog : WebDriverItemDialog
    {
        private WebDriverTickBoxControl _showOnlySelected;

        public WebDriverTickBoxControl ShowOnlySelected
        {
            get
            {
                return _showOnlySelected ??
                       (_showOnlySelected =
                           new WebDriverTickBoxControl(Driver, Waiter, "input#selectedattributesonly", true, false));

            }
        }

        private WebDriverTickBoxControl _applyAttributesToChildren;

        public WebDriverTickBoxControl ApplyAttributesToChildren
        {
            get
            {
               return _applyAttributesToChildren ??
                       (_applyAttributesToChildren =
                           new WebDriverTickBoxControl(Driver, Waiter, "input#applytochildfolders", true, false));
            }
        }

        private WebDriverTextField _searchBox;

        public WebDriverTextField SearchBox
        {
            get
            {
                return _searchBox ??
                       (_searchBox = new WebDriverTextField(Driver, Waiter, "input#attributessearchterm", true));
            }
        }

        private WebDriverButton _okButton;
        public new WebDriverButton OkButton
        {
            get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "btnAttributesOk")); }
        }

        private WebDriverButton _saveButton;
        public new WebDriverButton SaveButton
        {
            get { return _saveButton ?? (_saveButton = new WebDriverButton(Driver, Waiter, "btnAttributesSave")); }
        }

        public WebDriverAttributesDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter)
        {

        }

        public void SelectAtrribute(string attributeName)
        {
           var selectElement = Driver.FindElement(By.CssSelector("div.modal-dialog div#attrtree_dropdown"));
            var attName = selectElement.FindElements(By.CssSelector("span.arm-tree-node"));
            foreach (var item in attName)
            {
                if (item.Text.Contains(attributeName))
                {
                    item.Click();
                }
            }
        }

        public void CheckIfAttributeSelected(string attributeName)
        {

            var selectElement = Driver.FindElement(By.CssSelector("treecontrol.arm-tree-control"));
            var selectedAttributename =
                selectElement.FindElement(By.CssSelector("treecontrol li .tree-selected.highlight-selected")).Text;
            Assert.AreEqual(attributeName, selectedAttributename);


        }

        public void ConfirmNoAttributesAreSelected()
        {
            var selectElement = Driver.FindElement(By.CssSelector("treecontrol.arm-tree-control"));

            var selectedAttributename = selectElement.FindElements(By.CssSelector("treecontrol li .tree-selected.highlight-selected"));
            Assert.AreEqual(0, selectedAttributename.Count, "Some attributes are selected by default");
        }

        public void CheckOnlySelectedAttributesAreDisplayed(Table attributeTabletable)
        {
            int i = 0;
            var selectElement = Driver.FindElement(By.CssSelector("div#attrtree"));
            IList<IWebElement> attributeList =
                selectElement.FindElements(By.CssSelector("treecontrol li .tree-selected.highlight-selected")).ToList();
            Assert.AreEqual(2, attributeList.Count);
            foreach (var rows in attributeTabletable.Rows)
            {
                Assert.AreEqual(attributeList.ElementAt(i).Text, rows["AttributeName"]);
                i++;
            }

        }

        public void SearchResults(string searchInput)
        {
            var selectElement = Driver.FindElement(By.CssSelector("div#attrtree"));
            var attributeName=
                selectElement.FindElements(By.CssSelector("treecontrol li .tree-selected.highlight-selected"));
            foreach (var attItem in attributeName)
            {
                bool result = attItem.Text.Contains(searchInput);
                Assert.IsTrue(result);
            }
            



        }
           
        
    }
}
