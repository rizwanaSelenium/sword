﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.BusinessFolder
{
    public class WebDriverBusinessFolderDialog : WebDriverItemDialog
    {
        private WebDriverDropDown _nodeStatusDropDown;
        public WebDriverDropDown NodeStatusDropDown
        {
            get
            {
                return _nodeStatusDropDown ?? (_nodeStatusDropDown = new WebDriverDropDown(Driver, Waiter, "select#NodeStatusId", true));
            }
        }


        private WebDriverDatePicker _plannedStartDate;
        public WebDriverDatePicker PlannedStartDate
        {
            get
            {
                return _plannedStartDate ?? (_plannedStartDate = new WebDriverDatePicker(Driver, Waiter, "input#PlannedStartDate", true));
            }
        }


        private WebDriverDropDown _nodeStatus;
        public WebDriverDropDown NodeStatus
        {
            get
            {
                return _nodeStatus ?? (_nodeStatus = new WebDriverDropDown(Driver, Waiter, "select#NodeStatusId", true, false));
            }

        }

        private WebDriverDatePicker _plannedEndDate;
        public WebDriverDatePicker PlannedEndDate
        {
            get
            {
                return _plannedEndDate ?? (_plannedEndDate = new WebDriverDatePicker(Driver, Waiter, "input#PlannedEndDate", true));
            }
        }

        private WebDriverTextField _reviewPeriod;
        public WebDriverTextField  ReviewPeriod
        {
            get
            {
                return _reviewPeriod ?? (_reviewPeriod = new WebDriverTextField(Driver, Waiter, "input#RiskReviewPeriod", true));
            }
        }

        private WebDriverDropDown _statusDropDown;
        public WebDriverDropDown StatusDropDown
        {
            get
            {
                return _statusDropDown ?? (_statusDropDown = new WebDriverDropDown(Driver, Waiter, "select#StatusId", true));
            }
        }

         private WebDriverTextField _percentageComplete;
         public WebDriverTextField  PercentageComplete
        {
            get
            {
                return _percentageComplete ?? (_percentageComplete = new WebDriverTextField(Driver, Waiter, "input#PercentageComplete", true));
            }
        }
        

        public WebDriverBusinessFolderDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            WaitUntilPlanningApplicationIsDisplayed();
            waiter.Until(d => ConfigurationDropDown.GetValue().Length > 0);
        }

       
        private void WaitUntilPlanningApplicationIsDisplayed()
        {
            bool planningApplicationDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var planningApplications = Driver.FindElements(By.CssSelector("input#PlanningApplicationName")).Where(x => x.Displayed).ToList();
                if (planningApplications.Count > 0)
                {
                    planningApplicationDisplayed = true;
                    break;
                }
            }

            if (!planningApplicationDisplayed)
            {
                Assert.Fail("Was waiting for the Business Folder Dialogue Planning Application Field to be Displayed, but it was not displayed");
            }
        }
    }
}
