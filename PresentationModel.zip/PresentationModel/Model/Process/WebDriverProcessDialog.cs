﻿using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.Process
{
    public class WebDriverProcessDialog : WebDriverItemDialog
    {
        private WdMvcDropDown _nodeStatus;
        public WdMvcDropDown NodeStatus
        {
            get
            {
                return _nodeStatus ?? (_nodeStatus = new WdMvcDropDown(Driver, Waiter, "", "NodeStatusId"));
            }
        }

        public WebDriverProcessDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            WaitUntilPlanningApplicationIsDisplayed();
            waiter.Until(d => ConfigurationDropDown.GetValue().Length > 0);
        }

      
        private void WaitUntilPlanningApplicationIsDisplayed()
        {
            bool planningApplicationDisplayed = false;

            for (var i = 1; i < 30; i++)
            {
                Thread.Sleep(1000);
                var planningApplications = Driver.FindElements(By.CssSelector("input#PlanningApplicationName")).Where(x => x.Displayed).ToList();
                if (planningApplications.Count > 0)
                {
                    planningApplicationDisplayed = true;
                    break;
                }
            }

            if (!planningApplicationDisplayed)
            {
                Assert.Fail("Was waiting for the Process Properties Dialogue Planning Application Field to be Displayed, but it was not displayed");
            }
        }
    }
}
