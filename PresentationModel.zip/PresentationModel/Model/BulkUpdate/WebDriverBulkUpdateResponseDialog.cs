﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.BulkUpdate
{
    public class WebDriverBulkUpdateResponseDialog : WebDriverArmPage
    {
        private WebDriverDropDownTextBoxEditText _chooseDataFieldsDropdown;
        private WebDriverDropDownTextBoxEditText ChooseDataFieldsDropDown
        {
            get { return _chooseDataFieldsDropdown ?? (_chooseDataFieldsDropdown = new WebDriverDropDownTextBoxEditText(Driver, Waiter, "dropDownTextBox editText"));}
        }

        private WebDriverButton _nextButton;
        public WebDriverButton NextButton
        {
            get { return _nextButton ?? (_nextButton = new WebDriverButton(Driver, Waiter, "RootView_Next_btn")); }
        }

        private WebDriverButton _confirmButton;
        public WebDriverButton ConfirmButton
        {
            get { return _confirmButton ?? (_confirmButton = new WebDriverButton(Driver, Waiter, "RootView_Confirm_btn")); }
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "RootView_Help_btn")); }
        }

        public WebDriverBulkUpdateResponseDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "BulkUpdateResponse.aspx")
        {
            WaitUntilPageIsReady();
        }

        public void ChooseOwnerFromDataFieldsDropDownWithValue(string valueToSelect)
        {
            ChooseDataFieldsDropDown.ChooseTextFieldItem("Owner", valueToSelect);
        }

        public void ChooseDueFromDataFieldsDropDownWithValueTomorrow()
        {
            ChooseDataFieldsDropDown.ChooseTomorrow("Due");
        }

        public void ChoosePriorityFromDataFieldsDropDownWithValue(string valueToSelect)
        {
            ChooseDataFieldsDropDown.ChooseDropdownItem("Priority", valueToSelect);
        }

        public void ClickNext()
        {
            NextButton.AssertEnabled();
            NextButton.Click();
        }

        public void ConfirmDateValuePropertiesInRowToBeChanged(int rowNumber, string fieldProperty, string valueProperty)
        {
            var alteredValueProperty = valueProperty;
            switch (valueProperty)
            {
                case "Today":
                    var todayDate = DateTime.Now.ToString("dd") + " " + DateTime.Now.ToString("MMMM") + " " + DateTime.Today.Year;
                    alteredValueProperty = todayDate;
                    break;
                case "Tomorrow":
                    var tomorrowDate = DateTime.Now.AddDays(1).ToString("dd") + " " + DateTime.Now.AddDays(1).ToString("MMMM") + " " + DateTime.Now.AddDays(1).Year;
                    alteredValueProperty = tomorrowDate;
                    break;
            }
            ConfirmFieldValuePropertiesInRowToBeChanged(rowNumber, fieldProperty, alteredValueProperty);
        }

        public void ConfirmFieldValuePropertiesInRowToBeChanged(int rowNumber, string fieldProperty, string valueProperty)
        {
            WaitUntilPageIsReady();
            var bulkUpdatePropertiesToBeChangedTable = new WebDriverTableControl(Driver, Waiter, "RootView_PropertiesChangedTable");
            bulkUpdatePropertiesToBeChangedTable.AssertCellText(rowNumber-1, 0, fieldProperty);
            bulkUpdatePropertiesToBeChangedTable.AssertCellText(rowNumber-1, 1, valueProperty);
        }

        public void ConfirmRecordsInRowToBeUpdated(int rowNumber, string recordId, string recordTitle)
        {
            WaitUntilPageIsReady();
            var bulkUpdateRecordsToBeUpdatedTable = new WebDriverTableControl(Driver, Waiter, "RootView_RecordsUpdatedTable");
            bulkUpdateRecordsToBeUpdatedTable.AssertCellText(rowNumber-1, 0, recordId);
            bulkUpdateRecordsToBeUpdatedTable.AssertCellText(rowNumber-1, 1, recordTitle);
        }

        public void ClickConfirm()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            ConfirmButton.Click();
            Waiter.Until(d => !(d.WindowHandles).Contains(currentWindowHandle));
        }

        public void AssertErrorPromptDisplayed()
        {
            Waiter.Until(x => !x.IsAjaxRequestInProgress());
            var errorPrompts = Driver.FindElements(By.CssSelector("div#UIPrompt"));

            if (errorPrompts.Count == 0)
            {
                Assert.Fail("No error prompts found on the Bulk Update Response Dialogue");
            }
        }

        public void ClickOkInErrorPrompt()
        {
            var errorPrompts = Driver.FindElements(By.CssSelector("div#UIPrompt"));

            if (errorPrompts.Count == 0)
            {
                Assert.Fail("No error prompts found on the Bulk Update Response Dialogue");
            }
            errorPrompts[0].FindElement(By.CssSelector("button[title='OK']")).Click();
        }

        public void AssertNumberOfBulkErrors(int numberOfErrorsExpected)
        {
            var bulkErrorsTable = new WebDriverTableControl(Driver, Waiter, "RootView_BulkErrorsTable");

            Assert.AreEqual(numberOfErrorsExpected, bulkErrorsTable.GetTotalRowCount());
        }

        public void ConfirmErrorValuesInRow(int rowNumber, string valid, string id, string type, string responseTitle,
            string message)
        {
            var bulkErrorsTable = new WebDriverTableControl(Driver, Waiter, "RootView_BulkErrorsTable");
            var bulkRowNumber = rowNumber - 1;
            
            AssertValidCellContains(bulkRowNumber, valid);
            bulkErrorsTable.AssertCellText(bulkRowNumber, 1, id);
            bulkErrorsTable.AssertCellText(bulkRowNumber, 2, type);
            bulkErrorsTable.AssertCellText(bulkRowNumber, 3, responseTitle);
            bulkErrorsTable.AssertCellText(bulkRowNumber, 4, message);
        }

        public void ClickBack()
        {
            var backButton = new WebDriverButton(Driver, Waiter, "RootView_Back_btn");
            backButton.AssertEnabled();
            backButton.Click();
        }

        //this should be removed and reworked
        public void ChangeOwnerValueUsingPrefixTo(string newOwner, string newOwnerPrefix)
        {
            var textFields = Driver.FindElements(By.CssSelector("input[title='Owner'][id^='clone']"));
            if (textFields.Count == 0)
            {
                Assert.Fail("No Owner Fields Found On The Bulk Update Response Dialogue");
            }
            var ownerTextFieldId = textFields[0].GetAttribute("id");
            var ownerTexField = new WebDriverTextField(Driver, Waiter, "div.armcontrol input[id='" + ownerTextFieldId + "']", true);
            ownerTexField.SetValue(newOwner);
        }

        private void AssertValidCellContains(int rowNumber, string valid)
        {
            switch (valid)
            {
                case "NotValid":
                    var cell = Driver.FindElement(By.CssSelector("div.tablecontrol#RootView_BulkErrorsTable td.grid-cell[id='" + rowNumber + "_Valid']"));
                    var notValidIcons = cell.FindElements(By.CssSelector("div.stg-icon-cross-enabled"));
                    if (notValidIcons.Count == 0)
                    {
                        Assert.Fail("Valid Cell Does Not Contain the Not Valid Symbol");
                    }
                    break;
                default:
                    Assert.Fail("Option: " + valid + " not found in Valid Cell");
                    break;
            }
        }
    }
}
