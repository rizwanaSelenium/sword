﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.BulkUpdate
{
    public class WebDriverBulkUpdateRiskDialog : WebDriverArmPage
    {
        //Old window but still exists in ARM

        private WebDriverDropDownTextBoxEditText _chooseDataFieldsDropDown;
        private WebDriverDropDownTextBoxEditText ChooseDataFieldsDropDown
        {
            get { return _chooseDataFieldsDropDown ?? (_chooseDataFieldsDropDown = new WebDriverDropDownTextBoxEditText(Driver, Waiter, "dropDownTextBox editText"));}
        }

        private WebDriverButton _nextButton;
        public WebDriverButton NextButton
        {
            get { return _nextButton ?? (_nextButton = new WebDriverButton(Driver, Waiter, "RootView_Next_btn")); }
        }

        private WebDriverButton _confirmButton;
        public WebDriverButton ConfirmButton
        {
            get { return _confirmButton ?? (_confirmButton = new WebDriverButton(Driver, Waiter, "RootView_Confirm_btn"));}
        }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "RootView_Help_btn")); }
        }
       
        public WebDriverBulkUpdateRiskDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "BulkUpdateRisk.aspx")
        {
            WaitUntilPageIsReady();
        }

        public void ChooseStatusFromDataFieldsDropDownWithValue(string valueToSelect)
        {
            ChooseDataFieldsDropDown.ChooseDropdownItem("Status", valueToSelect);
        }

        public void ChooseOwnerFromDataFieldsDropDownWithValue(string valueToSelect)
        {
            ChooseDataFieldsDropDown.ChooseTextFieldItem("Owner", valueToSelect);
        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();

            using (var page = new WebDriverHelpPage(Driver, Waiter, "Bulk_Update_Risk_Response.htm"))
            {
                page.AssertUrlEndsWith("Bulk_Update_Risk_Response.htm");
            }
        }

        public void ClickNext()
        {
            NextButton.AssertEnabled();
            NextButton.Click();
        }

        public void ConfirmFieldValuePropertiesInRowToBeChanged(int rowNumber, string fieldProperty, string valueProperty)
        {
            WaitUntilPageIsReady();
            var bulkUpdatePropertiesToBeChangedTable = new WebDriverTableControl(Driver, Waiter, "RootView_PropertiesChangedTable");
            bulkUpdatePropertiesToBeChangedTable.AssertCellText(rowNumber-1, 0, fieldProperty);
            bulkUpdatePropertiesToBeChangedTable.AssertCellText(rowNumber-1, 1, valueProperty);
        }

        public void ConfirmRecordsInRowToBeUpdated(int rowNumber, string recordId, string recordTitle)
        {
            WaitUntilPageIsReady();
            var bulkUpdateRecordsToBeUpdatedTable = new WebDriverTableControl(Driver, Waiter, "RootView_RecordsUpdatedTable");
            bulkUpdateRecordsToBeUpdatedTable.AssertCellText(rowNumber-1, 0, recordId);
            bulkUpdateRecordsToBeUpdatedTable.AssertCellText(rowNumber-1, 1, recordTitle);
        }

        public void ClickConfirm()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            ConfirmButton.Click();
            Waiter.Until(d => !(d.WindowHandles).Contains(currentWindowHandle));
        }
    }
}
