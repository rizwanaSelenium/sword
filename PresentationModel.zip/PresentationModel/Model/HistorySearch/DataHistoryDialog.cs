﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.HistorySearch
{
    public class DataHistoryDialog : WebDriverArmPage
    {
        private readonly WebDriverButton _searchButton;
        private readonly WebDriverButton _closeButton;

        public DataHistoryDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "history")
        {
            _searchButton = new WebDriverButton(Driver, Waiter, "btnSearch");
            _closeButton = new WebDriverButton(Driver, waiter, "Close");
        }

        public Boolean AssertDataHistoryFunctionExists(string functionName)
        {
            try
            {
                var historySearchDetailTable = Driver.FindElement(By.CssSelector("div.ui-grid-viewport"));

                Boolean flag = false;

                    var tablecolumnValue =
                        historySearchDetailTable.FindElements(By.CssSelector("div.ui-grid-cell-contents"));
                    foreach (var cellvalue in tablecolumnValue)
                    {
                        string cellText = cellvalue.Text;
                        if (cellText == functionName)
                        {
                            flag = true;
                            break;
                        }
                    }

                return flag;
            }
            finally
            {
                HistoryClose();
            }
        }


        public Boolean AssertFunctionExistsInAll(string functionName)
        {
            Driver.FindElement(By.CssSelector("input#searchSelectedElement")).Click();
            _searchButton.Click();
            try
            {
                var historySearchDetailTable = Driver.FindElement(By.CssSelector("div.ui-grid-viewport"));

                var flag = false;

                    var tablecolumnValue =
                        historySearchDetailTable.FindElements(By.CssSelector("div.ui-grid-cell-contents"));
                    foreach (var cellvalue in tablecolumnValue)
                    {
                        string cellText = cellvalue.Text;
                        if (cellText == functionName)
                        {
                            flag = true;

                            break;
                        }
                    }

                return flag;
            }
            finally
            {
                HistoryClose();
            }
        }


        public void HistoryClose()
        {
            FocusWindow();
            _closeButton.Click();
        }

        public void VerifyFunctionExistsInAll(string functionName, string statusComments)
        {
            Driver.FindElement(By.CssSelector("input#searchSelectedElement")).Click();
            _searchButton.Click();
            try
            {


                var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-viewport"));
                var historyRecords = historyTable.FindElements(By.CssSelector("div.ui-grid-row"));
                foreach (var record in historyRecords)
                {

                    if (record.FindElements(By.CssSelector("div.ui-grid-cell-contents"))[2].Text.Equals(functionName))
                    {

                        string temp = record.FindElement(By.CssSelector("div[data-target='#commentsModal']")).Text;
                        Assert.IsTrue(temp == statusComments);
                        break;
                    }


                }
            }
            finally
            {
                HistoryClose();
            }
        }
    }
}

    
