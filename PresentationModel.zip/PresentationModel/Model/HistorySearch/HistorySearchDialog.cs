﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.HistorySearch
{
    public class HistorySearchDialog : WebDriverArmPage
    {
        public static WebDriverButton SearchButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public static WebDriverTextField Name { get; set; }
        public WebDriverButton ViewButton { get; set; }
        public IWebElement IncidentHistorysearchTableControl { get; set; }

        public HistorySearchDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "HistoryData")
        {
            SearchButton = new WebDriverButton(Driver, Waiter, "btnSearch");
            CloseButton = new WebDriverButton(Driver, waiter, "Close");
            IncidentHistorysearchTableControl = Driver.FindElement(By.CssSelector("div#gridHistory"));
            ViewButton = new WebDriverButton(Driver, Waiter, "View");
        }

        public void Search()
        {
            SearchButton.AssertEnabled();
            SearchButton.Click();
        }

        public void SelectFirstRow()
        {
            IWebElement historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));

            var firstRow = historyTable.FindElement(By.CssSelector("div.ui-grid-cell-contents"));
            firstRow.Click();
        }

        public void SelectSecondRow()
        {
            Waiter.Until(d => !d.IsAjaxRequestInProgress());

            var firstRow = Driver.FindElement(By.CssSelector("table#auditReviewTable tbody tr#EntryRow1 td"));
            firstRow.Click();
        }

        public void ViewSelectedRow()
        {
            ViewButton.Click();
        }

        public void VerifyRecordUpdateData(string fieldToCheck, string expectedValue)
        {
            IWebElement historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var historyRecords = historyTable.FindElements(By.CssSelector("div.ui-grid-row"));
            foreach (var record in historyRecords)
                if (record.FindElement(By.CssSelector("div.ui-grid-cell-contents")).Text.Equals(fieldToCheck))
                {
                    string temp = record.FindElement(By.CssSelector("div[ng-if='row.entity.NewValue']")).Text;
                    Assert.IsTrue(temp == expectedValue);
                }
        }

        public void IncidentResuts()
        {
            Driver.SwitchTo().Frame(Driver.FindElement(By.Name("iFrAuditResults")));
            Driver.SwitchTo().Frame(Driver.FindElement(By.Name("audit_main")));
        }

        public void VerifyValuesInSecondSearchBusinessFolder(string incToCheck)
        {
            var secondRow = Driver.FindElements(By.CssSelector("div#gridHistory div.ui-grid-canvas div.ui-grid-row"))[1];

            var cells = secondRow.FindElements(By.CssSelector("div.ui-grid-cell"));

            Assert.AreEqual("ARMTest", cells[1].Text);
            Assert.AreEqual("Add Folder", cells[2].Text);
        }

        public void VerifyValuesInFirstSearchBusinessFolder(string incToCheck)
        {
            var firstRow = Driver.FindElements(By.CssSelector("div#gridHistory div.ui-grid-canvas div.ui-grid-row"))[0];

            var cells1 = firstRow.FindElements(By.CssSelector("div.ui-grid-cell"));

            Assert.AreEqual("ARMTest", cells1[1].Text);
            Assert.AreEqual("Update Folder", cells1[2].Text);
        }
    }
}