﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.HistorySearch
{
    public class HistorySearchCommentsDialogue :  WebDriverArmPage
    {
        private WebDriverButton _okButton;
        public WebDriverButton OkButton { get { return _okButton ?? (_okButton = new WebDriverButton(Driver, Waiter, "saveComment"));} }

        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton { get { return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "cancelComment")); } }

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton { get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "modalHelp")); } }

        private WebDriverTextAreaControl _comments;
        public WebDriverTextAreaControl Comments { get { return _comments ?? (_comments = new WebDriverTextAreaControl(Driver, Waiter, ".form-control.ng-valid.ng-valid-maxlength", true));} }

        private WebDriverTextAreaControl _remCharLabel;
        public WebDriverTextAreaControl RemCharlabel { get { return _remCharLabel ?? (_remCharLabel = new WebDriverTextAreaControl(Driver, Waiter, "p.pull-right.ng-binding", true));} }

       public HistorySearchCommentsDialogue(IWebDriver driver, WebDriverWait waiter)
           : base(driver, waiter, "Index")
        {
        }
    }
}
