﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Admin;

namespace PresentationModel.Model.HistorySearch
{
    public class IncidentHistorySearchDialog : WebDriverArmPage
    {
        public WebDriverTextField Recordid { get; set; }
        public WebDriverTextField Comments { get; set; }

        private WebDriverTextField _startDate;
        public WebDriverTextField StartDate
        {
            get
            {
                return _startDate ?? (_startDate = new WebDriverTextField(Driver, Waiter, "div[ng-model='historySearch.dateRange.startDate'] input", true));
            }
        }

        private WebDriverTextField _endDate;
        public WebDriverTextField EndDate
        {
            get { return _endDate ?? (_endDate = new WebDriverTextField(Driver, Waiter, "div[ng-model='historySearch.dateRange.endDate'] input", true)); }
        }

        public WebDriverDropDown FunctionControl { get; set; }
        public WebDriverDropDown OperationControl { get; set; }
        public WebDriverTextField Id { get; set; }
        public WebDriverTextField InicdentTitle { get; set; }
        public WebDriverButton SearchButton { get; set; }
        public WebDriverButton ResetButton { get; set; }
        public IWebElement SelectedRecordHistorySearch { get; set; }
        public WebDriverTextField PagecountonFooter { get; set; }

        private WebDriverTextField _totalItemsonFooter;
        public WebDriverTextField TotalItemsonFooter
        {
            get
            {
                return _totalItemsonFooter ??
                       (_totalItemsonFooter = new WebDriverTextField(Driver, Waiter, "div.ui-grid-pager-count span.ng-binding", true));
            }
        }

        public WebDriverButton ViewButton { get; set; }
        public WebDriverButton ExportButton { get; set; }
        public WebDriverButton HelpButton { get; set; }
        public WebDriverButton CloseButton { get; set; }
        public WebDriverButton NextButton { get; set; }
        public WebDriverButton PreviousButton { get; set; }

        public IncidentHistorySearchDialog(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "Index")
        {
            Recordid = new WebDriverTextField(Driver, Waiter, "input#customIdText", true);
            Comments = new WebDriverTextField(Driver, Waiter, "input#historyCommentsText", true);

            FunctionControl = new WebDriverDropDown(Driver, Waiter, "select#selectedFunction", true);
            OperationControl = new WebDriverDropDown(Driver, Waiter, "select#operation", true);
            Id = new WebDriverTextField(Driver, Waiter, "label#id", true);
            InicdentTitle = new WebDriverTextField(Driver, Waiter, "label#Name", true);
            SearchButton = new WebDriverButton(Driver, Waiter, "btnSearch");
            ResetButton = new WebDriverButton(Driver, Waiter, "btnReset");
            SelectedRecordHistorySearch = Driver.FindElement(By.CssSelector("input#searchSelectedElement"));
            PagecountonFooter = new WebDriverTextField(Driver, waiter, "SPAN.ui-grid-pager-row-count-label", true);
            CloseButton = new WebDriverButton(Driver, Waiter, "Close");
            ViewButton = new WebDriverButton(Driver, Waiter, "View");
            ExportButton = new WebDriverButton(Driver, Waiter, "Export");
            HelpButton = new WebDriverButton(Driver, Waiter, "Help");
        }

        public WebdriverIncidentHistoryDataDialog ViewIncidentHistorySearchDataDailog()
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".ui-grid-row"));
            var rowWeWant = fieldsA[0];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell"));
            var fieldLabel = contentCellsOfRow[0];
            fieldLabel.Click();
            fieldLabel.Click();
            ViewDetail();
            return OpenChildDialog<WebdriverIncidentHistoryDataDialog>();
        }

        public void AssertIncidentHistoryrowValues(int rowNumber, string function, string recordid, string user)
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var rowWeWant = fieldsA[rowNumber - 1];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell-contents"));
            var functionnamecontent = contentCellsOfRow[2].Text;
            var recordidcontent = contentCellsOfRow[3].Text;
            var usercontent = contentCellsOfRow[1].Text;

            Assert.AreEqual(function, functionnamecontent);
            Assert.AreEqual(recordid, recordidcontent);
            Assert.AreEqual(user, usercontent);
        }

        public HistorySearchCommentsDialogue OpenCommentsdialogInRow(int rowNumber)
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var rowWeWant = fieldsA[rowNumber - 1];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell-contents"));
            var comments = contentCellsOfRow[4];
            comments.Click();
            return OpenChildDialog<HistorySearchCommentsDialogue>();
        }

        public HistorySearchCommentsDialogue ClickPenIconToOpenCommentsDialogueInRow(int rowNumber)
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var rowWeWant = fieldsA[rowNumber - 1];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell-contents"));
            var comments = contentCellsOfRow[4];
            var penmark = comments.FindElement(By.TagName("i"));
            penmark.Click();
            return OpenChildDialog<HistorySearchCommentsDialogue>();
        }

        public void AssertIncidentHistorycommentsValues(int rowNumber, string comment)
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
            var rowWeWant = fieldsA[rowNumber - 1];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell-contents"));
            var commentcontent = contentCellsOfRow[4].Text;
            Assert.AreEqual(comment, commentcontent);
        }

        public void ViewDetail()
        {
            ViewButton.Click();
        }

        public void AssertDateRangeIsToday()
        {
            var today = DateTime.Now;
            var lastYear = today.AddYears(-1);
            StartDate.AssertEquals(lastYear.ToString("dd MMM yyyy"));
            EndDate.AssertEquals(today.ToString("dd MMM yyyy"));
        }

        public void AssertViewButtonDisabled()
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var fieldsA = historyTable.FindElements(By.CssSelector(".ui-grid-row"));
            var rowWeWant = fieldsA[0];
            var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell"));
            var fieldLabel = contentCellsOfRow[0];
            fieldLabel.Click();
            fieldLabel.Click();
            ViewButton.AssertDisabled();
        }

        public void AssertVisibleRowCount(int expectedCount)
        {
            var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
            var actualRowCount = historyTable.FindElements(By.CssSelector(".ui-grid-row")).Count;

            Assert.AreEqual(expectedCount, actualRowCount);
        }

        public string GetHistoryId(int rowNumber)
        {
            try
            {
                var historyTable = Driver.FindElement(By.CssSelector("div.ui-grid-canvas"));
                var fieldsA = historyTable.FindElements(By.CssSelector(".grid.ui-grid .ui-grid-row"));
                var rowWeWant = fieldsA[rowNumber - 1];
                var contentCellsOfRow = rowWeWant.FindElements(By.CssSelector(".ui-grid-cell-contents"));
                var historyidofRow = contentCellsOfRow[0].Text;
                return historyidofRow;
            }
            catch
            {
                return string.Empty;
            }
        }

        public override void Close()
        {
            FocusWindow();
            CloseButton.Click();
        }
    }
}
