﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Import
{
    public class ImportFromExcelDialogue : WebDriverArmPage
    {
        public FileSelector FileToImport { get; set; }

        public WebDriverButton ImportButton { get; set; }
        public WebDriverButton PreviewButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
        public WebDriverButton HelpButton { get; set; }

        public ImportFromExcelDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "ImportFromExcel.aspx")
        {
            FileToImport = new FileSelector(driver, waiter, "IFEV_UploadJobView_FileSelector");

            ImportButton = new WebDriverButton(driver, waiter, "IFEV_Import_btn");
            PreviewButton = new WebDriverButton(driver, waiter, "IFEV_Preview_btn");
            CancelButton = new WebDriverButton(driver, waiter, "IFEV_Cancel_btn");
            HelpButton = new WebDriverButton(driver, waiter, "IFEV_Help_btn");

            // Wait for page Initial Data Load, then page is ready, then JavaScript
            Waiter.Until(d => d.IsInitialDataLoadComplete());
            WaitUntilPageIsReady();
        }

        public void ClickCancel()
        {
            FocusWindow();
            var currentWindowHandle = Driver.CurrentWindowHandle;

            CancelButton.AssertEnabled();
            CancelButton.Click();

            Waiter.Until(d => !d.WindowHandles.Contains(currentWindowHandle));
        }

        public void AssertNoBackButton()
        {
            try
            {
                Driver.FindElement(By.CssSelector("button#IFEV_Back_btn"));
                Assert.Fail("Back button found on Import From Excel Dialogue - should not be present");
            }
            catch (NoSuchElementException)
            {
                // If we don't find the button, do nothing as we are not expecting it to be present
            }
        }

        public void AssertNoNextButton()
        {
            try
            {
                Driver.FindElement(By.CssSelector("button#IFEV_Next_btn"));
                Assert.Fail("Next button found on Import From Excel Dialogue - should not be present");
            }
            catch (NoSuchElementException)
            {
                // If we don't find the button, do nothing as we are not expecting it to be present
            }
        }
    }
}
