﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Help;

namespace PresentationModel.Model.DocumentManagement
{
    public class DocumentDialog : WebDriverArmPage
    {

        private WebDriverButton _helpButton;
        public WebDriverButton HelpButton
        {
            get { return _helpButton ?? (_helpButton = new WebDriverButton(Driver, Waiter, "Help")); }
        }

        public DocumentDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "Documents")
        {
            WaitUntilPageIsReady();

        }

        public void AssertHelpPageCorrect()
        {
            HelpButton.Click();
            var page = new WebDriverHelpPage(Driver, Waiter, "Documents.htm");
            page.AssertUrlEndsWith("Documents.htm");
            page.Close();
            
        }
    }
}