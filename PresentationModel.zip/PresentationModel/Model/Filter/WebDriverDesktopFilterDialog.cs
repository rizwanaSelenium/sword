﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;

namespace PresentationModel.Model.Filter
{
    public class WebDriverDesktopFilterDialog : WebDriverArmPage
    {
        public WebDriverDropDown FilterNameDropDown { get; set; }
        public WebDriverTextField FilterNameTextField { get; set; }
        public WebDriverRadioButton AllNodesRadioButton { get; set; }
        public WebDriverRadioButton CurrentNodeRadioButton { get; set; }
        public WebDriverRadioButton SelectTreeNodeRadioButton { get; set; }
        public WebDriverDropDownTextBox SelectNodeDropDownTextBox { get; set; }
        public WebDriverDropDownTextBox FilterCriteriaDownTextBox { get; set; }
        public WebDriverButton RunFilterButton { get; set; }
        public WebDriverButton SaveButton { get; set; }
        public WebDriverButton NewButton { get; set; }
        public WebDriverButton ClearButton { get; set; }
        public WebDriverButton DeleteButton { get; set; }
        public WebDriverButton CancelButton { get; set; }
       
        
        public WebDriverDesktopFilterDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter, "filterbuilder.aspx")
        {
            FilterNameDropDown = new WebDriverDropDown(driver, waiter, "select#V_FilterNameDropDown_cb", true);
            AllNodesRadioButton = new WebDriverRadioButton(driver, waiter, "input#V_AllNodes_rad", true);
            CurrentNodeRadioButton = new WebDriverRadioButton(driver, waiter, "input#V_CurrentNode_rad", true);
            SelectTreeNodeRadioButton = new WebDriverRadioButton(driver, waiter, "input#V_SelectNode_rad", true);           
            RunFilterButton = new WebDriverButton(driver, waiter, "V_Run_btn");
            SaveButton = new WebDriverButton(driver, waiter, "V_Save_btn");
            NewButton = new WebDriverButton(driver, waiter, "V_New_btn");
            ClearButton = new WebDriverButton(driver, waiter, "V_Clear_btn");
            DeleteButton = new WebDriverButton(driver, waiter, "V_Delete_btn");
            CancelButton = new WebDriverButton(driver, waiter, "V_Cancel_btn");
            WaitUntilPageIsReady();
            
        }
        
        private WebDriverTreeNode _selectFilterNodes;
        public WebDriverTreeNode SelectFilterNodes
        {
            get
            {
                _selectFilterNodes = new WebDriverTreeNode(Driver, Waiter, "treenode_1_div");
                return _selectFilterNodes;
            }
        }

        public void CreateNewFilter(String filterName)
        {
            NewButton.Click();
            Driver.FindElement(By.Id("V_FilterNameDropDown_tb")).SendKeys(filterName);
            SaveButton.Click();
            CancelButton.Click();            
        }

        public void DeleteFilter(String filterName)
        {            
            FilterNameDropDown.SetValue(filterName);
            DeleteButton.Click();
            RespondToUiPrompt("Yes");
            CancelButton.Click();
        }


    }
}
