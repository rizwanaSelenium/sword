﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Model.Item;

namespace PresentationModel.Model.BusinessArea
{
   public class CurrencyDialogue : WebDriverItemDialog
    {
        private WebDriverDropDown _selectCurrency;

        public  WebDriverDropDown SelectCurrency 
        {
        get
           {
               return _selectCurrency ?? (_selectCurrency = new WebDriverDropDown(Driver, Waiter, "select#itemCurrencyId", true));
           }

        }

        private WebDriverRadioButton _currencyUpdateToUnits;

        public WebDriverRadioButton CurrencyUpdateToUnits
        {
            get
            {
                return _currencyUpdateToUnits ?? (_currencyUpdateToUnits = new WebDriverRadioButton(Driver, Waiter, "input#updateOptionUnitsOnly",true,false));
               
            }
        }

        private WebDriverButton _cancelButton;

        public new WebDriverButton CancelButton
        {
            get
            {
                return _cancelButton ??
                       (_cancelButton = new WebDriverButton(Driver, Waiter, "btnItemCurrencyCancel"));
            }
        }
        private WebDriverButton _okButton;

        public new WebDriverButton OkButton
        {
            get
            {
                return _okButton ??
                       (_okButton = new WebDriverButton(Driver, Waiter, "btnItemCurrencyOk"));
            }
        }
        private WebDriverButton _helpButton;

        public new WebDriverButton HelpButton
        {
            get
            {
                return _helpButton ??
                       (_helpButton = new WebDriverButton(Driver, Waiter, "btnItemCurrencyHelp"));
            }
        }

       private WebDriverTickBoxControl _applyToChildren;

        public WebDriverTickBoxControl ApplyToChildren
        {
            get
            {
                return _applyToChildren ??
                       (_applyToChildren = new WebDriverTickBoxControl(Driver, Waiter, "input#updateCurrencyApplyToChildren", true,false));
            }
        }

    public CurrencyDialogue(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            
        }
    }
}
