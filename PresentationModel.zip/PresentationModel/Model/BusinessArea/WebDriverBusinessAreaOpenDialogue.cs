﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using NUnit.Framework;

namespace PresentationModel.Model.BusinessArea
{
    public class WebDriverBusinessAreaOpenDialogue : WebDriverArmPage
    {
        private WebDriverTableControl _selectBa;
        public WebDriverTableControl SelectBa
        {
            get
            {
                return _selectBa ?? (_selectBa = new WebDriverTableControl(Driver, Waiter, "RootView_BusinessAreas"));
            }
        }
        private WebDriverButton _cancelButton;
        public WebDriverButton CancelButton
        {
            get
            {
                return _cancelButton ?? (_cancelButton = new WebDriverButton(Driver, Waiter, "RootView_Cancel_btn"));
            }
        }
        
        public WebDriverBusinessAreaOpenDialogue(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "OpenBusinessArea.aspx")
        {
            WaitUntilUiSpinnerIsNotDisplayed();
            Waiter.Until(d => Driver.FindElement(By.CssSelector("form#form1")).Displayed);
        }

        public void AssertBusinessAreaExists(string businessAreaTitle)
        {
            bool businessAreaFound = false;
            var rows = SelectBa.FindElements(By.CssSelector("tr.grid-row"));
            foreach (var row in rows)
            {
                if (row.Text.Contains(businessAreaTitle))
                {
                    businessAreaFound = true;
                    break;
                }
            }
            if (!businessAreaFound)
            {
                Assert.Fail("Expecting Business Area: {0} to be present, but it was not", businessAreaTitle);
            }
        }

        public void AssertBusinessAreaDoesNotExist(string businessAreaTitle)
        {
            bool businessAreaFound = false;
            var rows = SelectBa.FindElements(By.CssSelector("tr.grid-row"));
            foreach (var row in rows)
            {
                if (row.Text.Contains(businessAreaTitle))
                {
                    businessAreaFound = true;
                    break;
                }
            }
            if (businessAreaFound)
            {
                Assert.Fail("Expected Business Area: {0} NOT to be present, but it WAS", businessAreaTitle);
            }
        }

        public void ClickCancel()
        {
            var currentWindowHandle = Driver.CurrentWindowHandle;
            CancelButton.AssertEnabled();
            CancelButton.Click();
            Waiter.Until(d => !d.WindowHandles.Contains((currentWindowHandle)));
        }
    }
}
