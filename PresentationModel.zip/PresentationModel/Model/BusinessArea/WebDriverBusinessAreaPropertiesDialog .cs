﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Item;
namespace PresentationModel.Model.BusinessArea
{
    public class WebDriverBusinessAreaPropertiesDialog : WebDriverItemDialog
    {
        
        public WebDriverBusinessAreaPropertiesDialog(IWebDriver driver, WebDriverWait waiter)
            : base(driver, waiter)
        {
            waiter.Until(d => ConfigurationDropDown.GetValue().Length > 0);
        }
    }
}
