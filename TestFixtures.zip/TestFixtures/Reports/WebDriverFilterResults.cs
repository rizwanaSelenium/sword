﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.WebDriver.Controls;

namespace TestFixtures.WebDriver.Reports
{
    public class WebDriverFilterResults : WebDriverArmPage
    {
        public WebDriverFilterResults(IWebDriver driver, WebDriverWait waiter) : base(driver, waiter, "ReportsRecordCount.aspx")
        {
            
        }
    }
}
