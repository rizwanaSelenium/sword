﻿using NUnit.Framework;
using TestFixtures.WebDriver;

namespace TestFixtures.Reports
{
    [TestFixture]
    public class WebDriverFilterResultsFixture : WebDriverDesktopFixture
    {
        [Test]
        public void Test()
        {
            Desktop.FilterSelector.Select("PublicFilter Specific Node");

            using (var filterReport = Desktop.ShowRecordCountReport())
            {
                filterReport.ResultsTable.AssertTableTitle("Recors Matched By Filter");
                filterReport.ResultsTable.AssertCellText(0, 1, "8");
            }
        }
    }
}
