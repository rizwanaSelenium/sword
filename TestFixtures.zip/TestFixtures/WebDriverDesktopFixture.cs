﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewSplashScreen;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures
{
    public class WebDriverDesktopFixture : RootWebDriverTest
    {
        public WebDriverDesktopFixture(ScenarioContext scenarioContext):base(scenarioContext)
        {           
            ScenarioContext = scenarioContext;
        }

        protected string ArmSplash;
        protected WebDriverDesktop Desktop;
        protected SurveyLandingPage LandingPage;
        protected ComplianceComponent CompliancePage;
        protected WebDriverDesktopNoAccess DesktopNoAccess;
        protected NewSplashScreenLogin NewSplashScreenLogin;

        protected string BaseArmUrl
        {
            get
            {
                var ip = "";
                if (ConfigurationManager.AppSettings["authenticationMode"] == "1")
                {
                    ip = ConfigurationManager.AppSettings["hostname"];
                }
                else if (ConfigurationManager.AppSettings["authenticationMode"] == "4")
                {
                    ip = ConfigurationManager.AppSettings["formsHostname"];
                }

                if (!Convert.ToBoolean(ConfigurationManager.AppSettings["localMode"]))
                {
                    ip =
                        Dns.GetHostEntry(Dns.GetHostName())
                            .AddressList.First(o => o.AddressFamily == AddressFamily.InterNetwork).ToString();
                }
                return ip + "/arm";
            }
        }

        protected string DirectBaseArmUrl
        {
            get
            {
                var ip = BaseArmUrl;

                var areaOfArm = ScenarioContext.Get<string>("ARM Area");
                switch (areaOfArm)
                {
                    case "desktop":
                    {
                        return ip + "/arm.aspx?inst=" + ScenarioContext.Get<int>("assignedInstanceID") + "&ba=" + BusinessAreaId;
                    }
                    case "survey":
                    {
                        return ip + "/" + ScenarioContext.Get<int>("assignedInstanceID") + "/" + BusinessAreaId + "/surveymanager/surveys";
                    }
                    case "compliance":
                    {
                        return ip + "/" + ScenarioContext.Get<int>("assignedInstanceID") + "/" + BusinessAreaId + "/compliance";
                    }
                    default:
                    {
                        throw new ArgumentException("Check ARM Area being passed in.");
                    }
                }
            }
        }

        private int _assignedInstanceId;
        protected const int BusinessAreaId = 1;

        protected const string WindowsAuthWastUsername = "WAST";
        protected const string WindowsAuthWastPassword = "wasttest1";

        protected string WindowsAuthDomain
        {
            get
            {
                if (!Convert.ToBoolean(ConfigurationManager.AppSettings["useLocalUsers"]))
                {
                    return ConfigurationManager.AppSettings["domain"];
                }

                return Dns.GetHostName();
            }
        }

        private static readonly object ActiveLoginsCheck = new object();
        public void Login(int businessAreaId, bool direct)
        {
            try
            {
                ArmSplash = !direct ? BaseArmUrl : DirectBaseArmUrl;

                base.TestFixtureSetup();
                Driver = ScenarioContext.Get<IWebDriver>();
                Waiter = ScenarioContext.Get<WebDriverWait>();

                ScenarioContext.Set(false, "FailedOnce");
                for (var i = 0; i < 2; i++)
                {
                    try
                    {
                        lock (ActiveLoginsCheck)
                        {
                            Waiter.Until(d => ActiveLogins < ConsecutiveLoginLimiter);
                            ActiveLogins++;
                            ScenarioContext.Set(true, "login Active");
                            Thread.Sleep(1000);
                        }
                        break;
                    }
                    catch (WebDriverTimeoutException)
                    {
                        if (ScenarioContext.Get<bool>("FailedOnce"))
                        {
                            throw new WebDriverTimeoutException("Timed out with the Active Login Checker twice.");
                        }

                        ScenarioContext.Set(true, "FailedOnce");
                    }
                }

                switch (ConfigurationManager.AppSettings["authenticationMode"])
                {
                    case "1":
                        GenerateAuthUrl(ArmSplash);
                        break;
                    case "4":
                        FormsAuthLogin(ArmSplash);
                        break;
                    default:
                        throw new Exception("Authentication mode not set to a valid value.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Caught exception in test Setup (Login): " + ex);
                Console.WriteLine(ex.StackTrace);
                Driver = ScenarioContext.Get<IWebDriver>();
                Driver.Quit();
                throw;
            }
        }

        [OneTimeSetUp]
        protected override void TestFixtureSetup()
        {
            try
            {
                ScenarioContext.Set(DateTime.Now.TimeOfDay, "TestStartTime");
                var direct = ScenarioContext.Get<bool>("Direct URL");
                if (!Convert.ToBoolean(ConfigurationManager.AppSettings["localMode"]))
                {
                    AllocateInstance();
                    _assignedInstanceId = ScenarioContext.Get<int>("assignedInstanceID");
                }
                else
                {
                    _assignedInstanceId = int.Parse(ConfigurationManager.AppSettings["localInstance"]);
                    ScenarioContext.Set(_assignedInstanceId, "assignedInstanceID");
                }

                Login(BusinessAreaId, direct);

                Driver = ScenarioContext.Get<IWebDriver>();
                Driver.Manage().Window.Maximize();

                if (!direct)
                {
                    NewSplashScreenLogin = new NewSplashScreenLogin(Driver, Waiter);
                    NewSplashScreenLogin.SplashWelcomeMessage.AssertEnabled();

                    NewSplashScreenLogin.SelectInstance("ARM Current", _assignedInstanceId);
                    NewSplashScreenLogin.SelectBusinessArea("Example Organisation", BusinessAreaId);
                }

                if (ScenarioContext.Get<string>("ARM Area") == "desktop")
                {
                    if (!direct)
                    {
                        NewSplashScreenLogin.ClickOnDesktopIcon();
                    }
                    Desktop = new WebDriverDesktop(Driver, Waiter);
                    ScenarioContext.Set(Desktop);
                    Desktop.FocusNewWindow();
                }
                else if (ScenarioContext.Get<string>("ARM Area") == "survey")
                {
                    if (!direct)
                    {
                        throw new NotImplementedException("Needs Implementation.");
                    }
                    LandingPage = new SurveyLandingPage(Driver, Waiter);
                    ScenarioContext.Set(LandingPage);
                    LandingPage.FocusNewWindow();
                }
                else if (ScenarioContext.Get<string>("ARM Area") == "compliance")
                {
                    if (!direct)
                    {
                        NewSplashScreenLogin.ClickOnComplianceManagerIcon();
                    }
                    CompliancePage = new ComplianceComponent(Driver, Waiter, "compliance");
                    ScenarioContext.Set(CompliancePage);
                    CompliancePage.FocusNewWindow();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    Console.WriteLine("Caught exception in test Setupm (TestFixtureSetup): " + ex);

                    Driver = ScenarioContext.Get<IWebDriver>();
                    Driver.Quit();
                    throw;
                }
                catch (KeyNotFoundException)
                {
                    Console.WriteLine("Test failed in setup, errored in tidyup as Driver did not exist. Will attempt to free the instance allocated.");
                }
            }
            finally
            {
                if (ScenarioContext.Get<bool>("login Active"))
                {
                    ScenarioContext.Set(false, "login Active");
                    ActiveLogins--;
                }
            }
        }

        [OneTimeTearDown]
        protected override void TestFixtureTearDown()
        {
            // We want to make sure that the release instance gets 
            // called otherwise we will lose the node during the run
            try
            {
                base.TestFixtureTearDown();
            }
            finally
            {
                ReleaseInstance();
            }
        }

        private void GenerateAuthUrl(string url, string mode = "normal")
        {
            var username = mode == "wast" ? WindowsAuthWastUsername : ConfigurationManager.AppSettings["username"];
            var password = mode == "wast" ? WindowsAuthWastPassword : ConfigurationManager.AppSettings["password"];
            var windowsAuthBase = "http://" + WindowsAuthDomain + "%5C" + username + ":" + password + "@";
            const string basic = "http://";

            Driver = ScenarioContext.Get<IWebDriver>();

            Driver.Navigate().GoToUrl(windowsAuthBase + url);
            var navigationFailedOnce = false;
            for (var i = 1 ; i < 2 ; i++)
            {
                try
                {
                    Driver.Navigate().GoToUrl(basic + url);
                    break;
                }
                catch (WebDriverTimeoutException tex)
                {
                    if (navigationFailedOnce)
                    {
                        throw new WebDriverTimeoutException("Timeout out navigating to ARM url: " + basic + url + " Failed twice. " + tex);
                    }
                    navigationFailedOnce = true;
                    Console.WriteLine("ALERT: Faield once navigating to ARM url " + basic + url + " will try one more time.");
                }
            }
        }

        private void FormsAuthLogin(string url)
        {
            var usernameBox = By.CssSelector("input#LoginProcess_LoginControl_UserName");
            var passwordBox = By.CssSelector("input#LoginProcess_LoginControl_Password");
            var loginButton = By.CssSelector("input#LoginProcess_LoginControl_LoginButton");

            var myUsername = ConfigurationManager.AppSettings["formsUsername"];
            var myPassword = ConfigurationManager.AppSettings["formsPassword"];

            Driver.Navigate().GoToUrl("https://" + url);

            Waiter.Until(d => d.FindElement(usernameBox));

            Driver.FindElement(usernameBox).Clear();
            Driver.FindElement(usernameBox).SendKeys(myUsername);

            Driver.FindElement(passwordBox).Clear();
            Driver.FindElement(passwordBox).SendKeys(myPassword);

            Driver.FindElement(loginButton).Click();
        }
    }

    public class SpecFlowRiskDesktopFixture : WebDriverDesktopFixture
    {
        public SpecFlowRiskDesktopFixture(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected override void TestFixtureSetup()
        {
            try
            {
                ScenarioContext.Set(false, "Direct URL");
                ScenarioContext.Set("desktop", "ARM Area");
                base.TestFixtureSetup();

                Desktop.GridSelector.Select("Risk, Issue...");
                Desktop.FilterSelector.Select("All nodes");

                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                  throw;
            }
        }

        protected void ComplianceSetup()
        {
            try
            {
                Driver = ScenarioContext.Get<IWebDriver>();
                Waiter = ScenarioContext.Get<WebDriverWait>();
                CompliancePage = new ComplianceComponent(Driver, Waiter);
                ScenarioContext.Set(CompliancePage);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
        }
    }

    public class LoginSetupFixture : WebDriverDesktopFixture
    {
        public LoginSetupFixture(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected void TestFixtureSetup(string area, bool directUrl, string filter = "Any", string gridType = "Any")
        {
            try
            {
                ValidParameterCheck(area, gridType);
                ScenarioContext.Set(directUrl, "Direct URL");
                ScenarioContext.Set(area.ToLower(), "ARM Area");
                base.TestFixtureSetup();

                if (area.ToLower() == "desktop")
                {
                    if (gridType != "Any")
                    {
                        Desktop.GridSelector.Select(gridType);
                    }
                    if (filter != "Any")
                    {
                        Desktop.FilterSelector.Select(filter);
                    }
                }

                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception ex)
            {
                throw new Exception("** ERROR ** Failed in LoginSetupFixture test never started. " + ex);
            }
        }

        private static void ValidParameterCheck(string area, string gridType)
        {
            var areaList = new List<string> { "desktop", "compliance", "dashboard", "survey", "risk express" };
            var gridTypeList = new List<string> { "Risk, Issue...", "Any" };

            if (!areaList.Contains(area.ToLower()))
            {
                throw new ArgumentException("Attempting to login into an unknown area, attempting to log into - " + area.ToLower());
            }

            if (!gridTypeList.Contains(gridType))
            {
                throw new ArgumentException("Attempting to use an unknown grid type, attempting to use - " + gridType);
            }
        }
    }

    public class SpecFlowDirectAnyDesktopFixture : WebDriverDesktopFixture
    {
        public SpecFlowDirectAnyDesktopFixture(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected void TestFixtureSetup(string area)
        {
            try
            {
                ScenarioContext.Set(area.ToLower(), "ARM Area");
                ScenarioContext.Set(true,"Direct URL");
                base.TestFixtureSetup();

                //This fixture will not set any filter or desktop grid as it does not affect the test what it is on
                
                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
        }
    }

    public class SpecFlowDirectRiskDesktopAnyFilterFixture : WebDriverDesktopFixture
    {
        public SpecFlowDirectRiskDesktopAnyFilterFixture(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected override void TestFixtureSetup()
        {
            ScenarioContext.Set("desktop", "ARM Area");
            ScenarioContext.Set(true, "Direct URL");
            base.TestFixtureSetup();
        }
    }

    public class SpecFlowDirectRiskDesktopNoFilterFixture : WebDriverDesktopFixture
    {
        public SpecFlowDirectRiskDesktopNoFilterFixture(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected void TestFixtureSetup(string area)
        {
            try
            {
                ScenarioContext.Set(area.ToLower(), "ARM Area");
                ScenarioContext.Set(true, "Direct URL");
                base.TestFixtureSetup();

                Desktop.GridSelector.Select("Risk, Issue...");
                Desktop.FilterSelector.Select("No Filter");
                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
        }
    }

    public class SpecFlowRiskDesktopFixtureNoFilter : WebDriverDesktopFixture
    {
        public SpecFlowRiskDesktopFixtureNoFilter(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected override void TestFixtureSetup()
        {
            try
            {
                ScenarioContext.Set(false, "Direct URL");
                ScenarioContext.Set("desktop", "ARM Area");
                base.TestFixtureSetup();
                
                Desktop.GridSelector.Select("Risk, Issue...");
                Desktop.FilterSelector.Select("No Filter");

                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
        }
    }

    public class SpecFlowRiskDesktopFixtureBasic : WebDriverDesktopFixture
    {
        public SpecFlowRiskDesktopFixtureBasic(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        protected override void TestFixtureSetup()
        {
            try
            {
                ScenarioContext.Set(false, "Direct URL");
                ScenarioContext.Set("desktop", "ARM Area");
                base.TestFixtureSetup();

                Driver = ScenarioContext.Get<IWebDriver>();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
        }
    }
}
