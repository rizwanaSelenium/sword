-- Insert new roles for Risk Visualiser--------------------------------------------------------------------------------------------------
--Risk Visualiser Full Privileges
DECLARE @RoleID int
SET @RoleID = (Select top 1 RoleID + 1 from RM_Role order by RoleID desc)
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Full Privileges', 'Risk Visualiser user can Add & Update Risk,Issue...,Update Impact, Add & Update Plan, Add & Update & Delete Response, Add & Update & Delete Evalaution, Add & Update & Delete Deficiency and Remediation Plan',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,1101
UNION ALL SELECT
@RoleID,	1200
UNION ALL SELECT
@RoleID,	1201
UNION ALL SELECT
@RoleID,	1300
UNION ALL SELECT
@RoleID,	1301
UNION ALL SELECT
@RoleID,	1302
UNION ALL SELECT
@RoleID,	1308
UNION ALL SELECT
@RoleID,	1309
UNION ALL SELECT
@RoleID,	1901
UNION ALL SELECT
@RoleID,	1902
UNION ALL SELECT
@RoleID,	1903
UNION ALL SELECT
@RoleID,	9000
UNION ALL SELECT
@RoleID,	9001
UNION ALL SELECT
@RoleID,	9004
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Privileges to Add & Update Risk,Issue...
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Add & Update Risk,Issue...', 'Risk Visualiser User can Add & Update Risk,Issue...',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	9000
UNION ALL SELECT
@RoleID,	9001
UNION ALL SELECT
@RoleID,	9004
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Update Impact
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Update Impact', 'Risk Visualiser User can Update Impact',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleId, 1101 
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Add & Update Plan
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Add & Update Plan', 'Risk Visualiser user can Add & Update Plan',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	1200
UNION ALL SELECT
@RoleID,	1201
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Add,Update & Delete Response
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Add,Update & Delete Response', 'Risk Visualiser User can Add & Update & Delete Response',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	1300
UNION ALL SELECT
@RoleID,	1301
UNION ALL SELECT
@RoleID,	1302
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Add,Update & Delete Evaluation
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Add,Update & Delete Evaluation', 'Risk Visualier User can Add & Update & Delete Evalaution',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	1308
UNION ALL SELECT
@RoleID,	1309
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Privileges to All elements accept Upate Impact
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Privileges to All elements accept Update Impact', 'Risk Visualier User can Add & update all elements accept Impact',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	9000
UNION ALL SELECT
@RoleID,	9001
UNION ALL SELECT
@RoleID,	1200
UNION ALL SELECT
@RoleID,	1201
UNION ALL SELECT
@RoleID,	1300
UNION ALL SELECT
@RoleID,	1301
UNION ALL SELECT
@RoleID,	1302
UNION ALL SELECT
@RoleID,	1306
UNION ALL SELECT
@RoleID,	1308
UNION ALL SELECT
@RoleID,	1309
UNION ALL SELECT
@RoleID,	1901
UNION ALL SELECT
@RoleID,	1902
UNION ALL SELECT
@RoleID,	1903
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701

--Risk Visualiser Add,Update & Delete Deficiency, Rating & Remediation Plan
SET @RoleId = @RoleID + 1
INSERT INTO RM_Role VALUES (@RoleID,'Risk Visualiser - Add,Update & Delete Deficiency & Remediation Plan', 'Risk Visualiser User can Add & Update & Delete Deficiency, Rating and Remediation Plan',10,2)

INSERT INTO RM_RoleHasFunction (RoleId, FunctionID) 
SELECT @RoleID,	1901
UNION ALL SELECT
@RoleID,	1902
UNION ALL SELECT
@RoleID,	1903
UNION ALL SELECT
@RoleID,	1401
UNION ALL SELECT
@RoleID,	1403
UNION ALL SELECT
@RoleID,	1406
UNION ALL SELECT
@RoleID,	1407
UNION ALL SELECT
@RoleID,	2701
-------