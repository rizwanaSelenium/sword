﻿using System;
using NUnit.Framework;
using PresentationModel.Controls.Angular;
using TechTalk.SpecFlow;
using PresentationModel.Model.Desktop;

namespace TestFixtures.ScoringDistribution.Steps
{
    [Binding]
    public class ChangeDistributionTypeSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private WebDriverDesktop _desktop;
        private ImpactComponent _scoringComponent;
        private RiskComponent _riskComponent;
        private AngularModal _messsageModal;

        public ChangeDistributionTypeSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [AfterScenario("ScoringChangeDistributionTypeTearDown")]
        public void AfterScenario()
        {
            try
            {
                _riskComponent.WaitUntilUiSpinnerIsNotDisplayed();
                _riskComponent = ScenarioContext.Get<RiskComponent>();
                _riskComponent.CloseButton.Click();
                _desktop = ScenarioContext.Get<WebDriverDesktop>();
                _desktop.FocusWindow();
                _desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [AfterScenario("ScoringChangeDistributionTypeWithSaveAlertTearDown")]
        public void TestFixtureTearDownWithSaveAlert()
        {
            try
            {
                _riskComponent = ScenarioContext.Get<RiskComponent>();
                _riskComponent.CloseButton.Click();
                _messsageModal = _riskComponent.ConfirmationModal;
                _messsageModal.AltActionButton.Click();
                _desktop = ScenarioContext.Get<WebDriverDesktop>();
                _desktop.FocusWindow();
                _desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }
        
        [Given(@"the user logs into ARM with no desktop filter")]
        public void GivenTheUserLogsIntoArmWithNoDesktopFilter()
        {
            TestFixtureSetup();
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
        }

        [Then(@"the user Opens Risk '(.*)' via context menu")]
        [When(@"the user Opens Risk '(.*)' via context menu")]
        [Given(@"the user Opens Risk '(.*)' via context menu")]
        public void GivenTheUserOpensRiskViaContextMenu(string riskName)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.FocusWindow();
            _desktop.RiskIssuesGrid.RightClickOnRecordAndSelectMenuItem("Risk", riskName, "ViewRisk");
            _riskComponent = _desktop.GetOpenedRisk();
            ScenarioContext.Set(_riskComponent);
        }

       [Given(@"the user is on the scoring screen")]
        public void GivenTheUserIsOnTheScoringScreen()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _scoringComponent = _riskComponent.Impact;
            ScenarioContext.Set(_scoringComponent);
        }

        [When(@"the user changes Distribution type to '(.*)' for Current Assessment")]
        public void WhenTheUserChangesDistributionTypeToForCurrentAssessment(string distributionType)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.Impact.CurrentAssessment.Distribution.SelectByText(distributionType);
        }

        [Then(@"the Distribution type field is changed to '(.*)'")]
        public void ThenTheDistributionTypeFieldIsChangedTo(string distributionType)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.Impact.CurrentAssessment.Distribution.AssertTextEquals(distributionType);
        }


        [Then(@"the correct distribution fields should be enabled '(.*)', '(.*)' , '(.*)'")]
        public void ThenTheCorrectDistributionFieldsShouldBeEnabled(string min, string exp, string max)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            string[] impactCategory = new[] {"Cost", "Time"};
            foreach (var _iC in impactCategory)
            {
                _scoringComponent.CurrentAssessment.ImpactCategoryValues.AssertImpactValueFieldState(_iC, "min", min);
                _scoringComponent.CurrentAssessment.ImpactCategoryValues.AssertImpactValueFieldState(_iC, "exp", exp);
                _scoringComponent.CurrentAssessment.ImpactCategoryValues.AssertImpactValueFieldState(_iC, "max", max);
            }
        }

        [When(@"the user seen the alert message")]
        [Then(@"the user seen the alert message")]
        [When(@"the user sees a distribution popup appears")]
        public void WhenTheUserSeesADistributionPopupAppears()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _messsageModal = _riskComponent.ConfirmationModal;
            ScenarioContext.Set(_messsageModal);
        }

        [Then(@"the user see no pop up displayed")]
        public void ThenTheUserSeeNoPopUpDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.IsFalse(_riskComponent.IsMessageModalPopUpDisplayed());
        }

        [Then(@"the user should see a distribution popup stating '(.*)'")]
        public void ThenTheUserShouldSeeADistributionPopupStating(string p0)
        { 
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _messsageModal = _riskComponent.ConfirmationModal;
            ScenarioContext.Set(_messsageModal);
            _messsageModal = ScenarioContext.Get<AngularModal>();
            _messsageModal.ModalHeaderText.AssertTextEquals("Distribution");
            string message = _messsageModal.ModalText.GetText();
            Assert.AreEqual(message, p0);         
        }

       [Then(@"the user clicks No in the popup")]
        public void ThenTheUserClicksNoInThePopup()
        {
            _messsageModal.NoButton.Click();
            _scoringComponent = _riskComponent.Impact;
            ScenarioContext.Set(_scoringComponent);
        }

        [Then(@"the current assessment distribution field '(.*)' should remain expected")]
        public void ThenTheCurrentAssessmentDistributionFieldShouldRemainExpected(string distributionType)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.Distribution.AssertTextEquals(distributionType);
        }
       
       [Given(@"the user enter all values for category '(.*)' , '(.*)' , '(.*)' , '(.*)'")]
        public void GivenTheUserEnterAllValuesForCategory(string category, string min, string exp, string max)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, min, "min");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, exp, "exp");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, max, "max");
        }

        [When(@"the user clicks Yes in the distribution type popup")]
        [Then(@"the user clicks Yes in the distribution type popup")]
        public void WhenTheUserClicksYesInTheDistributionTypePopup()
        {
            _messsageModal.YesButton.Click();
            _scoringComponent = _riskComponent.Impact;
            ScenarioContext.Set(_scoringComponent);
        }
        
        [Then(@"the alert message is displayed with the title '(.*)'")]
        public void ThenTheAlertMessageIsDisplayedWithTheTitle(string title)
        {
            _messsageModal = ScenarioContext.Get<AngularModal>();
            _messsageModal.ModalHeaderText.AssertTextEquals(title);
        }

        [Then(@"the alert message displayed with message (.*)")]
        public void ThenTheAlertMessageDisplayedWithMessage(string message)
        {
            _messsageModal = ScenarioContext.Get<AngularModal>();
            _messsageModal.ModalBodyText.AssertTextEquals("The Time Category's minimum and maximum values have both been updated to prevent a negative minimum value");
        }

        [When(@"the user clicks Ok in alert message")]
        [Then(@"the user clicks Ok in alert message")]
        public void ThenTheUserClicksOkInAlertMessage()
        {
            _messsageModal = ScenarioContext.Get<AngularModal>();
            _messsageModal.Yes();
        }

        [Then(@"the time category values are set correctly '(.*)' , '(.*)' , '(.*)' , '(.*)'")]
        public void ThenTheTimeCategoryValuesAreSetCorrectly(string category, string minValue, string expValue, string maxValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category,minValue,"min");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category,expValue,"exp");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category,maxValue,"max");
        }

        [Then(@"the time category values are set correctly '(.*)' , '(.*)' , '(.*)' with Normal distribution")]
        public void ThenTheTimeCategoryValuesAreSetCorrectlyWithNormalDistribution(string category, string minValue, string maxValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category, minValue, "min");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category, maxValue, "max");
        }

        [Given(@"the user enter values for '(.*)' , '(.*)' , '(.*)'")]
        public void GivenTheUserEnterValuesFor(string category, string minValue, string maxValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, minValue, "min");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, maxValue, "max");
        }

        [Then(@"the correct qualitative distribution should be enabled '(.*)'")]
        public void ThenTheCorrectQualitativeDistributionShouldBeEnabled(string state)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            string[] impactCategory = new[] { "Cost", "Time" };
            foreach (var _iC in impactCategory)
            {
                _scoringComponent.CurrentAssessment.ImpactCategoryValues.AssertImpactQuantitativeFieldEnable(_iC, state);
            }
        }

        [Given(@"the user enter level for category '(.*)' , '(.*)'")]
        public void GivenTheUserEnterLevelForCategory(string category, string value)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetQuantitativeImpact(category, value);
        }

        [Then(@"the time category level is set correctly '(.*)' , '(.*)' for '(.*)' Scoring Type")]
        public void ThenTheTimeCategoryLevelIsSetCorrectly(string category, string value, string scoringType)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _desktop.WaitUntilUiSpinnerIsNotDisplayed();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(category, value, scoringType);
        }

        [Given(@"the user enter Normal values for '(.*)' , '(.*)' , '(.*)'")]
        public void GivenTheUserEnterNormalValuesFor(string category, string expValue, string maxValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, expValue, "exp");
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, maxValue, "max");
        }

        [Then(@"the time category values are set correctly '(.*)' , '(.*)' for Normal distribution")]
        public void ThenTheTimeCategoryValuesAreSetCorrectlyForNormalDistribution(string category, string minValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category, minValue, "min");
        }

        [Given(@"the user enter values for '(.*)' , '(.*)' for Single Point distribution")]
        public void GivenTheUserEnterValuesForForSinglePointDistribution(string category, string expValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.SetImpactValue(category, expValue, "exp");
        }

        [Then(@"the time category values are set correctly '(.*)' , '(.*)' for Single Point distribution")]
        public void ThenTheTimeCategoryValuesAreSetCorrectlyForSinglePointDistribution(string category, string expValue)
        {
            _scoringComponent = ScenarioContext.Get<ImpactComponent>();
            _scoringComponent.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(category, expValue, "exp");
        }
    }
}
