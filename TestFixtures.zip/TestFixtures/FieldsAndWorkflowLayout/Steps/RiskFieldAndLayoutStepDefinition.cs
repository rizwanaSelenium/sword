﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.FieldsAndWorkflowLayout.Steps
{
    [Binding]
    public sealed class RiskFieldAndLayoutStepDefinition : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private FieldsAndLayout _fieldAndLayout;

        public RiskFieldAndLayoutStepDefinition(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("RiskLayout")]
        public void AfterScenario()
        {
            try
            {
                _fieldAndLayout.CloseLayoutScreen();
                _adminDialog.CloseButton.Click();
                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"I Logged in as an Admin User")]
        public void GivenILoggedInAsAnAdminUser()
        {
            TestFixtureSetup();
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
        }

        [When(@"I navigate to the Admin screen")]
        public void WhenINavigateToTheAdminScreen()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ClickOnToolsMenu();
            _adminDialog = Desktop.AdminDialog();
            ScenarioContext.Set(_adminDialog);

        }

        [When(@"Clicked on Fields and Workflow")]
        public void WhenClickedOnFieldsAndWorkflow()
        {
            _fieldAndLayout = _adminDialog.FieldsAndWorkflowTabPage.OpenRiskFieldsAndLayoutPage();
        }

        [Given(@"the user is at the Admin '(.*)' screen")]
        public void GivenTheUserIsAtTheAdminScreen(string expectedLayoutScreenTitle)
        {
            _fieldAndLayout.AssertLayoutScreenTitle(expectedLayoutScreenTitle);
        }


        [When(@"the user adds a new row to the layout screen")]
        public void WhenTheUserAddsANewRowToTheLayoutScreen()
        {
            ScenarioContext.Set(_fieldAndLayout.GetFieldRows().Count, "rowCount");
            _fieldAndLayout.AddRow.Click();
        }

        [Then(@"the user verifies new row is added to the layout screen")]
        public void ThenANewRowIsAddedToTheLayoutScreen()
        {
            ScenarioContext.Set(_fieldAndLayout.GetFieldRows().Count, "newRowCount");
            Assert.AreEqual(ScenarioContext.Get<int>("rowCount"), ScenarioContext.Get<int>("newRowCount") - 1);
        }

        [When(@"the user deletes the new row")]
        public void WhenTheUserDeletesTheNewRow()
        {
            _fieldAndLayout.RemoveRowFromLayout(ScenarioContext.Get<int>("newRowCount"));
        }

        [Then(@"the user verifies row is removed from layout screen")]
        public void ThenRowIsRemovedFromLayoutScreen()
        {
            Assert.AreEqual(ScenarioContext.Get<int>("rowCount"), _fieldAndLayout.GetFieldRows().Count());
            ScenarioContext.Remove("rowCount");
        }

        [Then(@"the user verifies '(.*)' field of type '(.*)' is moved to the available fields section")]
        public void ThenVerifyFieldOfTypeIsMovedToTheAvailableFieldsSection(string field, string fieldType)
        {
            bool verifyFieldExists = _fieldAndLayout.GetAvailableFieldsByType(fieldType).Any(x => x.Text.Equals(field));
            Assert.IsTrue(verifyFieldExists, "Field " + field + " is not available in the available fields section");
        }

        [When(@"the user gets the fields from row '(.*)' and row '(.*)'")]
        public void WhenTheUserGetsTheFieldsFromRowAndRow(int sourceRow, int targetRow)
        {
            ScenarioContext.Set(_fieldAndLayout.GetElementsFromRow(sourceRow), "sourceRowElementsBeforeDragAndDrop");
            ScenarioContext.Set(_fieldAndLayout.GetElementsFromRow(targetRow), "targetRowElementsBeforeDragAndDrop");
        }

        [When(@"the user drag and drops a row from row '(.*)' to row '(.*)' on the layout screen")]
        public void WhenTheUserDragAndDropsARowFromRowToRowOnTheLayoutScreen(int sourceRowNumber, int targetRowNumber)
        {
            _fieldAndLayout.DragAndDropRow(sourceRowNumber, targetRowNumber);
        }

        [Then(@"the user verifies correct fields are displayed in row '(.*)' and row '(.*)' after drag and drop")]
        public void ThenTheUserVerifiesCorrectFieldsAreDisplayedInRowAndRowAfterDragAndDrop(int targetRowNumber, int sourceRowNumber)
        {
            IList<IWebElement> sourceRowElementsAfterDragAndDrop = _fieldAndLayout.GetElementsFromRow(sourceRowNumber);
            IList<IWebElement> targetRowElementsAfterDragAndDrop = _fieldAndLayout.GetElementsFromRow(targetRowNumber);

            Assert.IsTrue(_fieldAndLayout.ListsAreTheSame(ScenarioContext.Get<IList<IWebElement>>("sourceRowElementsBeforeDragAndDrop"), sourceRowElementsAfterDragAndDrop),
                "Fields in the row " + sourceRowNumber + " are not the same before drag and drop row");
            Assert.IsTrue(_fieldAndLayout.ListsAreTheSame(ScenarioContext.Get<IList<IWebElement>>("targetRowElementsBeforeDragAndDrop"), targetRowElementsAfterDragAndDrop),
                "Fields in the row " + targetRowNumber + " are not the same before drag and drop row");

            ScenarioContext.Remove("sourceRowElementsBeforeDragAndDrop");
            ScenarioContext.Remove("targetRowElementsBeforeDragAndDrop");
        }

        [When(@"the user drag and drop '(.*)' field of type '(.*)' from available fields to the row '(.*)' on the layout screen")]
        public void WhenTheUserDragAndDropFieldOfTypeFromavailableFieldsToTheRowOnTheLayoutScreen(string field, string fieldType, int rowNumberToDrop)
        {
            _fieldAndLayout.DragAndDropAvailableFieldsToTheLayoutSection(field, fieldType, rowNumberToDrop);
        }

        [Then(@"verify field '(.*)' is added to the row '(.*)' successfully")]
        public void ThenVerifyFieldIsAddedToTheRowSuccessfully(string field, int rowNumberToDrop)
        {
            _fieldAndLayout.AssertFieldIsDraggedToTheLayout(field, rowNumberToDrop);
        }

        [When(@"the user drag and drop '(.*)' field of type '(.*)' from available fields to the new row on the layout")]
        public void WhenTheUserDragAndDropFieldOfTypeFromavailableFieldsToTheNewRowOnTheLayout(string field, string fieldType)
        {
            _fieldAndLayout.DragAndDropAvailableFieldsToTheLayoutSection(field, fieldType, ScenarioContext.Get<int>("rowCount"));
        }

        [Then(@"the user verifies '(.*)' field is added to the new row successfully")]
        public void ThenVerifyFieldIsAddedToTheNewRowSuccessfully(string field)
        {
            _fieldAndLayout.AssertFieldIsDraggedFromAvailableFieldsToTheLayout(field, ScenarioContext.Get<int>("rowCount"));
        }

        [Then(@"the user verifies '(.*)' field is not highlighted in the layout section")]
        public void ThenTheUserVerifiesFieldIsNotHighlightedInTheLayoutSection(string field)
        {
            _fieldAndLayout.AssertDraggedFieldIsNotHighlightedAfterClickingSave(field, ScenarioContext.Get<int>("rowCount"));
        }


        [When(@"the user deletes the field '(.*)' in the layout screen")]
        public void WhenTheUserDeletesTheFieldInThaLayoutScreen(string field)
        {
            _fieldAndLayout.RemoveFieldFromLayout(field);
        }

        [When(@"the user drag and drop '(.*)' field to the row '(.*)' on the layout screen")]
        public void WhenTheUserDragAndDropFieldToTheRowOnTheLayoutScreen(string field, int rowNumber)
        {
            _fieldAndLayout.DragAndDropFieldsWithInTheLayout(field, rowNumber);
        }

        [When(@"the user select a default value '(.*)' for field '(.*)' on the layout screen")]
        public void WhenTheUserSelectADefaultValueForFieldOnTheLayoutScreen(string defaultValue, string field)
        {
            _fieldAndLayout.SelectDefaultValueForField(field, defaultValue);
        }

        [When(@"the user click on Save on the layout screen")]
        public void WhenIClickOnSaveOnTheLayoutScreen()
        {
            _fieldAndLayout.Save.Click();
        }

        [Then(@"the user verifies '(.*)' field displays the default value '(.*)' in the Risk layout screen")]
        public void ThenTheUserVerifiesFieldDisplaysTheDefaultValueInTheRiskLayoutScreen(string field, string defaultValue)
        {
            _fieldAndLayout.AssertSelectedDefaultValueIsDisplayedInTheDropdownList(field, defaultValue);
        }

        [When(@"the user select a '(.*)' checkbox for field '(.*)' on the layout screen")]
        public void WhenTheUserSelectACheckboxForFieldOnTheLayoutScreen(string checkBoxToSelect, string field)
        {
            _fieldAndLayout.SelectMandatoryOrReadOnlyCheckBoxForField(field, checkBoxToSelect);
        }

        [Then(@"the user verifies '(.*)' checkbox is selected for field '(.*)' in the Risk layout screen")]
        public void ThenTheUserVerifiesCheckboxIsSelectedForFieldInTheRiskLayoutScreen(string checkBoxToSelect, string field)
        {
            _fieldAndLayout.AssertCheckBoxIsSelected(field, checkBoxToSelect);
        }

        [When(@"the user close the risk layout screen")]
        public void WhenTheUserCloseTheRiskLayoutScreen()
        {
            _fieldAndLayout.CloseLayoutScreen();
        }

        [When(@"the user navigates back to '(.*)' screen")]
        public void WhenTheUserNavigatesBackToScreen(string expectedLayoutScreenTitle)
        {
            _fieldAndLayout = _adminDialog.FieldsAndWorkflowTabPage.OpenRiskFieldsAndLayoutPage();
            _fieldAndLayout.AssertLayoutScreenTitle(expectedLayoutScreenTitle);
        }

        [When(@"the user adds a new divider row to the layout screen")]
        public void WhenTheUserAddsANewDividerRowToTheLayoutScreen()
        {
            ScenarioContext.Set(_fieldAndLayout.GetFieldRows().Count, "rowCount");
            _fieldAndLayout.DividerRow.Click();
        }

        [Then(@"the user verifies new divider is added to the layout screen")]
        public void ThenTheUserVerifiesNewDividerIsAddedToTheLayoutScreen()
        {
            ScenarioContext.Set(_fieldAndLayout.GetFieldRows().Count, "newRowCount");
            Assert.AreEqual(ScenarioContext.Get<int>("rowCount"), ScenarioContext.Get<int>("newRowCount") - 1);
            _fieldAndLayout.AssertDividerRowIsAddedToTheLayout(ScenarioContext.Get<int>("rowCount"));

        }

        [When(@"the user unselect a '(.*)' checkbox for field '(.*)' on the layout screen")]
        public void WhenTheUserUnselectACheckboxForFieldOnTheLayoutScreen(string checkBoxName, string fieldName)
        {
            _fieldAndLayout.UnselectMandatoryOrReadOnlyCheckBoxForField(fieldName, checkBoxName);
        }

        [Then(@"the user verifies '(.*)' checkbox is unselected for field '(.*)' in the Risk layout screen")]
        public void ThenTheUserVerifiesCheckboxIsUnselectedForFieldInTheRiskLayoutScreen(string checkBoxName, string fieldName)
        {
            _fieldAndLayout.AssertCheckBoxIsNotSelected(fieldName, checkBoxName);
        }
    }
}
