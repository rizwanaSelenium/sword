﻿using System;
using System.Data;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.EvaluationAndTest.Steps
{
    [Binding]
    public sealed class NewEvaluationForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewEvaluationForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)' have been updated in Evaluation")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInEvaluation(string fields, string details, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_newRiskDialogue);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Preparer":
                        _newRiskDialogue.Evaluation.Preparer.AssertEquals(fieldValue[1]);
                        break;
                    case "Reviewer":
                        _newRiskDialogue.Evaluation.Reviewer.AssertEquals(fieldValue[1]);
                        break;
                    case "Operating Result":
                        _newRiskDialogue.Evaluation.OperatingResult.AssertLabelEquals(fieldValue[1]);
                        break;
                    case "Design Result":
                        _newRiskDialogue.Evaluation.DesignResult.AssertLabelEquals(fieldValue[1]);
                        break;
                    case "Control Influence":
                        _newRiskDialogue.Evaluation.ControlInfluence.AssertLabelEquals(fieldValue[1]);
                        break;
                    case "Remedial Action Link":
                        _newRiskDialogue.Evaluation.RemedialActionLink.AssertEquals(fieldValue[1]);
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.Evaluation.CustomField1.AssertEquals(fieldValue[1]);
                        break;
                    case "Custom Field 2":
                        _newRiskDialogue.Evaluation.CustomField2.AssertEquals(fieldValue[1]);
                        break;
                    case "Conclusions":
                        _newRiskDialogue.Evaluation.Conclusions.AssertEquals(fieldValue[1]);
                        break;
                    case "Review Comments":
                        _newRiskDialogue.Evaluation.ReviewComments.AssertEquals(fieldValue[1]);
                        break;
                    case "Description":
                        _newRiskDialogue.Evaluation.Description.AssertEquals(fieldValue[1]);
                        break;
                    case "Recommendations":
                        _newRiskDialogue.Evaluation.Recommendations.AssertEquals(fieldValue[1]);
                        break;
                    case "Objective":
                        _newRiskDialogue.Evaluation.Objective.AssertEquals(fieldValue[1]);
                        break;
                    case "Ref":
                        _newRiskDialogue.Evaluation.Ref.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Due":
                        _newRiskDialogue.Evaluation.DueDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Prepared":
                        _newRiskDialogue.Evaluation.PreparedDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Reviewed":
                        _newRiskDialogue.Evaluation.ReviewDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Status":
                        _newRiskDialogue.Evaluation.Status.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Title":
                        _newRiskDialogue.Evaluation.Title.AssertEquals(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }
        
        [Then(@"the user see Evaluation Ref is displayed")]
        public void ThenTheUserSeeEvaluationRefIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if(_newRiskDialogue.Evaluation.Ref.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Ref field is empty");
        }
    }
}
