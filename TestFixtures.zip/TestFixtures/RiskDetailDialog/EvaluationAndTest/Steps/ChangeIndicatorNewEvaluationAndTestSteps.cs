﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.EvaluationAndTest.Steps
{
    [Binding]
    public sealed class ChangeIndicatorNewEvaluationAndTestSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public ChangeIndicatorNewEvaluationAndTestSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [Then(@"the change indicator should be displayed on the Evaluation Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheEvaluationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.EvaluationChangeIndicator.Displayed, "The change indicator is not displayed on the Evaluation Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Evaluation Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheEvaluationNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.EvaluationChangeIndicator.Text, "The change indicator is not a white asterisk on the Evaluation Navigation section");
        }

        [Given(@"the user clicks on Add Evaluation button")]
        [When(@"the user clicks on Add Evaluation button")]
        public void WhenTheUserClicksOnAddEvaluationButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Evaluation.AddEvaluationButton.Click();
        }
        
        [Then(@"the change indicator should be displayed on the Test Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheTestSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.TestChangeIndicator.Displayed, "The change indicator is not displayed on the Test Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Test Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheTestNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.TestChangeIndicator.Text, "The change indicator is not a white asterisk on the Test Navigation section");
        }

        [Given(@"the user clicks on Add Test button")]
        [When(@"the user clicks on Add Test button")]
        public void WhenTheUserClicksOnAddTestButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Test.AddTestButton.Click();
        }

        [Given(@"the user enters '(.*)' in Evaluation for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Evaluation for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInEvaluationForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                switch (row[0])
                {
                    case "Title":
                        _newRiskDialogue.Evaluation.Title.SetValue(row[1]);
                        break;
                    case "Reviewer":
                        _newRiskDialogue.Evaluation.Reviewer.SelectResource(row[1]);
                        break;
                    case "Due":
                        _newRiskDialogue.Evaluation.DueDate.PickDate(row[1]);
                        break;
                    case "Status":
                        _newRiskDialogue.Evaluation.Status.SelectByText(row[1]);
                        break;
                    case "Prepared":
                        _newRiskDialogue.Evaluation.PreparedDate.PickDate(row[1]);
                        break;
                    case "Reviewed":
                        _newRiskDialogue.Evaluation.ReviewDate.PickDate(row[1]);
                        break;
                    case "Description":
                        _newRiskDialogue.Evaluation.Description.SetValue(row[1]);
                        break;
                    case "Review Comments":
                        _newRiskDialogue.Evaluation.ReviewComments.SetValue(row[1]);
                        break;
                    case "Conclusions":
                        _newRiskDialogue.Evaluation.Conclusions.SetValue(row[1]);
                        break;
                    case "Objective":
                        _newRiskDialogue.Evaluation.Objective.SetValue(row[1]);
                        break;
                    case "Recommendations":
                        _newRiskDialogue.Evaluation.Recommendations.SetValue(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }

        [Given(@"the user enters '(.*)' in Test for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Test for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInTestForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                switch (row[0])
                {
                    case "Test Type":
                        _newRiskDialogue.Test.TestType.SelectByText(row[1]);
                        break;
                    case "Test Condition":
                        _newRiskDialogue.Test.TestCondition.SelectByText(row[1]);
                        break;
                    case "Test Classification":
                        _newRiskDialogue.Test.TestClassification.SelectByText(row[1]);
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.Test.CustomField1.SetValue(row[1]);
                        break;
                    case "Ref":
                        _newRiskDialogue.Test.Ref.SetValue(row[1]);
                        break;
                    case "Test Date":
                        _newRiskDialogue.Test.Date.PickDate(row[1]);
                        break;
                    case "Result":
                        _newRiskDialogue.Test.Result.SelectByText(row[1]);
                        break;
                    case "Title":
                        _newRiskDialogue.Test.Title.SetValue(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }
    }
}
