﻿using System;
using System.Data;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.EvaluationAndTest.Steps
{
    [Binding]
    public sealed class NewTestForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewTestForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated in Test")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInTest(string fields, string details, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_newRiskDialogue);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Test Type":
                        _newRiskDialogue.Test.TestType.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Test Condition":
                        _newRiskDialogue.Test.TestCondition.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Test Classification":
                        _newRiskDialogue.Test.TestClassification.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.Test.CustomField1.AssertEquals(fieldValue[1]);
                        break;
                    case "Ref":
                        _newRiskDialogue.Test.Ref.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Test Date":
                        _newRiskDialogue.Test.Date.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Result":
                        _newRiskDialogue.Test.Result.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Title":
                        _newRiskDialogue.Test.Title.AssertEquals(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");

                }
            }
        }

        [Then(@"the user see Test Ref is displayed")]
        public void ThenTheUserSeeTestRefIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if (_newRiskDialogue.Test.Ref.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Ref field is empty");
        }
    }
}
