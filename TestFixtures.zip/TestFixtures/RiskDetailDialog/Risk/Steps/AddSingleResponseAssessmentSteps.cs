﻿using System.Linq;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class AddSingleResponseAssessmentSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskComponent;
        private AngularResponseAssessmentModal _responseAssessmentModal;

        public AddSingleResponseAssessmentSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user clicks on View Score Assessment Icon in target score")]
        public void GivenTheUserClicksOnViewScoreAssessmentIconInTargetScore()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.Response.ViewTargetScoreAssessment.Click();
        }

        [Given(@"the user view response assessment popup for target score")]
        [When(@"the user views response assessment popup for achieved score")]
        public void GivenTheUserViewResponseAssessmentPopupForTargetScore()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _responseAssessmentModal = _riskComponent.AngularResponseAssessmentModal;
            ScenarioContext.Set(_responseAssessmentModal);
        }

        [Given(@"the user selects the Distributiontype  as '(.*)' in  reposne assessment popup")]
        public void GivenTheUserSelectsTheDistributiontypeAsInReposneAssessmentPopup(string distributionType)
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            _responseAssessmentModal.TargetAssessment.Distribution.SelectByText(distributionType);
        }

        [Given(@"the user enter Probability in response assessment popup")]
        public void GivenTheUserEnterProbabilityInResponseAssessmentPopup(Table table)
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            Driver = ScenarioContext.Get<IWebDriver>();
            _responseAssessmentModal.TargetAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Given(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values in response assessment poup")]
        public void GivenTheUserEnterTheValuesForEachForValuesInResponseAssessmentPoup(string impactCategory, string min, string exp, string max, Table table)
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _responseAssessmentModal.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMin, "min");
                }
                if (columnExp != "")
                {
                    _responseAssessmentModal.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnExp, "exp");
                }
                if (columnMax != "")
                {
                    _responseAssessmentModal.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [Given(@"the user clicks Apply button in response assessment popup")]
        [When(@"the user clicks Apply button in response assessment popup")]
        public void GivenTheUserClicksApplyButtonInResponseAssessmentPopup()
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            Waiter = ScenarioContext.Get<WebDriverWait>();          
            _responseAssessmentModal.ApplyButton.Click();
            Waiter.Until(d => _responseAssessmentModal.AssessmentModalClosed());
        }

        [When(@"the user clicks Copy button in response assessment popup")]
        public void WhenTheUserClicksCopyButtonInResponseAssessmentPopup()
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            _responseAssessmentModal.CopyButton.Click();
            Waiter.Until(d => _responseAssessmentModal.ApplyButton.IsEnabled());
        }

        [Then(@"the user verifies '(.*)' with correct '(.*)' in response is updated")]
        public void ThenTheUserVerifiesWithCorrectInResponseIsUpdated(string field, string color, Table table)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnField = values[keys.IndexOf(field)];
                var columnColor = values[keys.IndexOf(color)];

                switch (columnField)
                {
                    case "Target Score":
                        _riskComponent.Response.TargetScore.AssertColorEquals(columnColor);
                        break;
                    case "Achieved Score":
                        _riskComponent.Response.AchievedScore.AssertColorEquals(columnColor);
                        break;
                }
            }
        }

        [When(@"the user clicks on Risk tab")]
        public void WhenTheUserClicksOnRiskTab()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Thread.Sleep(3000);
            _riskComponent.RiskNavButton.Click();
        }

        [When(@"the user enter Probability  for current assesment in response assessment popup")]
        public void WhenTheUserEnterProbabilityForCurrentAssesmentInResponseAssessmentPopup(Table table)
        {
            Thread.Sleep(3000);
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _responseAssessmentModal = _riskComponent.AngularResponseAssessmentModal;
            Driver = ScenarioContext.Get<IWebDriver>();
            _responseAssessmentModal.CurrentAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
            ScenarioContext.Set(_responseAssessmentModal);
        }

        [When(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values  for current assessment in response assessment poup")]
        public void WhenTheUserEnterTheValuesForEachForValuesForCurrentAssessmentInResponseAssessmentPoup(string impactCategory, string min, string exp, string max, Table table)
        {
            _responseAssessmentModal = ScenarioContext.Get<AngularResponseAssessmentModal>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _responseAssessmentModal.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMin, "min");
                }
                if (columnExp != "")
                {
                    _responseAssessmentModal.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnExp, "exp");
                }
                if (columnMax != "")
                {
                    _responseAssessmentModal.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMax, "max");
                }
            }
        }
    }
}
