﻿using System;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class RiskStatusAndRiskApprovalDateSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;

        public RiskStatusAndRiskApprovalDateSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }
        
        [When(@"the user changes the Risk status to '(.*)'")]
        public void WhenTheUserChangesTheRiskStatusTo(string status)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.RiskStatus.SelectByText(status);
        }
        
        [When(@"the user changes the approval date to '(.*)'")]
        public void WhenTheUserChangesTheApprovalDateTo(string date)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.ApprovalDate.PickDate(date);
        }
        
        [Then(@"the approval date should be set to '(.*)'")]
        public void ThenTheApprovalDateShouldBeSetTo(string date)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            switch (date)
            {
                case "Current Date":
                    date = DateTime.Now.ToLongDateString();
                    break;
                case "Tomorrow":
                    date = DateTime.Now.AddDays(1).ToLongDateString();
                    break;
                case "Next Week":
                    date = DateTime.Now.AddDays(7).ToLongDateString();
                    break;
                case "Next Month":
                    date = DateTime.Now.AddMonths(1).ToLongDateString();
                    break;
                case "":
                    date = string.Empty;
                    break;
                default:
                    date = DateTime.Parse(date).ToLongDateString();
                    break;            
            }
            _openRiskDialog.RiskDetail.ApprovalDate.AssertValue(date);
        }
        
        [Then(@"the Risk status should be changed to '(.*)'")]
        public void ThenTheRiskStatusShouldBeChangedTo(string status)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.RiskStatus.AssertTextEquals(status);
        }
    }
}
