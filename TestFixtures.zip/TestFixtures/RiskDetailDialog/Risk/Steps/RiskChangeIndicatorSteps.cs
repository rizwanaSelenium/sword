﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class RiskChangeIndicatorSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;
        private RiskDetailComponent _riskDetailPage;
        private WebDriverDesktop _desktop;

        public RiskChangeIndicatorSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [AfterScenario("ChangeIndicatorTeardown")]
        public void AfterScenario()
        {
            try {
                if (ScenarioContext.TryGetValue(out _openRiskDialog))
                {
                    _openRiskDialog = ScenarioContext.Get<RiskComponent>();
                    _openRiskDialog.CloseButton.Click();
                    _openRiskDialog.ConfirmationModal.AltActionButton.Click();
                    
                    _desktop = ScenarioContext.Get<WebDriverDesktop>();
                    _desktop.FocusWindow();
                    _desktop.Logout();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [When(@"the user enters '(.*)' for the Risk '(.*)'")]
        public void WhenTheUserEntersForTheRisk(string details, string field)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _riskDetailPage = _openRiskDialog.RiskDetail;

            switch (field)
            {
                case "Title":
                    _openRiskDialog.RiskDetail.Name.SetValue(details);
                    break;
                case "Owner":
                    _openRiskDialog.RiskDetail.Owner.SelectResource(details);
                    break;
                case "Status":
                    _openRiskDialog.RiskDetail.RiskStatus.SelectByText(details);
                    break;
                default:
                    throw new ArgumentException("Unexpected field type given");
            }
            ScenarioContext.Set(_riskDetailPage);
        }

        [Then(@"the change indicator should be displayed on the Risk section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheRiskSection()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_openRiskDialog.RiskChangeIndicator.Displayed);
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Risk section button")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheRiskSectionButton()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _openRiskDialog.RiskChangeIndicator.Text);
        }

        [When(@"the user enters '(.*)' for the Scoring '(.*)'")]
        public void WhenTheUserEntersForTheScoring(string details, string field)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _riskDetailPage = _openRiskDialog.RiskDetail;

            switch (field)
            {
                case "Group":
                    _openRiskDialog.Impact.ImpactGroup.SelectByText(details);
                    break;
                case "Probability":
                    Driver = ScenarioContext.Get<IWebDriver>();
                    _openRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.SetProbabilityValue(details, Driver);
                    break;
                case "Target Resolution":
                    _openRiskDialog.Impact.TargetResolutionDate.PickDate(details);
                    break;
                default:
                    throw new ArgumentException("Unexpected field type given");
            }
            ScenarioContext.Set(_riskDetailPage);
        }

        [Then(@"the change indicator should be displayed on the Scoring section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheScoringSection()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_openRiskDialog.ScoringChangeIndicator.Displayed);
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Scoring section button")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheScoringSectionButton()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _openRiskDialog.ScoringChangeIndicator.Text);
        }

        [When(@"the user clicks Ok on the modal popup")]
        public void WhenTheUserClicksOkOnTheModalPopup()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ConfirmationModal.YesButton.Click();
        }

        [Then(@"the change indicator should not be displayed on the Risk section")]
        public void ThenTheChangeIndicatorShouldNotBeDisplayedOnTheRiskSection()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.IsFalse(_openRiskDialog.IsIndicatorVisible("RiskChangeIndicator"));
        }
    }
}
