﻿using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class ValidationMappingPlanFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private readonly ScenarioContext _scenarioContext;
        private RiskComponent _openRiskDialog;
        AngularValidationErrorModal _validationErrorModal;

        public ValidationMappingPlanFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given(@"the user sets the Plan title to (.*)")]
        public void GivenTheUserSetsThePlanTitleTo(string title)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.PlanTitle.SetValue(title);
        }

        [Given(@"the user sets the plan Start date to (.*)")]
        public void GivenThatTheUserSetsThePlanStartDateTo(string date)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.StartDate.PickDate(date);
        }

        [Given(@"the user sets the plan Completion date to (.*)")]
        public void GivenTheUserSetsThePlanCompletionDateTo(string date)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.CompletionDate.PickDate(date);
        }

        [Given(@"the user sets the response Owner to (.*)")]
        public void GivenTheUserSetsTheResponseOwnerOfResponseTo(string resource)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Response.Owner.SelectResource(resource);
        }

        [Given(@"the user sets the response Title to (.*)")]
        public void GivenTheUserSetsTheResponseTitleOfResponseTo(string name)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Response.ResponseTitle.SetValue(name);
        }


        [Given(@"the user sets the response Due date to (.*)")]
        public void GivenTheUserSetsTheResponseDueDateOfResponseTo(string date)
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _openRiskDialog.Response.DueDate.PickDate(date);
        }

        [Then(@"the user should see an ErrorMessage is displayed for the Plan Start date")]
        public void ThenTheUserShouldSeeAnErrorMessageIsDisplayedForThePlanStartDate()
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _validationErrorModal = _openRiskDialog.ValidationErrorModal;
            _validationErrorModal.AssertErrorMessagePresentFor("PlanStartLaterThanCompletion");
            _validationErrorModal.AssertErrorFieldNamePresent("StartDate");
        }

        [Then(@"the user should see an ErrorMessage is displayed for the Response Start date")]
        public void ThenTheUserShouldSeeAnErrorMessageIsDisplayedForTheResponseStartDate()
        {
            _openRiskDialog = _scenarioContext.Get<RiskComponent>();
            _validationErrorModal = _openRiskDialog.ValidationErrorModal;
            _validationErrorModal.AssertErrorMessagePresentFor("ResponseStartLaterThanDue");
            _validationErrorModal.AssertErrorFieldNamePresent("ResponseStart");
        }
    }
}
