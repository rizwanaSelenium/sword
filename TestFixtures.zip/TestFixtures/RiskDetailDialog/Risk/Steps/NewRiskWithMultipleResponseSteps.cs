﻿using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class NewRiskWithMultipleResponseSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewRiskWithMultipleResponseSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [Then(@"the user clicks on '(.*)' test")]
        public void ThenTheUserClicksOnTest(string testName)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Test.GridTests.FindRowByTitle(testName).Click();
        }

        [Then(@"the user clicks on '(.*)' response")]
        public void ThenTheUserClicksOnResponse(string responseName)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.WaitUntilUiSpinnerIsNotDisplayed();
            _newRiskDialogue.Response.ResponseGrid.FindRowByTitle(responseName).Click();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            _newRiskDialogue = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_newRiskDialogue);
        }

        [Then(@"the user clicks on '(.*)' evaluation")]
        public void ThenTheUserClicksOnEvaluation(string evaluationName)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Evaluation.GridEvaluation.FindRowByTitle(evaluationName).Click();
        }
    }
}
