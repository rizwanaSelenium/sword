﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class NewResponseAssessmentCostSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewResponseAssessmentCostSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;        
        }

        [Then("the user clicks on Response Assessment Cost button")]
        public void ThenTheUserClicksOnResponseAssessmentCostButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Response.ResponseCostAssessment.Click();
        }

        [Then("the user clicks on add a new response assessment cost")]
        public void ThenTheUserClicksOnAddANewResponseAssessmentCost()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Response.ResponseAssessmentDialogue.NewButton.Click();
        }

        [Then("the user enters the '(.*)' for '(.*)' in Response Assessment Cost")]
        public void ThenTheUserEntersTheDetailsForFieldsInResponseAssessmentCost(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var fieldName in table.Rows)
            {
                switch (fieldName[0])
                {
                    case "Start Date":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.ResponseCostFromDate.PickDate(DateTime.Parse(fieldName[1]));
                        break;
                    case "End Date":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.ResponseCostToDate.PickDate(DateTime.Parse(fieldName[1]));
                        break;
                    case "Probability":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.Probability.SetValue(fieldName[1]);
                        break;
                    case "Min":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.Min.SetValue(fieldName[1]);
                        break;
                    case "Expected Cost":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.ExpectedCost.SetValue(fieldName[1]);
                        break;
                    case "Max":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.Max.SetValue(fieldName[1]);
                        break;
                    case "Planned Cost":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.PlannedCost.SetValue(fieldName[1]);
                        break;
                    case "Actual Cost":
                        _newRiskDialogue.Response.ResponseAssessmentDialogue.ActualCost.SetValue(fieldName[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldName[0]} field not recognised. Does it need to be added?");
                        break;
                }
            }
        }

        [Then("the user clicks on Save button on response assessment cost")]
        public void ThenTheUserClicksOnSaveButtonOnResponseAssessmentCost()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Response.ResponseAssessmentDialogue.SaveButton.Click();
        }

        [Then("the user clicks on Yes button on response assessment cost dialog")]
        public void ThenTheUserClicksOnYesButtonOnResponseAssessmentCostDialog()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Response.ResponseAssessmentDialogue.YesButtonBlockedDialog.Click();
        }

        [Then("the user clicks on OK button on response assessment cost")]
        public void ThenTheUserClicksOnOkButtonOnResponseAssessmentCost()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Response.ResponseAssessmentDialogue.OkButton.Click();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            _newRiskDialogue = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_newRiskDialogue);
        }
    }
}
