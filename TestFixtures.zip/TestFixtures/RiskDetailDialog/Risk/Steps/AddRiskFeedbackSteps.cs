﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class AddRiskFeedbackSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskPage;

        public AddRiskFeedbackSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Then(@"there should be '(.*)' buttons in the feedback panel")]
        public void ThenThereShouldBeButtonsInTheFeedbackPanel(string buttons)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();

            foreach (string button in buttons.Split(','))
            {
                switch (button)
                {
                    case "Close":
                        Assert.IsTrue(_riskPage.FeedbackPanel.CloseButton.IsEnabled());
                        break;
                    case "Help":
                        Assert.IsTrue(_riskPage.FeedbackPanel.HelpButton.IsEnabled());
                        break;
                    case "New":
                        Assert.IsTrue(_riskPage.FeedbackPanel.NewButton.IsEnabled());
                        break;
                }
            }
        }

        [When(@"the user enters '(.*)' into the feedback comments field")]
        public void WhenTheUserEntersIntoTheFeedbackCommentsField(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.FeedbackPanel.EnterTextIntoNewCommentField(comment);
        }
        
        [When(@"the user clicks on the save button in the feedback panel")]
        public void WhenTheUserClicksOnTheSaveButtonInTheFeedbackPanel()
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.FeedbackPanel.SaveButton.Click();
            _riskPage.FeedbackPanel.WaitUntilSaveIsComplete();
        }
        
        [When(@"the User clicks on the '(.*)' button in the feedback Panel")]
        public void WhenTheUserClicksOnTheButtonInTheFeedbackPanel(string button)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            switch (button)
            {
                case "Close":
                    _riskPage.FeedbackPanel.CloseButton.Click();
                    break;
                case "Help":
                    _riskPage.FeedbackPanel.HelpButton.Click();
                    break;
                case "New":
                    _riskPage.FeedbackPanel.NewButton.Click();
                    break;
                default:
                    Assert.Fail("Button not recognised");
                    break;
            }
        }

        [Then(@"there should not be '(.*)' buttons in the feedback panel")]
        public void ThenThereShouldNotBeButtonsInTheReviewPanel(string buttons)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();

            foreach (string button in buttons.Split(','))
            {
                Assert.IsFalse(_riskPage.FeedbackPanel.ButtonIsVisible(button));
            }
        }

        [Then(@"the feedback with '(.*)' should be the first feedback in the feedback panel")]
        public void ThenTheFeedbackWithShouldBeTheFirstReviewInTheFeedbackPanel(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var topFeedback = _riskPage.FeedbackPanel.GetFirstFeedback();
            Assert.AreEqual(comment, topFeedback.Comment);
        }

        [Then(@"the feedback with '(.*)' should have newest feedback ID")]
        public void ThenTheFeedbackWithShouldHaveNewestFeedbackId(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var feedback = _riskPage.FeedbackPanel.GetFeedbackByComment(comment);
            Assert.AreEqual(feedback.FeedbackId, _riskPage.FeedbackPanel.GetLatestFeedbackId());
        }

        [Then(@"the feedback with '(.*)' should have todays date")]
        public void ThenTheFeedbackWithShouldHaveTodaysDate(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var feedback = _riskPage.FeedbackPanel.GetFeedbackByComment(comment);
            Assert.AreEqual(DateTime.Today.ToString("dd MMM yyyy"), feedback.Date);
        }
    }
}
