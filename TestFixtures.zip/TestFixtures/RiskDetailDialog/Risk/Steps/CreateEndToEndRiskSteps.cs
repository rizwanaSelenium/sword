﻿using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class CreateEndToEndRiskSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public CreateEndToEndRiskSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [Given(@"the user clicks on Scoring Change")]
        [When(@"the user clicks on Scoring Change")]
        public void ThenTheUserClicksOnScoringChange()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.AngularScoringCommentsModal.ScoringChange.Click();
        }

        [Then(@"the user verifies risk details for '(.*)' in desktop grid")]
        public void ThenTheUserVerifiesRiskDetailsForInDesktopGrid(string riskTitle, Table table)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            foreach (var fieldValue in table.Rows)
            {
                Assert.AreEqual(fieldValue[1].Trim(), Desktop.RiskIssuesGrid.GetValueOfCellForRecordWithTitle(riskTitle, "Risk", fieldValue[0]).Trim());
            }
        }


    }
}
