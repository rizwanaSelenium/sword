﻿using System;
using System.Data;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class OpenSavedRiskSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public OpenSavedRiskSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Then(@"the user see the risk title")]
        public void ThenTheUserSeeTheRiskTitleIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if (_newRiskDialogue.Impact.RiskTitle.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Id is empty");
        }

        [Then(@"the user see Impact ID is displayed")]
        public void ThenTheUserSeeImpactIdIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if (_newRiskDialogue.Impact.Id.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Id is empty");
        }
    }
}
