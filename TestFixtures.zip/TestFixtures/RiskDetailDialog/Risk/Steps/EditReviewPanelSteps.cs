﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class EditReviewPanelSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private WebDriverNewAdminDialog _adminDialog;
        private WebDriverRolesConfigDialog _roleConfigDialog;
        private RiskComponent _openRiskDialog;
        
        public EditReviewPanelSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [AfterScenario("EditReviewNoteRoleRightTearDown")]
        public void AfterScenario()
        {
            try
            {
                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.ClickOnToolsMenu();
                _adminDialog = Desktop.AdminDialog();
                ScenarioContext.Set(_adminDialog);

                _roleConfigDialog = _adminDialog.RoleConfiguration();
                ScenarioContext.Set(_roleConfigDialog);
                _roleConfigDialog.SelectRole("ARM Administrator");
                _roleConfigDialog.AllowFunctionAndThenSave("Edit Review Note");

                _roleConfigDialog.Close();
                _adminDialog.Close();
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user checks '(.*)' role right is Allowed")]
        public void GivenTheUserChecksRoleRightIsAllowed(string editReviewNote)
        {
            _roleConfigDialog = ScenarioContext.Get<WebDriverRolesConfigDialog>();
            _roleConfigDialog.AllowedFunctionsTable.Search("Edit Review Note");
            _roleConfigDialog.AllowedFunctionsTable.AssertCellText(0, 0, "Edit Review Note");
            _roleConfigDialog.Close();
        }

        [When(@"the user clicks on '(.*)'")]
        public void WhenTheUserClicksOn(string reviewName, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();

            foreach (var row in table.Rows)
            {
                _openRiskDialog.ReviewPanel.SelectReviewId(row["Review Name"].Trim());
            }
        }

        [Then(@"the user is shown an Edit Icon for selected review with '(.*)'")]
        public void ThenTheUserIsShownAnEditIconForSelectedReviewWith(string editIcon)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            var review = _openRiskDialog.ReviewPanel.GetReviewByComment(editIcon);
            Assert.IsTrue(review.EditButtonIsVisible);
        }

        [When(@"the user clicks the Edit Icon for the Review '(.*)'")]
        public void WhenTheUserClicksTheEditIconForTheReview(string reviewName)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ReviewPanel.GetReviewByComment(reviewName).EditButton.Click();
        }

        [When(@"the user updates  the review comments to '(.*)'")]
        public void WhenTheUserUpdatesTheReviewComments(string updateReviewComments)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ReviewPanel.UpdateRiskReviewComments(updateReviewComments);
            _openRiskDialog.ReviewPanel.EditSaveButton.Click();
        }

        [Then(@"the user should see the updated Review Comment  to '(.*)'in Review Panel")]
        public void ThenTheUserShouldSeeTheUpdatedReviewCommentToInReviewPanel(string updatedComment)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
           _openRiskDialog.ReviewPanel.VerifyUpdatedReviewComment(updatedComment);     
        }

        [Then(@"the unselected ReviewId should not show Edit Icon")]
        public void ThenTheUnselectedReviewIdShouldNotShowEditIcon(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var review = _openRiskDialog.ReviewPanel.GetReviewByComment(row[0]);
                Assert.IsTrue(review.EditButtonIsVisible);
            }

            Assert.Fail("Method is the exact same as the one below check if these are the same remove this one and re-word the step calling this to use the other binding");
        }

        [Then(@"the user should not be able to see the edit icon in review Panel for review '(.*)'")]
        public void ThenTheUserShouldNotBeAbleToSeeTheInReviewPanelForUnselectedReviews(string reviewName, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var review = _openRiskDialog.ReviewPanel.GetReviewByComment(row[0]);
                Assert.IsFalse(review.EditButtonIsVisible);
            }
        }
    }
}
