﻿using System;
using System.Linq;
using NUnit.Framework;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class VerifyHorizontalTabsAndArmVisualizerSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private RiskComponent _openRiskDialog;
        private WebDriverResourceListDialog _searchResource;
        private WebDriverResourceEditDialog _editResource;
        private bool _visualizerAccessChanged;
        private bool _visualizerAccess;
        private WebDriverDesktop _desktop;

        public VerifyHorizontalTabsAndArmVisualizerSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [AfterScenario("ARMVisualizerRoleRightTearDown"), Order(1)]
        public void TextFixtureTearDown()
        {
            _visualizerAccessChanged = ScenarioContext.Get<bool>("visualizerInterface");
            _visualizerAccess = ScenarioContext.Get<bool>("VisualizerAccess");
            if (_visualizerAccessChanged)
            {
                GivenTheUserOpensAdminDialog();
                GivenTheUserOpensUsersAndResourcesDialog();
                GivenTheUserSelectsTheResource("ARMTest");

                if (_visualizerAccess)
                {
                    GivenTheUserSelectsInterfaceArmVisualizerAndClickOnOkButton();
                }
                else
                {
                    GivenTheUserUntickTheInterfaceArmVisualizerAndClickOnOkButton();
                }

                _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                _adminDialog.FocusWindow();
                _adminDialog.Close();
            }
        }

        [AfterScenario("AdminDialogTearDown"), Order(2)]
        public void AfterScenario()
        {
            try
            {
                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception)
            {
                Console.WriteLine("Error in  teardown");          
            }
            TestFixtureTearDown();
        }

        [Given(@"the user opens Admin dialog")]
        public void GivenTheUserOpensAdminDialog()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ClickOnToolsMenu();
            _adminDialog = Desktop.AdminDialog();
            ScenarioContext.Set(_adminDialog);
        }

        [Given(@"the user opens Users and Resources dialog")]
        public void GivenTheUserOpensUsersAndResourcesDialog()
        {
           _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _searchResource = _adminDialog.UsersAndResources();
            ScenarioContext.Set(_searchResource);
        }
        [Given(@"the user selects the resource  '(.*)'")]
        public void GivenTheUserSelectsTheResource(string resource)
        {
            _searchResource= ScenarioContext.Get<WebDriverResourceListDialog>();
            _searchResource.ResourcesTable.Search(resource);
            _editResource = _searchResource.UsersEditDialog();
            ScenarioContext.Set(_editResource);

        }

        [Given(@"the user selects interface  ARM Visualizer and click on ok button")]
        public void GivenTheUserSelectsInterfaceArmVisualizerAndClickOnOkButton()
        {
            _editResource = ScenarioContext.Get<WebDriverResourceEditDialog>();
            if (!_editResource.LicensedToArmRiskVisualiser.GetStatus())
            {
                _visualizerAccessChanged = true;
                
                _visualizerAccess = _editResource.LicensedToArmRiskVisualiser.GetStatus();

                ScenarioContext.Set(_visualizerAccess, "VisualizerAccess");


            }
            ScenarioContext.Set(_visualizerAccessChanged, "visualizerInterface");
            _editResource.LicensedToArmRiskVisualiser.Check();
            _editResource.OkButton.Click();
            _searchResource = ScenarioContext.Get<WebDriverResourceListDialog>();
            _searchResource.FocusWindow();
            _searchResource.CloseButton.Click();
        }

        [Given(@"the user untick the interface  ARM Visualizer and click on ok button")]
        public void GivenTheUserUntickTheInterfaceArmVisualizerAndClickOnOkButton()
        {
            _editResource = ScenarioContext.Get<WebDriverResourceEditDialog>();
            if (_editResource.LicensedToArmRiskVisualiser.GetStatus())
            {
                _visualizerAccessChanged = true;

                _visualizerAccess = _editResource.LicensedToArmRiskVisualiser.GetStatus();
               
                ScenarioContext.Set(_visualizerAccess, "VisualizerAccess");

            }
            ScenarioContext.Set(_visualizerAccessChanged, "visualizerInterface");
         
            _editResource.LicensedToArmRiskVisualiser.Uncheck();
            _editResource.OkButton.Click();
            _searchResource = ScenarioContext.Get<WebDriverResourceListDialog>();
            _searchResource.FocusWindow();
            _searchResource.CloseButton.Click();

        }


        [Given(@"the user clicks Close button on ARM Admin")]
        [When(@"the user clicks Close button on ARM Admin")]
        public void GivenTheUserClicksCloseButtonOnArmAdmin()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _adminDialog.FocusWindow();
            _adminDialog.WaitUntilUiSpinnerIsNotDisplayed();          
            _adminDialog.CloseButton.Click();
        }

        [When(@"the user is on New Risk Dialog Page")]
        public void WhenTheUserIsOnNewRiskDialogPage()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
        }

        [Then(@"the user verifies '(.*)' are visible")]
        public void ThenTheUserVerifiesAreVisible(string horizontalTabs, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();

            foreach (var rows in table.Rows.ToList())
            {
                string myHorizontalTabs = rows[0];
                switch (myHorizontalTabs)
                {
                    case "Details":
                        _openRiskDialog.DetailsButton.AssertVisible();
                        break;

                    case "Documents":
                        _openRiskDialog.DocumentsButton.AssertVisible();
                        break;
                    case "History":
                        _openRiskDialog.HistoryButton.AssertVisible();
                        break;
                    case "Charts":
                        _openRiskDialog.ChartsButton.AssertVisible();
                        break;
                    case "ARM Visualizer":
                        _openRiskDialog.ArmVisualizerButton.AssertVisible();
                        break;

                    default:
                      Assert.Fail("Horizontal Tabs are not displayed");
                        break;
                }
             }
          }

       [Then(@"'(.*)' is not Visible")]
        public void ThenIsNotVisible(string armVisualiizer)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Assert.IsFalse(_openRiskDialog.IsArmVisualizerVisible());
            ScenarioContext.Set(_openRiskDialog);
        }

        [Then(@"the user clicks close button in new Risk dialog")]
        public void ThenTheUserClicksCloseButtonInNewRiskDialog()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.CloseButton.Click();
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.FocusWindow();
        }
    }
}
