﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class AddRiskReviewSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskPage;

        public AddRiskReviewSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user closes role config and admin dialogs")]
        public void GivenTheUserClosesRoleConfigAndAdminDialogs()
        {
            var roleConfigDialog = ScenarioContext.Get<WebDriverRolesConfigDialog>();
            var adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            var desktop = ScenarioContext.Get<WebDriverDesktop>();
            roleConfigDialog.Close();
            adminDialog.Close();
            desktop.FocusWindow();
        }

        [Given(@"the user has '(.*)' role right")]
        public void GivenTheUserHasRoleRight(string roleRight)
        {
            var rolesConfigDialog = ScenarioContext.Get<WebDriverRolesConfigDialog>();
            rolesConfigDialog.AllowFunctionAndThenSave(roleRight);
        }

        [Then(@"there should be '(.*)' buttons in the review panel")]
        public void ThenThereShouldBeButtonsInTheReviewPanel(string buttons)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();

            foreach (string button in buttons.Split(','))
            {
                switch (button)
                {
                    case "Close":
                        Assert.IsTrue(_riskPage.ReviewPanel.CloseButton.IsEnabled());
                        break;
                    case "Help":
                        Assert.IsTrue(_riskPage.ReviewPanel.HelpButton.IsEnabled());
                        break;
                    case "New":
                        Assert.IsTrue(_riskPage.ReviewPanel.NewButton.IsEnabled());
                        break;
                }
            }
        }

        [Given(@"the user doesnt have '(.*)' role right")]
        public void GivenTheUserDoesntHaveReviewRiskRoleRight(string roleRight)
        {
            var rolesConfigDialog = ScenarioContext.Get<WebDriverRolesConfigDialog>();
            rolesConfigDialog.DisAllowFunctionAndThenSave(roleRight);
        }

        [Then(@"there should not be '(.*)' buttons in the review panel")]
        public void ThenThereShouldNotBeButtonsInTheReviewPanel(string buttons)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();

            foreach (string button in buttons.Split(','))
            {
                Assert.IsFalse(_riskPage.ReviewPanel.ButtonIsVisible(button));
            }
        }

        [When(@"the user enters '(.*)' into the review comments field")]
        public void WhenTheUserEntersIntoTheReviewCommentsField(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.ReviewPanel.EnterTextIntoNewCommentField(comment);
        }

        [Then(@"the review with '(.*)' should be the first review in the review panel")]
        public void ThenTheReviewWithShouldBeTheFirstReviewInTheReviewPanel(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var topReview = _riskPage.ReviewPanel.GetFirstReview();
            Assert.AreEqual(comment, topReview.Comment);
        }

        [Then(@"the review with '(.*)' should have newest review ID")]
        public void ThenTheReviewWithShouldHaveNewestReviewId(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var review = _riskPage.ReviewPanel.GetReviewByComment(comment);
            Assert.AreEqual(review.ReviewId, _riskPage.ReviewPanel.GetLatestReviewId());
        }

        [Then(@"the review with '(.*)' should have todays date")]
        public void ThenTheReviewWithShouldHaveTodaysDate(string comment)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var review = _riskPage.ReviewPanel.GetReviewByComment(comment);
            Assert.AreEqual(DateTime.Today.ToString("dd MMM yyyy"), review.Date);
        }

        [When(@"the user clicks on the save button in the review panel")]
        public void WhenTheUserClicksOnTheSaveButtonInTheReviewPanel()
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.ReviewPanel.SaveButton.Click();
            _riskPage.ReviewPanel.WaitUntilSaveIsComplete();
        }
    }
}
