﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using PresentationModel;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class RiskEscalationSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskComponent;
        private WebDriverDesktop _desktop;
        private AngularEscalationModal _escalationModal;

        public RiskEscalationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [AfterScenario("EscalationTearDownWithEscalationModal")]
        public void TestFixtureTearDownWithEscaltionModal()
        {
            try
            {
                ScenarioContext.Set(_escalationModal);
                _escalationModal.CancelButton.Click();
                _riskComponent = ScenarioContext.Get<RiskComponent>();
                _riskComponent.CloseButton.Click();
                _desktop = ScenarioContext.Get<WebDriverDesktop>();
                _desktop.FocusWindow();
                _desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

     [When(@"the user changes the Risk status '(.*)'")]
        public void WhenTheUserChangesTheRiskStatus(string status)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.RiskDetail.RiskStatus.SelectByText(status);
        }

        [Then(@"the user should see escalation field '(.*)'")]
        public void ThenTheUserShouldSeeEscalationField(string escalationFieldState)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.RiskDetail.Escalation.VerifyFieldState(escalationFieldState);
        }

        [When(@"the user selects escalate '(.*)' option in Escalate dropdown")]
        public void WhenTheUserSelectsEscalateOptionInEscalateDropdown(string escalationOption)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.RiskDetail.Escalation.SetValue(escalationOption);
        }

        [Then(@"the user should see escalation modal displayed")]
        public void ThenTheUserShouldSeeEscalationModalDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _escalationModal = _riskComponent.EscalationModal;
            ScenarioContext.Set(_escalationModal);
        }

        [Then(@"the user should see '(.*)' radio buttons")]
        public void ThenTheUserShouldSeeRadioButtons(string radioButtons)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _escalationModal = _riskComponent.EscalationModal;
            ScenarioContext.Set(_escalationModal);
            var radioButtonsList = radioButtons.Split(',').ToList();
            Assert.IsTrue(_escalationModal.ExpectedRadioButtonsArePresent(radioButtonsList));
        }

        [Then(@"the user should not see escalation modal displayed")]
        public void ThenTheUserShouldNotSeeEscalationModalDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.IsFalse(_riskComponent.IsEscalationModalDisplayed());
        }

        [Then(@"the user should stay in the Risk dialog")]
        public void ThenTheUserShouldStayInTheRiskDialog()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.RiskHeaderId.AssertEnabled();

        }
        
        [When(@"the user selects option '(.*)' in the escalation modal window")]
        public void WhenTheUserSelectsOptionInTheEscalationModalWindow(string radioButton)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _escalationModal = _riskComponent.EscalationModal;
            ScenarioContext.Set(_escalationModal);
            _escalationModal.SelectRadioButton(radioButton);
        }

        [When(@"the user enters the escalation comments '(.*)'")]
        public void WhenTheUserEntersTheEscalationComments(string comments)
        {
            _escalationModal=ScenarioContext.Get<AngularEscalationModal>();
            _escalationModal.EscalateCommentTextArea.SetValue(comments);
        }

        [When(@"the user clicks on save in the escalation modal window")]
        public void WhenTheUserClicksOnSaveInTheEscalationModalWindow()
        {
            _escalationModal = ScenarioContext.Get<AngularEscalationModal>();
            _riskComponent = _escalationModal.SaveEscalation(); 
            ScenarioContext.Set(_riskComponent);
        }

        [Then(@"the user verifies the correct escalation '(.*)' with correct color '(.*)' is displayed")]
        public void ThenTheUserVerifiesTheCorrectEscalationWithCorrectColorIsDisplayed(string nodeName, string color)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_riskComponent.RiskDetail.Escalation.VerifySelectedOptionBackgroundColor(nodeName, color));
        }

        [When(@"the user clicks on cancel button")]
        public void WhenTheUserClicksOnCancelButton()
        {
            _escalationModal = ScenarioContext.Get<AngularEscalationModal>();
            _escalationModal.Cancel();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            _riskComponent = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_riskComponent);
        }
    }
}
