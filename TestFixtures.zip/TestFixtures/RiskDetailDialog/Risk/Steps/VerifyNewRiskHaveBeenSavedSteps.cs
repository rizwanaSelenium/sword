﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class VerifyNewRiskHaveBeenSavedSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;
        private AngularModal _messsageModal;
        private AngularValidationErrorModal _validationErrorModal;

        public VerifyNewRiskHaveBeenSavedSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [AfterScenario("NewRiskTeardown")]
        public void AfterScenario()
        {
            try
            {
                if (ScenarioContext.TryGetValue(out _openRiskDialog))
                {
                    _openRiskDialog = ScenarioContext.Get<RiskComponent>();
                    // if an extra panel is open close that first
                    if (_openRiskDialog.IsExtraOptionsPanelVisible())
                    {
                        _openRiskDialog.ClosePanelButton.Click();
                    }
                    _openRiskDialog.CloseButton.Click();
                    Desktop.FocusWindow();
                    Desktop.Logout();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [AfterScenario("NewRiskWithSaveAlertTearDown")]
        public void TestFixtureTearDownWithSaveAlert()
        {
            try
            {
                if (ScenarioContext.TryGetValue(out _openRiskDialog))
                {
                    _openRiskDialog = ScenarioContext.Get<RiskComponent>();
                    _openRiskDialog.CloseButton.Click();
                    _messsageModal = _openRiskDialog.ConfirmationModal;
                    _messsageModal.AltActionButton.Click();
                    Desktop = ScenarioContext.Get<WebDriverDesktop>();
                    Desktop.FocusWindow();
                    Desktop.Logout();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user expands the business folder '(.*)'")]
        public void GivenTheUserExpandsTheBusinessFolder(string folderName)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();

            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter = ScenarioContext.Get<WebDriverWait>();

            Desktop = new WebDriverDesktop(Driver, Waiter);
            Desktop.ActivityTree.ExpandItem(DesktopTreeType.Folder, folderName);
        }

        [Given(@"the user clicks on '(.*)' folder")]
        [When(@"the user clicks on '(.*)' folder")]
        public void GivenTheUserClicksOnFolder(string childName)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ActivityTree.ClickItem(DesktopTreeType.Folder, childName);
        }

        [Given(@"the user right clicks on the desktop and selects the context menu option '(.*)'")]
        [When(@"the user right clicks on the desktop and selects the context menu option '(.*)'")]
        public void GivenTheUserRightClicksOnTheDesktopAndSelectsTheContextMenuOption(string newrisk)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            var riskViaContext = Desktop.NewRiskViaContextMenu();
            ScenarioContext.Set(riskViaContext);
        }

        [Then(@"the user enters '(.*)' for following '(.*)' in Risk")]
        [Given(@"the user enters '(.*)' for following '(.*)' in Risk")]
        [When(@"the user enters '(.*)' for following '(.*)' in Risk")]
        public void WhenTheUserEntersForFollowingInRisk(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Approval":
                        _openRiskDialog.RiskDetail.ApprovalDate.PickDate(fieldValue[1]);
                        break;
                    case "Assessment":
                        _openRiskDialog.RiskDetail.AssessmentDate.PickDate(fieldValue[1]);
                        break;
                    case "Category":
                        _openRiskDialog.RiskDetail.RiskCategories.SelectValue(fieldValue[1]);
                        break;
                    case "Cause":
                        _openRiskDialog.RiskDetail.Cause.SetValue((fieldValue[1]));
                        break;
                    case "Comments":
                        _openRiskDialog.RiskDetail.Comments.SetValue(fieldValue[1]);
                        break;
                    case "Description":
                        _openRiskDialog.RiskDetail.Description.SetValue(fieldValue[1]);
                        break;
                    case "Effect":
                        _openRiskDialog.RiskDetail.Effect.SetValue(fieldValue[1]);
                        break;
                    case "ID":
                        _openRiskDialog.RiskDetail.RiskId.SetValue(fieldValue[1]);
                        break;
                    case "Initiation":
                        _openRiskDialog.RiskDetail.InitiationDate.PickDate(fieldValue[1]);
                        break;
                    case "Owner":
                        _openRiskDialog.RiskDetail.Owner.SelectResource(fieldValue[1]);
                        break;
                    case "Phase":
                        _openRiskDialog.RiskDetail.RiskPhase.SelectByText(fieldValue[1]);
                        break;
                    case "Source":
                        _openRiskDialog.RiskDetail.RiskSource.SelectByText(fieldValue[1]);
                        break;
                    case "Status":
                        _openRiskDialog.RiskDetail.RiskStatus.SelectByText(fieldValue[1]);
                        break;
                    case "Title":
                        _openRiskDialog.RiskDetail.Name.SetValue(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
            ScenarioContext.Set(_openRiskDialog);
        }

        [When(@"the user clicks on the save button in Risk Dialog")]
        [Given(@"the user clicks on the save button in Risk page")]
        public void WhenTheUserClicksOnTheSaveButtonInRiskPage()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.SaveButton.Click();
            _openRiskDialog = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);
        }

        [When(@"the user clicks Ok button in the save alert")]
        [Given(@"the user clicks Ok button in the save alert")]
        public void WhenTheUserClicksOkButtonInTheSaveAlert()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ConfirmationModal.YesButton.Click();
            _openRiskDialog = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);

        }

        [Given(@"the user clicks on the close button in Risk page")]
        [When(@"the user clicks on the close button in Risk Dialog")]
        public void GivenTheUserClicksOnTheCloseButtonInRiskPage()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.WaitUntilUiSpinnerIsNotDisplayed();
            _openRiskDialog.CloseButton.Click();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdated(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Approval":
                        _openRiskDialog.RiskDetail.ApprovalDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Assessment":
                        _openRiskDialog.RiskDetail.AssessmentDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Category":
                        _openRiskDialog.RiskDetail.RiskCategories.AssertIsSelected(fieldValue[1]);
                        break;
                    case "Cause":
                        _openRiskDialog.RiskDetail.Cause.AssertEquals(fieldValue[1]);
                        break;
                    case "Comments":
                        _openRiskDialog.RiskDetail.Comments.AssertEquals(fieldValue[1]);
                        break;
                    case "Description":
                        _openRiskDialog.RiskDetail.Description.AssertEquals(fieldValue[1]);
                        break;
                    case "Effect":
                        _openRiskDialog.RiskDetail.Effect.AssertEquals(fieldValue[1]);
                        break;
                    case "ID":
                        _openRiskDialog.RiskDetail.RiskId.AssertEquals(fieldValue[1]);
                        break;
                    case "Initiation":
                        _openRiskDialog.RiskDetail.InitiationDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Owner":
                        _openRiskDialog.RiskDetail.Owner.AssertEquals(fieldValue[1]);
                        break;
                    case "Phase":
                        _openRiskDialog.RiskDetail.RiskPhase.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Source":
                        _openRiskDialog.RiskDetail.RiskSource.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Status":
                        _openRiskDialog.RiskDetail.RiskStatus.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Title":
                        _openRiskDialog.RiskDetail.Name.AssertValueEquals(fieldValue[1]);
                        break;
                    case "Cost":
                        _openRiskDialog.RiskDetail.Cost.AssertReadOnlyField(fieldValue[1]);
                        break;
                    case "Raised By":
                        _openRiskDialog.RiskDetail.RaisedBy.AssertEquals(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
        }

        [Then(@"the user see header is updated with Risk title '(.*)'")]
        public void ThenTheUserSeeHeaderIsUpdatedWithRiskTitle(string name)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskHeaderTitle.AssertTextContains(name);
        }

        [Then(@"the user see Risk ID is not generated yet")]
        public void ThenTheUserSeeRiskIdIsNotGeneratedYet()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.AssertNoRiskIdNotPresentInHeader();
        }

        [Then(@"the folder '(.*)' is displayed")]
        public void ThenTheFolderIsDisplayed(string folderName)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.FolderName.AssertTextEquals(folderName);
        }

        [Then(@"the tooltip for folder '(.*)' is displayed")]
        public void ThenTheTooltipForFolderIsDisplayed(string expTooltip)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskHeaderFolderTooltip.AssertTooltipEquals(expTooltip);
        }

        [Then(@"the navigation buttons are displayed")]
        public void ThenTheNavigationButtonsAreDisplayed()
        {
            _openRiskDialog.NextRecordIcon.AssertDisplayed();
            _openRiskDialog.PreviousRecordIcon.AssertDisplayed();
        }

        [Then(@"the user see Risk ID is displayed")]
        public void ThenTheUserSeeRiskIdIsDisplayed()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskHeaderId.AssertNotNull();
        }

        [Then(@"the tooltip for Risk ID and name '(.*)' is displayed")]
        public void ThenTheTooltipForRiskIdAndNameIsDisplayed(string riskName)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            var riskId = _openRiskDialog.RiskDetail.RiskId.GetValue();
            _openRiskDialog.RiskHeaderTitleTooltip.AssertTooltipEquals(riskId + ": " + riskName);
        }

        [Then(@"the user should see validation error for unique risk ID")]
        public void ThenTheUserShouldSeeValidationErrorForUniqueRiskId()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _validationErrorModal = _openRiskDialog.ValidationErrorModal;
            _validationErrorModal.AssertErrorFieldNamePresent("ID");
            _validationErrorModal.AssertErrorMessagePresentFor("IdNotUnique");
        }

        [Given(@"the user enables custom multi-select list option to visible")]
        public void GivenTheUserEnablesCustomMulti_SelectListOptionToVisible()
        {
            Assert.Fail("Needs Implementing");
        }

        [Given(@"the user selects options '(.*)' in multi-select list field")]
        public void WhenTheUserSelectsOptionsInMulti_SelectListField(string selectOptions)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.CustomMultiList1.SelectMultipleItems(selectOptions);
        }

        [Then(@"the user see the options (.*) are selected")]
        public void ThenTheUserSeeTheOptionsAreSelected(string expOptions)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.CustomMultiList1.AssertMultipleItemsSelected(expOptions);
        }

        [Given(@"the user deselcts all items in multi-select list field")]
        public void GivenTheUserDeselctsAllItemsInMulti_SelectListField()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.CustomMultiList1.DeselectAll();
        }
    }
}
