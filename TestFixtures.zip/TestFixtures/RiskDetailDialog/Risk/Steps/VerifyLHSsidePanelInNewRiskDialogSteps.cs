﻿using System;
using System.Linq;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class VerifyLhSsidePanelInNewRiskDialogSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;
        private WebDriverDesktop _desktop;

        public VerifyLhSsidePanelInNewRiskDialogSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user clicks expand icon in lefthandside panel in new risk dialog page")]
        [When(@"the user clicks expand icon in lefthandside panel in new risk dialog page")]
        public void WhenTheUserClicksExpandIconInLefthandsidePanelInNewRiskDialogPage()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ExpandNavigationPanel();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user clicks '(.*)' in left hand side Panel")]
        [When(@"the user clicks '(.*)' in left hand side Panel")]
        public void GivenTheUserClicksInLeftHandSidePanel(string icon, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var rows in table.Rows.ToList())
            {
                string myIcon = rows[0];
                switch (myIcon)
                {
                    case "Risk":
                        _openRiskDialog.RiskNavIcon.Click();
                        break;
                    case "Scoring":
                        _openRiskDialog.ScoringNavIcon.Click();
                        break;
                    case "Plan":
                        _openRiskDialog.PlanNavIcon.Click();
                        break;
                    default:
                        Assert.Fail("Navigation Icons are not displayed in New Risk Dialog");
                        break;
                }
            }
        }

        [Given(@"the user clicks  '(.*)' in lefthandside panel")]
        [When(@"the user clicks  '(.*)' in lefthandside panel")]
        public void WhenTheUserClicksInLefthandsidePanel(string navigationButton, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.WaitUntilUiSpinnerIsNotDisplayed();
            foreach (var rows in table.Rows.ToList())
            {
                string myNavigationButton = rows[0];
                switch (myNavigationButton)
                {
                    case "Risk":
                        _openRiskDialog.RiskNavButton.Click();
                        break;
                    case "Scoring":
                        _openRiskDialog.SelectScoringSection();
                        break;
                    case "Plan":
                        _openRiskDialog.PlanNavButton.Click();
                        break;
                    case "Response":
                        _openRiskDialog.ResponseNavButton.Click();
                        break;
                    case "Evaluation":
                        _openRiskDialog.EvaluationNavButton.Click();
                        break;
                    case "Test":
                        _openRiskDialog.TestNavButton.Click();
                        break;
                    case "Deficiency":
                        _openRiskDialog.DeficiencyNavButton.Click();
                        break;
                    case "Rating":
                        _openRiskDialog.RatingNavButton.Click();
                        break;
                    case "Remediation Plan":
                        _openRiskDialog.RemediationPlanNavButton.Click();
                        break;
                    default:
                        Assert.Fail("Navigation Buttons are not displayed in New Risk Dialog");
                        break;
                }
            }
        }

        [When(@"the user clicks collapse icon in new risk dialog page")]
        public void WhenTheUserClicksCollapseIconInNewRiskDialogPage()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.CollapseArrow.Click();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Then(@"the user verifies '(.*)' are displayed")]
        public void ThenTheUserVerifiesAreDisplayed(string navigationIcon, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var rows in table.Rows.ToList())
            {
                string myNavigationIcon = rows[0];
                switch (myNavigationIcon)
                {
                    case "Risk":
                        Assert.IsTrue(_openRiskDialog.RiskNavIcon.Displayed);
                        break;
                    case "Scoring":
                        Assert.IsTrue(_openRiskDialog.ScoringNavIcon.Displayed);
                        break;
                    case "Plan":
                        Assert.IsTrue(_openRiskDialog.PlanNavIcon.Displayed);
                        break;
                    case "Response":
                        Assert.IsTrue(_openRiskDialog.ResponseNavIcon.Displayed);
                        break;
                    default:
                        Assert.Fail("Navigation Icons are not displayed in New Risk Dialog");
                        break;

                }
            }
        }

        [Given(@"the user clicks on New from desktop Menu")]
        public void GivenTheUserClicksOnNewFromDesktopMenu()
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.NewMenu.Click();
            ScenarioContext.Set(_desktop);
        }

        [Given(@"the user clicks  '(.*)'  from desktop MenuNew")]
        [When(@"the user clicks  '(.*)'  from desktop MenuNew")]
        public void WhenTheUserClicksFromDesktopMenuNew(string menuOption, Table table)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            foreach (var rows in table.Rows.ToList())
            {
                string myMenuOption = rows[0];
                switch (myMenuOption)
                {
                    case "Risk...":
                        _desktop.NewMenu.ClickOptionFromMenu(myMenuOption);
                        _openRiskDialog = _desktop.GetOpenedRisk();
                        ScenarioContext.Set(_openRiskDialog);
                        break;
                    case "Issue...":
                        _desktop.NewMenu.ClickOptionFromMenu(myMenuOption);
                        _openRiskDialog = _desktop.GetOpenedRisk();
                        ScenarioContext.Set(_openRiskDialog);
                        break;
                    default:
                        throw new ArgumentException("Menu option not displayed in desktop grid Menu");
                }
            }
        }

        [Given(@"the user clicks  RiskID  '(.*)' in  desktop grid")]
        [When(@"the user clicks  RiskID  '(.*)' in  desktop grid")]
        public void WhenTheUserClicksRiskIdInDesktopGrid(string riskId)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.RiskIssuesGrid.OpenRecordInGridWithId<RiskComponent>(riskId, "Risk");
            _openRiskDialog = _desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user clicks risk title '(.*)' in desktop grid")]
        [When(@"the user clicks risk title '(.*)' in desktop grid")]
        public void WhenTheUserClicksRiskTitleInDesktopGrid(string riskTitle)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.RiskIssuesGrid.OpenRecordInGridWithTitle<RiskComponent>(riskTitle, "Risk");
            _openRiskDialog = _desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);
        }

        [When(@"the user double click '(.*)' on a row desktop grid")]
        public void WhenTheUserDoubleClickOnARowDesktopGrid(string riskTitle)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.RiskIssuesGrid.DoubleClickOnRecordInGrid<RiskComponent>(riskTitle, "Risk");
            _openRiskDialog = _desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Then(@"the user verifies  Risk Dialog page is displayed")]
        public void ThenTheUserVerifiesRiskDialogPageIsDisplayed()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);
            Assert.IsTrue(_openRiskDialog.RiskPanelHeaderLabel());
        }

        [Then(@"the user verifies correct Risk has been loaded")]
        public void ThenTheUserVerifiesCorrectRiskHasBeenloaded(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);

            _openRiskDialog.RiskDetail.RiskId.AssertEquals(table.Rows[0].Values.ToList()[1]);
            _openRiskDialog.RiskDetail.Name.AssertValueEquals(table.Rows[1].Values.ToList()[1]);
        }

        [Then(@"the user verifies '(.*)' riskTitle is displayed")]
        public void ThenTheUserVerifiesRiskTitleIsDisplayed(string riskTitle)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);
            _openRiskDialog.Impact.RiskTitle.AssertEquals(riskTitle);
        }

        [When(@"the user clicks the '(.*)' cell for risk '(.*)'")]
        public void WhenTheUserClicksTheCellForRisk(string cellToClick, string riskTitle)
        {
            _desktop = ScenarioContext.Get<WebDriverDesktop>();
            _desktop.RiskIssuesGrid.ClickOnCellofRecordWithTitle(riskTitle, "Risk", cellToClick);
            _openRiskDialog = _desktop.GetOpenedRisk();
            ScenarioContext.Set(_openRiskDialog);
        }
    }
}
