﻿using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public sealed class DeleteResponseVerifyCostSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public DeleteResponseVerifyCostSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [When(@"the user deleted the '(.*)' response")]
        public void WhenTheUserDeletedTheResponse(string responseName)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.WaitUntilUiSpinnerIsNotDisplayed();
            _newRiskDialogue.Response.ResponseGrid.FindRowByTitle(responseName).Click();
            _newRiskDialogue.Response.ResponseGrid.DeleteRowByTitle();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            _newRiskDialogue = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_newRiskDialogue);
        }
    }
}
