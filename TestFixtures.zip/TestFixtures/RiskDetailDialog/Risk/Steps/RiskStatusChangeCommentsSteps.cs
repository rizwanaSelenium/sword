﻿using System;
using System.Threading;
using NUnit.Framework;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.HistorySearch;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class RiskStatusChangeCommentsSteps: SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private RiskComponent _openRiskDialog;
        private WebDriverDesktop _desktop;
        private DataHistoryDialog _historyDialog;
        private WebdriverBusinessAreaSettingsDialog _businessAreaSettingsDialog;
        private readonly VerifyHorizontalTabsAndArmVisualizerSteps _adminSteps;
        private AngularStatusCommentsModal _riskStatusComments;
        private AngularScoringCommentsModal _riskScoringComments;

        private bool _riskstatusCommentsChanged;
        private bool _riskStatusCommentsAccess;

        public RiskStatusChangeCommentsSteps(ScenarioContext scenarioContext, VerifyHorizontalTabsAndArmVisualizerSteps adminSteps) : base(scenarioContext)
        {
            _adminSteps = adminSteps;
            ScenarioContext = scenarioContext;
        }

        [AfterScenario("RiskStatucChangeCommentsTearDown"), Order(1)]
        public void AfterScenario()
        {
            try
            {
                _riskstatusCommentsChanged = ScenarioContext.Get<bool>("RiskStatusChangeComments");
                _riskStatusCommentsAccess = ScenarioContext.Get<bool>("RiskStatusCommentsAccess");
                if (_riskstatusCommentsChanged)
                {
                    _adminSteps.GivenTheUserOpensAdminDialog();
                    GivenTheUserOpensBusinessAreaSettingsDialog();

                    if (_riskStatusCommentsAccess)
                    {
                        GivenTheUserSelectsRiskStatusChangeCommentsAndClickOkButton();
                    }
                    else
                    {
                        _businessAreaSettingsDialog = ScenarioContext.Get<WebdriverBusinessAreaSettingsDialog>();
                        if (_businessAreaSettingsDialog.RiskStatusChangeComments.GetStatus())
                        {
                            _riskstatusCommentsChanged = true;
                            _riskStatusCommentsAccess = _businessAreaSettingsDialog.RiskStatusChangeComments.GetStatus();
                            ScenarioContext.Set(_riskStatusCommentsAccess, "RiskStatusCommentsAccess");

                        }

                        ScenarioContext.Set(_riskstatusCommentsChanged, "RiskStatusChangeComments");
                        _businessAreaSettingsDialog.RiskStatusChangeComments.Uncheck();
                        _businessAreaSettingsDialog.OkButton.Click();
                    }

                    _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                    _adminDialog.FocusWindow();
                    _adminDialog.Close();
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error in  teardown");
                TestFixtureTearDown();
            }
        }

        [Given(@"the user opens Business Area Settings Dialog")]
        public void GivenTheUserOpensBusinessAreaSettingsDialog()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
           _businessAreaSettingsDialog = _adminDialog.BusinessAreaSettings();
           ScenarioContext.Set(_businessAreaSettingsDialog);
        }

        [Given(@"the user Selects Risk Status Change Comments  and click Ok button")]
        public void GivenTheUserSelectsRiskStatusChangeCommentsAndClickOkButton()
        {
            _businessAreaSettingsDialog = ScenarioContext.Get<WebdriverBusinessAreaSettingsDialog>();
            _riskStatusCommentsAccess = _businessAreaSettingsDialog.RiskStatusChangeComments.GetStatus();
            ScenarioContext.Set(_riskStatusCommentsAccess, "RiskStatusCommentsAccess");
            if (!_businessAreaSettingsDialog.RiskStatusChangeComments.GetStatus())
            {
                _riskstatusCommentsChanged = true;
                _businessAreaSettingsDialog.RiskStatusChangeComments.Check();
            }
            _businessAreaSettingsDialog.OkButton.Click();
            ScenarioContext.Set(_riskstatusCommentsChanged, "RiskStatusChangeComments");
        }

        [Given(@"the user updates  Status  to '(.*)' in existing Risk")]
        public void GivenTheUserUpdatesStatusToInExistingRisk(string status)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.RiskStatus.SelectByText(status);
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user enters comments '(.*)' in Risk Status comments dialog")]
        [When(@"the user enters comments '(.*)' in Risk Status comments dialog")]
        public void WhenTheUserEntersCommentsInRiskStatusCommentsDialog(string statuscomments)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _riskStatusComments = _openRiskDialog.StatusCommentsModal;
            _riskStatusComments.StatusComments.Click();
            _riskStatusComments.StatusComments.SetValue(statuscomments);
        }

        [Given(@"the user enters comments '(.*)' in Risk Scoring comments dialog")]
        [When(@"the user enters comments '(.*)' in Risk Scoring comments dialog")]
        public void WhenTheUserEntersCommentsInRiskScoringCommentsDialog(string scoringComments)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _riskScoringComments = _openRiskDialog.AngularScoringCommentsModal;
            _riskScoringComments.ScoringComments.SetValue(scoringComments);
        }

        [Given(@"the user clicks Ok button in Risk Status Comments Dialog")]
        [When(@"the user clicks Ok button in Risk Status Comments Dialog")]
        public void WhenTheUserClicksOkButtonInRiskStatusCommentsDialog()
        {
            _openRiskDialog= ScenarioContext.Get<RiskComponent>();
            _riskStatusComments = _openRiskDialog.StatusCommentsModal;
            _riskStatusComments.CommentsOkButton.Click();
        }

        [When(@"the user clicks Ok in Risk dialog")]
        [Then(@"the user clicks ok in Risk dialog")]
        public void WhenTheUserClicksOkInRiskDialog()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.OkButton.Click();
            Thread.Sleep(1000);
        }

        [When(@"the user clicks '(.*)' in desktop")]
        public void WhenTheUserClicksInDesktop(string viewdataHistory)
        {
           _desktop = ScenarioContext.Get<WebDriverDesktop>();
           _historyDialog =  _desktop.ViewRiskDataHistoryDialog();
            ScenarioContext.Set(_historyDialog);
        }

        [Then(@"the user verifies for FunctionName '(.*)'statuscomments '(.*)' have been updated in Data History")]
        public void ThenTheUserVerifiesForFunctionNameStatuscommentsHaveBeenUpdatedInDataHistory(string functionName, string statusComments)
        {
            _historyDialog = ScenarioContext.Get<DataHistoryDialog>();
            _historyDialog.VerifyFunctionExistsInAll(functionName, statusComments);
        }

       [Then(@"The user Verifies ErrorMessage is displayed on RiskStausComments Dialog")]
        public void ThenTheUserVerifiesErrorMessageIsDisplayedOnRiskStausCommentsDialog()
       {
           _openRiskDialog = ScenarioContext.Get<RiskComponent>();
           _riskStatusComments = _openRiskDialog.StatusCommentsModal;
            _riskStatusComments.AssertRiskStatusCommentsErrorMessage();
        }

        [Then(@"the user clicks cancel button in Risk status comments dialog")]
        public void ThenTheUserClicksCancelButtonInRiskStatusCommentsDialog()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _riskStatusComments = _openRiskDialog.StatusCommentsModal;
            _riskStatusComments.CommentsCancelButton.Click();
        }
    }
}
