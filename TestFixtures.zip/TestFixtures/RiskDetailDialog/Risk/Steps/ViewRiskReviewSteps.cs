﻿using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class ViewRiskReviewSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskPage;

        public ViewRiskReviewSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user Opens Risk '(.*)'")]
        [When(@"the user Opens Risk '(.*)'")]
        public void GivenTheUserOpensRisk(string riskName)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            ScenarioContext.Set(Desktop.RiskIssuesGrid.OpenRecordInGridWithTitle<RiskComponent>(riskName, "Risk"));
        }

        [Given(@"the User clicks on the Drop Down for the '(.*)' Section")]
        [When(@"the User clicks on the Drop Down for the '(.*)' Section")]
        public void WhenTheUserClicksOnTheDropDownForTheSection(string sectionName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.NavigationPanel.ExpandSection(sectionName);
        }

        [Given(@"the User clicks on the '(.*)' option for '(.*)' Section")]
        [When(@"the User clicks on the '(.*)' option for '(.*)' Section")]
        public void WhenTheUserClicksOnTheOptionForSection(string optionName, string sectionName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            _riskPage.NavigationPanel.SelectNavMenuOption(sectionName, optionName);
        }

        [Then(@"the '(.*)' Panel should open on the right hand side")]
        public void ThenThePanelShouldOpenOnTheRightHandSide(string panelName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_riskPage.GetPanel(panelName).IsVisible());       
        }

        [Then(@"the '(.*)' Panel should have a title of '(.*)'")]
        public void ThenThePanelShouldHaveATitleOf(string panelName, string title)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual(title, _riskPage.GetPanel(panelName).Title);
        }

        [Then(@"there should be '(.*)' reviews in the Review Panel")]
        public void ThenThereShouldBeReviewsInTheReviewPanel(int reviewCount)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual(reviewCount, _riskPage.ReviewPanel.Reviews.Count);
        }

        [Then(@"there should be a '(.*)' option in the '(.*)' Section")]
        public void ThenThereShouldBeAOptionInTheSection(string menuOption, string section)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.IsNotNull(_riskPage.NavigationPanel.GetNavMenuOption(section, menuOption));
        }

        [Then(@"the enabled property of the '(.*)' option in the '(.*)' section should be '(.*)'")]
        public void ThenEnabledPropertyOfTheOptionInTheSectionShouldBe(string menuOption, string section, bool enabled)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            var navOption = _riskPage.NavigationPanel.GetNavMenuOption(section, menuOption);

            Assert.AreEqual(enabled, navOption.Enabled);
        }

        [Then(@"the '(.*)' option tooltip in the '(.*)' section should be '(.*)'")]
        public void ThenTheOptionTooltipShouldBe(string menuOption, string section, string tooltip)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual(tooltip, _riskPage.NavigationPanel.GetNavOptionTooltip(section, menuOption));
        }

        [When(@"the User clicks on the '(.*)' button in the '(.*)' Panel")]
        [Then(@"the User clicks on the '(.*)' button in the '(.*)' Panel")]
        public void WhenTheUserClicksOnTheButtonInThePanel(string button, string panelName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            switch (button)
            {
                case "Close":
                    _riskPage.ReviewPanel.CloseButton.Click();
                    break;
                case "Help":
                    _riskPage.ReviewPanel.HelpButton.Click();
                    break;
                case "New":
                    _riskPage.ReviewPanel.NewButton.Click();
                    break;
                default:
                    Assert.Fail("Button not recognised");
                    break;
            }

        }

        [Then(@"the '(.*)' Panel should close")]
        public void ThenThePanelShouldClose(string panelName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.IsFalse(_riskPage.GetPanel(panelName).IsVisible());
        }

        [Then(@"a Window should open containing '(.*)' Panel specific Help information")]
        public void ThenAWindowShouldOpenContainingPanelSpecificHelpInformation(string panelName)
        {
            _riskPage = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_riskPage.GetPanel(panelName).HelpPageOpened());
        }

        [Then(@"the user Deletes Risk '(.*)'")]
        public void ThenTheUserDeletesRisk(string riskName)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.RiskIssuesGrid.RightClickOnRecordAndSelectMenuItem("Risk", riskName, "DeleteRisk");
            Desktop.ConfirmDeleteAndWaitForDesktopToBeReady();
        }
    }
}
