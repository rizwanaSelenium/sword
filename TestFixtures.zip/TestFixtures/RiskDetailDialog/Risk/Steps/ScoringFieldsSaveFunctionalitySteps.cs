﻿using System;
using System.Linq;
using OpenQA.Selenium;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class VerifyScoringBeenSaved : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;
        private AngularBlackFlagCommentsModal _blackFlagComments;
        private AngularScoringCommentsModal _scoringComments;
        private AngularAssessmentScoringSheetModal _scoringSheetDialog;

        public VerifyScoringBeenSaved(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user enters '(.*)' for the Owner field on Risk")]
        public void GivenTheUserEntersValueForOwnerFieldOnRisk(string riskOwner)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.Owner.SelectResource(riskOwner);
        }

        [Given(@"the user enters value  '(.*)' for Title field  on Risk")]
        [When(@"the user enters value  '(.*)' for Title field  on Risk")]
        public void GivenTheUserEntersValueForTitleFieldOnRisk(string riskTitle)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.RiskDetail.Name.SetValue(riskTitle);
        }

        [Given(@"the user clicks on Scoring tab")]
        [When(@"the user clicks on Scoring tab")]
        public void GivenTheUserClicksOnScoringTab()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.SelectScoringSection();
            _openRiskDialog = _openRiskDialog.GetOpenRiskComponent();
            ScenarioContext.Set(_openRiskDialog);           
        }

        [Given(@"the user enters '(.*)' for following '(.*)' in Scoring")]
        [When(@"the user enters '(.*)' for following '(.*)' in Scoring")]
        public void WhenTheUserEntersForFollowingInScoring(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);
            var scoring = _openRiskDialog.Impact;
            ScenarioContext.Set(scoring);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Group":
                        _openRiskDialog.Impact.ImpactGroup.SelectByText(fieldValue[1]);
                        break;
                    case "Trigger":
                        _openRiskDialog.Impact.TriggerDate.PickDate(fieldValue[1]);
                        break;
                    case "Expiry":
                        _openRiskDialog.Impact.ExpiryDate.PickDate(fieldValue[1]);
                        break;
                    case "Description":
                        _openRiskDialog.Impact.Description.SetValue(fieldValue[1]);
                        break;
                    case "Scoring Scheme":
                        _openRiskDialog.Impact.ScoringScheme.SelectByText(fieldValue[1]);
                        break;
                    case "Black Flag":
                        _openRiskDialog.Impact.BlackFlagType.SelectByText(fieldValue[1]);
                        _blackFlagComments = _openRiskDialog.BlackFlagCommentsModal;
                        _blackFlagComments.BlackFlagComments.SetValue("Some text");
                        _blackFlagComments.CommentsOkButton.Click();
                        break;
                    case "Target Resolution":
                        _openRiskDialog.Impact.TargetResolutionDate.PickDate(fieldValue[1]);
                        break;
                    case "Type":
                        _openRiskDialog.Impact.ScoringType.SelectByText(fieldValue[1]);
                        break;
                    case "Scoring Categories":
                        _openRiskDialog.Impact.ImpactCategories.SelectMultipleItems(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
            _openRiskDialog = _openRiskDialog.GetOpenRiskComponent();
            scoring = _openRiskDialog.Impact;
            ScenarioContext.Set(_openRiskDialog);
            ScenarioContext.Set(scoring);
        }
        
        [Given(@"the user selects the Distributiontype  as '(.*)' for current assessment")]
        [When(@"the user selects the Distributiontype  as '(.*)' for current assessment")]
        public void WhenTheUserSelectsTheDisributionTypeAsForCurrentAssessment(string distributionType)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.CurrentAssessment.Distribution.SelectByText(distributionType);
        }

        [Given(@"the user enter   Probability  for current assessment")]
        [When(@"the user enter   Probability  for current assessment")]
        public void WhenTheUserEnterProbabilityForCurrentAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Driver = ScenarioContext.Get<IWebDriver>();
            _openRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Given(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for current assessment")]
        [When(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for current assessment")]
        public void WhenTheUserEnterTheValuesForEachForValuesForCurrentAssessment(string impactCategory, string min, string expected, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [Given(@"the user selects the Exposure dropdown as '(.*)' for target assessment")]
        [When(@"the user selects the Exposure dropdown as '(.*)' for target assessment")]
        public void WhenTheUserSelectsTheExposureDropdownAsForTargetAssessment(string exposureType)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.TargetAssessment.Exposure.SelectByText(exposureType);
        }

        [Given(@"the user clicks Yes on Confirmation Popup")]
        [When(@"the user clicks Yes on Confirmation Popup")]
        public void WhenTheUserClicksYesOnConfirmationPopup()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.ConfirmationModal.YesButton.Click();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user enter Probability for target assessment")]
        [When(@"the user enter Probability for target assessment")]
        public void WhenTheUserEnterProbabilityForTargetAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            Driver = ScenarioContext.Get<IWebDriver>();
            _openRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Given(@"the user selects the Distribution type as '(.*)' for target  assessment")]
        [When(@"the user selects the Distribution type as '(.*)' for target  assessment")]
        public void WhenTheUserSelectsTheDistributionTypeAsForTargetAssessment(string distributionType)
        {
            _openRiskDialog.Impact.TargetAssessment.Distribution.SelectByText(distributionType);
        }

        [Given(@"the user enters the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for target Assessment")]
        [When(@"the user enters the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for target Assessment")]
        public void WhenTheUserEntersTheValuesForEachForValuesForTargetAssessment(string impactCategory, string min,string exp, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [When(@"the user enter  Probability for inherent assessment")]
        public void ThenTheProbabilityValueIsUpdatedForInherentAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.InherentAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Then(@"the Probability band updated for inherent assessment")]
        public void ThenTheProbabilityBandUpdatedForInherentAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.InherentAssessment.ProbabilityOccurrence.VerifyProbabilityBandName(table.Rows[0].Values.ToList()[1], "Classic");
        }

        [Given(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for inherent assessment")]
        [When(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for inherent assessment")]
        public void WhenTheUserEnterTheValuesForEachForValuesForInherentAssessment(string impactCategory, string min, string expected, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [Then(@"the Impact Category values updated  for each '(.*)' for '(.*)','(.*)','(.*)' values for inherent Assessment")]
        public void ThenTheImpactCategoryValuesUpdatedForEachForValuesForInherentAssessment(string impactCategory, string min, string exp, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [When(@"the user click on Save button")]
        public void WhenTheUserClickOnSaveButton()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Save();
        }

        [Given(@"the user enters the score change comment '(.*)'")]
        [When(@"the user enters the score change comment '(.*)'")]
        public void WhenTheUserEntersTheScoreChangeComment(string comment)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _scoringComments = _openRiskDialog.AngularScoringCommentsModal;
            _scoringComments.ScoringComments.SetValue(comment);
            _scoringComments.CommentsOkButton.Click();
            _openRiskDialog.WaitUntilUiSpinnerIsNotDisplayed();
        }

        [Then(@"user verifies the '(.*)' for the '(.*)'  scoring have been updated")]
        public void ThenUsrVerifiesTheForTheScoringHaveBeenUpdated(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Group":
                        _openRiskDialog.Impact.ImpactGroup.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Trigger":
                        _openRiskDialog.Impact.TriggerDate.AssertValue(fieldValue[1]);
                        break;
                    case "Expiry":
                        _openRiskDialog.Impact.ExpiryDate.AssertValue(fieldValue[1]);
                        break;
                    case "Description":
                        _openRiskDialog.Impact.Description.AssertEquals(fieldValue[1]);
                        break;
                    case "Scoring Scheme":
                        _openRiskDialog.Impact.ScoringScheme.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Black Flag":
                        _openRiskDialog.Impact.BlackFlagType.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Target Resolution":
                        _openRiskDialog.Impact.TargetResolutionDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Type":
                        _openRiskDialog.Impact.ScoringType.AssertTextEquals(fieldValue[1]);
                        break;
                    case "ROI":
                        _openRiskDialog.Impact.Roi.AssertEquals(fieldValue[1]);
                        break;
                    case "Probability/Frequency":
                        _openRiskDialog.Impact.ProbabilityFrequency.AssertTextEquals(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }

        [Then(@"the  Probability  value is updated for inherent Assessment")]
        public void ThenTheProbabilityValueUpdatedForInherentAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.InherentAssessment.ProbabilityOccurrence.VerifyProbabilityValue(table.Rows[0].Values.ToList()[1]);
        }

        [Then(@"the  Probability  value  Updated for Current Assessment")]
        public void ThenTheProbabilityValueUpdatedForCurrentAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.VerifyProbabilityValue(table.Rows[0].Values.ToList()[1]);           
        }

        [Then(@"the  Probability  value  Updated for Target Assessment")]
        public void ThenTheProbabilityValueUpdatedForTargetAssessment(Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.VerifyProbabilityValue(table.Rows[0].Values.ToList()[1]);
        }

        [Then(@"the Probability band updated for current assessment for '(.*)' Scoring Type")]
        public void ThenTheProbabilityBandUpdatedForCurrentAssessmentForScoringType(string scoringType, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.VerifyProbabilityBandName(table.Rows[0].Values.ToList()[1], scoringType);
        }

        [Then(@"the Probability band updated for target assessment for '(.*)' Scoring Type")]
        public void ThenTheProbabilityBandUpdatedForTargetAssessmentForScoringType(string scoringType, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.VerifyProbabilityBandName(table.Rows[0].Values.ToList()[1], scoringType);
        }

        [Then(@"the Impact Category values updated  for each '(.*)' for '(.*)','(.*)','(.*)' values for current Assessment")]
        public void ThenTheImpactCategoryValuesUpdatedForEachForValuesForCurrentAssessment(string impactCategory,
            string min, string exp, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMax, "max");
                }
            }
        }

        [Then(@"the '(.*)' should be updated for current Assessment for '(.*)' Scoring Type")]
        public void ThenTheShouldBeUpdatedForCurrentAssessmentForScoringType(string impactBand, string scoringType, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf("Category")];
                var columnBand = values[keys.IndexOf(impactBand)];
                _openRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(columnCategory,
                    columnBand, scoringType);
            }
        }

        [Then(@"the Impact Category values updated  for each '(.*)' for '(.*)','(.*)','(.*)' values for target  Assessment")]
        public void ThenTheImpactCategoryValuesUpdatedForEachForValuesForTargetAssessment(string impactCategory, string min, string exp, string max, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMin, "min");
                }

                if (columnExp != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory, columnMax, "max");
                }
            }
        }
        
        [Then(@"the '(.*)' should be updated for target Assessment for '(.*)' Scoring Type")]
        public void ThenTheShouldBeUpdatedForTargetAssessmentForScoringType(string impactBand, string scoringType, Table table)
        {
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf("Category")];
                var columnBand = values[keys.IndexOf(impactBand)];
                _openRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(columnCategory, columnBand, scoringType);
            }
        }

        [Given(@"the user clicks on scoring sheet button in current assessment")]
        [When(@"the user clicks on scoring sheet button in current assessment")]
        public void GivenTheUserClicksOnScoringSheetButtonInCurrentAssessment()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.CurrentAssessment.ScoringSheetButton.Click();
            _scoringSheetDialog = _openRiskDialog.ScoringSheetDialog;
            ScenarioContext.Set(_scoringSheetDialog);
        }

        [Given(@"the user clicks on scoring sheet button in target assessment")]
        [When(@"the user clicks on scoring sheet button in target assessment")]
        public void GivenTheUserClicksOnScoringSheetButtonInTargetAssessment()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.TargetAssessment.ScoringSheetButton.Click();
            _scoringSheetDialog = _openRiskDialog.ScoringSheetDialog;
            ScenarioContext.Set(_scoringSheetDialog);
        }

        [Given(@"the user selects the values for each Category for Scoring Sheet values in Assessment")]
        public void GivenTheUserSelectsTheValuesForEachCategoryForScoringSheetValuesInAssessment(Table table)
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            foreach (var fieldValue in table.Rows)
            {
                _scoringSheetDialog.SelectCategory(fieldValue[0].Trim(), fieldValue[1].Trim());
            }
        }

        [Given(@"the user clicks on Apply in scoring sheet for Assessment")]
        public void GivenTheUserClicksOnApplyInScoringSheetForAssessment()
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            _scoringSheetDialog.ApplyButton.Click();
            _scoringSheetDialog.WaitUntilScoringSheetModalClosed();
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user clicks on Close in scoring sheet for Assessment")]
        [When(@"the user clicks on Close in scoring sheet for Assessment")]
        public void GivenTheUserClicksOnCloseInScoringSheetForAssessment()
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            _scoringSheetDialog.CloseButton.Click();
            _scoringSheetDialog.WaitUntilScoringSheetModalClosed();
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_openRiskDialog);
        }

        [Given(@"the user selects Probability in Scoring Sheet for Assessment")]
        public void GivenTheUserSelectsProbabilityInScoringSheetForAssessment(Table table)
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            _scoringSheetDialog.SelectProbability(table.Rows[0].Values.ToList()[1].Trim());
        }

        [Given(@"the scoring sheet is shown for Assessment")]
        [When(@"the scoring sheet is shown for Assessment")]
        public void GivenTheScoringSheetIsShownForAssessment()
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
        }

        [Then(@"the user verifies for each Category in Scoring Sheet bands in Assessment is updated")]
        public void ThenTheUserVerifiesForEachCategoryInScoringSheetBandsInAssessmentIsUpdated(Table table)
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            foreach (var fieldValue in table.Rows)
            {
                _scoringSheetDialog.VerifyCategory(fieldValue[0].Trim(), fieldValue[1].Trim());
            }
        }

        [Then(@"the user verifies for each Category in scoring sheet Delete Icon is displayed next to Category")]
        public void ThenTheUserVerifiesForEachCategoryInScoringSheetDeleteIconIsDisplayedNextToCategory(Table table)
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            foreach (var fieldValue in table.Rows)
            {
                _scoringSheetDialog.VerifyCategoryDeleteIcon(fieldValue[0].Trim());
            }
        }

        [Then(@"the user verifies Probability in Scoring Sheet bands in Assessment is updated")]
        public void ThenTheUserVerifiesProbabilityInScoringSheetBandsInAssessmentIsUpdated(Table table)
        {
            _scoringSheetDialog = ScenarioContext.Get<AngularAssessmentScoringSheetModal>();
            _scoringSheetDialog.VerifyProbability(table.Rows[0].Values.ToList()[1].Trim());
        }

        [Then(@"the '(.*)' should be updated for inherent Assessment")]
        public void ThenTheShouldBeUpdatedForInherentAssessment(string impactBand, Table table)
        {
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf("Category")];
                var columnBand = values[keys.IndexOf(impactBand)];
                _openRiskDialog.Impact.InherentAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(columnCategory, columnBand, "Classic");
            }
        }

        [Given(@"the user clicks on No Assessment button in inherent assessment")]
        [When(@"the user clicks on No Assessment button in inherent assessment")]
        public void WhenTheUserClicksOnNoAssessmentButtonInInherentAssessment()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.ClicksOnNoAssessmentButtonInInherentAssessment();
        }

        [Given(@"the user clicks on risklevel button in inherent assessment")]
        [When(@"the user clicks on risklevel button in inherent assessment")]
        public void WhenTheUserClicksOnRiskLevelButtonInInherentAssessment()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.RiskLevelButton.Click();
        }

        [When(@"the user clicks Impact history button in inherent assessment")]
        public void WhenTheUserClicksImpactHistoryButtonInInherentAssessment()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Impact.ImpactHistoryButton.Click();
        }
    }
}
