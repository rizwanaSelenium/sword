﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Risk.Steps
{
    [Binding]
    public class InherentAssessmentSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskComponent;
        private AngularImpactHistoryModal _historyModal;

        public InherentAssessmentSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [When(@"the user selects '(.*)' in inherent popup grid")]
        public void WhenTheUserSelectsInInherentPopupGrid(string comment)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _historyModal = _riskComponent.AngularImpactHistoryModal;
            _historyModal.ClickCommentRow(comment);
            _historyModal.SelectButton.Click();
            _historyModal.WaitForModalToDisappear();
        }
    }
}
