﻿using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.RHSSingleResourceSelect.Steps
{
    [Binding]
    public class CheckResourceFieldsIncludeResourceIconSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openedRiskDialogue;
        public CheckResourceFieldsIncludeResourceIconSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [When(@"the user observes the Risk Detailed Dialogue")]
        public void WhenTheUserObservesTheRiskDetailedDialogue()
        {
            // Stub just for readability of the Top Level BDD
            _openedRiskDialogue = ScenarioContext.Get<RiskComponent>();
        }

        [Then(@"the '(.*)' Resource Fields should contain a Resource Icon")]
        public void ThenTheResourceFieldsShouldContainAResourceIcon(string resourceFields)
        {
            _openedRiskDialogue = ScenarioContext.Get<RiskComponent>();

            foreach (string resourceField in resourceFields.Split(','))
            {
                switch (resourceField)
                {
                    case "Owner":
                        _openedRiskDialogue.RiskDetail.Owner.ShouldContainResourceIcon();
                        break;
                    case "Raised By":
                        _openedRiskDialogue.RiskDetail.RaisedBy.ShouldContainResourceIcon();
                        break;
                    default:
                        Assert.Fail("Resource Field {0} not found on the Risk Detailed Dialogue", resourceField);
                        break;
                }
            }
        }
    }
}
