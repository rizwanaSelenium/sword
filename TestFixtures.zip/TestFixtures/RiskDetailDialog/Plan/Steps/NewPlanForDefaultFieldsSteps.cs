﻿using System;
using System.Data;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Plan.Steps
{
    [Binding]
    public sealed class NewPlanForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewPlanForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated in Plan")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInPlan(string fields, string details,
            Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_newRiskDialogue);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Title":
                        _newRiskDialogue.Plan.PlanTitle.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Owner":
                        _newRiskDialogue.Plan.Owner.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Start Date":
                        _newRiskDialogue.Plan.StartDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Completion":
                        _newRiskDialogue.Plan.CompletionDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Strategy":
                        _newRiskDialogue.Plan.Strategy.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Fallback Plan Description":
                        _newRiskDialogue.Plan.FallbackPlanDescription.AssertEquals(fieldValue[1]);
                        break;
                    case "Cost":
                        _newRiskDialogue.Plan.Cost.AssertReadOnlyField(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }

        [Then(@"the user see Plan ID is displayed")]
        public void ThenTheUserSeePlanIdIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if (_newRiskDialogue.Plan.PlanId.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Id is empty");
        }
    }
}
