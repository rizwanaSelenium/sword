﻿using System;
using System.Linq;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Plan.Steps
{
    [Binding]
    public class AddPlanSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _openRiskDialog;

        public AddPlanSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user clicks AddPlan Button")]
        public void GivenTheUserClicksAddPlanButton()
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.AddPlanButton.Click();
            var plan = _openRiskDialog.Plan;
            ScenarioContext.Set(plan);
        }

        [When(@"the user enters '(.*)' for the following '(.*)' in Plan")]
        public void WhenTheUserEntersForTheFollowingInPlan(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.PlanTitle.SetValue(table.Rows[0].Values.ToList()[1]);
            _openRiskDialog.Plan.Owner.SelectResource(table.Rows[1].Values.ToList()[1]);
            _openRiskDialog.Plan.StartDate.PickDate(table.Rows[2].Values.ToList()[1]);
            _openRiskDialog.Plan.CompletionDate.PickDate(table.Rows[3].Values.ToList()[1]);
            _openRiskDialog.Plan.Strategy.SelectByText(table.Rows[4].Values.ToList()[1]);
            _openRiskDialog.Plan.HighLevelDescription.SetValue(table.Rows[5].Values.ToList()[1]);
            _openRiskDialog.Plan.FallbackPlanDescription.SetValue(table.Rows[6].Values.ToList()[1]);
        }

        [Given(@"the user right clicks on desktop and selects the context menu option '(.*)'")]
        public void GivenTheUserRightClicksOnDesktopAndSelectsTheContextMenuOption(string contextMenu)
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            switch (contextMenu)
            {
                case "New Risk...":
                    var newrRiskViaContext = Desktop.NewRiskViaContextMenu();
                    ScenarioContext.Set(newrRiskViaContext);
                    break;
                case "New Amazing Risk...":
                    var amazingViaContext = Desktop.NewAmazingRiskViaContextMenu();
                    ScenarioContext.Set(amazingViaContext);
                    break;

                default:
                    throw new ArgumentException(" ContextMenu option not displayed in desktop grid");
            }
        }

        [Then(@"the user verifies '(.*)' for the following '(.*)' Plan has been updated")]
        public void ThenTheUserVerifiesForTheFollowingPlanHasBeenUpdated(string fields, string details, Table table)
        {
            _openRiskDialog = ScenarioContext.Get<RiskComponent>();
            _openRiskDialog.Plan.PlanTitle.AssertEquals(table.Rows[0].Values.ToList()[1]);
            _openRiskDialog.Plan.Owner.AssertEquals(table.Rows[1].Values.ToList()[1]);
            _openRiskDialog.Plan.StartDate.AssertDateEquals(table.Rows[2].Values.ToList()[1]);
            _openRiskDialog.Plan.CompletionDate.AssertDateEquals(table.Rows[3].Values.ToList()[1]);
            _openRiskDialog.Plan.Strategy.AssertTextEquals(table.Rows[4].Values.ToList()[1]);
            _openRiskDialog.Plan.HighLevelDescription.AssertEquals(table.Rows[5].Values.ToList()[1]);
            _openRiskDialog.Plan.FallbackPlanDescription.AssertEquals(table.Rows[6].Values.ToList()[1]);
        }
    }
}
