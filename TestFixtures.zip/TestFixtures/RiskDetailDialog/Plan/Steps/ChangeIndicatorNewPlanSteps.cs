﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Plan.Steps
{
    [Binding]
    public sealed class ChangeIndicatorNewPlanSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public ChangeIndicatorNewPlanSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [Then(@"the change indicator should be displayed on the Plan Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnThePlanSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.PlanChangeIndicator.Displayed, "The change indicator is not displayed on the Plan Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Plan Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfThePlanNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.PlanChangeIndicator.Text, "The change indicator is not a white asterisk on the Plan Navigation section");
        }

        [Given(@"the user clicks on Add Plan button")]
        [When(@"the user clicks on Add Plan button")]
        public void WhenTheUserClicksOnAddPlanButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Plan.AddPlanButton.Click();
        }

        [Given(@"the user enters '(.*)' in Plan for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Plan for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInPlanForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
               switch (row[0])
                {
                    case "Title":
                        _newRiskDialogue.Plan.PlanTitle.SetValue(row[1]);
                        break;
                    case "Owner":
                        _newRiskDialogue.Plan.Owner.SelectResource(row[1]); ;
                        break;
                    case "Start Date":
                        _newRiskDialogue.Plan.StartDate.PickDate(row[1]);
                        break;
                    case "Completion":
                        _newRiskDialogue.Plan.CompletionDate.PickDate(row[1]);
                        break;
                    case "Strategy":
                        _newRiskDialogue.Plan.Strategy.SelectByText(row[1]);
                        break;
                    case "Fallback Plan Description":
                        _newRiskDialogue.Plan.FallbackPlanDescription.SetValue(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }
    }
}
