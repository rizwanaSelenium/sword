﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.DeficiencyRatingAndRemediation.Steps
{
    [Binding]
    public sealed class ChangeIndicatorNewDeficiencyRatingAndRemediationSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public ChangeIndicatorNewDeficiencyRatingAndRemediationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [Then(@"the change indicator should be displayed on the Deficiency Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheDeficiencySection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.DeficiencyChangeIndicator.Displayed, "The change indicator is not displayed on the Deficiency Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Deficiency Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheDeficiencyNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.DeficiencyChangeIndicator.Text, "The change indicator is not a white asterisk on the Deficiency Navigation section");
        }

        [Given(@"the user clicks on Add Deficiency button")]
        [When(@"the user clicks on Add Deficiency button")]
        public void WhenTheUserClicksOnAddDeficiencyButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Deficiency.AddDeficiencyButton.Click();
        }

        [Given(@"the user enters '(.*)' in Deficiency for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Deficiency for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInDeficiencyForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                switch (row[0])
                {
                    case "Title":
                        _newRiskDialogue.Deficiency.Title.SetValue(row[1]);
                        break;
                    case "Raised By":
                        _newRiskDialogue.Deficiency.RaisedBy.SelectResource(row[1]);
                        break;
                    case "Status":
                        _newRiskDialogue.Deficiency.Status.SelectByText(row[1]);
                        break;
                    case "Description":
                        _newRiskDialogue.Deficiency.Description.SetValue(row[1]);
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.Deficiency.CustomField1.SetValue(row[1]);
                        break;
                    case "Deficiency Type":
                        _newRiskDialogue.Deficiency.DeficiencyType.SelectByText(row[1]);
                        break;
                    case "Control Component":
                        _newRiskDialogue.Deficiency.ControlComponent.SelectByText(row[1]);
                        break;
                    case "Custom Field 2":
                        _newRiskDialogue.Deficiency.CustomField2.SetValue(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }

        [Then(@"the change indicator should be displayed on the Rating Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheRatingSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.RatingChangeIndicator.Displayed, "The change indicator is not displayed on the Rating Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Rating Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheRatingNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.RatingChangeIndicator.Text, "The change indicator is not a white asterisk on the Rating Navigation section");
        }

        [Given(@"the user clicks on Add Rating button")]
        [When(@"the user clicks on Add Rating button")]
        public void WhenTheUserClicksOnAddRatingButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.Rating.AddRatingButton.Click();
        }

        [Given(@"the user enters '(.*)' in Rating for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Rating for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInRatingForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                switch (row[0])
                {
                    case "Custom Field 1":
                        _newRiskDialogue.Rating.CustomField1.SetValue(row[1]);
                        break;
                    case "Gross Exposure":
                        _newRiskDialogue.Rating.GrossExposure.SetValue(row[1]);
                        break;
                    case "Net Exposure":
                        _newRiskDialogue.Rating.NetExposure.SetValue(row[1]);
                        break;
                    case "Significance Of Missstatement":
                        _newRiskDialogue.Rating.SignificanceOfMissstatement.SelectByText(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }

        [Then(@"the change indicator should be displayed on the Remediation Plan Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheRemediationPlanSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_newRiskDialogue.RemediationPlanChangeIndicator.Displayed, "The change indicator is not displayed on the Remediation Plan Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Remediation Plan Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCornerOfTheRemediationPlanNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            Assert.AreEqual("*", _newRiskDialogue.RemediationPlanChangeIndicator.Text, "The change indicator is not a white asterisk on the Remediation Plan Navigation section");
        }

        [Given(@"the user clicks on Add Remediation Plan button")]
        [When(@"the user clicks on Add Remediation Plan button")]
        public void WhenTheUserClicksOnAddRemediationPlanButton()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            _newRiskDialogue.RemediationPlan.AddRemediationPlanButton.Click();
        }

        [Given(@"the user enters '(.*)' in Remediation Plan for the following '(.*)'")]
        [When(@"the user enters '(.*)' in Remediation Plan for the following '(.*)'")]
        public void WhenTheUserEntersDetailsInRemediationPlanForTheFollowingField(string details, string fields, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            foreach (var row in table.Rows)
            {
                switch (row[0])
                {
                    case "Description":
                        _newRiskDialogue.RemediationPlan.Description.SetValue(row[1]);
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.RemediationPlan.CustomField1.SetValue(row[1]);
                        break;
                    case "Completion Date":
                        _newRiskDialogue.RemediationPlan.CompletionDate.PickDate(row[1]);
                        break;
                    case "Status":
                        _newRiskDialogue.RemediationPlan.Status.SelectByText(row[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected details type given");
                }
            }
        }
    }
}
