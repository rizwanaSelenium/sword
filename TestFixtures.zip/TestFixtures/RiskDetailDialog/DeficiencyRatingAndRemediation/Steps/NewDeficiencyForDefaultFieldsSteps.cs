﻿using System;
using System.Data;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.DeficiencyRatingAndRemediation.Steps
{
    [Binding]
    public sealed class NewDeficiencyForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewDeficiencyForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated in Deficiency")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInDeficiency(string fields, string details, Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_newRiskDialogue);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Title":
                        _newRiskDialogue.Deficiency.Title.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Raised By":
                        _newRiskDialogue.Deficiency.RaisedBy.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Status":
                        _newRiskDialogue.Deficiency.Status.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Description":
                        _newRiskDialogue.Deficiency.Description.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Custom Field 1":
                        _newRiskDialogue.Deficiency.CustomField1.AssertEquals(fieldValue[1]); ;
                        break;
                    case "Deficiency Type":
                        _newRiskDialogue.Deficiency.DeficiencyType.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Control Component":
                        _newRiskDialogue.Deficiency.ControlComponent.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Custom Field 2":
                        _newRiskDialogue.Deficiency.CustomField2.AssertEquals(fieldValue[1]); ;
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }    

        [Then(@"the user see Deficiency ID is displayed")]
        public void ThenTheUserSeeDeficiencyIdIsDisplayed()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            if (_newRiskDialogue.Deficiency.Id.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Id is empty");
        }
    }
}
