﻿using System;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.DeficiencyRatingAndRemediation.Steps
{
    [Binding]
    public sealed class NewRatingForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public NewRatingForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated in Rating")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInRating(string fields, string details,
            Table table)
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_newRiskDialogue);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Custom Field 1":
                        _newRiskDialogue.Rating.CustomField1.AssertEquals(fieldValue[1]);
                        break;
                    case "Gross Exposure":
                        _newRiskDialogue.Rating.GrossExposure.AssertEquals(fieldValue[1]);
                        break;
                    case "Net Exposure":
                        _newRiskDialogue.Rating.NetExposure.AssertEquals(fieldValue[1]);
                        break;
                    case "Significance Of Missstatement":
                        _newRiskDialogue.Rating.SignificanceOfMissstatement.AssertTextEquals(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }
    }
}
