﻿using System;
using System.Data;
using System.Linq;
using NUnit.Framework;
using PresentationModel.Controls.Angular;
using PresentationModel.Controls.NewAdmin;
using PresentationModel.Model.Admin.Configuration;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Response.Steps 
{
    [Binding]
    public class NewResponseForDefaultFieldsSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _riskComponent;
        private WebDriverNewAdminDialog _adminDialog;
        private AdminFieldsAndWorkflowTabPage _fieldsAndWorkflowTabPage;
        private ResponseScreenLayout _responseScreenLayout;
        private AngularModal _messsageModal;
        private WebDriverDesktop _desktop;

        public NewResponseForDefaultFieldsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [AfterStep("CatchAllErrors")]
        public void AfterStep()
        {
            if (ScenarioContext.TestError != null)
            {
                Console.WriteLine("Automation failed in steps error below.");
                Console.WriteLine(ScenarioContext.TestError);
            }
        }

        [AfterScenario("ResponseResetDefaultResponseType")]
        public void TestFixtureTearDownWithSaveAlert()
        {
            try
            {
                _riskComponent = ScenarioContext.Get<RiskComponent>();
                _riskComponent.CloseButton.Click();
                _messsageModal = _riskComponent.ConfirmationModal;
                _messsageModal.AltActionButton.Click();
                _desktop = ScenarioContext.Get<WebDriverDesktop>();
                _desktop.FocusWindow();
                _desktop.ClickOnToolsMenu();
                _adminDialog = _desktop.AdminDialog();
                _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                _fieldsAndWorkflowTabPage = _adminDialog.FieldsAndWorkflowTabPage;
                _fieldsAndWorkflowTabPage = ScenarioContext.Get<AdminFieldsAndWorkflowTabPage>();
                _responseScreenLayout = _adminDialog.ResponseScreenLayout();
                _responseScreenLayout.DefaultResponseAction.Click();
                _responseScreenLayout.OkButton.Click();
                _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                _adminDialog.FocusWindow();
                _adminDialog.CloseButton.Click();
                _desktop = ScenarioContext.Get<WebDriverDesktop>();
                _desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user does not have any default Response Type set in Admin")]
        public void GivenTheUserDoesNotHaveAnyDefaultResponseTypeSetInAdmin()
        {
            _responseScreenLayout = ScenarioContext.Get<ResponseScreenLayout>();
            _responseScreenLayout.DefaultResponseAction.Uncheck();
            _responseScreenLayout.DefaultResponseControl.Uncheck();
            _responseScreenLayout.DefaultResponseFallback.Uncheck();
            _responseScreenLayout.OkButton.Click();
            ScenarioContext.Set(_adminDialog);
        }      
       
        [Given(@"the user have default Response Type set in Admin")]
        public void GivenTheUserHaveDefaultResponseTypeSetInAdmin()
        {
            _responseScreenLayout = ScenarioContext.Get<ResponseScreenLayout>();
            _responseScreenLayout.DefaultResponseAction.Check();
            _responseScreenLayout.OkButton.Click();
            ScenarioContext.Set(_adminDialog);
        }

        [Given(@"the user navigates to Fields and Workflow")]
        public void GivenTheUserNavigatesToFieldsAndWorkflow()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _fieldsAndWorkflowTabPage = _adminDialog.FieldsAndWorkflowTabPage;
            ScenarioContext.Set(_fieldsAndWorkflowTabPage);
        }

        [Given(@"the user opens Response Screen Layout")]
        public void GivenTheUserOpensResponseScreenLayout()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            if (_adminDialog != null)
            {
                _responseScreenLayout = _adminDialog.ResponseScreenLayout();
            }

            ScenarioContext.Set(_responseScreenLayout);
        }

        [Given(@"the user clicks on Add Response button")]
        [When(@"the user clicks on Add Response button")]
        public void WhenTheUserClicksOnAddResponseButton()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.Response.AddResponseButton.Click();
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            _riskComponent = Desktop.GetOpenedRisk();
            ScenarioContext.Set(_riskComponent);
        }

        [Given(@"the user enters the '(.*)' for '(.*)' in Response")]
        [When(@"the user enters the '(.*)' for '(.*)' in Response")]
        public void WhenTheUserEntersTheForInResponse(string field, string value, Table table)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            foreach (var fieldName in table.Rows)
            {
               switch (fieldName[0])
                {
                    case "ID":
                        _riskComponent.Response.ResponseId.SetValue(fieldName[1]);
                        break;
                    case "Title":
                        _riskComponent.Response.ResponseTitle.SetValue(fieldName[1]);
                        break;
                    case "Owner":
                        _riskComponent.Response.Owner.SelectResource(fieldName[1]);
                        break;
                    case "Type":
                        _riskComponent.Response.ResponseTypeOptions.SelectByText(fieldName[1]);
                        break;
                    case "Due Date":
                    case "Review Date":
                        _riskComponent.Response.DueDate.PickDate(fieldName[1]);
                        break;
                    case "Target Score":
                        _riskComponent.Response.TargetScore.SetValueViaPid(fieldName[1]);
                        break;
                    case "Status":
                        _riskComponent.Response.ResponseStatus.SelectByText(fieldName[1]);
                        if (_riskComponent.IsMessageModalPopUpDisplayed())
                            _riskComponent.ConfirmationModal.YesButton.Click();
                        break;
                    case "Priority":
                        _riskComponent.Response.ResponsePriority.SelectByText(fieldName[1]);
                        break;
                    case "Start":
                        _riskComponent.Response.StartDate.PickDate(fieldName[1]);
                        break;
                    case "Completion":
                        _riskComponent.Response.Completion.PickDate(fieldName[1]);
                        break;
                    case "Percent Complete":
                        _riskComponent.Response.PercentComplete.SetValue(fieldName[1]);
                        break;
                    case "Effectiveness":
                        _riskComponent.Response.Effectiveness.SelectByText(fieldName[1]);
                        break;
                    case "Planned Cost":
                        _riskComponent.Response.PlannedCost.SetValue(fieldName[1]);
                        break;
                    case "Currency":
                        _riskComponent.Response.Currency.SelectByText(fieldName[1]);
                        _riskComponent.ConfirmationModal.ActionButton.Click();
                        break;
                    default:
                        Assert.Fail($"{fieldName[0]} field not recognised. Does it need to be added?");
                        break;
                }
            }            
        }
        
        [Then(@"the user should not see response type options displayed")]
        public void ThenTheUserShouldNotSeeResponseTypeOptionsDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.True(_riskComponent.Response.AssertAddResponseButtonDropdownNotDisplayed());
        }
      
        [Then(@"the user should see Save button is enabled")]
        public void ThenTheUserShouldSeeSaveButtonIsEnabled()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.True(_riskComponent.SaveButton.IsEnabled());
        }
        
        [Then(@"the user should see response type options displayed")]
        public void ThenTheUserShouldSeeResponseTypeOptionsDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.True(_riskComponent.Response.AddResponseButtonDropDown.Displayed);
        }

        [Then(@"the user should see the response grid")]
        public void ThenTheUserShouldSeeTheResponseGrid()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.True(_riskComponent.Response.ResponseGrid.IsVisible());
        }

        [Then(@"the user should see the grid with headers and its response values")]
        public void ThenTheUserShouldSeeTheGridWithHeadersAndItsResponseValues(Table table)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            var rowCount = table.RowCount;
            for (var i = 0; i < rowCount; i++)
            {
                var headerValue = table.Rows[i].Values.ToList()[0];
                var fieldValue = table.Rows[i].Values.ToList()[1];

                Assert.True(_riskComponent.Response.ResponseGrid.GridHeaderContains(headerValue), headerValue + " : No such header exists");

                switch (headerValue)
                {
                    case "ID":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridId(fieldValue, 1), "No such "+ fieldValue + " exists for " + headerValue);
                        break;
                    case "Type":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridType(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Title":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridTitle(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Owner":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridOwner(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Review":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridDue(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Due":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridDue(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Target Score":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridScore(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Status":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridStatus(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    case "Effectiveness":
                        Assert.IsTrue(_riskComponent.Response.ResponseGrid.AssertResponseGridEffectiveness(fieldValue, 1), "No such " + fieldValue + " exists for " + headerValue);
                        break;
                    default:
                        Assert.Fail(fieldValue+" No such field exists. Does it needs to be added?");
                        break;
                }
            }
        }

        [Then(@"the user should not see the response change indicator in the navigation panel")]
        public void ThenTheUserShouldNotSeeTheResponseChangeIndicatorInTheNavigationPanel()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.True(_riskComponent.AssertChangeIndicatorNotDisplayed("Response"));
        }

        [Then(@"the user should see the Response change indicator in navigation panel")]
        public void ThenTheUserShouldSeeTheResponseChangeIndicatorInNavigationPanel()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            Assert.IsTrue(_riskComponent.ResponseChangeIndicator.Displayed);
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)' in Response is updated")]
        public void ThenTheUserVerifiesTheForTheInResponseIsUpdated(string field, string fieldValue, Table table)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            foreach (var fieldName in table.Rows)
            {
               switch (fieldName[0])
                {
                    case "ID":
                        _riskComponent.Response.ResponseId.AssertEquals(fieldName[1]);
                        break;
                    case "Title":
                        _riskComponent.Response.ResponseTitle.AssertTextEquals(fieldName[1]);
                        break;
                    case "Owner":
                        _riskComponent.Response.Owner.AssertEquals(fieldName[1]);
                        break;
                    case "Type":
                        _riskComponent.Response.ResponseTypeOptions.AssertTextEquals(fieldName[1]);
                        break;
                    case "Due Date":
                        _riskComponent.Response.DueDate.AssertDateEquals(fieldName[1]);
                        break;
                    case "Target Score":
                    case "Target Risk Level":
                        _riskComponent.Response.TargetScore.AssertEquals(fieldName[1]);
                        break;
                    case "Achieved Score":
                        _riskComponent.Response.AchievedScore.AssertEquals(fieldName[1]);
                        break;
                    case "Status":
                        _riskComponent.Response.ResponseStatus.AssertTextEquals(fieldName[1]);
                        break;
                    case "Priority":
                        _riskComponent.Response.ResponsePriority.AssertTextEquals(fieldName[1]);
                        break;
                    case "Expected Cost":
                        _riskComponent.Response.ExpectedCost.AssertReadOnlyField(fieldName[1]);
                        break;
                    case "Planned Cost":
                        _riskComponent.Response.PlannedCostReadOnly.AssertReadOnlyField(fieldName[1]);
                        break;
                    case "Actual Cost":
                        _riskComponent.Response.ActualCost.AssertReadOnlyField(fieldName[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldName[0]} No such field name exists");
                        break;
                }
            }
        }

        [When(@"the user navigates to response section")]
        [Given(@"the user navigates to response section")]
        public void WhenTheUserNavigatesToResponseSection()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            _riskComponent.ResponseNavButton.Click();
        }

        [Then(@"the user should see the new response with the selected response type '(.*)'")]
        public void ThenTheUserShouldSeeTheNewResponseWithTheSelectedResponseType(string responseType)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            switch (responseType)
            {
                case "Action":
                    _riskComponent.Response.ResponseButtonActionType.Click();
                    break;
                case "Control":
                    _riskComponent.Response.ResponseButtonControlType.Click();
                    break;
                case "Fallback":
                    _riskComponent.Response.ResponseButtonFallbackType.Click();
                    break;
                default:
                    Assert.Fail("No such response type options :"+responseType);
                    break;
            }
            _riskComponent.Response.ResponseTypeOptions.AssertTextEquals(responseType);
        }

        [Then(@"the user verifies the '(.*)' for the '(.*)'  have been updated in Response")]
        public void ThenTheUserVerifiesTheValuesForTheHaveBeenUpdatedInResponse(string fields, string details, Table table)
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_riskComponent);

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Title":
                        _riskComponent.Response.ResponseTitle.AssertEquals(fieldValue[1]);
                        break;
                    case "Owner":
                        _riskComponent.Response.Owner.AssertEquals(fieldValue[1]);
                        break;
                    case "Type":
                        _riskComponent.Response.ResponseTypeOptions.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Due Date":
                        _riskComponent.Response.DueDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Status":
                        _riskComponent.Response.ResponseStatus.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Priority":
                        _riskComponent.Response.ResponsePriority.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Start":
                        _riskComponent.Response.StartDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Completion":
                        _riskComponent.Response.Completion.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Percent Complete":
                        _riskComponent.Response.PercentComplete.AssertEquals(fieldValue[1]);
                        break;
                    case "Effectiveness":
                        _riskComponent.Response.Effectiveness.AssertTextEquals(fieldValue[1]);
                        break;
                    default:
                        throw new ArgumentException("Unexpected field type given");
                }
            }
        }

        [Then(@"the user see Response ID is displayed")]
        public void ThenTheUserSeeResponseIdIsDisplayed()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            if (_riskComponent.Response.ResponseId.GetValue().Equals(String.Empty))
                throw new SyntaxErrorException("Id is empty");
        }

        [When(@"the user closes the risk")]
        public void WhenTheUserClosesTheRisk()
        {
            _riskComponent = ScenarioContext.Get<RiskComponent>();
            ScenarioContext.Set(_riskComponent);

            _riskComponent.CloseButton.Click();
        }
    }
}
