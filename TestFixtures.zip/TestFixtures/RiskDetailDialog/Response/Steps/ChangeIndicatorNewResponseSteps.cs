﻿using NUnit.Framework;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.RiskDetailDialog.Response.Steps
{
    [Binding]
    public class ChangeIndicatorNewResponseSteps : SpecFlowRiskDesktopFixtureNoFilter
    {
        private RiskComponent _newRiskDialogue;

        public ChangeIndicatorNewResponseSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;           
        }

        [Then(@"the change indicator should be displayed on the Response Navigation section")]
        public void ThenTheChangeIndicatorShouldBeDisplayedOnTheResponseSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();

            Assert.IsTrue(_newRiskDialogue.ResponseChangeIndicator.Displayed, "The change indicator is not displayed on the Response Navigation section");
        }

        [Then(@"the change indicator should be a white asterisk in the corner of the Response Navigation section")]
        public void ThenTheChangeIndicatorShouldBeAWhiteAsteriskInTheCorenerOfTheResponseNavigationSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();

            Assert.AreEqual("*", _newRiskDialogue.ResponseChangeIndicator.Text, "The change indicator is not a white asterisk on the Response Navigation section");
        }

        [Then(@"the change indicator should not be displayed on the Response Navigation section")]
        public void ThenTheChangeIndicatorShouldNotBeDisplayedOnTheResponseSection()
        {
            _newRiskDialogue = ScenarioContext.Get<RiskComponent>();

            Assert.IsFalse(_newRiskDialogue.IsIndicatorVisible("ResponseChangeIndicator"), "The change indicator is displayed on the Response Navigation section");
        }
    }
}
