using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Events;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;

namespace TestFixtures
{
    public abstract class RootWebDriverTest
    {
        protected ScenarioContext ScenarioContext;

        protected RootWebDriverTest()
        {

        }

        protected RootWebDriverTest(ScenarioContext scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        protected IWebDriver Driver;
        protected TimeSpan WaitPeriod = new TimeSpan(0, 4, 0);
        private static readonly TimeSpan BrowserCommandWait = new TimeSpan(0, 5, 0);
        protected WebDriverWait Waiter;
        protected static int?[] InstanceAllocation = new int?[34];
        protected static int ConsecutiveLoginLimiter = 14;
        protected static int ActiveLogins;
        protected static int PassCount;
        protected static int FailCount;
        protected static int Inconclusive;

        [OneTimeSetUp]
        protected virtual void TestFixtureSetup()
        {
            Driver = GetDriver();
            ScenarioContext.Set(Driver);

            Driver.Manage().Timeouts().PageLoad = BrowserCommandWait;
            Driver.Manage().Timeouts().AsynchronousJavaScript = WaitPeriod;
            Driver.Manage().Timeouts().ImplicitWait= TimeSpan.FromSeconds(10);

            Waiter = new WebDriverWait(Driver, WaitPeriod);
            ScenarioContext.Set(Waiter);
        }

        [OneTimeTearDown]
        protected virtual void TestFixtureTearDown()
        {
            if (TestContext.CurrentContext.Result.Outcome.Equals(ResultState.Success))
            {
                try
                {
                    Driver = ScenarioContext.Get<IWebDriver>();
                    Driver.Dispose();
                    Driver.Quit();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private IWebDriver GetLocalDriver()
        {
            EventFiringWebDriver myLocalDriver;

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["useChrome"]))
            {
                var chromeOptions = new ChromeOptions();
                chromeOptions.AddArgument("--incognito");           
                chromeOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                myLocalDriver = new EventFiringWebDriver(new ChromeDriver(ChromeDriverService.CreateDefaultService(), chromeOptions, BrowserCommandWait));
                myLocalDriver.ExceptionThrown += EventFireTakeScreenshotAndLog;            
                return myLocalDriver;
            }

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["useIE"]))
            {
                var ieOptions = new InternetExplorerOptions();
                ieOptions.RequireWindowFocus = true;
                ieOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                myLocalDriver = new EventFiringWebDriver(new InternetExplorerDriver(InternetExplorerDriverService.CreateDefaultService(), ieOptions, BrowserCommandWait));
                myLocalDriver.ExceptionThrown += EventFireTakeScreenshotAndLog;
                return myLocalDriver;
            }

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["useFirefox"]))
            {
                var firefoxOptions = new FirefoxOptions();
                firefoxOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                myLocalDriver = new EventFiringWebDriver(new FirefoxDriver(FirefoxDriverService.CreateDefaultService(), firefoxOptions, BrowserCommandWait));
                myLocalDriver.ExceptionThrown += EventFireTakeScreenshotAndLog;
                return myLocalDriver;
            }
            throw new WebDriverException("** Error ** Check app settings, something is not configured correctly. Unknown browser. ** **");
        }

        private IWebDriver GetRemoteDriver()
        {
            //Sometimes the Driver encounters an error while trying to start, attempting twice. 
            for(var attempt = 1 ; attempt < 3 ; attempt++)
            {
                try
                {
                    var gridHost = ConfigurationManager.AppSettings["gridHost"];
                    var gridPort = ConfigurationManager.AppSettings["gridPort"];

                    EventFiringWebDriver myRemoteDriver;
                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["useChrome"]))
                    {
                        var remoteChromeOptions = new ChromeOptions();
                        remoteChromeOptions.AddArgument("--incognito");
                        remoteChromeOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                        myRemoteDriver = new EventFiringWebDriver(new RemoteWebDriver(new Uri(string.Format("http://{0}:{1}/wd/hub", gridHost, gridPort)), remoteChromeOptions.ToCapabilities(), BrowserCommandWait));
                        return myRemoteDriver;
                    }

                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["useIE"]))
                    {
                        var remoteIeOptions = new InternetExplorerOptions();
                        remoteIeOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                        remoteIeOptions.EnsureCleanSession = true;
                        myRemoteDriver = new EventFiringWebDriver(new RemoteWebDriver(new Uri(string.Format("http://{0}:{1}/wd/hub", gridHost, gridPort)), remoteIeOptions.ToCapabilities(), BrowserCommandWait));
                        return myRemoteDriver;
                    }

                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["useFirefox"]))
                    {
                        var remoteFireFoxOptions = new FirefoxOptions();
                        remoteFireFoxOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore;
                        myRemoteDriver = new EventFiringWebDriver(new RemoteWebDriver(new Uri(string.Format("http://{0}:{1}/wd/hub", gridHost, gridPort)), remoteFireFoxOptions.ToCapabilities(), BrowserCommandWait));
                        return myRemoteDriver;
                    }

                    throw new WebDriverException("** Error ** Check app settings, something is not configured correctly. Unknown browser. ** **");
                }
                catch (Exception ex)
                {
                    if (attempt > 1)
                    {
                        throw new WebDriverException("** Error ** Errored twice trying to launch new Remote Driver. " + ex);
                    }
                    Console.WriteLine("** Info ** Errored once trying to launch a new Remote Driver, trying once more.");
                }
            }
            throw new Exception("** Errror ** Automation failed should not hit this point.");
        }

        protected IWebDriver GetDriver()
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["localMode"]) && !Convert.ToBoolean(ConfigurationManager.AppSettings["gridMode"]))
            {
                return GetLocalDriver();
            }
            if (!Convert.ToBoolean(ConfigurationManager.AppSettings["localMode"]) && Convert.ToBoolean(ConfigurationManager.AppSettings["gridMode"]))
            {
                return GetRemoteDriver();
            }

            throw new WebDriverException("** Error ** Check app settings, something is not configured correctly. ** **");
        }

        private void EventFireTakeScreenshotAndLog(object sender, WebDriverExceptionEventArgs myException)
        {
            try
            {
                var testFixtureName = TestContext.CurrentContext.Test.ClassName.Split('.').Last();
                var failedTestName = TestContext.CurrentContext.Test.Name;

                var today = DateTime.Now.ToString("dd_MMMM");
                var testTime = DateTime.Now.ToString("dd_MMMM_hh_mm");

                const string basePath = @"C:\selenium\Failed Tests\";
                var pathLevel2 = testFixtureName + @"\Event Fired\";
                var folderPath = Path.Combine(basePath, today, pathLevel2);

                CreateFailedLogDirectory(basePath, folderPath);
                TakeScreenshot(folderPath, testTime, failedTestName);
                var filename = Path.Combine(folderPath, failedTestName + " " + testTime + ".txt");
                PrintErrorLog(filename, myException.ThrownException.StackTrace, myException.ThrownException.Message,
                    "This is not available", "This is not available from this exception", myException.ThrownException.GetBaseException().ToString(), myException.Driver.Url);
            }
            catch (Exception)
            {
                Console.WriteLine("**** Take a screenshot on error, had an error in EventFireTakeScreenshotAndLog ****");
                Console.WriteLine("**** Normally this is caused by the page closing before webDriver got the information ****");
            }
        }

        public void FailedTakeScreenshotAndLog(string stack, string message, string workerId, string test, string baseException, string url)
        {
            try
            {
                var testFixtureName = TestContext.CurrentContext.Test.ClassName.Split('.').Last();
                var failedTestName = TestContext.CurrentContext.Test.Name;

                var today = DateTime.Now.ToString("dd_MMMM");
                var testTime = DateTime.Now.ToString("dd_MMMM_hh_mm");

                var basePath = @"C:\selenium\ARM11 Failed Tests\";
                var pathLevel2 = testFixtureName + @"\Error\";
                var folderPath = Path.Combine(basePath, today, pathLevel2);

                CreateFailedLogDirectory(basePath, folderPath);
                TakeScreenshot(folderPath, testTime, failedTestName);
                var filename = Path.Combine(folderPath, failedTestName + " " + testTime + ".txt");
                PrintErrorLog(filename, stack, message, workerId, test, baseException, url);
            }
            catch (Exception)
            {
                Console.WriteLine("**** Take a screenshot on error, had an error in FailedTakeScreenshotAndLog ****");
                Console.WriteLine("**** Normally this is caused by the page closing before webDriver got the information ****");
            }
        }

        private void CreateFailedLogDirectory(string basePath, string folderPath)
        {
            try
            {
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);

                    var fileList = new List<string>
                    {
                        DateTime.Now.Date.AddDays(-0).ToString("dd_MMMM"),
                        DateTime.Now.Date.AddDays(-1).ToString("dd_MMMM"),
                        DateTime.Now.Date.AddDays(-2).ToString("dd_MMMM"),
                        DateTime.Now.Date.AddDays(-3).ToString("dd_MMMM")
                    };

                    foreach (var s in Directory.GetDirectories(basePath))
                    {
                        Console.WriteLine(s.Remove(0, basePath.Length));
                        if (!fileList.Contains(s.Remove(0, basePath.Length)))
                        {
                            Console.WriteLine(s.Remove(0, basePath.Length));
                            Directory.Delete(s, true);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Take a screenshot on error, creating the directory. " + folderPath);
                Console.WriteLine(e);
            }
        }

        private void TakeScreenshot(string folderPath, string testTime, string failedTestName)
        {
            try
            {
                var failTestScreenShot = ((ITakesScreenshot)Driver).GetScreenshot();
                var location = Path.Combine(folderPath, failedTestName + " " + testTime + ".png");
                failTestScreenShot.SaveAsFile(location, ScreenshotImageFormat.Png);
            }
            catch (Exception)
            {
                //this will trigger the catch event log in "...Screenshot and Log" above so to stop double logging this has logging been removed for now.
            }
        }

        private void PrintErrorLog(string filename, string stacktrace, string failMessage, string workerId, string testName, string baseException, string url)
        {
            try
            {      
                using (StreamWriter output = File.CreateText(filename))
                {
                    output.WriteLine("- - - Test Name - - -");
                    output.WriteLine(testName);
                    output.WriteLine();
                    output.WriteLine("- - - Worker ID and or URL - - -");
                    output.WriteLine(workerId);
                    output.WriteLine(url);
                    output.WriteLine();
                    output.WriteLine("- - - Base Exception - - -");
                    output.WriteLine(baseException);
                    output.WriteLine();
                    output.WriteLine("- - - Sacktrace - - -");
                    output.WriteLine(stacktrace);
                    output.WriteLine();
                    output.WriteLine("- - - Message - - -");
                    output.WriteLine(failMessage);
                    output.WriteLine();
                    output.Flush();
                    output.Close();
                }
            }
            catch (Exception)
            {
                //this will trigger the catch event log in "...Screenshot and Log" above so to stop double logging this has logging been removed for now.
            }
        }

        private static readonly object InstanceLock = new object();
        protected void AllocateInstance()
        {
            //We have 34 instances and 30 nodes running so the below loop should never be hit fully. If it is then we have a problem in a test teardown not releasing a node correctly.
            //We have a very small delay between the test completing with WebDriver and the node being released.
           
            for (var attempt = 0; attempt < 120; attempt++)
            {
                lock (InstanceLock)
                {
                    for (var index = 0; index < InstanceAllocation.Length; index++)
                    {
                        if (InstanceAllocation[index] == null)
                        {
                            InstanceAllocation[index] = index + 1;

                            ScenarioContext.Set(InstanceAllocation[index].Value , "assignedInstanceID");

                            Console.WriteLine("Instance Allocated: " + InstanceAllocation[index].Value);

                            return;
                        }
                    }
                }
                Console.WriteLine("Failed to allocate an instance " + (attempt + 1) + " times, " + (120 - 1 - attempt) + " attempts left , before I fail.");
                Thread.Sleep(500);
            }
            throw new IndexOutOfRangeException("All instances have been allocated, try reducing the number of tests run at the same time.");
        }

        protected void ReleaseInstance()
        {
            var assignedInstanceId = ScenarioContext.Get<int>("assignedInstanceID");

            var testRunTime = DateTime.Now.TimeOfDay - ScenarioContext.Get<TimeSpan>("TestStartTime");
            if (TestContext.CurrentContext.Result.Outcome.Equals(ResultState.Success))
            {
                PassCount++;               
            }
            else if (TestContext.CurrentContext.Result.Outcome.Equals(ResultState.Inconclusive))
            {
                Inconclusive++;
            }
            else
            {
                FailCount++;
            }

            Console.WriteLine("Test Run Time - " + testRunTime.Minutes + ":" + testRunTime.Seconds);
            Console.WriteLine("Running test results: Passed - " + PassCount + ", Failed - " + FailCount + ", Inconclusive - " + Inconclusive);

            if (assignedInstanceId > 0 && assignedInstanceId <= InstanceAllocation.Length)
            {
                if (!InstanceAllocation[assignedInstanceId - 1].Equals(assignedInstanceId) && Convert.ToBoolean(ConfigurationManager.AppSettings["gridMode"]))
                {
                    throw new WebDriverException("Instance allocation and or release has gone wrong. Attempting to release instance: " + InstanceAllocation[assignedInstanceId - 1] + ", Instance assigned: " + assignedInstanceId);
                }

                InstanceAllocation[assignedInstanceId - 1] = null;
                Console.WriteLine("Instance Released: " + assignedInstanceId);
                ScenarioContext.Set(9999, "assignedInstanceID");
            }
            else
            {
                throw new WebDriverException("Attempted to release an instance more than once, or instance value is invalid. My instance was " + assignedInstanceId);
            }
        }
    }
}
