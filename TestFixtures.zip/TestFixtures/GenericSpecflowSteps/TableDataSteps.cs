﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.GenericSpecflowSteps
{
    [Binding]
    public class TableDataSteps : SpecFlowRiskDesktopFixtureBasic
    {
        private IDictionary<string, string> _tableDataDictionary;
        private ObligationDialog _obligationPage;

        public TableDataSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        private void ReadSpecflowTableIntoDictionary(Table table)
        {
            var rowsInTable = table.RowCount;

            _tableDataDictionary = new Dictionary<string, string>();

            for (int i = 0; i < rowsInTable; i++)
            {
                _tableDataDictionary.Add(table.Rows[i].Values.ToList()[0], table.Rows[i].Values.ToList()[1]);
            }

            ScenarioContext.Set(_tableDataDictionary, "tableDictionary");
        }

        public void WriteTableDataToObligation(Table table)
        {
            ReadSpecflowTableIntoDictionary(table);

            _tableDataDictionary = ScenarioContext.Get<IDictionary<string, string>>("tableDictionary");
            _obligationPage = ScenarioContext.Get<ObligationDialog>();

            var keys = _tableDataDictionary.Keys;
            foreach (var key in keys)
            {
                _tableDataDictionary.TryGetValue(key, out var result);
                switch (key.ToLower())
                {
                    case "id":
                    {
                        _obligationPage.Id.SetValue(result);
                        break;
                    }
                    case "title":
                    {
                        _obligationPage.Title.SetValue(result);
                        break;
                    }
                    case "due":
                    {
                        _obligationPage.Due.PickDate(result);
                        break;
                    }
                    case "source updated":
                    {
                        _obligationPage.SourceUpdated.PickDate(result);
                        break;
                    }
                    case "owner":
                    {
                        _obligationPage.Owner.Clear();
                        _obligationPage.Owner.SelectResource(result);
                        break;
                    }
                    case "category":
                    {
                        _obligationPage.Category.SelectByText(result);
                        break;
                    }
                    case "compliance status":
                    {
                        _obligationPage.ComplianceStatus.SelectByText(result);
                        break;
                    }
                    case "approver":
                    {
                        _obligationPage.Approver.Clear();
                        _obligationPage.Approver.SelectResource(result);
                        break;
                    }
                    case "approval status":
                    {
                        _obligationPage.ApprovalStatus.SelectByText(result);
                        break;
                    }
                    case "archived":
                    {
                        if (result == "True")
                        {
                            _obligationPage.Archived.SetChecked();
                        }
                        else
                        {
                            _obligationPage.Archived.SetUnchecked();
                        }

                        break;
                    }
                    case "description":
                    {
                        _obligationPage.Description.SetValue(result);
                        break;
                    }
                    case "practical guidance":
                    {
                        _obligationPage.PracticalGuidance.SetValue(result);
                        break;
                    }
                    case "remediation":
                    {
                        _obligationPage.Remediation.SetValue(result);
                        break;
                    }
                    case "consequence":
                    {
                        _obligationPage.Consequence.SetValue(result);
                        break;
                    }
                    case "compliance source":
                    {
                        _obligationPage.ComplianceSource.SetValue(result);
                        break;
                    }
                    case "approval date":
                    {
                        _obligationPage.ApprovalDate.PickDate(result);
                        break;
                    }
                    case "tree 1":
                    {
                        _obligationPage.Tree1.SelectValues(result);
                        break;
                    }
                    case "tree 2":
                    {
                        _obligationPage.Tree2.SelectValues(result);
                        break;
                    }
                    case "multi select 1":
                    {
                        _obligationPage.MultiSelect1.SelectItem(result);
                        break;
                    }
                    case "multi select 2":
                    {
                        _obligationPage.MultiSelect2.SelectItem(result);
                        break;
                    }
                    case "multi select 3":
                    {
                        _obligationPage.MultiSelect3.SelectItem(result);
                        break;
                    }
                    default:
                    {
                        Assert.Fail("Error in switch statement field key not known. Key searching for was " + key.ToLower());
                        break;
                    }
                }
            }
        }

        public void AssertObligationData(Table table)
        {
            ReadSpecflowTableIntoDictionary(table);

            _tableDataDictionary = ScenarioContext.Get<IDictionary<string, string>>("tableDictionary");
            _obligationPage = ScenarioContext.Get<ObligationDialog>();

            var keys = _tableDataDictionary.Keys;
            foreach (var key in keys)
            {
                _tableDataDictionary.TryGetValue(key, out var result);
                switch (key.ToLower())
                {
                    case "id":
                    {
                        if (result != "@autogenerated")
                        {
                            _obligationPage.Id.AssertEquals(result);
                        }
                        break;
                    }
                    case "title":
                    {
                        _obligationPage.Title.AssertEquals(result);
                        break;
                    }
                    case "due":
                    {
                        _obligationPage.Due.AssertDateEquals(result);
                        break;
                    }
                    case "created":
                    {
                        _obligationPage.Created.AssertDateEquals(result);
                        break;
                    }
                    case "source updated":
                    {
                        _obligationPage.SourceUpdated.AssertDateEquals(result);
                        break;
                    }
                    case "owner":
                    {
                        _obligationPage.Owner.AssertEquals(result);
                        break;
                    }
                    case "category":
                    {
                        _obligationPage.Category.AssertTextEquals(result);
                        break;
                    }
                    case "compliance status":
                    {
                        _obligationPage.ComplianceStatus.AssertTextEquals(result);
                        break;
                    }
                    case "approver":
                    {
                        _obligationPage.Approver.AssertEquals(result);
                        break;
                    }
                    case "approval status":
                    {
                        _obligationPage.ApprovalStatus.AssertTextEquals(result);
                        break;
                    }
                    case "archived":
                    {
                        if (result == "True")
                            _obligationPage.Archived.AssertSelected();
                        else
                            _obligationPage.Archived.AssertUnselected();

                        break;
                    }
                    case "description":
                    {
                        _obligationPage.Description.AssertEquals(result);
                        break;
                    }
                    case "practical guidance":
                    {
                        _obligationPage.PracticalGuidance.AssertEquals(result);
                        break;
                    }
                    case "remediation":
                    {
                        _obligationPage.Remediation.AssertEquals(result);
                        break;
                    }
                    case "consequence":
                    {
                        _obligationPage.Consequence.AssertEquals(result);
                        break;
                    }
                    case "compliance source":
                    {
                        _obligationPage.ComplianceSource.AssertEquals(result);
                        break;
                    }
                    case "approval date":
                    {
                        _obligationPage.ApprovalDate.AssertDateEquals(result);
                        break;
                    }
                    case "tree 1":
                    {
                        _obligationPage.Tree1.AssertValueIsSelected(result);
                        break;
                    }
                    case "tree 2":
                    {
                        _obligationPage.Tree2.AssertValueIsSelected(result);
                        break;
                    }
                    case "multi select 1":
                    {
                        _obligationPage.MultiSelect1.AssertMultipleItemsSelected(result);
                        break;
                    }
                    case "multi select 2":
                    {
                        _obligationPage.MultiSelect2.AssertMultipleItemsSelected(result);
                        break;
                    }
                    case "multi select 3":
                    {
                        _obligationPage.MultiSelect3.AssertMultipleItemsSelected(result);
                        break;
                    }
                    case "last updated":
                    {
                        _obligationPage.LastUpdated.AssertDateEquals(result);
                        break;
                    }
                    default:
                    {
                        Assert.Fail("Error in switch statment field key not known. Key searching for was " + key.ToLower());
                        break;
                    }
                }
            }
        }
    }
}
