﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewSplashScreen;
using TechTalk.SpecFlow;

namespace TestFixtures.GenericSpecflowSteps
{
    [Binding]
    public class AppNavigationSteps : SpecFlowRiskDesktopFixture
    {
        private NewSplashScreenLogin _splashScreen;

        public AppNavigationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [When(@"the user navigates to ARM Desktop")]
        public void WhenTheUserNavigatesToArmDesktop()
        {
            _splashScreen = ScenarioContext.Get<NewSplashScreenLogin>();
            _splashScreen.ClickOnDesktopIcon();

            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter = ScenarioContext.Get<WebDriverWait>();
            Desktop = new WebDriverDesktop(Driver, Waiter);
            ScenarioContext.Set(Desktop);
            Desktop.FocusNewWindow();
        }

        [When(@"the user clicks on Sword logo")]
        public void WhenTheUserClicksOnSwordLogo()
        {
            var driver = ScenarioContext.Get<IWebDriver>();
            var waiter = ScenarioContext.Get<WebDriverWait>();
            _splashScreen = new NewSplashScreenLogin(driver, waiter);
            _splashScreen.ClickSwordLogo();
            _splashScreen.WaitUntilUiSpinnerIsNotDisplayed();

            ScenarioContext.Set(_splashScreen);
            _splashScreen = ScenarioContext.Get<NewSplashScreenLogin>();
            _splashScreen.FocusNewWindow();
        }

        [Given(@"the user navigates to ACM Active Compliance Manager")]
        [When(@"the user navigates to ACM Active Compliance Manager")]
        public void GivenTheUserNavigatesToAcmActiveComplianceManager()
        {
            WhenTheUserClicksOnSwordLogo();
            _splashScreen = ScenarioContext.Get<NewSplashScreenLogin>();
            _splashScreen.ClickOnComplianceManagerIcon();
            ComplianceSetup();
        }
    }
}
