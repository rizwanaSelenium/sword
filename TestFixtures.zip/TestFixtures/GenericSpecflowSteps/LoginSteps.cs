﻿using TechTalk.SpecFlow;

namespace TestFixtures.GenericSpecflowSteps
{
    [Binding]
    public class LoginSteps : SpecFlowRiskDesktopFixtureBasic
    {
        public LoginSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;            
        }

        [Given(@"the user Logs into ARM with any desktop setup")]
        public void GivenTheUserLogsIntoArm()
        {
            TestFixtureSetup();
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }
    }

    [Binding]
    public class LoginStepsDirect : SpecFlowDirectAnyDesktopFixture
    {
        public LoginStepsDirect(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [Given(@"the user Logs into ARM desktop directly")]
        public void GivenTheUserLogsIntoArmDesktopDirectly()
        {
            TestFixtureSetup("desktop");
            //ScenarioContext.Set(Desktop);
            //ScenarioContext.Set(Driver);
            //ScenarioContext.Set(Waiter);
        }

        [Given(@"the user logs into Survey Manager directly")]
        public void GivenTheUserLogsIntoSurveyManagerDirectly()
        {
            TestFixtureSetup("survey");
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }

        [Given(@"the user logs into ACM Active Compliance Manager directly")]
        public void GivenTheUserLogsIntoAcmActiveComplianceManagerDirectly()
        {
            TestFixtureSetup("compliance");
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }
    }

    [Binding]
    public class LoginStepsRiskDesktopAnyFilterDirect : SpecFlowDirectRiskDesktopAnyFilterFixture
    {
        public LoginStepsRiskDesktopAnyFilterDirect(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [Given(@"the user Logs into ARM Risk desktop with any filter directly")]
        public void GivenTheUserLogsIntoArmRiskDesktopWithAnyFilterDirectly()
        {
            TestFixtureSetup();
        }
    }

    [Binding]
    public class LoginStepsRiskNoFilterDirect : SpecFlowDirectRiskDesktopNoFilterFixture
    {
        public LoginStepsRiskNoFilterDirect(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [Given(@"the user Logs into ARM Risk desktop directly with no filter")]
        public void GivenTheUserLogsIntoArmRiskDesktopDirectlyWithNoFilter()
        {
            TestFixtureSetup("desktop");
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }

        [AfterScenario("QuickTearDown")]
        public void QuickAfterScenario()
        {
            TestFixtureTearDown();
        }
    }
}
