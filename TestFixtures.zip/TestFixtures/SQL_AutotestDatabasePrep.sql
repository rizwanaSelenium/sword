﻿-- Data setup for the WebDriver ARM Automated Tests
-- There was no precedent for this in Watin.

IF(SELECT COUNT(*) FROM RM_Language WHERE Id='fr') = 0
BEGIN
    INSERT INTO RM_LANGUAGE (Id, Name) VALUES ('fr', 'Français')
END
IF(SELECT COUNT(*) FROM RM_Language WHERE Id='de') = 0
BEGIN
    INSERT INTO RM_LANGUAGE (Id, Name) VALUES ('de', 'Deutsche')
END
IF(SELECT COUNT(*) FROM RM_Language WHERE Id='pt') = 0
BEGIN
    INSERT INTO RM_LANGUAGE (Id, Name) VALUES ('pt', 'Português')
END
IF(SELECT COUNT(*) FROM RM_Language WHERE Id='sv') = 0
BEGIN
    INSERT INTO RM_LANGUAGE (Id, Name) VALUES ('sv', 'Svenska')
END

UPDATE RM_Resource SET LicensedToARMDashboard = 1, LicensedToARMCompliance = 1, LicensedToARMBowTie = 1, LicensedToARMRiskVisualiser = 1, LicensedToARMScheduleAnalysis = 1, LicensedToARMSurveys = 1 where UserName = 'armtest';

UPDATE RM_SystemSetting SET VALUE='9' WHERE NAME='LogLevel'

UPDATE RM_Licence SET Doors=1

-- Adding new role 'ARM Risk Express 1'
DECLARE @RoleID1 int
SET @RoleID1 = (Select top 1 RoleID + 1 from RM_Role order by RoleID desc)
INSERT INTO RM_Role VALUES(@RoleID1,'ARM Risk Express 1','ARM Risk Express user can add risk, update impact, add responses, update responses ,link and unlink responses and delete records',10,3);

INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1903);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,3502);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1201);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1202);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1200);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1301);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1302);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1300);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,9001);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,9000);
INSERT INTO RM_RoleHasFunction VALUES(@RoleID1,1101);

-- Adding new read only role 'ARM Risk Express 2'
DECLARE @RoleID2 int
SET @RoleID2 = (Select top 1 RoleID + 1 from RM_Role order by RoleID desc)
INSERT INTO RM_Role VALUES(@RoleID2,'ARM Risk Express 2','ARM Risk Express read only user (browser)',10,1);

-- Adding qauser1
DECLARE @ResourceID1 int
SET @ResourceID1 = (Select top 1 ResourceId + 1 from RM_Resource order by ResourceId desc)
INSERT INTO RM_Resource
(ResourceId, ResourceType, FirstName, LastName, Name, Email, UserName, Domain, RoleID, CostLimit, BlackFlagLimit, LabelSetId, UpperUserName, UpperDomain, ManagerID, LastLogonTime, UseDefault, AlertDigests, DefaultFilterID, DefaultBusAreaID, DetailFieldsExpanded, IsRetired, DetailAssessmentView, DesktopPageSize, DesktopGrid, PortfolioTree, HighlightItems, ShowToolbarIcons, EmployeeRef, Location, Comments, ExpandTreeToDepth, TreeNodeLimit, CurrencyID, RollupFromDetailRecords, LanguageId, SqlAuthUserId, LicensedToARMDesktop, LicensedToARMApps, LicensedToArmRiskExpress, LicensedToARMUnplugged, LicensedToARMWebServiceApi, LicensedToARMScheduleAnalysis, LicensedToARMRiskVisualiser)
VALUES(@ResourceID1,2,'qauser1','qauser1','qauser1','qauser1@activerisk1.com','qauser1','whiskers',@RoleID1,10000,100000,-1,'QAUSER1','WHISKERS',-2,NULL,1,0,999,1,0,0,0,25,0,0,0,1,NULL,NULL,NULL,1,500,1,0,'SYSTEM',NULL,0,0,1,0,0,0,0);

INSERT INTO RM_ResourceGroup VALUES(@ResourceID1,1,0);
INSERT INTO RM_ResourceGroup VALUES(@ResourceID1,2,0);
INSERT INTO RM_ResourceGroup VALUES(@ResourceID1,3,0);

-- Adding qauser2
DECLARE @ResourceID2 int
SET @ResourceID2 = (Select top 1 ResourceId + 1 from RM_Resource order by ResourceId desc)
INSERT INTO RM_Resource
(ResourceId, ResourceType, FirstName, LastName, Name, Email, UserName, Domain, RoleID, CostLimit, BlackFlagLimit, LabelSetId, UpperUserName, UpperDomain, ManagerID, LastLogonTime, UseDefault, AlertDigests, DefaultFilterID, DefaultBusAreaID, DetailFieldsExpanded, IsRetired, DetailAssessmentView, DesktopPageSize, DesktopGrid, PortfolioTree, HighlightItems, ShowToolbarIcons, EmployeeRef, Location, Comments, ExpandTreeToDepth, TreeNodeLimit, CurrencyID, RollupFromDetailRecords, LanguageId, SqlAuthUserId, LicensedToARMDesktop, LicensedToARMApps, LicensedToArmRiskExpress, LicensedToARMUnplugged, LicensedToARMWebServiceApi, LicensedToARMScheduleAnalysis, LicensedToARMRiskVisualiser)
VALUES(@ResourceID2,2,'qauser2','qauser2','qauser2','qauser2@activerisk1.com','qauser2','whiskers',@RoleID2,10000,100000,-1,'QAUSER2','WHISKERS',-2,NULL,1,0,999,1,0,0,0,25,0,0,0,1,NULL,NULL,NULL,1,500,1,0,'SYSTEM',NULL,0,0,1,0,0,0,0);

INSERT INTO RM_ResourceGroup VALUES(@ResourceID2,1,0);
INSERT INTO RM_ResourceGroup VALUES(@ResourceID2,2,0);
INSERT INTO RM_ResourceGroup VALUES(@ResourceID2,3,0);

UPDATE RM_HibernateIDs SET ResourceHi = (SELECT ISNULL(MAX(ResourceID),0) / 20 + 1 FROM RM_Resource) WHERE ResourceHi >= 0;

-- Set default business area and give access to all areas for ARMTest
UPDATE RM_Resource SET DefaultBusAreaId = 1, LicensedToArmDesktop=1, LicensedToArmApps=1, LicensedToArmRiskExpress=1, LicensedToArmUnplugged=1, LicensedToArmWebServiceApi=1 WHERE ResourceId = 22

-- Setting Default filter for all the resources
--update rm_resource set DefaultFilterId=999, LicensedToArmDesktop=1, LicensedToArmApps=1, LicensedToArmRiskExpress=1, LicensedToArmUnplugged=1, LicensedToArmWebServiceApi=1

INSERT INTO RM_RoleHasFunction (RoleID,FunctionID)
SELECT 2, functionId FROM RM_Function
WHERE functionid NOT IN (SELECT functionId FROM RM_RoleHasFunction WHERE RoleID = 2)
AND IsRoleRight = 1

-- Enable Risk Tabs / Fields by Default
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 643 -- 'Inherent Assessment'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 644 -- 'Inherent Distribution'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 645 -- 'Inherent Exposure'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 136 -- 'Feedback By'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 137 -- 'Last Feedback Date'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 138 -- 'Last Feedback Comment'
UPDATE RM_FieldConfig SET Active=1 WHERE FieldID = 139 -- 'Feedback Button'

-- Add List Entries to Audit, Finding and Audit Action Tab Fields

-- Add Initiated List Entry to Audit Tab Status Field
INSERT INTO RM_AuditStatus (AuditStatusId, Description) VALUES (3, 'Initiated')

-- Add Reviewed List Entry to Audit Action Tab Review Status Field
INSERT INTO RM_AuditReviewStatus (ReviewStatusId, Description) VALUES (4, 'Reviewed')

-- Add Not Compliant List Entry to Finding Tab UDF Drop Down 1 Field
INSERT INTO RM_FindingCustomDropdown1 (FindingCustomDropdownId, Description) VALUES (4, 'Not Compliant')

-- Add In Progress List Entry to Audit Action Tab Status Field
INSERT INTO RM_AuditActionStatus (StatusId, Description) VALUES (3, 'In Progress')


/*
Enable existing alerts and insert a number of new ones.  This is being done to try and weed out any issues that may be lurking in the new alerts before we release ARM 9.
*/

DECLARE @AlertMessage VARCHAR(2000);
DECLARE @AlertName VARCHAR(500);

-- Enable existing alerts...
UPDATE RM_AlertConfiguration SET [Enabled] = 1;

-- Add a bunch more...

-- Audit
SET @AlertMessage = ' %AuditTeam%  %Contact%  %DepartmentBeingAudited%  %Description%  %Hyperlink%  %CustomAuditRef%  %Manager%  %Objectives%  %PlannedCompletionDate%  %PlannedStartDate%  %ProcessBeingAudited%  %ReviewDate1%  %ReviewDate2%  %ReviewDate3%  %ReviewDate4%  %Reviewer1%  %Reviewer2%  %Reviewer3%  %Reviewer4%  %AuditStatus%  %Title%  %AuditType%  %UserDefinedDate1%  %UserDefinedDate2%  %UserDefinedDate3%  %UserDefinedDate4%  %UserDefinedDate5%  %UserDefinedDropDown1%  %UserDefinedDropDown2%  %UserDefinedDropDown3%  %UserDefinedDropDown4%  %UserDefinedDropDown5%  %UserDefinedResource1%  %UserDefinedResource2%  %UserDefinedResource3%  %UserDefinedResource4%  %UserDefinedResource5% ';

SET @AlertName = 'AUDIT ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 70, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 71, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 73, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 101, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'AUDIT ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 70, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 71, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 73, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 101, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Audit Action
SET @AlertMessage = ' %AuditCustomRef%  %AuditManager%  %AuditPlannedStartDate%  %AuditTitle%  %AuditorComment%  %BaselineDueDate%  %BusinessAdminOwner%  %CompletionDate%  %CustomResource1%  %DaysUntilDueDate%  %Description%  %DueDate%  %Hyperlink%  %CustomAuditActionRef%  %Owner%  %ActionOwnerComment%  %Priority%  %Process%  %ProcessOwner%  %ReviewDate%  %ReviewStatus%  %Reviewer%  %Status%  %Title%  %CustomField1%  %CustomField2%  %CustomField3%  %CustomField4%  %CustomField5%  %FindingCustomRef%  %FindingTitle% ';

SET @AlertName = 'AUDIT ACTION ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 76, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 77, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 78, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 103, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'AUDIT ACTION ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 76, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 77, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 78, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 103, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Cost Breakdown
SET @AlertMessage = ' %Comments%  %Description%  %Name%  %Owner%  %OwnerEmail%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'COST BREAKDOWN ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 68, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'COST BREAKDOWN ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 68, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Evaluation
SET @AlertMessage = ' %CurrentExpCostImpactInBaseCur%  %CurrentExpCostImpactInLocalCur%  %TargetExpCostImpactInBaseCur%  %TargetExpCostImpactInLocalCur%  %Conclusion%  %DaysTilDue%  %Description%  %DueDate%  %PreparerEmail%  %ReviewerEmail%  %TestObjective%  %PreparerDate%  %Preparer%  %Recommendation%  %CustomEvaluationRef%  %ReviewComment%  %ReviewerDate%  %Reviewer%  %Status%  %Title%  %RecordType%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'EVALUATION ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 40, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 41, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 44, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 48, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 60, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 97, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'EVALUATION ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 40, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 41, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 44, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 48, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 60, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 97, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Finding
SET @AlertMessage = ' %AuditCustomRef%  %AuditManager%  %AuditPlannedStartDate%  %AuditTitle%  %Description%  %Hyperlink%  %CustomFindingRef%  %Title%  %UserDefinedDate1%  %UserDefinedDate2%  %UserDefinedDropDown1%  %UserDefinedDropDown2%  %UserDefinedResource1%  %UserDefinedResource2%  %UserDefinedFreeText1%  %UserDefinedFreeText2%  %UserDefinedFreeText3%  %UserDefinedFreeText4%  %UserDefinedFreeText5% ';

SET @AlertName = 'FINDING ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 74, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 75, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 102, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'FINDING ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 74, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 75, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 102, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea


-- Impact
SET @AlertMessage = ' %ActualCostInBaseCurrency%  %ActualCostInLocalCurrency%  %BlackFlagComments%  %BlackFlagType%  %CurrentExpectedImpact1%  %CurrentExpectedImpact10%  %CurrentExpectedImpact2%  %CurrentExpectedImpact3%  %CurrentExpectedImpact4%  %CurrentExpectedImpact5%  %CurrentExpectedImpact6%  %CurrentExpectedImpact7%  %CurrentExpectedImpact8%  %CurrentExpectedImpact9%  %CurrentExpCostImpactInBaseCur%  %CurrentExpCostImpactInLocalCur%  %CurrentExpectedTimeImpact%  %CurrentFrequencyOccurrences%  %CurrentFrequencyYears%  %CurrentPessimisticImpact1%  %CurrentPessimisticImpact10%  %CurrentPessimisticImpact2%  %CurrentPessimisticImpact3%  %CurrentPessimisticImpact4%  %CurrentPessimisticImpact5%  %CurrentPessimisticImpact6%  %CurrentPessimisticImpact7%  %CurrentPessimisticImpact8%  %CurrentPessimisticImpact9%  %CurrentPesCostImpactInBaseCur%  %CurrentPesCostImpactInLocalCur%  %CurrentPessimisticTimeImpact%  %CurrentOptimisticImpact1%  %CurrentOptimisticImpact10%  %CurrentOptimisticImpact2%  %CurrentOptimisticImpact3%  %CurrentOptimisticImpact4%  %CurrentOptimisticImpact5%  %CurrentOptimisticImpact6%  %CurrentOptimisticImpact7%  %CurrentOptimisticImpact8%  %CurrentOptimisticImpact9%  %CurrentOptCostImpactInBaseCur%  %CurrentOptCostImpactInLocalCur%  %CurrentOptimisticTimeImpact%  %CurrentOverallScore%  %CurrentProbability%  %DateImpacted%  %DateLastChanged%  %DaysToExpiry%  %DaysToTargetResolutionDate%  %DaysToTrigger%  %ExpiryDate%  %FieldsChanged%  %Hyperlink%  %HyperlinkArm%  %HyperlinkRiskExpress%  %LinkedItem%  %TargetExpCostImpactInBaseCur%  %TargetExpCostImpactInLocalCur%  %TargetOverallScore%  %ProbabilityOrFrequency%  %TargetResolutionDate%  %TimeUnits%  %TriggerDate%  %RiskCategories%  %CustomRiskRef%  %InterestedParties%  %InterestedPartiesEmail%  %Owner%  %OwnerEmail%  %RiskRaisedBy%  %RiskRaisedByEmail%  %RecordType%  %Status%  %Name%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'IMPACT ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 3, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 4, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 26, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 30, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 33, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'IMPACT ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 3, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 4, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 26, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 30, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 33, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Impact Response
SET @AlertMessage = '%Description%  %ActualCostInBaseCurrency%  %ActualCostInLocalCurrency%  %BaselineDaysChanged%  %BaselineDueDate%  %Comments%  %ControlAssertion%  %ControlClassification%  %ControlCondition%  %ControlType%  %CostInBaseCurrency%  %CostInLocalCurrency%  %CostThreatInBaseCurrency%  %CostThreatInLocalCurrency%  %CustomField1%  %CustomField2%  %CustomField3%  %CustomField4%  %DateLastChanged%  %DaysChanged%  %DaysSlipped%  %DaysTilDue%  %DaysTilStart%  %DesignEffectiveness%  %Effectiveness%  %ExpectedCostInBaseCurrency%  %ExpectedCostInLocalCurrency%  %FieldsChanged%  %Hyperlink%  %HyperlinkArm%  %CustomResponseRef%  %IsLinkedActivity%  %LinkedItems%  %LinkedProjectId%  %LinkedProjectType%  %LinkedProjectVersionNumber%  %Owner%  %OwnerEmail%  %PercentageComplete%  %DueDate%  %StartDate%  %PreviousBaselineDueDate%  %PreviousDueDate%  %Priority%  %ReviewDate%  %Reviewer%  %Status%  %TestFrequency%  %TimeUnits%  %Name%  %Type%  %CurrentExpCostImpactInBaseCur%  %CurrentExpCostImpactInLocalCur%  %FrequencyOccurrences%  %FrequencyYears%  %PesCostImpactInBaseCur%  %PesCostImpactInLocalCur%  %OptimisticCostImpactInBaseCur%  %OptimisticCostImpactInLocalCur%  %ExpectedImpact1%  %ExpectedImpact10%  %ExpectedImpact2%  %ExpectedImpact3%  %ExpectedImpact4%  %ExpectedImpact5%  %ExpectedImpact6%  %ExpectedImpact7%  %ExpectedImpact8%  %ExpectedImpact9%  %ExpectedCostImpactInBaseCur%  %ExpectedCostImpactInLocalCur%  %ExpectedTimeImpact%  %PessimisticImpact1%  %PessimisticImpact10%  %PessimisticImpact2%  %PessimisticImpact3%  %PessimisticImpact4%  %PessimisticImpact5%  %PessimisticImpact6%  %PessimisticImpact7%  %PessimisticImpact8%  %PessimisticImpact9%  %PessimisticTimeImpact%  %OptimisticImpact1%  %OptimisticImpact10%  %OptimisticImpact2%  %OptimisticImpact3%  %OptimisticImpact4%  %OptimisticImpact5%  %OptimisticImpact6%  %OptimisticImpact7%  %OptimisticImpact8%  %OptimisticImpact9%  %OptimisticTimeImpact%  %TargetExpCostImpactInBaseCur%  %TargetExpCostImpactInLocalCur%  %TargetRiskLevel%  %Probability%  %ProbabilityOrFrequency%  %RiskIds%  %RiskInterestedParties%  %RiskOwners%  %RiskStatuses%  %RiskNames%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %BusinessArea%  %Instance% ';

SET @AlertName = 'IMPACT RESPONSE ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 5, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 9, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 10, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 11, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 12, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 21, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 28, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 31, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 34, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 45, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 82, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 96, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'IMPACT RESPONSE ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 5, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 9, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 10, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 11, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 12, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 21, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 28, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 31, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 34, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 45, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 82, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 96, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Incident
SET @AlertMessage = ' %AssetNumber%  %BasicCauseOfIncident%  %BodilyLocation%  %Categories%  %ClaimManager%  %ClaimNumber%  %ClaimStatus%  %ClaimType%  %DateOfClaimAdvise%  %IncidentDate%  %DateReported%  %Description%  %DirectCause%  %EstimatedCostOfClaimInBaseCur%  %EstimatedCostOfClaimInLocalCur%  %EstimCostOfIncidentInBaseCur%  %EstimCostOfIncidentInLocalCur%  %EstimatedLossInBaseCurrency%  %EstimatedLossInLocalCurrency%  %Hyperlink%  %HyperlinkArm%  %CustomIncidentRef%  %InsuranceStatus%  %InterestedParties%  %InterestedPartiesEmail%  %InsuranceClaim%  %LinkedItems%  %LocationOfIncident%  %IsNearMiss%  %Owner%  %OwnerEmail%  %RaisedBy%  %IncidentRaiserEmail%  %RegulatoryAuthorities%  %ResponsiblePerson%  %SeverityBand%  %Status%  %IncidentTime%  %TimeReported%  %Name%  %Type%  %MechanismOfInjury%  %NatureOfInjury%  %InvestigationComments%  %InvestigationContributingCauses%  %InvestigationDatePrepared%  %InvestigationReviewDate%  %DaysTilDue%  %InvestigationDueDate%  %InvestigationCustomRef%  %InvestigationPreparer%  %InvestigationPreparerEmail%  %InvestigationReviewer%  %InvestigationReviewerEmail%  %InvestigationRootCause%  %InvestigationStatus%  %InvestigationTitle%  %InvestigationType%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'INCIDENT ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 29, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 35, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 36, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 104, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'INCIDENT ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 29, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 35, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 36, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 104, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Incident Response
SET @AlertMessage = ' %Description%  %ActualCostInBaseCurrency%  %ActualCostInLocalCurrency%  %BaselineDaysChanged%  %BaselineDueDate%  %Comments%  %ControlAssertion%  %ControlClassification%  %ControlCondition%  %ControlType%  %CostInBaseCurrency%  %CostInLocalCurrency%  %CostThreatInBaseCurrency%  %CostThreatInLocalCurrency%  %CustomField1%  %CustomField2%  %CustomField3%  %CustomField4%  %DateLastChanged%  %DaysChanged%  %DaysSlipped%  %DaysTilDue%  %DaysTilStart%  %DesignEffectiveness%  %Effectiveness%  %ExpectedCostInBaseCurrency%  %ExpectedCostInLocalCurrency%  %FieldsChanged%  %Hyperlink%  %HyperlinkArm%  %CustomResponseRef%  %IsLinkedActivity%  %LinkedItems%  %LinkedProjectId%  %LinkedProjectType%  %LinkedProjectVersionNumber%  %Owner%  %OwnerEmail%  %PercentageComplete%  %DueDate%  %StartDate%  %PreviousBaselineDueDate%  %PreviousDueDate%  %Priority%  %ReviewDate%  %Reviewer%  %Status%  %TestFrequency%  %TimeUnits%  %Name%  %Type%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'INCIDENT RESPONSE ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 84, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 85, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 86, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 87, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 88, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 89, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 99, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'INCIDENT RESPONSE ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 84, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 85, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 86, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 87, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 88, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 89, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 99, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Investigation
SET @AlertMessage = ' %AssetNumber%  %BasicCauseOfIncident%  %BodilyLocation%  %Categories%  %ClaimManager%  %ClaimNumber%  %ClaimStatus%  %ClaimType%  %DateOfClaimAdvise%  %IncidentDate%  %DateReported%  %Description%  %DirectCause%  %EstimatedCostOfClaimInBaseCur%  %EstimatedCostOfClaimInLocalCur%  %EstimCostOfIncidentInBaseCur%  %EstimCostOfIncidentInLocalCur%  %EstimatedLossInBaseCurrency%  %EstimatedLossInLocalCurrency%  %CustomIncidentRef%  %InsuranceStatus%  %InterestedParties%  %InterestedPartiesEmail%  %LocationOfIncident%  %IsNearMiss%  %Owner%  %OwnerEmail%  %RaisedBy%  %IncidentRaiserEmail%  %RegulatoryAuthorities%  %ResponsiblePerson%  %SeverityBand%  %IncidentStatus%  %IncidentTime%  %TimeReported%  %IncidentName%  %IncidentType%  %MechanismOfInjury%  %NatureOfInjury%  %Comments%  %ContributingCauses%  %DatePrepared%  %DateReviewed%  %DaysTilDue%  %DueDate%  %Hyperlink%  %HyperlinkArm%  %CustomInvestigationRef%  %InsuranceClaim%  %LeadInvestigator%  %LeadInvestigatorEmail%  %LinkedItems%  %Reviewer%  %ReviewerEmail%  %RootCause%  %Status%  %Name%  %Type%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'INVESTIGATION ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 37, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 38, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 81, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'INVESTIGATION ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 37, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 38, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 81, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Plan
SET @AlertMessage = ' %CurrentExpCostImpactInBaseCur%  %CurrentExpCostImpactInLocalCur%  %TargetExpCostImpactInBaseCur%  %TargetExpCostImpactInLocalCur%  %RiskIds%  %InterestedParties%  %RiskOwners%  %RecordTypes%  %RiskNames%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance%  %CompletionDate%  %CostInBaseCurrency%  %CostInLocalCurrency%  %DateLastChanged%  %FallbackPlanDescription%  %FieldsChanged%  %Hyperlink%  %HyperlinkArm%  %CustomPlanRef%  %LinkedItems%  %Owner%  %OwnerEmail%  %ApprovalDate%  %Name%  %HighLevelDescription% ';

SET @AlertName = 'PLAN ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 24, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 27, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 83, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 95, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'PLAN ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 24, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 27, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 83, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 95, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Requirement
SET @AlertMessage = ' %BusinessObjectives%  %Comments%  %CostInBaseCurrency%  %CostInLocalCurrency%  %Description%  %Name%  %ObjectID%  %Owner%  %OwnerEmail%  %RequirementCustomList2%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'REQUIREMENT ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 61, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 62, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 63, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 64, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 67, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'REQUIREMENT ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 61, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 62, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 63, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 64, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 67, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Risk
SET @AlertMessage = ' %CurrentExpCostImpactInBaseCur%  %CurrentExpCostImpactInLocalCur%  %MaxProbability%  %TargetExpCostImpactInBaseCur%  %TargetExpCostImpactInLocalCur%  %Description%  %Categories%  %Cause%  %DateLastChanged%  %DaysToAssessment%  %Effect%  %FieldsChanged%  %Hyperlink%  %HyperlinkArm%  %HyperlinkRiskExpress%  %CustomRiskRef%  %InterestedParties%  %InterestedPartiesEmail%  %LinkedItem%  %AssessmentDate%  %Owner%  %OwnerEmail%  %RaisedBy%  %RaisedByEmail%  %RiskType%  %Status%  %Name%  %BusinessAreaManager%  %BusinessAreaManagerEmail%  %BusinessArea%  %Instance% ';

SET @AlertName = 'RISK ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 1, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 2, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 16, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 25, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 32, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 65, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 80, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 94, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'RISK ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 1, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 2, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 16, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 25, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 32, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 65, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 80, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 94, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0, 0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

-- Resource
SET @AlertMessage = '%Domain%  %Email%  %Instance%  %JobTitle%  %LastLogonTime%  %Manager%  %Name%  %Role%  %ResourceType%  %UserName% ';

SET @AlertName = 'RESOURCE ALERT TEST [all folders]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 46, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 47, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	0,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

SET @AlertName = 'RESOURCE ALERT TEST [live folders only]';
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 46, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea
INSERT INTO RM_AlertConfiguration SELECT BusAreaID, (SELECT MAX(alertId) FROM RM_AlertConfiguration) + BusAreaID, 1, @AlertName, 47, @AlertMessage, 'johnstest', 2, 'nobody@nowhere.com',  0, 1, 0,	0,	@AlertName, 0,	0,	0,	1,	0,	'johnstest', GETDATE(),	'johnstest', GETDATE(), -3 FROM RM_BusinessArea

UPDATE RM_HibernateIDs SET AlertConfigHi = (SELECT ISNULL(MAX(alertId),0) / 20 + 1 FROM RM_AlertConfiguration);

DECLARE @StratID int
SET @StratID = (Select top 1 StrategyID + 1 from RM_Strategy order by StrategyID desc)
INSERT INTO RM_Strategy (StrategyID, Description, IsMitigating) VALUES (@StratID, 'non-mitigating', 0);

DECLARE @ConfigID int
SET @ConfigID = (SELECT EventID FROM RM_EVENT WHERE Name = 'Secret Risk')
UPDATE RM_FieldConfig SET Mandatory = 0 WHERE FieldID = 38 -- 'Approval Date'
AND EXISTS (
	SELECT * FROM RM_RiskTypeFieldConfigSet r WHERE r.RiskTypeID = @ConfigID AND r.FieldConfigSetID = RM_FieldConfig.FieldConfigSetID
)

--Adding Nil score band into large PID scoring scheme
INSERT INTO RM_ScoringCriteria ([SchemeID], [CategoryID], [BandID], [MinValue], [MaxValue], [Description], [ScoringMethodId]) VALUES (11, -2, 1, 0, 0, 'NIL', 2)

--Adding New survey
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (1, 'OwnedSurvey', 0, NULL, NULL, '10 Apr 2018', 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (2, 'OwnedSurvey1', 1, NULL, NULL, '10 Apr 2018', 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (3, 'SharedSurvey', 2, NULL, NULL, '10 Apr 2018', 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (4, 'Question Test 1', 0, NULL, NULL, NULL, 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (5, 'Question Test 2', 0, NULL, NULL, NULL, 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (6, 'Survey 1', 0, NULL, NULL, NULL, 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (7, 'Survey 2', 0, NULL, NULL, NULL, 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (8, 'Survey 3', 0, NULL, NULL, NULL, 0)
INSERT INTO RM_Survey(SurveyID, Title, Status, FromDate, ToDate, DueDate, Progress) VALUES (9, 'Survey 4', 0, NULL, NULL, NULL, 0)

--Adding Survey Page
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (1, 7, 1, 'OwnedSurveyPageTitle', 'OwnedSurveyPageDescription')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (4, 1, 1, 'Test Question Page 1', 'This is a test page')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (4, 2, 2, 'Test Question Page 2', 'This is another test page')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (5, 3, 1, 'Test Question Page 1', 'This page is to test the radio button question')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (5, 4, 2, 'Test Question Page 2', 'This page is to test the text question')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (5, 5, 3, 'Test Question Page 3', 'This page is to test the linear scaling question')
INSERT INTO RM_SurveyPage (SurveyID, PageID, OrderID, Title, Description) VALUES (5, 6, 4, 'Test Question Page 4', 'This page is to test the matrix question')

--Adding Survey Question
INSERT INTO RM_SurveyQuestion (QuestionID, PageID, Question, Type, DataString, Mandatory, OrderID) VALUES (1, 6, 'Are you satisfied with the following controls?', 3, '{
  "options": [
    {
      "order": 1,
      "value": "Yes"
    },
    {
      "order": 2,
      "value": "No"
    }
  ],
  "rows": [
    {
      "order": 1,
      "value": "Team A status report"
    },
    {
      "order": 2,
      "value": "Fire and storm procedure"
    },
    {
      "order": 3,
      "value": "linear analysis assessment"
    },
    {
      "order": 4,
      "value": "Plan measurements"
    },
    {
      "order": 5,
      "value": "Infrastructure"
    }
  ],
  "columns": [
    {
      "order": 1,
      "value": "Very"
    },
    {
      "order": 2,
      "value": "Some what"
    },
    {
      "order": 3,
      "value": "Not bad"
    },
    {
      "order": 4,
      "value": "Poor"
    },
    {
      "order": 5,
      "value": "Not at all"
    }
  ]
}',0,1 )



UPDATE RM_HibernateIDs SET SurveyHi = 1
UPDATE RM_HibernateIDs SET SurveyAccessHi = 1
UPDATE RM_HibernateIDs SET SurveyPageHi = 1
UPDATE RM_HibernateIDs SET SurveyQuestionHi = 1

--Adding SurveyAcess
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(1, 1, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(2, 2, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(3, 3, 64, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(4, 3, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(5, 4, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(6, 5, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(7, 6, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(8, 7, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(9, 8, 22, 0)
INSERT INTO RM_SurveyAccess(SurveyAccessID, SurveyID, ResourceID, AccessLevel) VALUES(10, 9, 22, 0)

--Compliance stuff still needing adding

    INSERT INTO RM_SpecialisedStrings (LabelSetId, StringKey, StringHolder, AreaID, SequenceNo, LangLabels, LanguageID)
    VALUES (3, 'TASK', 'Task', 221, 1, 'Task', 'de'),
    (3, 'COMPLIANCETASKCUSTOMID', 'ID kaart', 221, 1, 'Custom Id', 'de'),
    (3, 'COMPLIANCETASKTITLE', 'Titel', 221, 1, 'Title', 'de'),
    (3, 'COMPLIANCETASKCREATED', 'Gemaakt', 221, 1, 'Created', 'de'),
    (3, 'COMPLIANCETASKLASTUPDATED', 'Laatst bijgewerkt', 221, 1, 'Last Updated', 'de'),
    (3, 'COMPLIANCETASKDUE', 'Ten gevolge', 221, 1, 'Due', 'de'),
    (3, 'COMPLIANCETASKDESCRIPTION', 'Beschrijving', 221, 1, 'Description', 'de'),
    (3, 'COMPLIANCETASKNOTES', 'Notes', 221, 1, 'Notes', 'de'),
    (3, 'COMPLIANCETASKOWNER', 'Eigenaar', 221, 1, 'Owner', 'de'),
    (3, 'COMPLIANCETASKSTATUS', 'Staat', 221, 1, 'Status', 'de'),
    (3, 'OBLIGATION', 'Verpflichtung', 212, 1, 'Obligation', 'de'),
    (3, 'OBLIGATIONCUSTOMID', 'ID kaart ä', 212, 2, 'Id', 'de'),
    (3, 'OBLIGATIONTITLE', 'Titel å', 212, 3, 'Title', 'de'),
    (3, 'OBLIGATIONCREATED', 'erstellt æ', 212, 4, 'Created', 'de'),
    (3, 'OBLIGATIONSOURCEUPDATED', 'Quelle aktualisiert g', 212, 4, 'Source Updated', 'de'),
    (3, 'OBLIGATIONDUE', 'fällig ë', 212, 5, 'Due', 'de'),
    (3, 'OBLIGATIONARCHIVED', 'archiviert ö', 212, 6, 'Archived', 'de'),
    (3, 'OBLIGATIONDESCRIPTION', 'Beschreibung ø', 212, 7, 'Description', 'de'),
    (3, 'OBLIGATIONPRACTICALGUIDANCE', 'praktische Anleitung ß', 212, 8, 'Practical Guidance', 'de'),
    (3, 'OBLIGATIONREMEDIATION', 'Sanierung s', 212, 9, 'Remediation', 'de'),
    (3, 'OBLIGATIONCONSEQUENCE', 'Folge ü', 212, 10, 'Consequence', 'de'),
    (3, 'OBLIGATIONCOMPLIANCESOURCE', 'Compliance-Quelle ÿ', 212, 11, 'Compliance Source', 'de'),
    (3, 'OBLIGATIONCATEGORY', 'Kategorie Ä', 212, 12, 'Category', 'de'),
    (3, 'OBLIGATIONOWNER', 'Inhaber Å', 212, 13, 'Owner', 'de'),
    (3, 'OBLIGATIONAPPROVER', 'Genehmiger Æ', 212, 14, 'Approver', 'de'),
    (3, 'OBLIGATIONCOMPLIANCESTATUS', 'Konformitätsstatus G', 212, 15, 'Compliance Status', 'de'),
    (3, 'OBLIGATIONAPPROVALSTATUS', 'Freigabestand Ë', 212, 16, 'Approval Status', 'de'),
    (3, 'OBLIGATIONMULTISELECT1', 'Mehrfachauswahl 1 Ö', 212, 17, 'Multi Select 1', 'de'),
    (3, 'OBLIGATIONMULTISELECT2', 'Mehrfachauswahl 2 Ø', 212, 18, 'Multi Select 2', 'de'),
    (3, 'OBLIGATIONMULTISELECT3', 'Mehrfachauswahl 3 S', 212, 19, 'Multi Select 3', 'de'),
    (3, 'OBLIGATIONTREE1', 'Baum 1 Ü', 212, 20, 'Tree 1', 'de'),
    (3, 'OBLIGATIONTREE2', 'Baum 2', 212, 21, 'Tree 2', 'de'),
    (3, 'OBLIGATIONAPPROVALDATE', 'Datum van goedkeuring', 212, 22, 'Approval Date', 'de'),
    (3, 'OBLIGATIONLASTUPDATED', 'Laatst bijgewerkt', 212, 23, 'Last Updated', 'de'),
    (3, 'OBLIGATIONACTIVITYITEMS', 'Toepasselijke gebieden', 212, 23, 'Applicable Areas', 'de');

    INSERT INTO RM_SpecialisedStrings (LabelSetId, StringKey, StringHolder, AreaID, SequenceNo, LangLabels, LanguageID)
    VALUES (3, 'TASK', 'Tâche', 221, 1, 'Task', 'fr'),
    (3, 'COMPLIANCETASKCUSTOMID', 'Id', 221, 1, 'Custom Id', 'fr'),
    (3, 'COMPLIANCETASKTITLE', 'Titre', 221, 1, 'Title', 'fr'),
    (3, 'COMPLIANCETASKCREATED', 'Créé', 221, 1, 'Created', 'fr'),
    (3, 'COMPLIANCETASKLASTUPDATED', 'Dernière mise à jour', 221, 1, 'Last Updated', 'fr'),
    (3, 'COMPLIANCETASKDUE', 'Dû', 221, 1, 'Due', 'fr'),
    (3, 'COMPLIANCETASKDESCRIPTION', 'La description', 221, 1, 'Description', 'fr'),
    (3, 'COMPLIANCETASKNOTES', 'Remarques', 221, 1, 'Notes', 'fr'),
    (3, 'COMPLIANCETASKOWNER', 'Propriétaire', 221, 1, 'Owner', 'fr'),
    (3, 'COMPLIANCETASKSTATUS', 'Statut', 221, 1, 'Status', 'fr'),
    (3, 'OBLIGATION', 'Obligation', 212, 1, 'Obligation', 'fr'),
    (3, 'OBLIGATIONCUSTOMID', 'Id à À', 212, 2, 'Id', 'fr'),
    (3, 'OBLIGATIONTITLE', 'Titre â Â', 212, 3, 'Title', 'fr'),
    (3, 'OBLIGATIONCREATED', 'créé ä Ä', 212, 4, 'Created', 'fr'),
    (3, 'OBLIGATIONSOURCEUPDATED', 'actualisé æ Æ', 212, 4, 'Source Updated', 'fr'),
    (3, 'OBLIGATIONDUE', 'dû ç Ç', 212, 5, 'Due', 'fr'),
    (3, 'OBLIGATIONARCHIVED', 'archivé è È', 212, 6, 'Archived', 'fr'),
    (3, 'OBLIGATIONDESCRIPTION', 'la description é É', 212, 7, 'Description', 'fr'),
    (3, 'OBLIGATIONPRACTICALGUIDANCE', 'conseils pratiques ê Ê', 212, 8, 'Practical Guidance', 'fr'),
    (3, 'OBLIGATIONREMEDIATION', 'remédiation ë Ës', 212, 9, 'Remediation', 'fr'),
    (3, 'OBLIGATIONCONSEQUENCE', 'conséquence î Î', 212, 10, 'Consequence', 'fr'),
    (3, 'OBLIGATIONCOMPLIANCESOURCE', 'source de conformité ï Ï', 212, 11, 'Compliance Source', 'fr'),
    (3, 'OBLIGATIONCATEGORY', 'Catégorie ô Ô', 212, 12, 'Category', 'fr'),
    (3, 'OBLIGATIONOWNER', 'propriétaire œ Œ', 212, 13, 'Owner', 'fr'),
    (3, 'OBLIGATIONAPPROVER', 'approbateur ù Ù', 212, 14, 'Approver', 'fr'),
    (3, 'OBLIGATIONCOMPLIANCESTATUS', 'état de conformité û Û', 212, 15, 'Compliance Status', 'fr'),
    (3, 'OBLIGATIONAPPROVALSTATUS', 'Statut approuvé ü Ü', 212, 16, 'Approval Status', 'fr'),
    (3, 'OBLIGATIONMULTISELECT1', 'multi-sélection 1', 212, 17, 'Multi Select 1', 'fr'),
    (3, 'OBLIGATIONMULTISELECT2', 'multi-sélection 2', 212, 18, 'Multi Select 2', 'fr'),
    (3, 'OBLIGATIONMULTISELECT3', 'multi-sélection 3', 212, 19, 'Multi Select 3', 'fr'),
    (3, 'OBLIGATIONTREE1', 'arbre 1', 212, 20, 'Tree 1', 'fr'),
    (3, 'OBLIGATIONTREE2', 'arbre 2', 212, 21, 'Tree 2', 'fr'),
    (3, 'OBLIGATIONAPPROVALDATE', 'Date dapprobation', 212, 22, 'Approval Date', 'fr'),
    (3, 'OBLIGATIONLASTUPDATED', 'Dernière mise à jour', 212, 23, 'Last Updated', 'fr'),
    (3, 'OBLIGATIONACTIVITYITEMS', 'Zones applicables', 212, 23, 'Applicable Areas', 'fr');

    INSERT INTO RM_SpecialisedStrings (LabelSetId, StringKey, StringHolder, AreaID, SequenceNo, LangLabels, LanguageID)
    VALUES (3, 'TASK', 'Conformidade', 221, 1, 'Task', 'pt'),
    (3, 'COMPLIANCETASKCUSTOMID', 'Identidade', 221, 1, 'Custom Id', 'pt'),
    (3, 'COMPLIANCETASKTITLE', 'Título', 221, 1, 'Title', 'pt'),
    (3, 'COMPLIANCETASKCREATED', 'Criada', 221, 1, 'Created', 'pt'),
    (3, 'COMPLIANCETASKLASTUPDATED', 'Ultima atualização', 221, 1, 'Last Updated', 'pt'),
    (3, 'COMPLIANCETASKDUE', 'Vencimento', 221, 1, 'Due', 'pt'),
    (3, 'COMPLIANCETASKDESCRIPTION', 'Descrição', 221, 1, 'Description', 'pt'),
    (3, 'COMPLIANCETASKNOTES', 'Notas', 221, 1, 'Notes', 'pt'),
    (3, 'COMPLIANCETASKOWNER', 'Proprietário', 221, 1, 'Owner', 'pt'),
    (3, 'COMPLIANCETASKSTATUS', 'Status', 221, 1, 'Status', 'pt'),
    (3, 'OBLIGATION', 'Obrigação', 212, 1, 'Obligation', 'pt'),
    (3, 'OBLIGATIONCUSTOMID', 'Identidade à À', 212, 2, 'Id', 'pt'),
    (3, 'OBLIGATIONTITLE', 'título á Á', 212, 3, 'Title', 'pt'),
    (3, 'OBLIGATIONCREATED', 'criada â Â', 212, 4, 'Created', 'pt'),
    (3, 'OBLIGATIONSOURCEUPDATED', 'Fonte atualizada ã Ã', 212, 4, 'Source Updated', 'pt'),
    (3, 'OBLIGATIONDUE', 'vencimento é É', 212, 5, 'Due', 'pt'),
    (3, 'OBLIGATIONARCHIVED', 'arquivado ê Ê', 212, 6, 'Archived', 'pt'),
    (3, 'OBLIGATIONDESCRIPTION', 'descrição í Í', 212, 7, 'Description', 'pt'),
    (3, 'OBLIGATIONPRACTICALGUIDANCE', 'orientação prática ó Ó', 212, 8, 'Practical Guidance', 'pt'),
    (3, 'OBLIGATIONREMEDIATION', 'remediação ô Ô', 212, 9, 'Remediation', 'pt'),
    (3, 'OBLIGATIONCONSEQUENCE', 'consequência õ Õ', 212, 10, 'Consequence', 'pt'),
    (3, 'OBLIGATIONCOMPLIANCESOURCE', 'fonte de conformidade ú Ú', 212, 11, 'Compliance Source', 'pt'),
    (3, 'OBLIGATIONCATEGORY', 'categoria ü Ü', 212, 12, 'Category', 'pt'),
    (3, 'OBLIGATIONOWNER', 'proprietário ¿', 212, 13, 'Owner', 'pt'),
    (3, 'OBLIGATIONAPPROVER', 'aprovador', 212, 14, 'Approver', 'pt'),
    (3, 'OBLIGATIONCOMPLIANCESTATUS', 'status de conformidade º', 212, 15, 'Compliance Status', 'pt'),
    (3, 'OBLIGATIONAPPROVALSTATUS', 'status de aprovação ª', 212, 16, 'Approval Status', 'pt'),
    (3, 'OBLIGATIONMULTISELECT1', 'multi-selecionar 1 «', 212, 17, 'Multi Select 1', 'pt'),
    (3, 'OBLIGATIONMULTISELECT2', 'multi-selecionar 2 »', 212, 18, 'Multi Select 2', 'pt'),
    (3, 'OBLIGATIONMULTISELECT3', 'multi-selecionar 3 €', 212, 19, 'Multi Select 3', 'pt'),
    (3, 'OBLIGATIONTREE1', 'árvore 1', 212, 20, 'Tree 1', 'pt'),
    (3, 'OBLIGATIONTREE2', 'árvore 2', 212, 21, 'Tree 2', 'pt'),
    (3, 'OBLIGATIONAPPROVALDATE', 'Data de aprovação', 212, 22, 'Approval Date', 'pt'),
    (3, 'OBLIGATIONLASTUPDATED', 'Ultima atualização', 212, 23, 'Last Updated', 'pt'),
    (3, 'OBLIGATIONACTIVITYITEMS', 'Áreas Aplicáveis', 212, 23, 'Applicable Areas', 'pt');

    INSERT INTO RM_SpecialisedStrings (LabelSetId, StringKey, StringHolder, AreaID, SequenceNo, LangLabels, LanguageID)
    VALUES (3, 'TASK', 'Uppgift', 221, 1, 'Task', 'sv'),
    (3, 'COMPLIANCETASKCUSTOMID', 'Id', 221, 1, 'Custom Id', 'sv'),
    (3, 'COMPLIANCETASKTITLE', 'Titel', 221, 1, 'Title', 'sv'),
    (3, 'COMPLIANCETASKCREATED', 'Skapad', 221, 1, 'Created', 'sv'),
    (3, 'COMPLIANCETASKLASTUPDATED', 'Senast uppdaterad', 221, 1, 'Last Updated', 'sv'),
    (3, 'COMPLIANCETASKDUE', 'På grund av', 221, 1, 'Due', 'sv'),
    (3, 'COMPLIANCETASKDESCRIPTION', 'Beskrivning', 221, 1, 'Description', 'sv'),
    (3, 'COMPLIANCETASKNOTES', 'Anteckningar', 221, 1, 'Notes', 'sv'),
    (3, 'COMPLIANCETASKOWNER', 'Ägare', 221, 1, 'Owner', 'sv'),
    (3, 'COMPLIANCETASKSTATUS', 'Status', 221, 1, 'Status', 'sv'),
    (3, 'OBLIGATION', 'Skyldighet', 212, 1, 'Obligation', 'sv'),
    (3, 'OBLIGATIONCUSTOMID', 'Id Å', 212, 2, 'Id', 'sv'),
    (3, 'OBLIGATIONTITLE', 'titel å', 212, 3, 'Title', 'sv'),
    (3, 'OBLIGATIONCREATED', 'skapad Ä', 212, 4, 'Created', 'sv'),
    (3, 'OBLIGATIONSOURCEUPDATED', 'Uppdaterad källa ä', 212, 4, 'Source Updated', 'sv'),
    (3, 'OBLIGATIONDUE', 'på grund av Ö', 212, 5, 'Due', 'sv'),
    (3, 'OBLIGATIONARCHIVED', 'arkiveras ö', 212, 6, 'Archived', 'sv'),
    (3, 'OBLIGATIONDESCRIPTION', 'beskrivning ß', 212, 7, 'Description', 'sv'),
    (3, 'OBLIGATIONPRACTICALGUIDANCE', 'praktisk vägledning', 212, 8, 'Practical Guidance', 'sv'),
    (3, 'OBLIGATIONREMEDIATION', 'sanering', 212, 9, 'Remediation', 'sv'),
    (3, 'OBLIGATIONCONSEQUENCE', 'Följd', 212, 10, 'Consequence', 'sv'),
    (3, 'OBLIGATIONCOMPLIANCESOURCE', 'efterlevnadskälla', 212, 11, 'Compliance Source', 'sv'),
    (3, 'OBLIGATIONCATEGORY', 'kategori', 212, 12, 'Category', 'sv'),
    (3, 'OBLIGATIONOWNER', 'ägare', 212, 13, 'Owner', 'sv'),
    (3, 'OBLIGATIONAPPROVER', 'godkännare', 212, 14, 'Approver', 'sv'),
    (3, 'OBLIGATIONCOMPLIANCESTATUS', 'överensstämmelsestatus', 212, 15, 'Compliance Status', 'sv'),
    (3, 'OBLIGATIONAPPROVALSTATUS', 'godkännandestatus', 212, 16, 'Approval Status', 'sv'),
    (3, 'OBLIGATIONMULTISELECT1', 'multi-select 1', 212, 17, 'Multi Select 1', 'sv'),
    (3, 'OBLIGATIONMULTISELECT2', 'multi-select 2 »', 212, 18, 'Multi Select 2', 'sv'),
    (3, 'OBLIGATIONMULTISELECT3', 'multi-select 3 €', 212, 19, 'Multi Select 3', 'sv'),
    (3, 'OBLIGATIONTREE1', 'träd 1', 212, 20, 'Tree 1', 'sv'),
    (3, 'OBLIGATIONTREE2', 'träd 2', 212, 21, 'Tree 2', 'sv'),
    (3, 'OBLIGATIONAPPROVALDATE', 'Datum för godkännande', 212, 22, 'Approval Date', 'sv'),
    (3, 'OBLIGATIONLASTUPDATED', 'Senast uppdaterad', 212, 23, 'Last Updated', 'sv'),
    (3, 'OBLIGATIONACTIVITYITEMS', 'Tillämpliga områden', 212, 23, 'Applicable Areas', 'sv');

--Compliance Folder Security
    SELECT DISTINCT GroupId INTO #groups
    FROM RM_ComplianceFolderAccess 
    WHERE NodeId IN (1, 2);
    INSERT INTO RM_ResourceGroup (ResourceID, GroupID, IsAdmin)
    SELECT 22, GroupId, 0 FROM #groups
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 21, GroupId, 2 FROM #groups; 
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 22, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 23, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 24, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 25, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 26, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 98, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 99, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 100, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 168, GroupId, 0 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 169, GroupId, 0 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 189, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 190, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 193, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 197, GroupId, 2 FROM #groups;
    INSERT INTO RM_ComplianceFolderAccess (NodeId, GroupId, AccessRights) 
    SELECT 203, GroupId, 2 FROM #groups;
    DROP TABLE #groups;
