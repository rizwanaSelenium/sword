﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class ListSurveys : SpecFlowDirectAnyDesktopFixture
    {
        public ListSurveys(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyLandingPage _landingPage;

        [Then(@"the user verifies fields ID, Title, Owner, Status, VaildFrom, DueDate and Progress in the surveys table")]
        public void ThenTheUserVerifiesFieldsForSurveysInListSurveysTable(Table table)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();

            var tableRows = table.Rows.Count;
            for (int i = 1; i < tableRows; i++)
            {
                var id = table.Rows[i]["ID"];
                _landingPage.VerifySurveyData(table.Rows[i]["Title"], "title", id);
                _landingPage.VerifySurveyData(table.Rows[i]["Owner"], "owner", id);
                _landingPage.VerifySurveyData(table.Rows[i]["Status"], "status", id);
                _landingPage.VerifySurveyData(table.Rows[i]["VaildFrom"], "from-date", id);
                _landingPage.VerifySurveyData(table.Rows[i]["DueDate"], "due-date", id);
                _landingPage.VerifySurveyData(table.Rows[i]["Progress"], "progress", id);
            }  
        }

        [Given(@"the user Logs into ARM directly")]
        public void GivenTheUserLogsIntoArmDirectly()
        {
            TestFixtureSetup("desktop");
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }
    }
}
