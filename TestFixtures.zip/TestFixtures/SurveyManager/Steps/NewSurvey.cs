﻿using System;
using OpenQA.Selenium;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class NewSurvey : SpecFlowDirectAnyDesktopFixture
    {
        private readonly ScenarioContext _scenarioContext;

        public NewSurvey(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        private SurveyLandingPage _landingPage;
        private SurveyBuildPage _surveyBuildPage;

        [AfterScenario("SurveyManagerNewSurveyTeardown")]
        public void AfterScenario()
        {
            try
            {
                _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
                _surveyBuildPage.Cancel.Click();
                _landingPage = _scenarioContext.Get<SurveyLandingPage>();
                _landingPage.Close.Click();
                Desktop = _scenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"The user navigates to new survey manager")]
        public void GivenTheUserNavigatesToNewSurveyManager()
        {
            Desktop = _scenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            var landingPage =  Desktop.OpenLandingPage();
            _scenarioContext.Set(landingPage);
        }

        [Given(@"the user is on the survey landing page")]
        public void GivenTheUserIsOnTheSurveyLandingPage()
        {
            _landingPage = _scenarioContext.Get<SurveyLandingPage>();
        }

        [When(@"the user clicks on the new survey button")]
        public void WhenTheUserClicksOnTheNewSurveyButton()
        { 
            _landingPage = _scenarioContext.Get<SurveyLandingPage>();
            var surveyBuildPage = _landingPage.NewSurvey;
            _scenarioContext.Set(surveyBuildPage);
        }

        [When(@"the user enters the surveytitle in new survey dialog '(.*)'")]
        public void WhenTheUserEntersTheSurveytitleInNewSurveyDialog(string surveyTitle)
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.NewSurveyTitle.SetValue(surveyTitle);
        }

        [When(@"the user clicks on the save button")]
        public void WhenTheUserClicksOnTheSaveButton()
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SaveSurvey();
            var surveyid = _surveyBuildPage.GetId();
            _scenarioContext.Set(surveyid, "surveyId");
        }

        [Then(@"the user clicks on the Cancel button")]
        public void ThenTheUserClicksOnTheCancelButton()
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.Cancel.Click();
        }

        [Then(@"the user closes the save changes dialog box")]
        public void TheUserClosesTheSaveChangesDialogBox()
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.ConfirmationModal.AltActionButton.Click();

        }

        [When(@"the user clicks on Home button")]
        public void WhenTheUserClicksOnHomeButton()
        {
            _landingPage = _scenarioContext.Get<SurveyLandingPage>();
            _landingPage.HomeTab.Click();
        }

        [Then(@"the user verifies the saved survey '(.*)'")]
        public void ThenTheUserVerifiesTheSavedSurvey(string title)
        {
            _landingPage = _scenarioContext.Get<SurveyLandingPage>();
            var surveyId = _scenarioContext.Get<int>("surveyId");
            _scenarioContext.Set(_landingPage);
            _landingPage.ArmSurveyBuilderMessage.AssertTextEquals("Survey Manager");
            _landingPage.VerifySurveyData(title, "title", surveyId.ToString());
        }

       [When(@"the user skips entering the title")]
        public void WhenTheUserSkipsEnteringTheTitle()
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.NewSurveyTitle.SetValue(Keys.Tab);
        }


        [Then(@"a message appears saying that the ""(.*)""")]
        public void ThenAMessageAppearsSayingThatThe(string validationMessage)
        {
            _surveyBuildPage = _scenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.VerifyNoSurveyTitleValidationMessage(validationMessage);
        }
    }
}
