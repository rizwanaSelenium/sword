﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public sealed class SurveyBuilderSteps : SpecFlowDirectAnyDesktopFixture
    {
        public SurveyBuilderSteps(ScenarioContext scenarioContext) : base( scenarioContext)
        {
            ScenarioContext = scenarioContext;  
        }

        private SurveyLandingPage _landingPage;

        [AfterScenario("SurveyManagerTeardown")]
        public void AfterScenario()
        {
            try
            {
                _landingPage = ScenarioContext.Get<SurveyLandingPage>();
                _landingPage.Close.Click();
                Desktop = new WebDriverDesktop(Driver, Waiter);
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user Logs into ARM")]
        public void GivenTheUserLogsIntoArm()
        {
            TestFixtureSetup("desktop");
            ScenarioContext.Set(Desktop);
            ScenarioContext.Set(Driver);
            ScenarioContext.Set(Waiter);
        }

        [Given(@"the survey menu item is enabled")]
        public void GivenTheSurveyMenuItemIsEnabled()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
        }

        [When(@"the user clicks on the survey menu")]
        public void WhenTheUserClicksOnTheSurveyMenu()
        {
            Desktop.SurveyMenu.Click();
        }

        [When(@"the user clicks on the survey manager tab")]
        public void WhenTheUserClicksOnTheSurveyManagerTab()
        {
            Desktop.SurveyMenu.ClickOption("Survey Manager");
        }

        [Then(@"the survey manager landing page is shown")]
        public void ThenTheSurveyManagerLandingPageIsShown()
        {
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter = ScenarioContext.Get<WebDriverWait>();
            _landingPage = new SurveyLandingPage(Driver, Waiter);
            ScenarioContext.Set(_landingPage);
            _landingPage.ArmSurveyBuilderMessage.AssertTextEquals("Survey Manager");
        }
    }
}
