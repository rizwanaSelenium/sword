﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class AddLinearScalingQuestionsSteps : SpecFlowDirectAnyDesktopFixture
    {
        public AddLinearScalingQuestionsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }
        private SurveyBuildPage _surveyBuildPage;

        [When(@"the user adds questions")]
        public void WhenTheUserAddsQuestions(Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var radioButtonQuestion = new AddARadioButtonQuestionSteps(ScenarioContext);

            foreach (var row in table.Rows)
            {
                var questionType = row["Type"].Trim();
                radioButtonQuestion.WhenTheUserAddsAQuestion(questionType);

                var questionText = row["Text"].Trim();
                var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
                _surveyBuildPage.SetQuestionText(newQuestionId, questionText);

                var required = row["AnswerRequired"].Trim();
                if (required == "Yes")
                {
                    radioButtonQuestion.WhenTheUserChecksTheRespondentMustAnswerCheckbox();
                }

                var maxScaleValue = row["MaxScaleValue"].Trim();
                var minScaleLabel = row["MinScaleLabel"].Trim();
                var maxScaleLabel = row["MaxScaleLabel"].Trim();
                _surveyBuildPage.SetScalingQuestion(newQuestionId, maxScaleValue, minScaleLabel, maxScaleLabel);
            }
        }

        [Then(@"the user verifies the data for the above added linear scaling questions for page '(.*)'")]
        public void ThenTheUserVerifiesTheDataForTheAboveAddedLinearScalingQuestionsFor(string pageNumber, Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SelectAddedNewsurveypage(pageNumber);

            var i = 0;
            foreach (var row in table.Rows)
            {
                var questionTextVerif = row["Text"].Trim();
                var maxScaleValueVerif = row["MaxScaleValue"].Trim();
                var minScaleLabelVerif = row["MinScaleLabel"].Trim();
                var maxScaleLabelVerif = row["MaxScaleLabel"].Trim();
                var questionIdVerif = "question-" + i;
                _surveyBuildPage.VerifyQuestionCommons(questionIdVerif, questionTextVerif);
                _surveyBuildPage.VerifyScalingQuestion(questionIdVerif, maxScaleValueVerif, minScaleLabelVerif, maxScaleLabelVerif);
                i++;
            }
        }
    }
}
