﻿using System.Linq;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class AddGridChoiceQuestionSteps : SpecFlowDirectAnyDesktopFixture
    {
        public AddGridChoiceQuestionSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyBuildPage _surveyBuildPage;

        [When(@"the user adds the row titles")]
        public void WhenTheUserAddsTheRowTitles(Table data)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            foreach (var row in data.Rows)
            {
                var radioLabel = row["Rowtitle"].Trim();
                _surveyBuildPage.AddNewRowTitle(newQuestionId, radioLabel);
            }
        }

        [When(@"the user adds the answer options")]
        public void WhenTheUserAddsTheAnswerOptions(Table data)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            foreach (var row in data.Rows)
            {
                var columnLabel = row["Answer options"].Trim();
                _surveyBuildPage.AddNewAnswerOption(newQuestionId, columnLabel);
            }
        }

        [Then(@"Then the user verifies the data for the above added grid question for page '(.*)'")]
            public void ThenThenTheUserVerifiesTheDataForTheAboveAddedGridQuestionFor(string pageNumber, Table table)
            {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SelectAddedNewsurveypage(pageNumber);
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            var newQuestionText = ScenarioContext.Get<string>("newQuestionText");
            _surveyBuildPage.VerifyQuestionCommons(newQuestionId, newQuestionText);

            int rowNumber = 1;
                foreach (var row in table.Rows)
                {
                    var rowTitle = row["Row title"].Trim();
                    var columnTitle = row["Answer options"].Trim();
                    var questionIdVerif = newQuestionId;
                   _surveyBuildPage.VerifyGridRowColumValues(questionIdVerif, rowTitle, columnTitle, rowNumber);
                    rowNumber++;
                }
        }

        [When(@"The user removes Row Title")]
        [When(@"The user removes Answer options")]
        public void WhenTheUserRemovesRowOrColumn(Table data)
        {
            var header = data.Header.First();
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            foreach (var row in data.Rows)
            {
                var radioLabel = row[header].Trim();
                _surveyBuildPage.DeleteRadioButtonOption(newQuestionId, radioLabel);
            }
        }

        [When(@"the user selects question '(.*)'")]
        public void WhenTheUserSelectsQuestion(int questionNumber)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var questionNumberInHtml = questionNumber - 1;
            var questionId = "question-" + questionNumberInHtml;
            ScenarioContext.Set(questionId, "newQuestionId");
            var questionText = _surveyBuildPage.GetQuestionText(questionId);
            ScenarioContext.Set(questionText, "newQuestionText");
            _surveyBuildPage.EditAQuestion(questionId);
        }
    }
}
