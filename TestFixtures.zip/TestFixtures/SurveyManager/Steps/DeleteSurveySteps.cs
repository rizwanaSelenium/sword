﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class DeleteSurveySteps : SpecFlowDirectAnyDesktopFixture
    {
        public DeleteSurveySteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyLandingPage _landingPage;

        [Given(@"the user verifies that the following surveys do not exit")]
        [Then(@"the user verifies that the following surveys do not exit")]
        public void GivenTheUserVerifiesThatTheFollowingSurveysDoNotExit(Table table)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            foreach (var row in table.Rows)
            {
                var surveyTitle = row["Survey title"].Trim();
                _landingPage.CheckOnlyOneSurveyWithTheTitleExists(surveyTitle, "title", false);
            }
        }
        
        [Given(@"the user add new surveys")]
        public void GivenTheUserAddNewSurveys(Table table)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            var newSurvey = new AddARadioButtonQuestionSteps(ScenarioContext);
            foreach (var row in table.Rows)
            {
                var surveyTitle = row["Survey title"].Trim();
                newSurvey.GivenTheUserAddsANewSurvey(surveyTitle);
                _landingPage.HomeTab.Click();
            }
        }
        
        [Given(@"the following surveys exists")]
        public void GivenTheFollowingSurveysExists(Table table)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            foreach (var row in table.Rows)
            {
                var surveyTitle = row["Survey title"].Trim();
                _landingPage.CheckOnlyOneSurveyWithTheTitleExists(surveyTitle, "title");
            }
        }
        
        [When(@"the user deletes surveys")]
        public void WhenTheUserDeletesSurveys(Table table)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            _landingPage.DeleteSurvey(table);
        }   
    }
}
