﻿using System;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class ConfigurationSendingSurveys : SpecFlowDirectAnyDesktopFixture
    {
        public int RecordId;

        public ConfigurationSendingSurveys(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyLandingPage _landingPage;
        private SurveyPublishPage _surveyPublishPage;


        [Given(@"the user clicks on publish tab")]
        public void GivenTheUserClicksOnPublishTab()
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
             var publishPage = _landingPage.SurveyPublishPage;
            ScenarioContext.Set(publishPage);
        }

        [Given(@"the user is on the survey publish page")]
        public void GivenTheUserIsOnTheSurveyPublishPage()
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
        }

        [When(@"the user enters dates '(.*)','(.*)','(.*)'")]
        public void WhenTheUserEntersDates(string fromDate, string toDate, string dueDate)
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            _surveyPublishPage.FromDate.PickDate(fromDate);
            _surveyPublishPage.ToDate.PickDate(toDate);
            _surveyPublishPage.DueDate.PickDate(dueDate);
        }

        [When(@"the user can select '(.*)','(.*)','(.*)'")]
        public void WhenTheUserCanSelect(string sendTo, string recepientType, string subject)
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            if (sendTo == "Resource")
            {
                _surveyPublishPage.SendTo.SetValue(sendTo);
                //Haven't implemented resource picker yet.Need to create new control for surveys resource picker.Needto ignore this test for resource untill its done
                _surveyPublishPage.Resource.SelectResource(recepientType);
                _surveyPublishPage.Subject.SetValue(subject);
            }
            else
            {
                _surveyPublishPage.SendTo.SetValue(sendTo);
                _surveyPublishPage.ResourceGroup.Selectvalue(recepientType);
                _surveyPublishPage.Subject.SetValue(subject);
            }
        }

        [When(@"the user can click on survey URL")]
        public void WhenTheUserCanClickOnSurveyUrl()
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            ScenarioContext.Set(_surveyPublishPage);
            _surveyPublishPage.SurveyUrl.Click();
        }

        [When(@"the user clicks on the save button on publish Page")]
        public void WhenTheUserClicksOnTheSaveButtonOnPublishPage()
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            _surveyPublishPage.SaveSurvey();
            var surveyid = _surveyPublishPage.GetId();
            ScenarioContext.Set(surveyid, "surveyId");
        }


        [When(@"the user opens the above saved survey on list surveys with '(.*)'")]
        public void WhenTheUserOpensTheAboveSavedSurveyOnListSurveysWith(string id)
        {
           _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            var surveyId = ScenarioContext.Get<int>("surveyId");
            ScenarioContext.Set(_landingPage);
            _landingPage.SelectSurveyOnGrid("id", Convert.ToString(surveyId));
            var surveyPublishPage = _landingPage.SurveyPublishPage;
            ScenarioContext.Set(surveyPublishPage);
        }

         [Then(@"the user verifies the saved survey configuration for '(.*)','(.*)','(.*)'")]
        public void ThenTheUserVerifiesTheSavedSurveyConfigurationFor(string sendTo, string recepientType, string subject)
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
           
            if (sendTo == "Resource")
            {
                _surveyPublishPage.SendTo.AssertEquals(sendTo);
                _surveyPublishPage.Resource.AssertEquals(recepientType);
                _surveyPublishPage.AssertSurveySubjectText(subject);
            }
            else
            {
                _surveyPublishPage.SendTo.AssertEquals(sendTo);
                _surveyPublishPage.AssertSurveyResourceGroups(recepientType);
                _surveyPublishPage.AssertSurveySubjectText(subject);
            }
        }

        [Then(@"the user verifies the saved dates '(.*)','(.*)','(.*)' and url '(.*)'")]
        public void ThenTheUserVerifiesTheSavedDatesAndUrl(string fromDate, string toDate, string dueDate, string surveyUrl)
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            _surveyPublishPage.FromDate.AssertValue(fromDate);
            _surveyPublishPage.ToDate.AssertValue(toDate);
            _surveyPublishPage.DueDate.AssertValue(dueDate);
            _surveyPublishPage.SurveyEmailBody.AssertTextEquals(surveyUrl);
        }

    }
}
