﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class AddARadioButtonQuestionSteps : SpecFlowDirectAnyDesktopFixture
    {
        public AddARadioButtonQuestionSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }
        private SurveyBuildPage _surveyBuildPage;
       
        [Given(@"the user adds a new survey with title '(.*)' and clicks on save")]
        public void GivenTheUserAddsANewSurvey(string surveyTitle)
        {
            var newSurvey = new NewSurvey(ScenarioContext);
            newSurvey.WhenTheUserClicksOnTheNewSurveyButton();
            newSurvey.WhenTheUserEntersTheSurveytitleInNewSurveyDialog(surveyTitle);
            newSurvey.WhenTheUserClicksOnTheSaveButton();
        }

        [Given(@"the user select the survey page '(.*)'")]
        [When(@"the user select the survey page '(.*)'")]
        [When (@"For data persistence check the user move to survey page '(.*)'")]
        public void GivenTheUserSelectThe(string page)
        {
            var newPage = new AddPage(ScenarioContext);
            newPage.WhenTheUserSelectTheNewSurveyPageIsAddedBelowTheExistingPage(page);
        }

        [When(@"the user adds a question '(.*)'")]
        public void WhenTheUserAddsAQuestion(string questionType)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
           _surveyBuildPage.AddQuestionButton.Click();
            var newQuestionId = _surveyBuildPage.GetNewQuestionId();
            ScenarioContext.Set(newQuestionId, "newQuestionId");
            _surveyBuildPage.SelectQuestionType(newQuestionId, questionType);
        }
        
        [When(@"the user enters a question '(.*)'")]
        public void WhenTheUserEntersAQuestion(string questionText)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            ScenarioContext.Set(questionText, "newQuestionText");
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            _surveyBuildPage.SetQuestionText(newQuestionId, questionText);
        }
        
        [When(@"the user checks the respondent must answer checkbox")]
        public void WhenTheUserChecksTheRespondentMustAnswerCheckbox()
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            _surveyBuildPage.CheckTheRequiredBox(newQuestionId);
            ScenarioContext.Set(true, "requiredStatus");
        }
        
        [When(@"the user adds new radio buttons")]
        public void WhenTheUserAddsRadioButtons(Table data)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            foreach (var row in data.Rows)
            {
                var radioLabel = row["RadioButton"].Trim();
                _surveyBuildPage.AddNewRadioButton(newQuestionId, radioLabel);
            }
        }

        [Then(@"the user verifies the data for the above added radio buttons question for page '(.*)'")]
        public void ThenTheUserVerifiesTheDataForTheAboveAddedRadioButtonsQuestionFor(string pageNumber, Table data)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SelectAddedNewsurveypage(pageNumber);
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            var newQuestionText = ScenarioContext.Get<string>("newQuestionText");
            _surveyBuildPage.VerifyQuestionCommons(newQuestionId, newQuestionText);

            var i = 0;
            foreach (var row in data.Rows)
            {
                var radioLabel = row["RadioButton"].Trim();
                _surveyBuildPage.VerifyNewRadioButtonLabels(newQuestionId,radioLabel, i);
                i++;
            }
        }

        [Then(@"the user can delete the Yes and No radio buttons")]
        public void TheUserCanDeleteTheYesAndNoRadioButtons(Table data)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            _surveyBuildPage.EditAQuestion(newQuestionId);
            foreach (var row in data.Rows)
            {
                var radioLabel = row["RadioButton"].Trim();
                _surveyBuildPage.DeleteRadioButtonOption(newQuestionId, radioLabel);
            }
        }

        [Then(@"no more radio buttons can be deleted")]
        public void NoMoreRadioButtonsCanBeDeleted()
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            _surveyBuildPage.CheckNoMoreOptionCanBedeleted(newQuestionId);
        }
    }
}
