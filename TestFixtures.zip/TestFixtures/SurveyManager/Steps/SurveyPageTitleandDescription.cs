﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
   public class SurveyPageTitleandDescription : SpecFlowDirectAnyDesktopFixture
    {
        public int Recordid;

        public SurveyPageTitleandDescription(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyPublishPage _surveyPublishPage;
        private SurveyBuildPage _surveyBuildPage;
        private SurveyLandingPage _surveyLandingPage;

        [When(@"the user clicks on the save button on new survey dialog")]
        public void WhenTheUserClicksOnTheSaveButtonOnNewSurveyDialog()
        {
            _surveyPublishPage = ScenarioContext.Get<SurveyPublishPage>();
            _surveyPublishPage.SaveSurvey();
            var surveyid = _surveyPublishPage.GetId();
            ScenarioContext.Set(surveyid, "surveyId");
        }

        [When(@"the user enters '(.*)' and '(.*)'")]
        public void WhenTheUserEntersAnd(string pageTitle, string pageDescription)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SurveyPageTitle.SetValue(pageTitle);
            _surveyBuildPage.SurveyPageDescription.SetValue(pageDescription);
        }

       [Then(@"Click on Save button on survey detail dialog")]
       [When(@"Click on Save button on survey detail dialog")]
        public void WhenClickOnSaveButtonOnSurveyDetailDialog()
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.SaveSurvey();
        }

        [When(@"the user navigates back to the survey grid")]
        public void WhenTheUserNavigatesBckToTheSurveyGrid()
        {
            _surveyLandingPage = ScenarioContext.Get<SurveyLandingPage>();
            _surveyLandingPage.HomeTab.Click();
        }

        [Then(@"the user checks the survey only appears once in the list of surveys '(.*)'")]
        public void ThenTheUserChecksTheSurveyOnlyAppearsOnceInTheListOfSurveys(string surveyTitle)
        {
            _surveyLandingPage = ScenarioContext.Get<SurveyLandingPage>();
            _surveyLandingPage.SelectSurveyOnGrid("title", surveyTitle);
        }

        [Then(@"the user verifies that the survey page title '(.*)' and page description '(.*)' saved correctly on page '(.*)'")]
        public void ThenTheUserVerifiesThatTheSurveyPageTitleAndPageDescriptionSavedCorrectly(string pageTitle, string pageDescription, string surveyPageNumber)
        {
            _surveyLandingPage = ScenarioContext.Get<SurveyLandingPage>();
            _surveyBuildPage = _surveyLandingPage.SurveyBuildPage;
            ScenarioContext.Set(_surveyBuildPage);
           _surveyBuildPage.VerifyPageTitleandDescription(pageTitle, pageDescription, surveyPageNumber);
        }
    }
}
