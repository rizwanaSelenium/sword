﻿using System;
using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
   public class ViewSurveys : SpecFlowDirectAnyDesktopFixture
    {
        public int RecordId;

        public ViewSurveys(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyLandingPage _landingPage;
        private SurveyBuildPage _surveyBuildPage;

        [Given(@"the user selects the existing survey of Id ‘(.*)’ from the list of surveys")]
        [When(@"the user selects the existing survey of Id ‘(.*)’ from the list of surveys")]
        public void WhenTheUserSelectsTheExistingSurveyOnListSurveys(int id)
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            _landingPage.SelectSurveyOnGrid("id", Convert.ToString(id));
        }

        [Given(@"the user clicks on the survey build tab")]
        [When(@"the user clicks on the survey build tab")]
        public void WhenTheUserClicksOnTheSurveyBuildTab()
        {
            _landingPage = ScenarioContext.Get<SurveyLandingPage>();
            ScenarioContext.Set(_landingPage);
            var buildPage = _landingPage.SurveyBuildPage;
            ScenarioContext.Set(buildPage);
        }


        [Then(@"the survey detail dialog is opened with '(.*)' url")]
        public void ThenTheSurveyDetailDialogIsOpenedWithUrl(string url)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.AssertUrlEndsWith(url);
        }

        [Then(@"the user verifies the survey title is '(.*)'")]
        public void ThenTheUserVerifiesTheSurveyTitleIs(string surveyTitle)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.AssertSurveyTitle(surveyTitle);
        }
    }
}
