﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class AddTextQuestionsSteps : SpecFlowDirectAnyDesktopFixture
    {     
        public AddTextQuestionsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        private SurveyBuildPage _surveyBuildPage;

        [When(@"the user adds Text questions")]
        public void WhenTheUserAddsTextQuestions(Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var radioButtonQuestion = new AddARadioButtonQuestionSteps(ScenarioContext);
            foreach (var row in table.Rows)
            {
                var questionType = row["Type"].Trim();
                radioButtonQuestion.WhenTheUserAddsAQuestion(questionType);

                var questionText = row["QuestionText"].Trim();
                var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
                _surveyBuildPage.SetQuestionText(newQuestionId, questionText);

                var required = row["AnswerRequired"].Trim();
                if (required == "Yes")
                {
                    radioButtonQuestion.WhenTheUserChecksTheRespondentMustAnswerCheckbox();
                }

                var lineType = row["LineType"].Trim();
                _surveyBuildPage.SetTextQuestion(newQuestionId, lineType);
            }
        }

        [Then(@"the user verifies the data for the above added Text questions for page '(.*)'")]
        public void ThenTheUserVerifiesTheDataForTheAboveAddedTextQuestionsFor(string page, Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.FocusNewWindow();
            var newPage = new AddPage(ScenarioContext);
            newPage.WhenTheUserSelectTheNewSurveyPageIsAddedBelowTheExistingPage(page);

            var i = 0;
            foreach (var row in table.Rows)
            {
                var questionTextVerif = row["QuestionText"].Trim();
                var lineTypeVerif = row["LineType"].Trim();
                var questionIdVerif = "question-" + i;
                _surveyBuildPage.VerifyQuestionCommons(questionIdVerif, questionTextVerif);
                _surveyBuildPage.VerifyTextQuestion(questionIdVerif, lineTypeVerif);
                i++;
            }
        }

        [When(@"the user changes the question to a Text question")]
        public void WhenTheUserChangesTheQuestionToATextQuestion(Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            _surveyBuildPage.EditAQuestion(newQuestionId);          
            var radioButtonQuestion = new AddARadioButtonQuestionSteps(ScenarioContext);
            foreach (var row in table.Rows)
            {
                var questionType = row["Type"].Trim();
                ScenarioContext.Set(_surveyBuildPage);
                _surveyBuildPage.SelectQuestionType(newQuestionId, questionType);
         
                var questionText = row["QuestionText"].Trim();
                _surveyBuildPage.SetQuestionText(newQuestionId, questionText);

                var required = row["AnswerRequired"].Trim();
                if (required == "Yes")
                {
                    radioButtonQuestion.WhenTheUserChecksTheRespondentMustAnswerCheckbox();
                }

                var lineType = row["LineType"].Trim();
                _surveyBuildPage.SetTextQuestion(newQuestionId, lineType);
            }
        }

        [Then(@"the user verifies the data for the modified question for page '(.*)'")]
        public void TheTheUserVerifiesTheDataForTheModifiedQuestionFor(string page, Table table)
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.FocusWindow();
            var newPage = new AddPage(ScenarioContext);
            newPage.WhenTheUserSelectTheNewSurveyPageIsAddedBelowTheExistingPage(page);
            var newQuestionId = ScenarioContext.Get<string>("newQuestionId");
            foreach (var row in table.Rows)
            {
                var questionTextVerif = row["QuestionText"].Trim();
                var lineTypeVerif = row["LineType"].Trim();
                _surveyBuildPage.VerifyQuestionCommons(newQuestionId, questionTextVerif);
                _surveyBuildPage.VerifyTextQuestion(newQuestionId, lineTypeVerif);
            }
        }
    }
}
