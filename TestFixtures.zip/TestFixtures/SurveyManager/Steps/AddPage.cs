﻿using PresentationModel.Model.SurveyBuilder;
using TechTalk.SpecFlow;

namespace TestFixtures.SurveyManager.Steps
{
    [Binding]
    public class AddPage : SpecFlowDirectAnyDesktopFixture
    {
        private SurveyBuildPage _surveyBuildPage;

        public AddPage(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;
        }

        [When(@"the user clicks on Add survey Page button")]
        public void WhenTheUserClicksOnAddSurveyPageButton()
        {
            _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
            _surveyBuildPage.AddNewSurveyPage();
        }

        [When(@"the user select the new survey page '(.*)' is added below the existing page")]
        public void WhenTheUserSelectTheNewSurveyPageIsAddedBelowTheExistingPage(string pageNumber)
        {
             _surveyBuildPage = ScenarioContext.Get<SurveyBuildPage>();
             _surveyBuildPage.SelectAddedNewsurveypage(pageNumber);
        }
    }
}
