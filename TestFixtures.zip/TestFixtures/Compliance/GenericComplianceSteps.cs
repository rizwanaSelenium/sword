﻿using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceRisk;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance
{
    [Binding]
    public class GenericComplianceSteps : LoginSetupFixture
    {
        private ObligationDialog _obligationPage;
        private ComplianceRiskComponent _riskPage;

        public GenericComplianceSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Given(@"the user logs into ACM Active Compliance Manager")]
        [When(@"the user logs into ACM Active Compliance Manager")]
        public void GivenTheUserLogsIntoAcmActiveComplianceManager()
        {
            TestFixtureSetup("Compliance", false);

            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.FocusNewWindow();
        }

        [Given(@"the user is logged into ACM Active Compliance Manager")]
        [Given(@"the user is on Compliance Manager")]
        public void GivenTheUserIsOnComplianceManager()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
        }

        [Given(@"the user clicks on the new Obligation button")]
        public void GivenTheUserClicksOnTheNewObligationButton()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.NewButton.Click();
            _obligationPage = CompliancePage.GetOpenedObligationPage();
            ScenarioContext.Set(_obligationPage);
        }

        [When(@"the user clicks on Add Risk icon")]
        public void WhenTheUserClicksOnAddRiskIcon()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.AddRiskIcon.Click();
            _riskPage = CompliancePage.GetOpenedRiskPage();
            ScenarioContext.Set(_riskPage);
        }

        [Given(@"the user clicks on the Compliance manager save button")]
        [When(@"the user clicks on the Compliance manager save button")]
        public void GivenTheUserClicksOnTheComplianceManagerSaveButton()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.FocusWindow();

            CompliancePage.SaveButton.Click();

            Driver = ScenarioContext.Get<IWebDriver>();
            CompliancePage = CompliancePage.GetOpenedComplianceManager();
            ScenarioContext.Set(CompliancePage);
        }

        [When(@"the user clicks Yes on the delete confirmation message")]
        public void WhenTheUserClicksYesOnTheDeleteConfirmationMessage()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.FocusNewWindow();
            CompliancePage.MessagePrompt.Yes();
            CompliancePage.WaitUntilUiSpinnerIsNotDisplayed();
            CompliancePage = CompliancePage.GetOpenedComplianceManager();
            ScenarioContext.Set(CompliancePage);
        }

        [Given(@"the user clicks on Cut icon")]
        [When(@"the user clicks on Cut icon")]
        public void WhenTheUserClicksOnCutIcon()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.CutIcon.Click();
            CompliancePage.WaitUntilUiSpinnerIsNotDisplayed();
        }

        [Given(@"the user clicks on Paste icon")]
        [When(@"the user clicks on Paste icon")]
        public void WhenTheUserClicksOnPasteIcon()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.PasteIcon.Click();
            CompliancePage.WaitUntilUiSpinnerIsNotDisplayed();

            Driver = ScenarioContext.Get<IWebDriver>();
            CompliancePage = CompliancePage.GetOpenedComplianceManager();
            ScenarioContext.Set(CompliancePage);
        }

        [Given(@"the user clicks on Paste as child icon")]
        [When(@"the user clicks on Paste as child icon")]
        public void WhenTheUserClicksOnPasteAsChildIcon()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.PasteIcon.Click();

            CompliancePage.PasteAsChildIcon.WaitForElementToAppear();
            CompliancePage.PasteAsChildIcon.Click();
            CompliancePage.WaitUntilUiSpinnerIsNotDisplayed();

            Driver = ScenarioContext.Get<IWebDriver>();
            CompliancePage = CompliancePage.GetOpenedComplianceManager();
            ScenarioContext.Set(CompliancePage);
        }

        [Then(@"the user verifies Paste icon is disabled with proper tooltip text")]
        public void ThenTheUserVerifiesPasteIconIsDisabledWithProperTooltipText(Table table)
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.PasteIcon.AssertTabIsDisabled();
            Assert.AreEqual(table.Rows[0], CompliancePage.PasteIcon.GetTooltipText(), "Tooltip doesn't match");
        }

        [Then(@"the user verifies Paste as child icon is disabled with proper tooltip text")]
        public void ThenTheUserVerifiesPasteAsChildIconIsDisabledWithProperTooltipText(Table table)
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.PasteAsChildIcon.AssertTabIsDisabled();
            Assert.AreEqual(table.Rows[0].Values.ToList()[0], CompliancePage.PasteAsChildIcon.GetTooltipText(), "Tooltip doesn't match");
        }

        [Then(@"the user verifies Cut icon is disabled")]
        public void ThenTheUserVerifiesCutIconIsDisabled()
        {
            CompliancePage = ScenarioContext.Get<ComplianceComponent>();
            CompliancePage.CutIcon.AssertTabIsDisabled();
        }
    }
}
