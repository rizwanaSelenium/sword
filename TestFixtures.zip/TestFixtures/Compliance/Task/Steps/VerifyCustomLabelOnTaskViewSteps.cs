﻿using System;
using System.Linq;
using OpenQA.Selenium;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceTask;
using PresentationModel.Model.Desktop;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Task.Steps
{
    [Binding]
   public class VerifyCustomLabelOnTaskViewSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverUserOptionsDialog _userOptionsDialog;
        private ComplianceComponent _compliancePage;
        private ComplianceTaskDialog _taskDialog;

        public VerifyCustomLabelOnTaskViewSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("RemoveCustomLabelSetTeardown")]
        public void AfterScenario()
        {
            try
            {
                var assignedInstanceId = ScenarioContext.Get<int>("assignedInstanceID").ToString();
                IWebDriver driver = ScenarioContext.Get<IWebDriver>();
                _compliancePage = ScenarioContext.Get<ComplianceComponent>();

                Desktop = _compliancePage.NavigateToArm(BaseArmUrl, assignedInstanceId, driver);
                Desktop.FocusWindow();
                ScenarioContext.Set(Desktop);

                var optionsDialog = Desktop.OptionsDialog();
                ScenarioContext.Set(optionsDialog);
                optionsDialog.FocusWindow();
                optionsDialog.LabelSet.SetValue("Standard Label Set");
                optionsDialog.Save();
                optionsDialog.Ok();

                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.RespondToUiPrompt("Yes");
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user opens User Options dialog")]
        public void GivenTheUserOpensUserOptionsDialog()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ClickOnToolsMenu();

            _userOptionsDialog = Desktop.OptionsDialog();
            ScenarioContext.Set(_userOptionsDialog);
        }

        [Given(@"the user selects '(.*)' label set for ArmTest user")]
        public void GivenTheUserSelectsLabelSetForArmTestUser(string labelSet)
        {
            _userOptionsDialog = ScenarioContext.Get<WebDriverUserOptionsDialog>();
            _userOptionsDialog.FocusWindow();
            _userOptionsDialog.LabelSet.SetValue(labelSet);
        }

        [Given(@"the user selects '(.*)' language for ArmTest user")]
        public void GivenTheUserSelectsLanguageForArmTestUser(string language)
        {
            _userOptionsDialog = ScenarioContext.Get<WebDriverUserOptionsDialog>();
            _userOptionsDialog.FocusWindow();
            _userOptionsDialog.Language.SetValue(language);
        }

        [Given(@"the user clicks on User Options dialog Save button")]
        public void GivenTheUserClicksOnUserOptionsDialogSaveButton()
        {
            _userOptionsDialog = ScenarioContext.Get<WebDriverUserOptionsDialog>();
            _userOptionsDialog.FocusWindow();
            _userOptionsDialog.Save();
        }

        [Given(@"the user clicks on User Options dialog OK button")]
        public void GivenTheUserClicksOnUserOptionsDialogOkButton()
        {
            _userOptionsDialog = ScenarioContext.Get<WebDriverUserOptionsDialog>();
            _userOptionsDialog.FocusWindow();
            _userOptionsDialog.Ok();
        }

        [Given(@"the user responds to UI prompt")]
        public void GivenTheUserRespondsToUiPrompt()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.RespondToUiPrompt("Yes");
        }

        [Then(@"the '(.*)' for the following Task '(.*)' in the view should be displayed correctly")]
        public void ThenTheForTheFollowingTaskInTheViewShouldBeDisplayedCorrectly(string label, string field, Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _taskDialog = _compliancePage.OpenComplianceTaskPage();
            ScenarioContext.Set(_taskDialog);

            foreach (var row in table.Rows)
            {
                var values = row.Values.ToList();
                _taskDialog.AssertLabelsEqualsToCustomConfig(values[0],values[1]);
            }
        }
    }
}
