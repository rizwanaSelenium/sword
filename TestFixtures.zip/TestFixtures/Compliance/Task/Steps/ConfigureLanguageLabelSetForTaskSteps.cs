﻿using System;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.NewAdmin.FieldsAndWorkflow;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Task.Steps
{
    [Binding]
    public class ConfigureLanguageLabelSetForTaskSteps : SpecFlowRiskDesktopFixture
    {
        private LabelSetConfiguration _labelSetDialog;
        private WebDriverNewAdminDialog _adminDialog;
        private WebDriverDesktop _armDesktop;

        public ConfigureLanguageLabelSetForTaskSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("ConfigureLanguageLabelSetForTaskTeardown")]
        public void AfterScenario()
        {
            try
            {
                _labelSetDialog = ScenarioContext.Get<LabelSetConfiguration>();
                _labelSetDialog.CancelButton.Click();

                _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                _adminDialog.Close();

                _armDesktop = ScenarioContext.Get<WebDriverDesktop>();

                _armDesktop.FocusWindow();
                _armDesktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }
    }
}
