﻿using NUnit.Framework;
using PresentationModel.Model.Compliance;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Task.Steps
{
    [Binding]
    public class VerifyAddTaskRoleRight : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;

        public VerifyAddTaskRoleRight(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Then(@"the new Task icon should be disabled for the user to add Task")]
        public void ThenTheNewTaskIconShouldBeDisabledForTheUserToAddTask()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();         
            Assert.IsTrue(_compliancePage.AddTaskIcon.GetAttribute("disabled").Equals("true"));
        }

        [Then(@"the new Task button should be disabled for the user to add Task")]
        public void ThenTheNewTaskButtonShouldBeDisabledForTheUserToAddTask()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            Assert.IsTrue(_compliancePage.NewButton.GetAttribute("disabled").Equals("true"));
        }
    }
}
