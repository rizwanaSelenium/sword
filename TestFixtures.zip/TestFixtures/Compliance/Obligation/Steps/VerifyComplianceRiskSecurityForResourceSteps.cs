﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyComplianceRiskSecurityForResourceSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private WebDriverResourceListDialog _resourcesListDialog;
        private WebDriverResourceEditDialog _resourceEditDialog;
        public VerifyComplianceRiskSecurityForResourceSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("RemoveComplianceRiskSecurityRoleRightTeardown")]
        public void AfterScenario()
        {
            try
            {
                if (ScenarioContext.TryGetValue(out _resourceEditDialog))
                {
                    _resourceEditDialog = ScenarioContext.Get<WebDriverResourceEditDialog>();
                    _resourcesListDialog = ScenarioContext.Get<WebDriverResourceListDialog>();
                    _resourceEditDialog.FocusWindow();
                    _resourceEditDialog.Close();
                    _resourcesListDialog.FocusWindow();
                    _resourcesListDialog.Close();
                    _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
                    ScenarioContext.Set(_adminDialog);

                    using (var userRolesConfig = _adminDialog.RoleConfiguration())
                    {
                        userRolesConfig.AllowFunctionAndThenSave("Compliance Risk Security");
                    }

                    _adminDialog.FocusWindow();
                    _adminDialog.Close();

                    Desktop = ScenarioContext.Get<WebDriverDesktop>();
                    Desktop.FocusWindow();
                    Desktop.Logout();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user opens Resources dialog")]
        public void GivenTheUserOpensResourcesDialog()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            _adminDialog = Desktop.AdminDialog();
            _resourcesListDialog = _adminDialog.UsersAndResources();
            ScenarioContext.Set(_adminDialog);
            ScenarioContext.Set(_resourcesListDialog);
        }

        [Given(@"the user is on the Resources dialog")]
        public void GivenTheUserIsOnTheResourcesDialog()
        {
            _resourcesListDialog = ScenarioContext.Get<WebDriverResourceListDialog>();
            _resourcesListDialog.FocusWindow();
        }

        [When(@"the user searches for '(.*)' user")]
        public void WhenTheUserSearchesForUser(string userName)
        {
            _resourcesListDialog = ScenarioContext.Get<WebDriverResourceListDialog>();
            _resourcesListDialog.OpenResource(userName);
        }

        [When(@"the user clicks on Edit button")]
        public void WhenTheUserClicksOnEditButton()
        {
            _resourcesListDialog = ScenarioContext.Get<WebDriverResourceListDialog>();
            _resourceEditDialog = _resourcesListDialog.OpenedResource();
            ScenarioContext.Set(_resourceEditDialog);
        }

        [Then(@"the Compliance button should be disabled for the user")]
        public void ThenTheComplianceButtonShouldBeDisabledForTheUser()
        {
            _resourceEditDialog = ScenarioContext.Get<WebDriverResourceEditDialog>();
            Assert.IsTrue(_resourceEditDialog.ComplianceButton.GetAttribute("disabled").Equals("true"));
        }
    }
}
