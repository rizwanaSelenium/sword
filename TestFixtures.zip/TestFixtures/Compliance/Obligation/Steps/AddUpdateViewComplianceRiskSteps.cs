﻿using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Admin.Resources;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceRisk;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class AddUpdateViewComplianceRiskSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private WebDriverResourceListDialog _resourcesListDialog;
        private WebDriverResourceEditDialog _resourceEditDialog;
        private WebDriverComplianceResourceAdminDialog _complianceResourceAdminDialog;
        private AngularScoringCommentsModal _scoringComments;
        private AngularStatusCommentsModal _riskStatusComments;

        private ComplianceRiskComponent _complianceRiskDialog;
        private ComplianceComponent _compliancePage;
        private FieldsAndLayout _fieldsAndLayoutPage;

        public AddUpdateViewComplianceRiskSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        public void UserOpensArmAdminScreen()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            _adminDialog = Desktop.AdminDialog();
            ScenarioContext.Set(_adminDialog);
        }

        [When(@"the user opens Resources dialog from ARM Admin")]
        public void WhenTheUserOpensResourcesDialogFromArmAdmin()
        {
            UserOpensArmAdminScreen();
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _resourcesListDialog = _adminDialog.UsersAndResources();
            ScenarioContext.Set(_resourcesListDialog);
        }

        [When(@"the user opens Risk Screen Layout page from ARM Admin")]
        public void WhenTheUserOpensRiskScreenLayoutPageFromArmAdmin()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _fieldsAndLayoutPage = _adminDialog.FieldsAndWorkflowTabPage.OpenRiskFieldsAndLayoutPage();
            ScenarioContext.Set(_fieldsAndLayoutPage);
        }

        [When(@"the user selects '(.*)' Interface")]
        public void WhenTheUserSelectsInterface(string interfaceName)
        {
            _fieldsAndLayoutPage = ScenarioContext.Get<FieldsAndLayout>();
            _fieldsAndLayoutPage.Interface.SetValue(interfaceName);
        }


        [When(@"the user opens Scoring Screen Layout page from ARM Admin")]
        public void WhenTheUserOpensScoringScreenLayoutPageFromArmAdmin()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _fieldsAndLayoutPage = _adminDialog.FieldsAndWorkflowTabPage.OpenScoringScreenLayoutPage();
            ScenarioContext.Set(_fieldsAndLayoutPage);
        }

        [When(@"the user clicks on OK button on Fields and Layout page")]
        public void WhenTheUserClicksOnOkButtonOnFieldsAndLayoutPage()
        {
            _fieldsAndLayoutPage = ScenarioContext.Get<FieldsAndLayout>();
            _fieldsAndLayoutPage.OK.Click();
        }

        [When(@"the user selects Default Value for following Screen Fields")]
        public void WhenTheUserSelectsDefaultValueForFollowingScreenFields(Table table)
        {
            _fieldsAndLayoutPage = ScenarioContext.Get<FieldsAndLayout>();
            foreach (var fieldValue in table.Rows)
            {
                _fieldsAndLayoutPage.SelectDefaultValueForField(fieldValue[0], fieldValue[1]);
            }
        }
        
        [When(@"the user clicks on Compliance button")]
        public void WhenTheUserClicksOnComplianceButton()
        {
            _resourceEditDialog = ScenarioContext.Get<WebDriverResourceEditDialog>();
            _complianceResourceAdminDialog = _resourceEditDialog.OpenResourceAdminDialog();
            ScenarioContext.Set(_resourceEditDialog);
            ScenarioContext.Set(_complianceResourceAdminDialog);
        }
        
        [When(@"the user expands the tree of Default Compliance Risk Folder for Resource field")]
        public void WhenTheUserExpandsTheTreeOfDefaultComplianceRiskFolderForResourceField()
        {
            _complianceResourceAdminDialog = ScenarioContext.Get<WebDriverComplianceResourceAdminDialog>();
            _complianceResourceAdminDialog.ComplianceRiskFolder.DisplayTree();
            ScenarioContext.Set(_complianceResourceAdminDialog);
        }
        
        [When(@"the user selects the risk folder with below Title")]
        public void WhenTheUserSelectsTheRiskFolderWithBelowTitle(Table table)
        {
            Waiter = ScenarioContext.Get<WebDriverWait>();
            _complianceResourceAdminDialog = ScenarioContext.Get<WebDriverComplianceResourceAdminDialog>();
            var rows = table.Rows.ToList();
            foreach (var row in rows)
            {
                if (!_complianceResourceAdminDialog.ComplianceRiskFolder.IsItemSelected(row.Values.ToList()[0]))
                {
                    _complianceResourceAdminDialog.ComplianceRiskFolder.SelectItem(row.Values.ToList()[0]);
                }
            }
            ScenarioContext.Set(_complianceResourceAdminDialog);
        }
        
        [When(@"the user clicks on OK button on Default Compliance Risk Folder for Resource dialog")]
        public void WhenTheUserClicksOnOkButtonOnDefaultComplianceRiskFolderForResourceDialog()
        {
            _complianceResourceAdminDialog = ScenarioContext.Get<WebDriverComplianceResourceAdminDialog>();
            _complianceResourceAdminDialog.OkButton.Click();
            ScenarioContext.Set(_complianceResourceAdminDialog);
        }
        
        [When(@"the user clicks on OK button on Edit Resource dialog")]
        public void WhenTheUserClicksOnOkButtonOnEditResourceDialog()
        {
            _resourceEditDialog = ScenarioContext.Get<WebDriverResourceEditDialog>();
            _resourceEditDialog.FocusWindow();
            _resourceEditDialog.OkButton.Click();
            ScenarioContext.Set(_resourceEditDialog);
        }
        
        [When(@"the user clicks on Close button on Resources dialog")]
        public void WhenTheUserClicksOnCloseButtonOnResourcesDialog()
        {
            _resourcesListDialog = ScenarioContext.Get<WebDriverResourceListDialog>();
            _resourcesListDialog.FocusWindow();
            _resourcesListDialog.CloseButton.Click();
            ScenarioContext.Set(_resourcesListDialog);
        }

        [When(@"the user clicks on Compliance manager add Risk icon")]
        public void WhenTheUserClicksOnComplianceManagerAddRiskIcon()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.AddRiskIcon.Click();

            _complianceRiskDialog = _compliancePage.RiskComponent;
            Waiter.Until(d => _complianceRiskDialog.Risk.Name.IsVisible());

            ScenarioContext.Set(_complianceRiskDialog);
            ScenarioContext.Set(_compliancePage);
        }

        [When(@"the user enters Risk details for following Compliance Risk fields")]
        public void WhenTheUserEntersRiskDetailsForFollowingComplianceRiskFields(Table table)
        {
           _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Approval":
                        _complianceRiskDialog.Risk.ApprovalDate.PickDate(fieldValue[1]);
                        break;
                    case "Assessment":
                        _complianceRiskDialog.Risk.AssessmentDate.PickDate(fieldValue[1]);
                        break;
                    case "Category":
                        _complianceRiskDialog.Risk.RiskCategories.SelectValue(fieldValue[1]);
                        break;
                    case "Cause":
                        _complianceRiskDialog.Risk.Cause.SetValue((fieldValue[1]));
                        break;
                    case "Comments":
                        _complianceRiskDialog.Risk.Comments.SetValue(fieldValue[1]);
                        break;
                    case "Description":
                        _complianceRiskDialog.Risk.Description.SetValue(fieldValue[1]);
                        break;
                    case "Effect":
                        _complianceRiskDialog.Risk.Effect.SetValue(fieldValue[1]);
                        break;
                    case "ID":
                        _complianceRiskDialog.Risk.RiskId.SetValue(fieldValue[1]);
                        break;
                    case "Initiation":
                        _complianceRiskDialog.Risk.InitiationDate.PickDate(fieldValue[1]);
                        break;
                    case "Owner":
                        _complianceRiskDialog.Risk.Owner.SelectResource(fieldValue[1]);
                        break;
                    case "Phase":
                        _complianceRiskDialog.Risk.RiskPhase.SelectByText(fieldValue[1]);
                        break;
                    case "Source":
                        _complianceRiskDialog.Risk.RiskSource.SelectByText(fieldValue[1]);
                        break;
                    case "Status":
                        _complianceRiskDialog.Risk.RiskStatus.SelectByText(fieldValue[1]);
                        break;
                    case "Title":
                        _complianceRiskDialog.Risk.Name.SetValue(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
            ScenarioContext.Set(_complianceRiskDialog);
        }
    
        [When(@"the user enters Scoring Details for following Compliance Risk Fields")]
        public void WhenTheUserEntersScoringDetailsForFollowingComplianceRiskFields(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();

            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Scoring Description":
                        _complianceRiskDialog.Impact.Description.SetValue(fieldValue[1]);
                        break;
                    case "Black Flag":
                        _complianceRiskDialog.Impact.BlackFlagType.SelectByText(fieldValue[1]);
                        break;
                    case "Probability/Frequency":
                        _complianceRiskDialog.Impact.ProbabilityFrequency.SelectByText(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
            ScenarioContext.Set(_complianceRiskDialog);
        }

        [When(@"the user selects the Risk with below Title")]
        public void WhenTheUserSelectsTheRiskWithBelowTitle(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.ClearParameters();

            var tree = _compliancePage.Tree;
            var node = tree.Node(table.Rows[0].Values.ToList()[0]);
            node.Click();
            _compliancePage.WaitUntilUiSpinnerIsNotDisplayed();
            _complianceRiskDialog = _compliancePage.GetOpenedRiskPage();
            ScenarioContext.Set(_complianceRiskDialog);
        }

        [Then(@"user verifies the Details for the Compliance Risk Fields scoring have been updated")]
        public void ThenUserVerifiesTheDetailsForTheComplianceRiskFieldsScoringHaveBeenUpdated(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Scoring Description":
                        _complianceRiskDialog.Impact.Description.AssertEquals(fieldValue[1]);
                        break;
                    case "Black Flag":
                        _complianceRiskDialog.Impact.BlackFlagType.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Probability/Frequency":
                        _complianceRiskDialog.Impact.ProbabilityFrequency.AssertTextEquals(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
        }

        [Then(@"the Details for the Compliance Risk Fields should be displayed correctly")]
        public void ThenTheDetailsForTheComplianceRiskFieldsShouldBeDisplayedCorrectly(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var fieldValue in table.Rows)
            {
                switch (fieldValue[0])
                {
                    case "Approval":
                        _complianceRiskDialog.Risk.ApprovalDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Assessment":
                        _complianceRiskDialog.Risk.AssessmentDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Category":
                        _complianceRiskDialog.Risk.RiskCategories.AssertIsSelected(fieldValue[1]);
                        break;
                    case "Cause":
                        _complianceRiskDialog.Risk.Cause.AssertEquals((fieldValue[1]));
                        break;
                    case "Comments":
                        _complianceRiskDialog.Risk.Comments.AssertEquals(fieldValue[1]);
                        break;
                    case "Description":
                        _complianceRiskDialog.Risk.Description.AssertEquals(fieldValue[1]);
                        break;
                    case "Effect":
                        _complianceRiskDialog.Risk.Effect.AssertEquals(fieldValue[1]);
                        break;
                    case "ID":
                        _complianceRiskDialog.Risk.RiskId.AssertEquals(fieldValue[1]);
                        break;
                    case "Initiation":
                        _complianceRiskDialog.Risk.InitiationDate.AssertDateEquals(fieldValue[1]);
                        break;
                    case "Owner":
                        _complianceRiskDialog.Risk.Owner.AssertEquals(fieldValue[1]);
                        break;
                    case "Phase":
                        _complianceRiskDialog.Risk.RiskPhase.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Source":
                        _complianceRiskDialog.Risk.RiskSource.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Status":
                        _complianceRiskDialog.Risk.RiskStatus.AssertTextEquals(fieldValue[1]);
                        break;
                    case "Title":
                        _complianceRiskDialog.Risk.Name.AssertValueEquals(fieldValue[1]);
                        break;
                    case "Raised By":
                        _complianceRiskDialog.Risk.RaisedBy.AssertEquals(fieldValue[1]);
                        break;
                    default:
                        Assert.Fail($"{fieldValue[1]} field not recognized. Does it need to be added?");
                        break;
                }
            }
        }

        [Given(@"the user selects the Disributiontype  as '(.*)' for current assessment Compliance Risk Fields")]
        [When(@"the user selects the Disributiontype  as '(.*)' for current assessment Compliance Risk Fields")]
        public void WhenTheUserSelectsTheDisributionTypeAsForCurrentAssessmentComplianceRiskFields(string distributionType)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.Impact.CurrentAssessment.Distribution.SelectByText(distributionType);
        }


        [Given(@"the user enter   Probability  for current assessment Compliance Risk Fields")]
        [When(@"the user enter   Probability  for current assessment Compliance Risk Fields")]
        public void WhenTheUserEnterProbabilityForCurrentAssessmentComplianceRiskFields(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            Driver = ScenarioContext.Get<IWebDriver>();
            _complianceRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Given(@"the user enter Probability for target assessment Compliance Risk Fields")]
        [When(@"the user enter Probability for target assessment Compliance Risk Fields")]
        public void WhenTheUserEnterProbabilityForTargetAssessmentComplianceRiskFields(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            Driver = ScenarioContext.Get<IWebDriver>();
            _complianceRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.SetProbabilityValue(table.Rows[0].Values.ToList()[1], Driver);
        }

        [Given(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for current assessment Compliance Risk Fields")]
        [When(@"the user enter the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for current assessment Compliance Risk Fields")]
        public void WhenTheUserEnterTheValuesForEachForValuesForCurrentAssessmentComplianceRiskFields(string impactCategory, string min,
            string expected, string max, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnMin, "min");

                }

                if (columnExp != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnMax, "max");
                }
            }
        }

        [Given(@"the user selects the Exposure dropdown as '(.*)' for target assessment Compliance Risk Fields")]
        [When(@"the user selects the Exposure dropdown as '(.*)' for target assessment Compliance Risk Fields")]
        public void WhenTheUserSelectsTheExposureDropdownAsForTargetAssessmentComplianceRiskFields(string exposureType)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.Impact.TargetAssessment.Exposure.SelectByText(exposureType);

        }

        [Given(@"the user clicks Yes on Confirmation Popup Compliance Risk Fields")]
        [When(@"the user clicks Yes on Confirmation Popup Compliance Risk Fields")]
        public void WhenTheUserClicksYesOnConfirmationPopupComplianceRiskFields()
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.ConfirmationModal.YesButton.Click();
            ScenarioContext.Set(_complianceRiskDialog);

        }

        [Given(@"the user selects the Disribution type as '(.*)' for target  assessment Compliance Risk Fields")]
        [When(@"the user selects the Disribution type as '(.*)' for target  assessment Compliance Risk Fields")]
        public void WhenTheUserSelectsTheDisributionTypeAsForTargetAssessmentComplianceRiskFields(string distributionType)
        {
            _complianceRiskDialog.Impact.TargetAssessment.Distribution.SelectByText(distributionType);
        }

        [Given(@"the user enters the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for target Assessment Compliance Risk Fields")]
        [When(@"the user enters the values  for each '(.*)' for '(.*)','(.*)','(.*)' values for target Assessment Compliance Risk Fields")]
        public void WhenTheUserEntersTheValuesForEachForValuesForTargetAssessmentComplianceRiskFields(string impactCategory, string min, string exp, string max, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnMin, "min");

                }

                if (columnExp != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.SetImpactValue(columnCategory,
                        columnMax, "max");
                }
            }
        }

        [Given(@"the user enters the score change comment '(.*)' Compliance Risk Fields")]
        [When(@"the user enters the score change comment '(.*)' Compliance Risk Fields")]
        public void WhenTheUserEntersTheScoreChangeCommentComplianceRiskFields(string comment)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _scoringComments = _complianceRiskDialog.AngularScoringCommentsModal;
            _scoringComments.ScoringComments.SetValue(comment);
            _scoringComments.CommentsOkButton.Click();
            _complianceRiskDialog.WaitUntilUiSpinnerIsNotDisplayed();
        }

        [Then(@"the  Probability  value  Updated for Current Assessment Compliance Risk Fields")]
        public void ThenTheProbabilityValueUpdatedForCurrentAssessmentComplianceRiskFields(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.VerifyProbabilityValue(table.Rows[0].Values.ToList()[1]);

        }

        [Then(@"the  Probability  value  Updated for Target Assessment Compliance Risk Fields")]
        public void ThenTheProbabilityValueUpdatedForTargetAssessmentComplianceRiskFields(Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.Impact.TargetAssessment.ProbabilityOccurrence.VerifyProbabilityValue(table.Rows[0].Values.ToList()[1]);

        }

        [Then(@"the Probability band updated for current assessment Compliance Risk Fields for '(.*)' Scoring Type")]
        public void ThenTheProbabilityBandUpdatedForCurrentAssessmentComplianceRiskFields(string scoringType, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _complianceRiskDialog.Impact.CurrentAssessment.ProbabilityOccurrence.VerifyProbabilityBandName(table.Rows[0].Values.ToList()[1], scoringType);
        }

        [Then(@"the Impact Category values updated  for each '(.*)' for '(.*)','(.*)','(.*)' values for current Assessment Compliance Risk Fields")]
        public void ThenTheImpactCategoryValuesUpdatedForEachForValuesForCurrentAssessmentComplianceRiskFields(string impactCategory,
            string min, string exp, string max, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnMin, "min");

                }

                if (columnExp != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnMax, "max");
                }
            }
        }

        [Then(@"the '(.*)' should be updated for current Assessment Compliance Risk Fields for '(.*)' Scoring Type")]
        public void ThenTheShouldBeUpdatedForCurrentAssessmentComplianceRiskFields(string impactBand, string scoringType, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf("Category")];
                var columnBand = values[keys.IndexOf(impactBand)];
                _complianceRiskDialog.Impact.CurrentAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(columnCategory,
                    columnBand, scoringType);

            }
        }

        [Then(
            @"the Impact Category values updated  for each '(.*)' for '(.*)','(.*)','(.*)' values for target  Assessment Compliance Risk Fields")]
        public void ThenTheImpactCategoryValuesUpdatedForEachForValuesForTargetAssessmentComplianceRiskFields(string impactCategory,
            string min, string exp, string max, Table table)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf(impactCategory)];
                var columnMin = values[keys.IndexOf("Min")];
                var columnExp = values[keys.IndexOf("Expected")];
                var columnMax = values[keys.IndexOf("Max")];
                if (columnMin != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnMin, "min");

                }

                if (columnExp != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnExp, "exp");
                }

                if (columnMax != "")
                {
                    _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyImpactValue(columnCategory,
                        columnMax, "max");
                }
            }
        }


        [Then(@"the '(.*)' should be updated for target Assessment Compliance Risk Fields for '(.*)' Scoring Type")]
        public void ThenTheShouldBeUpdatedForTargetAssessmentComplianceRiskFields(string impactBand, string scoringType, Table table)
        {
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                var columnCategory = values[keys.IndexOf("Category")];
                var columnBand = values[keys.IndexOf(impactBand)];
                _complianceRiskDialog.Impact.TargetAssessment.ImpactCategoryValues.VerifyQuantitativeImpact(columnCategory, columnBand, scoringType);
            }
        }

        [Given(@"the user enters comments '(.*)' in Risk Status comments dialog Compliance Risk")]
        [When(@"the user enters comments '(.*)' in Risk Status comments dialog Compliance Risk")]
        public void WhenTheUserEntersCommentsInRiskStatusCommentsDialogComplianceRisk(string statuscomments)
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _riskStatusComments = _complianceRiskDialog.StatusCommentsModal;
            _riskStatusComments.StatusComments.SetValue(statuscomments);

        }

        [When(@"the user clicks Ok button in Risk Status Comments Dialog Compliance Risk")]
        public void WhenTheUserClicksOkButtonInRiskStatusCommentsDialogComplianceRisk()
        {
            _complianceRiskDialog = ScenarioContext.Get<ComplianceRiskComponent>();
            _riskStatusComments = _complianceRiskDialog.StatusCommentsModal;
            _riskStatusComments.CommentsOkButton.Click();
        }
    }
}
