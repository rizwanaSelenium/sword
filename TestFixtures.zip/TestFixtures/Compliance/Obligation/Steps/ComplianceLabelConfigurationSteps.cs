﻿using System.Linq;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.NewAdmin.FieldsAndWorkflow;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class ComplianceLabelConfigurationSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private LabelSetConfiguration _labelSet;

        public ComplianceLabelConfigurationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Given(@"the user opens Label Set Configuration dialog")]
        [When(@"the user opens Label Set Configuration dialog")]
        public void GivenTheUserOpensLabelSetConfigurationDialog()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ClickOnToolsMenu();
            _adminDialog = Desktop.AdminDialog();
            ScenarioContext.Set(_adminDialog);
            _labelSet = _adminDialog.FieldsAndWorkflowTabPage.OpenLabelSetDialog();
            _labelSet.WaitUntilUiSpinnerIsNotDisplayed();
            ScenarioContext.Set(_labelSet);
        }

        [Given(@"the user is on the Label Set Configuration dialog")]
        public void GivenTheUserIsOnTheLabelSetConfigurationDialog()
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            ScenarioContext.Set(_labelSet);
        }

        [When(@"the user clicks on the new button on label configuration page")]
        public void WhenTheUserClicksOnTheNewButtonOnLabelConfigurationPage()
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.WaitUntilUiSpinnerIsNotDisplayed();
            _labelSet.NewLabelSetButton.Click();
            ScenarioContext.Set(_labelSet);
        }

        [When(@"the user enters the label configuration name")]
        public void WhenTheUserEntersTheLabelConfigurationName(Table table)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();

            foreach (var row in table.Rows)
            {
                var values = row.Values.ToList();
                if (values.Count > 0)
                {
                    _labelSet.SetLabelSetName(values[0]);
                }
            }
        }

        [When(@"the user selects the label set area as '(.*)'")]
        public void WhenTheUserSelectsTheLabelSetAreaAs(string labelSetArea)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.SelectAreaValue(labelSetArea);
        }

        [When(@"the user enters the custom labels for the following fields")]
        public void WhenTheUserEntersTheCustomLabelsForTheFollowingFields(Table table)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();

            foreach (var row in table.Rows)
            {
                var values = row.Values.ToList();
                if (values.Count > 0)
                {
                    _labelSet.SetTranslationValue(values[1], values[0], table);
                }
            }
        }

        [When(@"the user navigates to label configuration page '(.*)'")]
        [Then(@"the user navigates to label configuration page '(.*)'")]
        public void WhenTheUserNavigatesToLabelConfigurationPage(int pageNumber)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.NavigateToPage(pageNumber);
        }

        [When(@"the user clicks on the OK button on the label configuration page")]
        public void WhenTheUserClicksOnTheOkButtonOnTheLabelConfigurationPage()
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.OkButton.Click();
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _adminDialog.FocusNewWindow();
        }

        [When(@"the user opens the Label Set Configuration dialog")]
        public void WhenTheUserOpensTheLabelSetConfigurationDialog()
        {
            _adminDialog = ScenarioContext.Get<WebDriverNewAdminDialog>();
            _adminDialog.FocusWindow();
            _labelSet = _adminDialog.FieldsAndWorkflowTabPage.OpenLabelSetDialog();
            ScenarioContext.Set(_labelSet);
        }

        [When(@"the user selects the '(.*)' label set")]
        public void WhenTheUserSelectsTheLabelSet(string p0)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.SelectLabelSetValue(p0);
        }

        [Then(@"the '(.*)' for the following Obligation '(.*)' should be as displayed correctly")]
        [Then(@"the '(.*)' for the following Task '(.*)' should be as displayed correctly")]
        public void ThenTheForTheFollowingObligationShouldBeAsDisplayedCorrectly(string p0, string p1, Table table)
        {
            int i = 0;
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                _labelSet.CheckTranslationValue(i++, values[keys.IndexOf(p1)], values[keys.IndexOf(p0)], p0 == "Custom Labels");
            }
        }

        [When(@"the user selects the language as '(.*)'")]
        public void WhenTheUserSelectsTheLanguageAs(string p0)
        {
            _labelSet = ScenarioContext.Get<LabelSetConfiguration>();
            _labelSet.SelectLanguageValue(p0);
        }

        [Then(@"the '(.*)' for the following Obligation '(.*)' should be displayed correctly")]
        [Then(@"the '(.*)' for the following Task '(.*)' should be displayed correctly")]
        public void ThenTheForTheFollowingObligationShouldBeDisplayedCorrectly(string p0, string p1, Table table)
        {
            int i = 0;
            foreach (var row in table.Rows)
            {
                var keys = row.Keys.ToList();
                var values = row.Values.ToList();
                _labelSet.CheckTranslationValue(i++, values[keys.IndexOf(p1)], values[keys.IndexOf(p0)], false);
            }
        }
    }
}
