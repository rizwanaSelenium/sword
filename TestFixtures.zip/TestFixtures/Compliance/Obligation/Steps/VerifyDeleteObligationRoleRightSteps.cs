﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using PresentationModel.Model.Admin;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyDeleteObligationRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private WebDriverRolesConfigDialog _roleConfigDialog;
        private string _obligationPermission;
        private ComplianceComponent _compliancePage;

        public VerifyDeleteObligationRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("RemoveObligationRoleRightTeardown")]
        public void AfterScenario()
        {
            try
            {
                var assignedInstanceId = ScenarioContext.Get<int>("assignedInstanceID").ToString();
                IWebDriver driver = ScenarioContext.Get<IWebDriver>();

                _adminDialog = _compliancePage.NavigateToArmAdmin(BaseArmUrl, assignedInstanceId, driver);
                _adminDialog.FocusWindow();
                ScenarioContext.Set(_adminDialog);

                using (var userRolesConfig = _adminDialog.RoleConfiguration())
                {
                    userRolesConfig.AllowFunctionAndThenSave(_obligationPermission);
                }

                _adminDialog.FocusWindow();
                _adminDialog.Close();

                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user opens Role Configuration dialog")]
        public void GivenTheUserOpensRoleConfigurationDialog()
        {
            Desktop = ScenarioContext.Get<WebDriverDesktop>();
            Desktop.FocusWindow();
            Desktop.ClickOnToolsMenu();
            _adminDialog = Desktop.AdminDialog();
            ScenarioContext.Set(_adminDialog);

           _roleConfigDialog = _adminDialog.RoleConfiguration();
            ScenarioContext.Set(_roleConfigDialog);
        }

        [Given(@"the user select '(.*)' role")]
        public void GivenTheUserSelectRole(string role)
        {
            _roleConfigDialog.SelectRole(role);
        }

        [Given(@"the user moves '(.*)' role right from Allowed to Not Allowed")]
        public void GivenTheUserMovesRoleRightFromAllowedToNotAllowed(string permission)
        {
            _obligationPermission = permission;
            _roleConfigDialog.DisAllowFunction(_obligationPermission);
        }

        [Given(@"the user clicks on OK button")]
        public void GivenTheUserClicksOnOkButton()
        {
            _roleConfigDialog.Save();
            _roleConfigDialog.OkButton.Click();

            _adminDialog.FocusWindow();
            _adminDialog.Close();
            Desktop.FocusNewWindow();
        }

        [Then(@"the delete obligation button should be disabled for the user to delete Obligation")]
        public void ThenTheDeleteObligationButtonShouldBeDisabledForTheUserToDeleteObligation()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.FocusWindow();
            Assert.IsTrue(_compliancePage.DeleteButton.GetAttribute("disabled").Equals("true"));
        }
    }
}
