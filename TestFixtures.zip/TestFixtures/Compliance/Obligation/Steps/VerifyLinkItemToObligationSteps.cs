﻿using System.Linq;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyLinkItemToObligationSteps : SpecFlowRiskDesktopFixture
    {
        private ObligationDialog _obligationPage;

        public VerifyLinkItemToObligationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Given(@"the user clicks on the Applicable Areas plus icon")]
        [When(@"the user clicks on the Applicable Areas plus icon")]
        public void GivenTheUserClicksOnTheApplicableAreasPlusIcon()
        {
            _obligationPage = ScenarioContext.Get<ObligationDialog>();
            _obligationPage.ApplicableAreas.DisplayTree();
            ScenarioContext.Set(_obligationPage);
        }

        [Given(@"the user selects the below Activity tree '(.*)'")]
        public void GivenTheUserSelectsTheBelowActivityTree(string items, Table table)
        {
            _obligationPage = ScenarioContext.Get<ObligationDialog>();
            var rows = table.Rows.ToList();
            foreach (var row in rows)
            {
                _obligationPage.ApplicableAreas.SelectItem(row.Values.ToList()[0]);
            }
            ScenarioContext.Set(_obligationPage);
        }

        [Then(@"the Applicable Areas field should correctly display the '(.*)' of linked Items as below")]
        public void ThenTheApplicableAreasFieldShouldCorrectlyDisplayTheOfLinkedItemsAsBelow(string paths, Table table)
        {
            _obligationPage = ScenarioContext.Get<ObligationDialog>();
            var rows = table.Rows.ToList();
            foreach (var row in rows)
            {
                _obligationPage.ApplicableAreas.DisplayedItem(row.Values.ToList()[0]);
            }
            ScenarioContext.Set(_obligationPage);
        }

        [Then(@"the below '(.*)' should be disabled for selection in the tree")]
        public void ThenTheBelowShouldBeDisabledForSelectionInTheTree(string items, Table table)
        {
            _obligationPage = ScenarioContext.Get<ObligationDialog>();
            var rows = table.Rows.ToList();
            foreach (var row in rows)
            {
                _obligationPage.ApplicableAreas.DisabledItem(row.Values.ToList()[0]);
            }
            ScenarioContext.Set(_obligationPage);
        }

        [Then(@"the below '(.*)' should not be displayed in the tree")]
        public void ThenTheBelowShouldNotBeDisplayedInTheTree(string items, Table table)
        {
            _obligationPage = ScenarioContext.Get<ObligationDialog>();
            var rows = table.Rows.ToList();
            foreach (var row in rows)
            {
                _obligationPage.ApplicableAreas.NotVisibleItem(row.Values.ToList()[0]);
            }
            ScenarioContext.Set(_obligationPage);
        }
    }
}
