﻿using PresentationModel.Model.Compliance;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;
using TestFixtures.GenericSpecflowSteps;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class AddUpdateViewObligationSteps : SpecFlowRiskDesktopFixture
    {
        private ObligationDialog _obligationPage;
        private ComplianceComponent _compliancePage;
        private TableDataSteps _readTable;

        public AddUpdateViewObligationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
        }

        [Then(@"the Obligation details for the following fields should be displayed correctly")]
        public void ThenTheForTheFollowingShouldBeDisplayedCorrectly(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _obligationPage = ScenarioContext.Get<ObligationDialog>();

            _compliancePage.FocusWindow();
            _readTable = new TableDataSteps(ScenarioContext);
            _readTable.AssertObligationData(table);

            ScenarioContext.Set(_obligationPage);
        }

        [Given(@"the user enters Obligation details for following fields")]
        public void GivenTheUserEntersObligationForFollowing(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _obligationPage = ScenarioContext.Get<ObligationDialog>();

            _compliancePage.FocusWindow();
            _readTable = new TableDataSteps(ScenarioContext);
            _readTable.WriteTableDataToObligation(table);

            ScenarioContext.Set(_obligationPage);
        }
    }
}
