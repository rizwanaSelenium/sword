﻿using NUnit.Framework;
using PresentationModel.Model.Compliance;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyAddObligationRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;
       
        public VerifyAddObligationRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }
     
        [Then(@"the new Obligation button should be disabled for the user to add Obligation")]
        public void ThenTheNewObligationButtonShouldBeDisabledForTheUserToAddObligation()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            
            Assert.IsTrue(_compliancePage.NewButton.GetAttribute("disabled").Equals("true"));
        }
    }
}
