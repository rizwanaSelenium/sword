﻿using System.Linq;
using PresentationModel.Model.Compliance;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyChildObligationsSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;

        public VerifyChildObligationsSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Then(@"the user verifies that Obligation is created in '(.*)' and the '(.*)' is highlighted")]
        public void ThenTheUserVerifiesThatObligationIsCreatedInAndTheIsHighlighted(string location, string title, Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.FocusWindow();

            var tree = _compliancePage.Tree;
            var node = tree.Node(table.Rows[0].Values.ToList()[0]);
            node.Click();
            ScenarioContext.Set(_compliancePage);
        }
    }
}
