﻿using System;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceTask;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyDeleteObligationSteps : SpecFlowRiskDesktopFixture
    {
        private ObligationDialog _obligationPage;
        private ComplianceComponent _compliancePage;
        private RiskDetailComponent _complianceRiskDialog;
        private ComplianceTaskDialog _complianceTask;

        public VerifyDeleteObligationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [AfterScenario("ComplianceManagerTeardown")]
        public void AfterScenario()
        {
            try
            {
                if (ScenarioContext.TryGetValue(out _compliancePage))
                {
                    _compliancePage = ScenarioContext.Get<ComplianceComponent>();
                    var assignedInstanceId = ScenarioContext.Get<int>("assignedInstanceID").ToString();
                    IWebDriver driver = ScenarioContext.Get<IWebDriver>();

                    var armDesktop = _compliancePage.NavigateToArm(BaseArmUrl, assignedInstanceId, driver);
                    armDesktop.FocusWindow();

                    ScenarioContext.Set(armDesktop);
                    armDesktop.Logout();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [Given(@"the user clicks on Delete button for the Obligation")]
        public void GivenTheUserClicksOnDeleteButtonForTheObligation()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _obligationPage = ScenarioContext.Get<ObligationDialog>();

            _compliancePage.FocusNewWindow();

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();

            Waiter.Until(d => _obligationPage.Title.IsVisible());
            _compliancePage.DeleteButton.Click();
        }

        [Given(@"the user clicks on Delete button for the Compliance Task")]
        public void GivenTheUserClicksOnDeleteButtonForTheComplianceTask()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _complianceTask = ScenarioContext.Get<ComplianceTaskDialog>();

            _compliancePage.FocusNewWindow();

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();

            Waiter.Until(d => _complianceTask.Title.IsVisible());
            _compliancePage.DeleteButton.Click();
        }

        [Given(@"the user clicks on Delete button for the Compliance Risk")]
        public void GivenTheUserClicksOnDeleteButtonForTheComplianceRisk()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _complianceRiskDialog = _compliancePage.RiskComponent.Risk;

            _compliancePage.FocusNewWindow();

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();

            Waiter.Until(d => _complianceRiskDialog.Name.IsVisible());
            _compliancePage.DeleteButton.Click();
        }

        [Then(@"the Folder with below '(.*)' should get deleted")]
        [Then(@"the Obligations with below '(.*)' should get deleted")]
        [Then(@"the Task with below '(.*)' should get deleted")]
        [Then(@"the Compliance Risk with below '(.*)' should get deleted")]
        [Then(@"the Control with below '(.*)' should get deleted")]
        [Then(@"the Folder with below '(.*)' should not be displayed")]
        [Then(@"the Obligation with below '(.*)' should not be displayed")]
        [Then(@"the Task with below '(.*)' should not be displayed")]
        [Then(@"the Risk with below '(.*)' should not be displayed")]
        public void ThenTheObligationsWithBelowShouldGetDeleted(string p0, Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage = _compliancePage.GetOpenedComplianceManager();
            _compliancePage.FocusNewWindow();
            _compliancePage.ClearParameters();

            var tree = _compliancePage.Tree;
            tree.AssertNodeDoesNotExist(table.Rows[0].Values.ToList()[0]);
        }
    }
}
