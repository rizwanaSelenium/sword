﻿using System.Linq;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Obligation.Steps
{
    [Binding]
    public class VerifyObligationHistorySteps : SpecFlowRiskDesktopFixture
    {
        public ObligationDialog ObligationPage;
        public ComplianceHistoryModel ComplianceHistory;
        private ComplianceComponent _compliancePage;

        public VerifyObligationHistorySteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Given(@"the user clicks on New Obligation Icon")]
        public void GivenTheUserClicksOnNewObligationIcon()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.AddButton.Click();
            ObligationPage = _compliancePage.GetOpenedObligationPage();

            ScenarioContext.Set(ObligationPage);
        }

        [When(@"the user navigates to History tab")]
        public void WhenTheUserNavigatesToHistoryTab()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.HistoryButton.Click();

            ComplianceHistory = _compliancePage.GetHistoryDialog;
            ScenarioContext.Set(ComplianceHistory);
        }

        [Then(@"the correct (.*),(.*) and (.*) should display")]
        public void ThenTheCorrectAndShouldDisplay(string p0, string p1, string p2, Table table)
        {
            ComplianceHistory = ScenarioContext.Get<ComplianceHistoryModel>();
            var keys = table.Rows.ToList()[0].Keys.ToList();
            var values = table.Rows.ToList()[0].Values.ToList();

            ComplianceHistory.VerifyHistoryData(values[0], keys[0], values[2]);
            ComplianceHistory.VerifyHistoryData(values[1], keys[1], values[2]);
        }
    }
}
