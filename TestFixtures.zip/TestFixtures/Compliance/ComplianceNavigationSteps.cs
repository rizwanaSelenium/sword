﻿using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceFolder;
using PresentationModel.Model.ComplianceRisk;
using PresentationModel.Model.ComplianceControl;
using PresentationModel.Model.ComplianceTask;
using PresentationModel.Model.Obligation;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance
{
    [Binding]
    public class ComplianceNavigationSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;
        private ObligationDialog _obligationPage;
        private ComplianceTaskDialog _complianceTask;
        private ComplianceFolderDialog _complianceFolder;
        private ComplianceRiskComponent _complianceRiskDialog;
        private ComplianceControlDialog _complianceControlDialog;
        private AngularTree _tree;
        private AngularTreeNode _node;

        public ComplianceNavigationSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Given(@"the user selects compliance Business Area with below name")]
        [When(@"the user selects compliance Business Area with below name")]
        public void WhenTheUserSelectsComplianceBusinessAreaWithBelowName(Table table)
        {
            SelectTreeItemPartOne(table);

            SelectTreeItemPartTwo();
        }

        [Then(@"the user verifies following nodes exist")]
        public void ThenTheUserVerifiesFollowingNodesExist(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.FocusWindow();
            _compliancePage.ClearParameters();
            _compliancePage.WaitForComplianceTreeToLoad();

            _tree = _compliancePage.Tree;
            foreach (var fieldValue in table.Rows)
            {
                _tree.AssertNodeExist(fieldValue[0]);
            }
        }

        [Given(@"the user selects the Obligation with below title")]
        [When(@"the user selects the Obligation with below title")]
        public void WhenTheUserSelectsTheObligationWithBelowTitle(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.WaitUntilUiSpinnerIsNotDisplayed();
            Waiter = ScenarioContext.Get<WebDriverWait>();
            
            SelectTreeItemPartOne(table);
            _compliancePage.WaitUntilUiSpinnerIsNotDisplayed();
            _obligationPage = _compliancePage.ObligationPage();
            ScenarioContext.Set(_obligationPage);
            Waiter.Until(d => _obligationPage.Title.IsVisible());
            
            SelectTreeItemPartTwo();
            _compliancePage.WaitUntilUiSpinnerIsNotDisplayed();
        }

        [Given(@"the user selects the Task with below title")]
        [When(@"the user selects the Task with below title")]
        public void WhenTheUserSelectsTheTaskWithBelowTitle(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            SelectTreeItemPartOne(table);

            _complianceTask = _compliancePage.GetTaskdialog;
            ScenarioContext.Set(_complianceTask);

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter.Until(d => _complianceTask.Title.IsVisible());

            SelectTreeItemPartTwo();
        }

        [Given(@"the user selects Compliance Folder with below title")]
        [When(@"the user selects Compliance Folder with below title")]
        [When(@"the user selects the Compliance Folder with below title")]
        public void WhenTheUserSelectsComplianceFolderWithBelowTitle(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            SelectTreeItemPartOne(table);

            _complianceFolder = _compliancePage.GetFolderdialog;
            ScenarioContext.Set(_complianceFolder);

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter.Until(d => _complianceFolder.Title.IsVisible());

            SelectTreeItemPartTwo();
        }

        [Given(@"the user selects the Compliance Risk with below title")]
        [When(@"the user selects the Compliance Risk with below title")]
        public void WhenTheUserSelectsComplianceRiskWithBelowName(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            SelectTreeItemPartOne(table);

            _complianceRiskDialog = _compliancePage.RiskComponent;
            ScenarioContext.Set(_complianceRiskDialog);

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter.Until(d => _complianceRiskDialog.Risk.Name.IsVisible());

            SelectTreeItemPartTwo();
        }

        [Given(@"the user selects the Compliance Control with below title")]
        [When(@"the user selects the Compliance Control with below title")]
        [Then(@"the user selects the Compliance Control with below title")]
        public void WhenTheUserSelectsComplianceControlWithBelowName(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            SelectTreeItemPartOne(table);

            _complianceControlDialog = _compliancePage.GetControlDialog;
            ScenarioContext.Set(_complianceControlDialog);

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter.Until(d => _complianceControlDialog.Title.IsVisible());

            SelectTreeItemPartTwo();
        }

        private void SelectTreeItemPartOne(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.FocusNewWindow();
            _compliancePage.ClearParameters();

            _compliancePage.WaitForComplianceTreeToLoad();
            _tree = _compliancePage.Tree;
            _node = _tree.Node(table.Rows[0].Values.ToList()[0]);
            _node.Click();

            Driver = ScenarioContext.Get<IWebDriver>();
            _compliancePage = _compliancePage.GetOpenedComplianceManager();
            ScenarioContext.Set(_compliancePage);
        }

        private void SelectTreeItemPartTwo()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();

            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter = ScenarioContext.Get<WebDriverWait>();

            _compliancePage = new ComplianceComponent(Driver, Waiter, "compliance");
            ScenarioContext.Set(_compliancePage);
        }
    }
}
