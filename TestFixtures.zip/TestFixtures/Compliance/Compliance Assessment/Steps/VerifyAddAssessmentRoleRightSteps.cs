﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Controls.Angular;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.Desktop;
using PresentationModel.Model.NewAdmin;
using PresentationModel.Model.NewSplashScreen;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Assessment.Steps
{
    [Binding]
    public class VerifyAddAssessmentRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        private WebDriverNewAdminDialog _adminDialog;
        private ComplianceComponent _compliancePage;
        private AngularTree _tree;
        private AngularTreeNode _node;
        private string _recordType;

        public VerifyAddAssessmentRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
        }

        [AfterScenario("RemoveAssessmentRoleRightTeardown")]
        public void AfterScenario()
        {
            try
            {
                var driver = ScenarioContext.Get<IWebDriver>();
                var waiter = ScenarioContext.Get<WebDriverWait>();
                var splashScreen = new NewSplashScreenLogin(driver, waiter);
                splashScreen.ClickSwordLogo();
                splashScreen.WaitUntilUiSpinnerIsNotDisplayed();

                ScenarioContext.Set(splashScreen);
                splashScreen = ScenarioContext.Get<NewSplashScreenLogin>();
                splashScreen.FocusNewWindow();
                splashScreen.ClickOnDesktopIcon();

                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                _adminDialog = Desktop.AdminDialog();
                _adminDialog.FocusWindow();
                ScenarioContext.Set(_adminDialog);

                using (var userRolesConfig = _adminDialog.RoleConfiguration())
                {
                    userRolesConfig.AllowFunctionAndThenSave("Add Assessment");
                }

                _adminDialog.FocusWindow();
                _adminDialog.Close();

                Desktop = ScenarioContext.Get<WebDriverDesktop>();
                Desktop.FocusWindow();
                Desktop.Logout();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Test Teardown failed");
            }
            finally
            {
                TestFixtureTearDown();
            }
        }

        [When(@"the user selects '(.*)' with below '(.*)'")]
        public void WhenTheUserSelectsWithBelow(string recordType, string title)
        {
            _recordType = recordType;

            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.FocusNewWindow();
            _compliancePage.ClearParameters();

            _compliancePage.WaitForComplianceTreeToLoad();
            _tree = _compliancePage.Tree;
            _node = _tree.Node(title);
            _node.Click();
        }

        [Then(@"the new Assessmemt button should be disabled for the user to add Assessment")]
        public void ThenTheNewAssessmemtButtonShouldBeDisabledForTheUserToAddAssessment()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();

            switch (_recordType)
            {
                case "Control":
                case "Obligation":
                    Assert.IsFalse(_compliancePage.IsAssessmentButtonVisible());
                    break;
                default:
                    Assert.Fail("Record type {0} can't have assessment", _recordType);
                    break;
            }
        }
    }
}
