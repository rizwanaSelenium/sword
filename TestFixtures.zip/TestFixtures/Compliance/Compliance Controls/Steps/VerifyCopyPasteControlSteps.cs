﻿using System.Linq;
using NUnit.Framework;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceControl;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Controls.Steps
{
    [Binding]
    public class VerifyCopyPasteControlSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;
        private ComplianceControlDialog _controlDialog;

        public VerifyCopyPasteControlSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
        }

        [When(@"the user clicks the compliance Copy button")]
        public void GivenTheUserClicksTheComplianceCopyButton()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.CopyIcon.Click();
        }

        [When(@"the user clicks the compliance Paste button")]
        public void WhenTheUserClicksTheCompliancePasteButton()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.PasteIcon.Click();
        }

        [Then(@"the id of the copied Control is different from the id of the original Control")]
        public void ThenTheIdOfTheCopiedControlIsDifferentFromTheIdOfTheOriginalControl(Table table)
        {
            _controlDialog = ScenarioContext.Get<ComplianceControlDialog>();

            var originalId = table.Rows[0].Values.ToList()[0];

            _controlDialog.Id.AssertNotEquals(originalId);
        }
    }
}
