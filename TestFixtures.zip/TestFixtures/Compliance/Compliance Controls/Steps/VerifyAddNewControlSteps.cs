﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceControl;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace TestFixtures.Compliance.Compliance_Controls.Steps
{
    [Binding]
    public class VerifyAddNewControlSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;
        private ComplianceControlDialog _controlDialog;

        public VerifyAddNewControlSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
        }

        [Given(@"the user clicks on new Control Icon")]
        public void GivenTheUserClicksOnNewControlIcon()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _compliancePage.AddControlIcon.Click();

            _compliancePage.FocusWindow();
            ScenarioContext.Set(_compliancePage);
            _controlDialog = _compliancePage.GetControlDialog;

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();
            Waiter.Until(d => _controlDialog.Title.IsVisible());
            ScenarioContext.Set(_controlDialog);
        }

        [Given(@"the user enters Compliance Control '(.*)' for following '(.*)'")]
        public void GivenTheUserEntersComplianceControlForFollowing(string details, string fields, Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _controlDialog = _compliancePage.GetControlDialog;
            _compliancePage.FocusWindow();

            var ctrl = table.CreateInstance<ComplianceControlModel>();

            if (ctrl.Id != null)
                _controlDialog.Id.SetValue(ctrl.Id);
            if (ctrl.Title != null)
                _controlDialog.Title.SetValue(ctrl.Title);
            if (ctrl.Created != null)
                _controlDialog.Created.PickDate(ctrl.Created);
            if (ctrl.SourceUpdated != null)
                _controlDialog.SourceUpdated.PickDate(ctrl.SourceUpdated);
            if (ctrl.Due != null)
                _controlDialog.Due.PickDate(ctrl.Due);
            if (ctrl.ApprovalDate != null)
                _controlDialog.ApprovalDate.PickDate(ctrl.ApprovalDate);
            if (ctrl.LastUpdated != null)
                _controlDialog.LastUpdated.PickDate(ctrl.LastUpdated);
            if (ctrl.Archived != null)
            {
                if (ctrl.Archived == "true")
                    _controlDialog.Archived.SetChecked();
                else
                    _controlDialog.Archived.SetUnchecked();
            }
            if (ctrl.Description != null)
                _controlDialog.Description.SetValue(ctrl.Description);
            if (ctrl.MaxText1 != null)
                _controlDialog.MaxText1.SetValue(ctrl.MaxText1);
            if (ctrl.MaxText2 != null)
                _controlDialog.MaxText2.SetValue(ctrl.MaxText2);
            if (ctrl.MaxText3 != null)
                _controlDialog.MaxText3.SetValue(ctrl.MaxText3);
            if (ctrl.MaxText4 != null)
                _controlDialog.MaxText4.SetValue(ctrl.MaxText4);
            if (ctrl.Category != null)
                _controlDialog.Category.SelectByText(ctrl.Category);
            if (ctrl.Owner != null)
            {
                _controlDialog.Owner.Clear();
                _controlDialog.Owner.SelectResource(ctrl.Owner);
            }
            if (ctrl.Approver != null)
            {
                _controlDialog.Approver.Clear();
                _controlDialog.Approver.SelectResource(ctrl.Approver);
            }
            if (ctrl.ComplianceStatus != null)
                _controlDialog.ComplianceStatus.SelectByText(ctrl.ComplianceStatus);
            if (ctrl.ApprovalStatus != null)
                _controlDialog.ApprovalStatus.SelectByText(ctrl.ApprovalStatus);
            if (ctrl.ApplicableAreas != null)
                _controlDialog.ApplicableAreas.SelectItem(ctrl.ApplicableAreas);
            if (ctrl.DesignEffectiveness != null)
                _controlDialog.DesignEffectiveness.SelectByText(ctrl.DesignEffectiveness);
            if (ctrl.OperatingEffectiveness != null)
                _controlDialog.OperatingEffectiveness.SelectByText(ctrl.OperatingEffectiveness);
            if (ctrl.Tree1 != null)
                _controlDialog.Tree1.SelectValues(ctrl.Tree1);
            if (ctrl.Tree2 != null)
                _controlDialog.Tree2.SelectValues(ctrl.Tree2);
            if (ctrl.MultiSelect1 != null)
                _controlDialog.MultiSelect1.SelectItem(ctrl.MultiSelect1);
            if (ctrl.MultiSelect2 != null)
                _controlDialog.MultiSelect2.SelectItem(ctrl.MultiSelect2);
            if (ctrl.MultiSelect3 != null)
                _controlDialog.MultiSelect3.SelectItem(ctrl.MultiSelect3);
            ScenarioContext.Set(_controlDialog);
        }

        [Then(@"the '(.*)' for the following Compliance Control '(.*)' should be displayed correctly")]
        public void ThenTheForTheFollowingComplianceControlShouldBeDisplayedCorrectly(string details, string fields, Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _controlDialog = _compliancePage.GetControlDialog;
            _compliancePage.FocusWindow();

            var ctrl = table.CreateInstance<ComplianceControlModel>();

            if (ctrl.Id != null && ctrl.Id != "@autogenerated")
                _controlDialog.Id.AssertEquals(ctrl.Id);
            if (ctrl.Title != null)
                _controlDialog.Title.AssertEquals(ctrl.Title);
            if (ctrl.Created != null)
                _controlDialog.Created.AssertDateEquals(ctrl.Created);
            if (ctrl.SourceUpdated != null)
                _controlDialog.SourceUpdated.AssertDateEquals(ctrl.SourceUpdated);
            if (ctrl.Due != null)
                _controlDialog.Due.AssertDateEquals(ctrl.Due);
            if (ctrl.ApprovalDate != null)
                _controlDialog.ApprovalDate.AssertDateEquals(ctrl.ApprovalDate);
            if (ctrl.LastUpdated != null)
                _controlDialog.LastUpdated.AssertDateEquals(ctrl.LastUpdated);
            if (ctrl.Archived != null)
            {
                if (ctrl.Archived == "true")
                    _controlDialog.Archived.AssertSelected();
                else
                    _controlDialog.Archived.AssertUnselected();
            }

            if (ctrl.Description != null)
                _controlDialog.Description.AssertEquals(ctrl.Description);
            if (ctrl.MaxText1 != null)
                _controlDialog.MaxText1.AssertEquals(ctrl.MaxText1);
            if (ctrl.MaxText2 != null)
                _controlDialog.MaxText2.AssertEquals(ctrl.MaxText2);
            if (ctrl.MaxText3 != null)
                _controlDialog.MaxText3.AssertEquals(ctrl.MaxText3);
            if (ctrl.MaxText4 != null)
                _controlDialog.MaxText4.AssertEquals(ctrl.MaxText4);
            if (ctrl.Category != null)
                _controlDialog.Category.AssertTextEquals(ctrl.Category);
            if (ctrl.Owner != null)
                _controlDialog.Owner.AssertEquals(ctrl.Owner);
            if (ctrl.Approver != null)
                _controlDialog.Approver.AssertEquals(ctrl.Approver);
            if (ctrl.ComplianceStatus != null)
                _controlDialog.ComplianceStatus.AssertTextEquals(ctrl.ComplianceStatus);
            if (ctrl.ApprovalStatus != null)
                _controlDialog.ApprovalStatus.AssertTextEquals(ctrl.ApprovalStatus);
            if (ctrl.ApplicableAreas != null)
                _controlDialog.ApplicableAreas.DisplayedItem(ctrl.ApplicableAreas);
            if (ctrl.DesignEffectiveness != null)
                _controlDialog.DesignEffectiveness.AssertTextEquals(ctrl.DesignEffectiveness);
            if (ctrl.OperatingEffectiveness != null)
                _controlDialog.OperatingEffectiveness.AssertTextEquals(ctrl.OperatingEffectiveness);
            if (ctrl.Tree1 != null)
                _controlDialog.Tree1.AssertValueIsSelected(ctrl.Tree1);
            if (ctrl.Tree2 != null)
                _controlDialog.Tree2.AssertValueIsSelected(ctrl.Tree2);
            if (ctrl.MultiSelect1 != null)
                _controlDialog.MultiSelect1.AssertMultipleItemsSelected(ctrl.MultiSelect1);
            if (ctrl.MultiSelect2 != null)
                _controlDialog.MultiSelect2.AssertMultipleItemsSelected(ctrl.MultiSelect2);
            if (ctrl.MultiSelect3 != null)
                _controlDialog.MultiSelect3.AssertMultipleItemsSelected(ctrl.MultiSelect3);

            ScenarioContext.Set(_controlDialog);
        }
    }
}
