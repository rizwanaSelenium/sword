﻿using NUnit.Framework;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Controls.Steps
{
    [Binding]
    public class VerifyUpdateControlRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        public VerifyUpdateControlRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Then(@"the user verifies that the following Compliance Control fields are disabled")]
        public void ThenTheUserVerifiesThatTheFollowingComplianceControlFieldsAreDisabled(Table table)
        {
            Assert.Fail("I am not implemented");
        }
    }
}
