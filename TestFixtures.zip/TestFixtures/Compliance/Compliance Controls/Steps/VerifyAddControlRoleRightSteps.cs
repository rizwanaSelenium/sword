﻿using NUnit.Framework;
using PresentationModel.Model.Compliance;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Controls.Steps
{
    [Binding]
    public class VerifyAddControlRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;

        public VerifyAddControlRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {

        }

        [Then(@"the following Buttons should be disabled on the Compliance Control detail screen")]
        public void ThenTheFollowingButtonsShouldBeDisabledOnTheComplianceControlDetailScreen(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            Assert.IsTrue(_compliancePage.AddControlIcon.GetAttribute("disabled").Equals("true"));
            Assert.IsTrue(_compliancePage.CopyIcon.GetAttribute("disabled").Equals("true"));
        }
    }
}
