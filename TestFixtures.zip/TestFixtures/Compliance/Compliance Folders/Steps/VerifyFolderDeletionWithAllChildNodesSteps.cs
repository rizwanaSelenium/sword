﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using PresentationModel.Model.Compliance;
using PresentationModel.Model.ComplianceFolder;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Folders.Steps
{
    [Binding]
    public class VerifyFolderDeletionWithAllChildNodesSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;
        private ComplianceFolderDialog _folderDialog;

        public VerifyFolderDeletionWithAllChildNodesSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
            ScenarioContext = scenarioContext;          
        }

        [Given(@"the user clicks on the Delete icon for the selected compliance folder")]
        [When(@"the user clicks on the Delete icon for the selected compliance folder")]
        public void WhenTheUserClicksOnTheDeleteIconForTheSelectedComplianceFolder()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            _folderDialog = _compliancePage.GetFolderdialog;
            _compliancePage.FocusWindow();

            Waiter = ScenarioContext.Get<WebDriverWait>();
            Driver = ScenarioContext.Get<IWebDriver>();

            Waiter.Until(d => _folderDialog.Title.IsVisible());
            _compliancePage.DeleteButton.Click();
        }
    }
}
