﻿using System;
using NUnit.Framework;
using PresentationModel.Model.Compliance;
using TechTalk.SpecFlow;

namespace TestFixtures.Compliance.Compliance_Folders.Steps
{
    [Binding]
    public class VerifyFolderRoleRightSteps : SpecFlowRiskDesktopFixture
    {
        private ComplianceComponent _compliancePage;

        public VerifyFolderRoleRightSteps(ScenarioContext scenarioContext) : base(scenarioContext)
        {
        }

        [Then(@"the New Folder icon should be disabled for the user to add Folder")]
        public void ThenTheNewFolderIconShouldBeDisabledForTheUserToAddFolder()
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();
            Assert.IsTrue(_compliancePage.AddFolderIcon.GetAttribute("disabled").Equals("true"));
        }

        [Then(@"the following Buttons should be disabled on the Compliance Folder detail screen")]
        public void ThenTheFollowingButtonsShouldBeDisabled(Table table)
        {
            _compliancePage = ScenarioContext.Get<ComplianceComponent>();

            foreach (var row in table.Rows)
            {
                switch (row["Buttons"])
                {
                    case "Delete folder icon":
                        Assert.IsTrue(_compliancePage.DeleteIcon.GetAttribute("disabled").Equals("true"));
                        break;
                    case "Add folder icon":
                        Assert.IsTrue(_compliancePage.AddFolderIcon.GetAttribute("disabled").Equals("true"));
                        break;
                    case "New folder button":
                        Assert.IsTrue(_compliancePage.NewButton.GetAttribute("disabled").Equals("true"));
                        break;
                    case "Save folder button":
                        Assert.IsTrue(_compliancePage.SaveButton.GetAttribute("disabled").Equals("true"));
                        break;
                    default:
                        throw new ArgumentException("Unknown button / icon provided, value passed in: " + row["Buttons"]);
                }
            }
        }
    }
}
